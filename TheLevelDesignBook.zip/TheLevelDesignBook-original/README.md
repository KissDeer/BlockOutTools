# The Level Design Book - local original Markdown

Downloaded from https://book.leveldesignbook.com on 2026-09-09 11:46:43 +08:00.

Pages in sitemap: 94
Downloaded successfully: 94
Failed: 0

Files:
- The-Level-Design-Book-full.md: all downloaded pages concatenated for reading/searching.
- pages/: one Markdown file per original page, preserving the website path.
- llms.txt: complete page index.
- sitemap-pages.xml: source page list.

License: unattributed text is CC BY-NC-SA 4.0. Cited images, screenshots, quotes, videos, and other attributed material may have separate rights.

Original: https://book.leveldesignbook.com/