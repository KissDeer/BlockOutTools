> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages.md).

# (Unfinished WIP pages)

- [Modern Combat](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/modern-combat.md): design exercise for a modern commercial action shooter game
- [Modern Stealth](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/modern-stealth.md): design exercise for a modern stealth game with cover and combat
- [Exercise: Direct Lighting](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/exercise-direct-lighting.md)
- [Exercise: Whiteboard 2D](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/exercise-whiteboard-2d.md)
- [Level Design Portfolio](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/level-design-portfolio.md)
- [Design Test: Adaptation](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/adaptation.md)
- [Exercise: Layout](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/exercise-floorplan.md)
- [Exercise: Verticality](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/verticality.md)
