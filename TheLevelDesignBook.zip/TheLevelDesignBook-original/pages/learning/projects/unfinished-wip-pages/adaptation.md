> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/adaptation.md).

# Design Test: Adaptation

For this design test, you will adapt a real-world building or location into a single player level.&#x20;

Focus on these design considerations:

* Typology: what are the main structural patterns of the real world site, and how can this logic be simplified while still maintaining a strong resemblance?
* Massing: what parts feel light or heavy, thin or thick, strong or delicate, and how do we distil those qualities into a 3D recreation?
* Gameplay: what types of mechanics, encounters, puzzles, and setpieces would work best in this type of place?
* Scope: how much of the location should we seek to adapt, a full exterior with a partial interior, or vice versa?
