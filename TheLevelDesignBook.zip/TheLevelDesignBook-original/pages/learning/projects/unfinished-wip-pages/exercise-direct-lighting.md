> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/exercise-direct-lighting.md).

# Exercise: Direct Lighting

To build up lighting skills, start as simple as possible: ignore all the fancy lighting features of your game engine or renderer, and instead manually hand-place every light source, including any bounce lights or fill lights. This is a labor-intensive "old fashioned" way of lighting a 3D space, but it is a useful exercise to force you to think about what your light is doing. This workflow is also more relevant than you may think; relatively recent games like Fallout 4 feature no precomputed light baking.

Light a simple blockout room with realtime direct lights and hand-placed indirect lighting.&#x20;

If this is your first time thinking about lighting, texture the blockout with grayscale textures and use desaturated grayscale lighting.

If you'd like more of a challenge, use colored prototyping textures and colored lights.

Disable precomputed light baking, use only realtime lights, consult the lighting page on how to setup a fill light
