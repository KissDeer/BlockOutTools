> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/exercise-whiteboard-2d.md).

# Exercise: Whiteboard 2D

Read David Sirlin's collectibles article about Donkey Kong Country

Draw a 2D platformer layout with collectibles

For specific setpieces, markup the outline of the player's screen; what can the player see exactly

Present and talk through the plan
