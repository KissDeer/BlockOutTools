> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/exercise-floorplan.md).

# Exercise: Layout

## Introduction

This is a design exercise for drawing a simple level layout.

Design brief... 5 minute single player level about unlocking a door and leaving, include a good layout and a bad layout

## Planning

Go beyond the brief

Define experience goals

Plot out the major beats for the level

## Research

other levels that do similar things?

practice looking at layout drawings... why did they draw it that way? what does it communicate?

## Layout

Parti

Bubble diagram

Layout
