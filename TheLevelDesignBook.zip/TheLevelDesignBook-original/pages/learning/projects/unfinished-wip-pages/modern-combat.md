> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/modern-combat.md).

# Modern Combat

design exercise for a modern commercial action shooter game

## Introduction

In this project, you'll research, pitch, and prototype a combat encounter for a modern commercial action shooter game, with dynamic squad formations and battle lines.

{% hint style="success" %}
Before continuing, make sure you've read about [Pacing](/process/preproduction/pacing.md), [Balance](/process/combat/balance.md), and [Encounters](/process/combat/encounter.md#encounter).\
We also recommend doing the [Classic Combat](/learning/projects/classic-combat.md) design exercise first.
{% endhint %}

![diagram from "Creating Conflict: Combat Design for AAA Action Games" by Michael Barclay, Sam Howels, Pete Ellis (GDC Europe 2016)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LtX1qT9uxspZe0aRBgD%2F-LtX9S_JeZqVlz5xv8rG%2Fgdc2016_combat_fronts.png?alt=media\&token=0079286c-7ad9-4d5c-a142-fc13d2a47fb5)

## 1. Research

### Review combat in Uncharted 4 (10-60 min)

Ideally, you have played an Uncharted game or some sort of cover shooter action game. **If you have never played any of these games, you should go play one now before continuing.** At the very least, play past the tutorial level and get through a few gun fights, which will likely take at least an hour.

If you are familiar with the genre, then take some time to review how the game plays. **Search for `"Uncharted 4 combat gameplay"` on YouTube and watch at least 10 minutes of game footage.**

While you watch the video, reflect on these questions:

* How do most combat encounters in Uncharted 4 begin? How does the player know when combat has begun? How does the player know where the enemies are?
* How long does the fight last? Does it feel like a small fight or a big fight, and why?
* Are there any "beats" to the combat encounter? What is the pacing and the combat story?
* How do the combat encounters end? How does the player know when it's over? How does the player feel at the end and why? How does the player know what the next activity is?

### Watch this developer talk about Uncharted 4's combat AI (60 min)

{% embed url="<https://www.youtube.com/watch?v=G8W7EQKBgcg>" %}

Next, watch this GDC 2017 talk ["Authored vs Systemic: Finding a Balance for Combat AI in Uncharted 4" by Matthew Gallant](https://www.youtube.com/watch?v=G8W7EQKBgcg) about Uncharted 4's combat AI and encounter design tools. Feel free to take notes, and refer to the [PDF slides](https://www.gdcvault.com/play/1024467/Authored-vs-Systemic-Finding-a) for reference.

Every game manages its combat AI differently, but Uncharted 4's core approach is similar enough to other action games and cover shooters that it represents current industry practice. An encounter designer or combat designer must understand game systems as well as AI tools.

### Research questions (15 min)

* **Analyze** the strengths and limitations of the "zone" approach used in Uncharted 1-3.
* Gallant's team prototyped several new systems for Uncharted 4, but ultimately did not use them. **Analyze** the strengths and limitations of one of these failed approaches.
* Gallant was inspired by Pac-Man's ghost AI while designing Uncharted 4's three (3) main combat roles. Do you remember these roles?
  * Can you recall any older classic game (let's just say, from before 2000) with interesting enemy design? How could you apply that design to a contemporary action shooter like Uncharted?
  * **Design** a fourth combat role for Uncharted 4; what would this enemy type do, and what would distinguish its behavior / abilities from the other three?
* What is one main takeaway that could be applied to many other combat games?

!["Encounter Coordinator" slide from "Authored vs Systemic: Finding a Balance for Combat AI in Uncharted 4" by Matthew Gallant  ](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LtXHu5gZNt05cbv1he5%2F-LtXJhy5lA9utEEjAyMr%2Fgdc2017_uncharted4_encounter-coordinator.png?alt=media\&token=4d2dffe6-dcfd-412d-8134-c550b8d0627a)

## 2. Layout

Now it's time to design your own dynamic combat encounter.

### Sketch an encounter (20 minutes)

Sketch 10+ thumbnail [parti](/process/layout.md#parti) diagrams within 1-2 minutes. Don't overthink it, just draw any shapes that might symbolize how the encounter would play out.

Then, sketch a [layout](/process/layout.md) of a small combat encounter for an Uncharted-like action game. But do NOT try to sketch something as big and complicated as in Uncharted 4! Clarity is more important than ambition. Keep it small. The encounter should last 2-3 minutes for the player.

* Define 1 [player experience goal](/process/preproduction.md#experience-goal) for the encounter. What kind of combat or tactics will your encounter emphasize?
* Design at least 1 [setpiece](/process/preproduction.md#setpiece) and at least 2 [pacing](/process/preproduction.md#pacing) beats.
* Label core elements like player and enemy spawns, items, cover, and crucial [sightlines](/process/combat/encounter.md#sightline), as well as hard points / zones.

(TODO: show some encounter sketch samples)

### Pitch your encounter (5 minutes)

Pitch your design to someone else, and have them use the rubric below to judge your pitch. For example. they might say your experience goal felt memorable, but doesn't really support any clear paths or strategies, and too many questions remain unanswered.

In your pitch, make sure you narrate different ways how the combat encounter would likely play out, while summarizing your intent and the player experience. Good luck!

### Encounter pitch evaluation rubric

| Evaluation      | Experience goal         | Supported play styles          | Clarity of plan         |
| --------------- | ----------------------- | ------------------------------ | ----------------------- |
| :smile:         | Memorable, cohesive     | Multiple robust strategies     | Can visualize it all    |
| :slight\_smile: | Typical, predictable    | One ideal path with side paths | Need to clarify details |
| :confused:      | Confusing, incompatible | No clear path or strategy      | Too many questions      |

## 3. Blockout

Try to implement your design plan within an actual game.

### Play a game with combat (2 hours)

Play a [moddable game](/appendix/tools.md#moddable-games-with-level-editor-tools-recommended), ideally a game with a "semi-dynamic" or "dynamic" combat setup.&#x20;

TODO: identify a game that can actually support this exercise... lol

* Pay attention to how the game plays / how the game sets up its combat encounters.&#x20;
* What are the various enemy types and roles?

### Prototype your encounter in the game (xx hours)

Open the level editor and build a level with a dynamic combat encounter.

You don't have to follow your plan from the Layout phase exactly, but use your sketch as a general guide while you blockout and prototype.

Playtest your encounter / share it with others
