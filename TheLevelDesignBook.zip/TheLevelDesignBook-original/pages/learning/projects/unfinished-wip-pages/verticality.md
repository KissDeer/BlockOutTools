> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/verticality.md).

# Exercise: Verticality

vertical massing, height, "z-levels", floors

Of course, it is difficult to plan in the vertical dimension with a top-down layout drawing. That's why architects draw elevations and sections to depict the vertical profile of a building. But for level design planning purposes, that is too much detail. Think more abstract.

(layout with verticality)

* Group your areas into major ground planes / elevations, and shade it like a heightmap: darker areas are lower, while lighter areas are higher.&#x20;
* Omit any minor height changes or shallow terrain sloping.&#x20;
* Reserve enough space for ramps, stairs, and any approaches or landings.

If your map consists of overlapping floors over floors, draw the floors separately and label the transitions between floors. But for structures with trivial ground floors, like a watchtower, then you can simply omit it. Draw what will best communicate the core ideas of the level.
