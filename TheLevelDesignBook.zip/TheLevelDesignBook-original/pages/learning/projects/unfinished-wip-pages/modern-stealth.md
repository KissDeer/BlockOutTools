> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/modern-stealth.md).

# Modern Stealth

design exercise for a modern stealth game with cover and combat

## Introduction

In this project, you'll research, pitch, and prototype a combat encounter for a modern commercial stealth action game, with cover systems and combat fallbacks.&#x20;

{% hint style="success" %}
Before continuing, make sure you've read about [Pacing](/process/preproduction.md#pacing), [Balance](/process/combat/balance.md), and [Encounters](/process/combat/encounter.md#encounter).\
We also recommend doing the [Classic Combat](/learning/projects/classic-combat.md) design exercise first.
{% endhint %}

## 1. Research

### Review stealth in Splinter Cell: Blacklist (10-60 min)

Ideally, you've played a recent stealth action game already. **If you have never played any of these games, you should go play one now before continuing.** At the very least, play past the tutorial level and the first mission, which will likely take at least an hour.

If you are already familiar with the genre, then take some time to review how the game plays. **Search for `"splinter cell blacklist gameplay"` on YouTube and watch at least 10 minutes of game footage.**

While you watch the video, reflect on these questions:

* How do most stealth encounters in Blacklist begin? How does the player track enemy movement?
* How long does the stealth encounter last? Does it feel like a small sneak or a big sneak, and why?
* Are there any "beats" to the stealth encounter? What is the pacing and the fantasy?
* How do the stealth encounters end? How does the player know when it's over? How does the player feel at the end and why? How does the player know what the next activity is?

### Watch this developer talk about Splinter Cell: Blacklist's AI (30 min)

{% embed url="<https://www.youtube.com/watch?v=RFWrKHM0vAg>" %}

Next, watch this GDC 2014 talk ["Modeling AI Perception and Awareness in Splinter Cell: Blacklist" by Martin Walsh](https://www.youtube.com/watch?v=RFWrKHM0vAg) about Splinter Cell's stealth AI and encounter design tools. Feel free to take notes, and refer to the [PDF slides](https://www.gdcvault.com/play/1024467/Authored-vs-Systemic-Finding-a) for reference.

Every game manages its stealth AI differently, but Splinter Cell's core approach is similar enough to other stealth action games that it represents current industry practice. An encounter designer must understand game systems as well as AI tools.

### Research questions (15 min)

* **Contrast** combat AI design vs. stealth AI design. What is the purpose of a "good" stealth AI? What type of experience should it push? What information does it track, and what information does it broadcast to the player?
* Walsh uses "perception" and "awareness" interchangeably. Why? What is the difference, if any, between these two concepts?
*
