> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/level-design-portfolio.md).

# Level Design Portfolio

## complete some of the projects in the Projects category

## find a web host

if you can afford it, register your own domain

don't use wix... a free wordpress is probably better

if your portfolio is visually oriented, just make an artstation

## flatten the web template

say what you are at the top

remove all the crap from the web template, delete everything except the home page

## create project pages

don't write too much

include 3-5 screenshots and a short video, and links to external websites and reviews

## test on mobile

imagine you're a bored manager scrolling through your e-mails

## (optional) get a twitter, use it at least once a week

show that you are following industry discourse and industry figures

helps you pretend you know people, helps you memorize names

## upload a CV

1 page at most, less text is almost always better

include your name, portfolio URL, and desired dev role

don't put your GPA or your minor, but list any big awards, grants, scholarships

don't pad your "skills and interests" section, imagine reading 40 of these and it won't seem as cute

omit your home address or phone number, you're putting this on the internet

include a PDF in case they want to save and download it, etc

your CV has two functions: (1) list your work experience and qualifications, and (2) give your interviewer stuff to ask you about... don't bore them

## update your portfolio regularly

after every project / before you apply

## example level design portfolios

* Anthony Panecasio: <https://www.panecasio.com/>
* Magnar Jenssen: <http://magnarj.net/>
