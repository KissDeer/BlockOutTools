> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/learning/notes.md).

# Notes for educators

Advice for teachers using this book in the classroom

{% hint style="warning" %}
**This book is still under heavy construction.** Page content may change a lot / randomly be complete or incomplete. You may want to use this book more to prep a lecture / discussion, vs. assigning readings.
{% endhint %}

## Teaching goals

This online book is intended as a free high quality resource for teaching level design.&#x20;

We try to use industry-specific terminology as used by working level designers, but we always try to define these concepts with simple plain straightforward language. When the game industry terminology is just really weak or undeveloped, we make a note of it, and usually emphasize a more robust concept from architecture or neighboring design fields instead.

* demonstrate what conventional 3D level design practice looks like
* unpack "design" in a broad conceptual sense with many contexts, avoid one-size-fits-all tips that make big assumptions, try to keep some nuance
* unpack "development" as a creative problem solving process that takes time, benefits from planning, has ups and downs
* emphasize a functional playtested level instead of beautiful environment art

### Audience

**We write for a late high school / undergraduate university** reading level, and assume a "serious" long term study of design and development. There are occasional curse words and Western cultural allusions. Our target tone is "cool professor." It is probably too much for early teens / summer camp format.

### Tools

Note that this book emphasizes theory and process. **As the instructor, you will have to provide the technical instruction for your students.** We have Opinions about the best [Tools](/appendix/tools.md) to teach:

* To teach ***level design as an industry specialization**,* then use **Quake** or **Doom**.
  * students won't have to re-invent player controllers, combat, AI, graphics etc.
  * Quake and Doom force a focus on encounter design and step-back from environment art, students' most common weakness today
  * Quake and Doom communities maintain solid free open source MacOS-compatible tools
  * if you want to mod something newer, see suggestions on the [Tools](/appendix/tools.md) page
* To teach ***level design workflows*** as part of a generalist game dev education, then you can probably get by with **Unity / Unreal / Godot**.
  * modern game engines are much more user-friendly than retro shooter engines
  * great for students who don't aim to become AAA combat designers
  * walking sim style projects are a doable weekend intro to general 3D world building; for a sample workshop format, see KO-OP's ["How To Make Cool Stuff in Unity"](https://workshops.ko-opmode.com/)
  * but students will have to prototype their own mechanics, which may leave very little time for actual level design

## How to teach with this book

### Process

Each [**Process**](/process/overview.md) page should be enough for a 60 minute lecture and discussion once a week.&#x20;

Pair each lecture with a group "let's play" / play a game together as a class, to apply the lecture concepts to an actual level.

Sample breakdown for a 15 week level design course, focused on finishing one long term project:

* [**Pre-production**](/process/preproduction.md)**: 1 week**. Emphasize setting experience design goals / articulating design constraints.
  * Concepts like [pacing](/process/preproduction/pacing.md) and [research](/process/preproduction/research.md) will usually feel too abstract until students have completed a few projects first. Don't assign too many planning tasks until maybe a final project.
* [**Layout**](/process/layout.md)**: 2 weeks**. No one can visualize flow in a floor plan without practice, visual communication is obviously a skill that needs to be developed over time. But layouts are still a key part of level design thinking and practice. So for a big final project spend at least two weeks to require at least two passes of iterations on the layout, and have students practice presenting their layouts to their peers.
* [**Blockout**](/process/blockout.md) **/** [**Scripting**](/process/scripting.md)**: 5+ weeks.** Learning how to use a 3D tool will take at least 2 weeks, if not much longer. Spend 1+ weeks on 3D modeling and constructing common shapes, e.g. ramps, stairs, doorways.&#x20;
  * Every 2 weeks, do a class [playtest](/process/blockout/playtesting.md) while also connecting back to key theory concepts.&#x20;
  * A solid blockout with 2-3 playtested iterations is a good target for a midterm project.
  * After the first two weeks focus on 3D construction, gradually ease non-programmers into visual scripting. Spend three weeks teaching triggers / collectibles, interactable buttons, and then [doors](/process/scripting/doors.md).
* **Production: 5+ weeks**. We usually spend the second half of the semester finishing the midterm blockouts into more finished levels. This focus will depend on your class / students' focus:&#x20;
  * For a AAA design focus, do more playtesting and [encounter design](/process/combat/encounter.md)
  * For a technical audience, do more [scripting](/process/scripting.md) and [optimization](/process/env-art/optimization.md)
  * For generalist and/or artist-heavy cohorts, talk more about [env art](/process/env-art.md) and [lighting](/process/lighting.md)
* **Presentations and demos: 1-2 weeks.** Many students loathe presentations, but it sets expectations for how workplaces operate: meetings with peers and supervisors.
  * This is also a good time for [reflective practice](https://en.wikipedia.org/wiki/Reflective_practice) -- students should document and compare each iteration, from layout to blockout to art pass.&#x20;

### Culture / Studies

[**Culture**](/culture/overview.md) articles provide useful background and historical context. [**Studies**](/studies/overview.md) are best accompanied by group live plays and/or students playing the actual level in question, before reading and debating the design analysis as presented in this book.&#x20;

These two sections complement each other. The average teen has played very few games from before they were born. But you can't quite understand the [history of the level designer](/culture/history-level-designer.md) without having played Doom, Quake, Half-Life, or Unreal Tournament..&#x20;

An industrial level design theory class could challenge students to present their own critical site studies. An academic research writing class could task students with writing their own design histories. What is the history of the walking simulator, the explosive barrel, or of trees in video games? *(example:* [*Stephen Murphy's "Frogs in Videogames."*](http://harmonyzone.org/frog.html)*)*&#x20;

## In-class activities

The [**Projects**](/learning/projects.md) section has ready-made project ideas and in-class lab activities for you to use. Discussion and evaluation phases are built into each assignment, along with suggested time lengths for each phase.

**Show instructions on the board or provide a paper printout.** If you just link students to the projects page on this website, then they will likely get distracted or lose the browser tab.

## How to run a critique

1. Student gives short informal presentation of their project, summarize intent and method
2. Instructor + fellow students give reactions and feedback

"Crits" can be constructive and enlightening, or humiliating and pointless. Instructors must model what good critique looks like -- specific and open-minded, pushing questions rather than cruel opinions. Before any crit session, discuss with students what makes for helpful feedback:

* **Describe specific core strengths**
  * unhelpful feedback: *"This level looks fun."*
  * more helpful: *"This level's fantasy about demolishing a student loan office really appealed to me."*
* **Describe specific problems that weaken those core strengths**
  * unhelpful: *"The level felt broken and bad, which is less fun."*
  * more helpful: *"The level is about canceling all student loan debt, but I had trouble understanding when or how the debt cancellation happened. Which parts of the level show the debt being destroyed? Did I miss those parts?..."*&#x20;
* **Use first person "i statements", refer to your specific reaction and play session**
  * unhelpful: *"No one will know where to go in the level."*
  * more helpful: *"**I** didn't know where to go in the level... **I** thought the debt monster would be in the basement, but instead I found it in the CEO bathroom..." (why?)*
* **Avoid second person "you statements", avoid accusing / attacking**
  * unhelpful: *"You made a confusing level, instead you should do (this) and (that)."*
  * more helpful: *"The level confused me. Maybe it could do (this) or (that)."*

![example classroom pinup from Pratt Graduate School of Architecture, photo by Sarah Le Clerc under CC-BY-ND license](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FUZYFaPCUFEvOrKvMlMSe%2FLDB_PinupPhoto_SarahLeClerc_PrattArchitecture.jpg?alt=media\&token=4d449dba-77c8-41e5-9257-5d87ba76dba9)

### Pin-ups

In architecture education, a **pin-up** is a critique where a student pins their architectural drawings to a wall and "critics" (instructors, guests, students) talk with the designer about their reasoning.

**Example of a quick weekly pin-up design exercise:**&#x20;

* prompt with a theme, design constraint, or genre *(example: "prison break")*
* individually, sketch small simple map [layout](/process/layout.md) on paper (5-15 minutes)
  * shorter times discourage detailed drawings and overly complicated concepts
* in groups of 4, pin-up drawings and present, with 3-5 minutes of discussion after each
  * at best, a pin-up leaves the student more excited about evolving their design

## General advice for teaching level design

This book was written by practicing level designers and academics, so we have a few words of advice on "best practices" for teaching level design.

### Focus

What type of level design will you teach? Most level design courses must focus on either visual space planning aspects as a generalist architecture approach, or on designing challenges and puzzles with frequent playtesting and iteration.&#x20;

For a generalist survey class, structure your class into different "units" where you focus on specific methods from month to month. Then for a final project, allow students to specialize in whichever unit(s) they preferred, to explore those topics more deeply on their own or in groups.&#x20;

### Communication

Design can happen on a whiteboard, on paper, in conversation, or in presentations. In a large commercial studio, lead game designers often do very little hands-on work in a editor tool.

In games education and STEM-related programs, students often neglect their underdeveloped "soft" skills and fundamentals. But it's impossible to be a good designer if you can't communicate. When students neglect soft skills, their career will collapse as soon as they have to talk to someone.

### Process

Plans rarely survive intact. Ask students, do you think your level meets your design goals? Is there a better way to accomplish that? Do you want to adjust your design goals? What will you do differently on the next project? Emphasize development as an ongoing process where mistakes and problems will definitely happen.

### Shared tools

Make every students use the same tools *at first,* before giving them the choice to branch out.&#x20;

So much of level design requires developing a shared design language, and if you fragment your students' reference points, it will be more difficult for them to draw those connections and comparisons.

### Shared social

Use internal classroom social media channels for sharing work and progress. If you have a class Slack or Discord, create a channel called "#screenshots" and task students to submit a screenshot every week as part of their homework. Students need to see each others' work so they can learn from each other.

### Careers

Some students seek a future career in level design. However, the game industry usually has low demand for junior level designers for prestige AAA 3D action games. Instead, encourage students to follow smaller studios and indie teams, which may not carry blockbuster prestige, but still offer mentorship and growth.

## Further reading

* ["Reorientating Level Design Education" (2020) by Alexander Muscat, RMIT](https://www.youtube.com/watch?v=qc2HQtK1bTU). A short talk about core problems in teaching level design, and Muscat's approach to a level design curriculum for typical students in a game design university course -- generalist designer-developers who have varied experience and interest in game engines and level design.
* [List of recommended level design related books](/appendix/resources/books.md).
