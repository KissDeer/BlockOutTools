> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/learning/projects.md).

# Project plans

On this page, we list various level design project plans / assignments. These are useful for teachers to plan lessons, but also useful for anyone seeking to learn and practice level design by themselves too.

{% hint style="warning" %}
Currently, our focus is on finishing [**Book 1, Process**](/process/overview.md). So this section is a little neglected.
{% endhint %}

However, we do have some almost-finished project plans to give you a sense of what we're going for:

* [**Classic Combat**](/learning/projects/classic-combat.md), make (and think about) Doom / Quake level design with classic arcade-style shooter combat.
