> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/process/layout/flow/verticality.md).

# Verticality

vertical flow, how it feels to move upwards and downwards in a level

**Verticality** is vertical flow, how it feels to move upwards and downwards.&#x20;

Imagine steadily climbing up a cliff or descending deep into a dark dungeon. These height changes embody the player's progression, and help orient the player towards their goals. A quest might tell the player to travel north, but that goal is impossible if they can't tell where north is. Instead, if the quest tasks the player with climbing to the top of a mountain, or descending down to the bottom of a valley -- up and down are much more obvious and unmistakable.

## Verticality mechanics

When discussing verticality, we assume we're designing for a typical 3D action game with two common physics constraints:

1. gravity pulls the player downward
2. the player camera rarely "rolls", sky and horizon are always upright

If you change any of these assumptions, then "up" is no longer upward, and thus the player's sense of verticality will be different. For example, verticality in Super Mario Galaxy is very different from verticality in Dark Souls.

(TODO: image compare verticality in Super Mario Galaxy vs other game)

### Too much verticality?

Many competitive multiplayer shooters and arena-based games require careful limited use of verticality.

(TODO: rollerdrome tweet)

For example, in Counter-Strike, competitive players tune their mouse sensitivity very low because precision matters more than reaction. Subsequently, constant height changes will frustrate their aim, so most CS levels are relatively flat.&#x20;

That said, CS features a stacking / boosting mechanic where teammates can jump on top of each other to see over obstacles or reach otherwise inaccessible places, thus rewarding team planning and coordination. Vertical flow can be situational and strategic.

![an absurd example of players stacking and boosting each other in Counter-Strike 1.5, from GDC 2015: Community Level Design for Competitive CS:GO](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MR8YB_azJ6oSOLXsNSs%2F-MR8ZtIstuCnj97qH77P%2FLDB_CSGO_StackingBoosting_GDC2015.jpg?alt=media\&token=d1a71717-a9a5-4897-a9df-aa4f6781e13f)

## Floor planes

When planning the verticality in a level, try to chunk it together into **floor planes** and merge minor height changes into a single floor. Don't try to hold 10 different distinct overlapping layers of floorplans in your mind, because players probably won't be able to process that much complexity either.&#x20;

Most maps tend to max-out at three different floor planes for any given area. Why three? Much like three lane typology, three plane format consists of a bottom, middle, and top layer. Comparatively, a fourth (p)lane doesn't add new dynamics, because it would simply yet add another middle layer or path.

{% hint style="info" %}
*Some older level designers called these "Z-levels" because in 3DS Max, Doom, Quake, and Unreal, the Z-axis was upward. But today, many engines and tools use the Y-axis up, not to mention graphics programmers use Z for camera depth, so... let's not.*
{% endhint %}

(image demonstrating floor planes)

## Downward flow

With gravity, it is easier to drop down than to climb up. Downward flow is heavier than upward flow.

The most common use of downward flow in level design is the one-way drop. When the player drops down from a ledge, they cannot backtrack and have no choice but to move forward.&#x20;

Puzzle exploration games use this technique to limit how much space the player must consider at a time, it's a way of saying "everything before this drop is irrelevant to the next challenge." Shooters rely on this pattern heavily to force the player into a combat [encounter](/process/combat/encounter.md), or else the player can simply backtrack to pull enemies back through a chokepoint.

(image showing one way drop)

## Upward flow

To push against gravity and create more upward flow, you'll have to work hard to create more opportunities to go upwards. Stairs, ramps, and ladders are all common tools to facilitate verticality, but require you to reserve enough space to accommodate them. (Elevators are less common due to their [scripting](/process/scripting.md) complexity, especially for multi-floor elevators.)

The Quake 3 Arena (1999) multiplayer space floater map Q3DM17 "The Longest Yard" famously used a dozen jump pads and teleporters to create strong upward flow. Because there is very little cover and limited floor area, players must dodge gunfire by flying through the air, while being careful not to fall to their deaths. The designer Brandon James [balanced](/process/combat/balance.md) the verticality with the far platform pictured in the lower-right; here, snipers can easily dodge incoming rockets while sniping all the players taking predictable flight arcs.

![diagram of jump pad and teleporter trajectories in Q3DM17 "The Longest Yard" by Brandon James for Quake 3 Arena (1999)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M0LFFpYhA9pRoTbeeA_%2F-M0LYunLb3nF9nAK8RAW%2Fldb_q3dm17_verticality.png?alt=media\&token=740db590-357f-4be3-a314-50156a3d4d20)

## Verticality for console shooters

Shooter games on consoles face unique level design challenges relating to input. Because console gamers use gamepads with analog sticks, the fixed turning rate from the analog stick makes it much more difficult to rapidly turn and track targets. In contrast, a mouse offers much more acceleration and precision. But we're not here to litigate a gamer spat over which input is better -- we're just here to say, if you anticipate your level will have a gamepad-using audience, then you must design accordingly.

For single player levels, that means spawning enemies behind the player ("backspawning") feels extra unfair because the player won't be able to turn around 180 degrees very quickly, and also flying enemy AI must maintain moderate distance and remain at a stable height.

For multiplayer console shooters like Halo or Call of Duty, players often park their camera's vertical rotation aimed at roughly head / chest height, and restrict their aiming movements to the horizontal axis. Levels for these games rarely incorporate very tall height changes, if ever, because it is so taxing and disadvantageous to force players to look very high or very low.

This type of shooter gamepad input only feels good if the level design supports it: lots of wide open landscapes with shallow slopes, and discrete floor planes that remain relatively flat. The left example below has high frequency height variation which will frustrate gamepad users, while the right example uses smoother slopes and flatter floor planes.

(TODO: image)
