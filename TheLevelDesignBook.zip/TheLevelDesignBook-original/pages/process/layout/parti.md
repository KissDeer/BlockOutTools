> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/process/layout/parti.md).

# Parti

the core idea / concept of a layout

In architecture, the **parti** is the central idea / concept of a project. Can you reduce the building down to its most important structural aspects in 1 sentence?

Similarly, level design benefits from defining a central core idea that anchors the rest of the design. If you're able to pitch your level with a clear parti statement or sketch, then your collaborators (or even the player) will understand your intent better.

### Parti in architecture

![plan, section, and photo of Price Tower, designed by Frank Lloyd Wright (images from https://es.wikiarquitectura.com/edificio/torre-price/)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MgspaaGysdgZGFw9dKO%2F-MgsqGph_sf0v7812P0U%2FLDB_PartiPlanSection_PriceTower_FrankLloydWright.jpg?alt=media\&token=40f624d6-7f30-42bf-99b4-e0f9ead27af7)

Price Tower, "The Tree that Escaped the Crowded Forest"

section: central "trunk" core (elevators) that "branch" out for each floor

plan: a square with a cross in the middle
