> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/process/preproduction/research.md).

# Research

How to study, analyze, and breakdown other levels / real world reference

## Why do research?

Your level does not exist by itself. Your level exists within a community of other people making levels, within a history of people making levels before (and after) you. Look at how others tackled design problems, and learn from their successes and failures.

Research also helps you get started with your project. Instead of staring at a blank page, you will have a collection of inspirations and influences to help you design your level.

To understand a level design problem better, do some research. Collect **references** of other levels and real-world structures, then **breakdown** a specific reference to go deeper into detail and study its construction. To pick out more general patterns, assemble a **moodboard** composed of many reference images all at once.

{% hint style="info" %}
To collect references, compose breakdowns, and assemble moodboards, you'll need to use a 2D art tool like Photoshop. See the [list of 2D art tools](/appendix/tools.md#2d-art-tools).
{% endhint %}

## Reference

To draw people, look at a lot of people; to paint landscapes, look at a lot of landscapes. No one has a perfect understanding of anatomy, light, or shape, without research.&#x20;

Level design and architecture are no different. Study different places (both virtual and physical) and those **references** will lead you to build new places.&#x20;

Reference helps you build contrast:

* To make something new, learn what has already been done before, and then break it.
* To make something feel weird, establish a sense of normalcy first, and then break it.

### Real world reference

If realism and plausible *sense-of-place* are important to your project, then do research before  [layout](/process/layout.md) or [blockout](/process/blockout.md).

To research a real world location:

* Visit the place physically in-person (when there isn't a worldwide pandemic)
* Visit the place "virtually" via Google Street View
* For famous buildings and monuments, search for blueprints and plans in government / architectural archives, or even 3D scans on [SketchFab](https://sketchfab.com/)

From there, perform a **study**: a prototype that will never appear in the game. Sketch the layout or make a blockout, with attention to accuracy rather than gameplay. **Observe the place as it is, rather than what you imagine it is.**

This type of recreation exercise goes beyond mere observation, and forces you to answer questions about construction and flow that you never would've asked yourself before.&#x20;

You won't use this layout or blockout, but afterwards it will improve your actual layout or blockout.

![recreating an authentic British village in Untitled Goose Game; from "Google Maps, Not Greyboxes: Digital Location Scouting for Untitled Goose Game" for GDC 2021 by Jake Strasser (via YouTube)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MfLsKyINncktC6XXWyL%2F-MfLuP5Mv9pSLTjvrSer%2FLDB_UntitledGooseGame_ResearchReference_GDC2021_Jake.jpg?alt=media\&token=64c39822-fc00-4745-a874-c12bf24aa08a)

### In-game reference

Imagine building a level with a tunnel / underpass. Research could involve studying other games and levels with similar structural features. What will make it work?

So you may want to search for famous maps with prominent tunnels and underpasses, like de\_dust.

Fortunately, [the creator of de\_dust Dave Johnston wrote about ](https://www.johnsto.co.uk/design/making-dust/)designing the underpass:

> *My past mapping experience was mostly creating tight interiors rather than not vast exteriors, and so I was feeling very lost. Desperate, I shoe-horned a bend in the road leading to a downward slope, and at the end of it - an underground cavern.*&#x20;
>
> *It didn’t work, of course. While the CT spawn area was light and airy, this giant room was gloomy, boxy and felt dead compared to the sunny exterior I’d already made. Observing it also lacked any gameplay potential, I swiftly deleted it. Dust would be an outdoor map.*
>
> *\[...] The shallow decline into the underpass is perhaps one of my favourite aspects, both aesthetically and as a player who spent many hours armed with a Steyr Scout at the crest popping off opponents’ heads.*

![underpass in de\_dust by Dave Johnston for Counter-Strike 1.6](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lu58xf7oEP7GGmBzX1_%2F-Lu59-ymdYcYVhp24tQN%2Fresearch_dust_underpass.jpg?alt=media\&token=0a598225-b30d-46fa-8e67-f8c65e07a62a)

Johnston's commentary offers some tips for building an underpass: avoid building something gloomy, cavernous, and dead. Compare that first attempt to a long, sunny, shallow ramp leading downward into an interior tunnel with low clearance. This [balance](/process/combat/balance.md) results in a risky sniper alley with subtle verticality and long sightlines.

However, the point is not to study de\_dust. Pay attention to this research process:

1. I wanted to know more about the de\_dust underpass
2. I googled `"de_dust underpass"`
3. I read the designer's commentary and why he designed the underpass
4. As a result, I'm now paying attention to new aspects that I didn't notice before

#### Other ways of studying a reference

* Play the level and analyze it yourself, take notes or make sketches
* Search websites, fan forums, guides, and wikis to see what others said about it
* Search for gameplay video on YouTube or Twitch, watch what the player does
* Ask someone else what they think or notice about its design

## Breakdown

To study a reference further, **breakdown** its component parts and examine its construction. Environment artists often breakdown their work into smaller parts to demonstrate its proportions and structural patterns.

The most direct way to breakdown a level is to open it in a level editor or some sort of 3D viewer, and fly around in it and study it.&#x20;

{% hint style="warning" %}
Sometimes you can decompile the map file or download ripped map geometry like at [Models Resource](https://www.models-resource.com/) or at [noclip.website](https://noclip.website/). Do this only for personal educational purposes, and do not redistribute it or reuse this work as your own.
{% endhint %}

But when you don't have access to the map source file or the map geometry, which is *most of the time,* then breakdown some photos or a screenshots with a **paintover**.

Import the screenshot(s) into Photoshop / your 2D art tool of choice (see [list of 2D art tools](/appendix/tools.md#2d-art-tools)) and highlight the main lines, shapes, and objects. Markup any repetition or patterns with the same color, with attention to tiered stacks or symmetry.

In the Brooklyn Bridge paintover below, notice how the top half has two pointed Gothic-style archways, with strong trim segmenting each vertical division along its height; the rest of the structure is some boxy beige brick forms. There's also clear left-right symmetry, which means we could save time by building one side of the tower and then copy-pasting / duplicating to the other side. If we're studying a real world reference, we can also look for schematics and plans to better understand shapes and proportions.

![example paintover breakdown of a Brooklyn Bridge tower, with color blocks highlighting symmetry and repetition](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M0Dzmo6OD1HqV78NCI6%2F-M0ESbljJwzAWy2isJV3%2FLDB_BrooklynBridge_Breakdown.jpg?alt=media\&token=4bdffe54-b07c-4132-9e91-1ce99a838799)

![example concept art breakdown by Lea Kronenberger; concept art by Chong Fei Giap (via Beyond Extent)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MHHcoN6AjFvv7uizacp%2F-MHHcxwTskIsIfPxaQkC%2FLeaKronenberger_ReferenceBreakdown.jpg?alt=media\&token=4d62d9df-18d2-432b-a8ef-cb1cd1842f05)

## Moodboard

When a deep breakdown doesn't help or when you have a lot of different references, it's more useful to study them together as a collection. A **moodboard** is composed of many references and images that all convey similar subjects, experiences, or feelings. Grab photos, movie stills, game screenshots, illustrations, concept art, whatever! When you study them all together as a whole, you'll tease out common patterns or trends.&#x20;

Moodboards are essential for pinpointing otherwise vague experience goals. Let's say you want to make a level that is scary. Well, what do you mean by "scary"? Did you mean an unsettling type of fear that something is just slightly "off", or maybe you meant grotesque monstrous zombies. But then what kind of zombies, the slow confident shambler or the unhinged running horror?

When you collect references and compare them, you will discover you actually have a more specific idea of your desired experience. Moodboards help you explain your intent to yourself as well as any collaborators and teammates, who might have different takes or perceptions too.

![example moodboard (screenshots from Hitman), blockout, and art pass for an "Italian Villa" project by Stavaas (via Polycount)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M0Dzmo6OD1HqV78NCI6%2F-M0EgvDIl_k_t8JJgNkF%2FMoodboardExample_ItalianVilla_Stavaas.jpg?alt=media\&token=a08150a3-52e7-4e18-8050-0c0f2d90cd21)

## To review\...

**Research** helps you plan and build your level.

* To do research, gather a bunch of **reference** material.
  * To analyze the reference closely, make a **study** -- a mini recreation / copy, with attention to accuracy and observation
* Study a specific reference in detail with a **breakdown**, a visual analysis
  * **Paintover** the reference image, add **labels** and notes
* Look for patterns in a **moodboard** made of many references.

## Now what?

* Use research to inform the [**layout**](/process/layout.md) and [**blockout**](/process/blockout.md).
