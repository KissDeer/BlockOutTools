> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/process/scripting/nav.md).

# (stub) Navigation

different ways that NPCs and AI can move and path around levels

{% hint style="info" %}
this is a stub, very unfinished obviously
{% endhint %}

## What is navigation?

Steering vs pathfinding

## Steering

Obstacle avoidance

Flocking

Formations

## Pathfinding

basics of A star

### Node graph

but also AI hinting, cover

### Navmesh

## How to prep navigation for a level

Debug tools (show destination, add AI follow debug)

recast or grid, vs manual markup

basic combat AI considerations
