> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/process/release.md).

# Release

How to document and distribute a level

Once you have prototyped, playtested, and polished your level, you should probably **release** it publicly.

You don't have to finish a project 100% to release it. You can release an alpha / beta version, or even just a short demo. Don't wait until something is completely perfect, because chances are, nothing will ever seem perfect enough. Plenty of designers and developers release unfinished projects -- some people even sell it, and their players love it!

On this page, we'll cover general best practices and norms for publicly presenting a custom level, map pack, mod, or standalone project.

## How to document a level

To show your project to others, here is the minimum you need:

* **3+ in-game screenshots** of **main areas** (no random hallways or closets)
  * at least 1920x1080 resolution
  * high quality .JPG (\~80%+ quality)
  * if possible, disable the HUD / UI elements and enemy AI
  * don't photograph a pretty wall or prop; instead your goal is to give an overall impression of the overall [layout](/process/layout.md), [flow](/process/layout/flow.md), mood, and [spatial composition](/process/blockout/massing/composition.md)
* **2-10 minute gameplay video** of the level in action
  * at least 1280x720 resolution at 30 fps
  * omit any splash screens, intro screens, trailer music, etc.
  * play "normally", show how an "average" player experiences the level
  * record with [Open Broadcaster Studio (OBS)](https://obsproject.com/), upload to YouTube or Vimeo
    * editing the footage can be nice but isn't necessarily important
    * optional: overlay your personal audio design commentary as an optional audio track, shows fluency and communication skills to a teacher or prospective employer
* **50-100 word description** about the project
  * give it a good short memorable name
  * single player, multiplayer? core themes, emotions, mechanics?
  * what's the scope? how many levels, how big is this project?
  * project credits, who worked on this? where do the assets come from?
* **link to download**
  * for a gamer audience, you must include a Windows-compatible version
  * if it's a custom level / mod for a game with Steam Workshop etc. link to it there
  * otherwise, you can host the files on a free service like [itch.io](https://itch.io), [GameJolt](https://gamejolt.com), or [ModDB](https://moddb.com)
    * **use .ZIP**... avoid .EXE installers or non-traditional formats like .RAR or .7Z, which are less accessible and require special software

TODO: Good screenshot vs bad screenshot

### Extra materials for a portfolio

If you are preparing a level design portfolio in hopes of gaining employment as a level designer, then you may want to prepare some additional documentation:

* **top-down map overview with labels**
  * in your editor tool's 3D view, fly up and look down, take a screenshot, and then open it in a 2D tool and add text labels / markings
    * to take a screenshot on Windows: press `Windows Key + Shift + S`, then drag a rectangle
    * to take a screenshot on MacOS: press `Command + Shift + 4`, then drag a rectangle
  * for single player: draw or number various points along the critical path
    * for combat-heavy levels, show enemy placement and strategic positions
    * for puzzles, show the sequence of clues / steps to solve the puzzle
  * for multiplayer: mark player spawns, capture points, etc.
* **process images**
  * show layout drawings, blockout screenshots... "show your work"
  * but don't upload too many, just a few to demonstrate that you understand the process
  * if your layout drawing is incomprehensible / chaotic, it's better not to show it
* **100 word devlog / analysis**
  * looking back, what were the main strengths and weaknesses of this project?
  * how did the project change over time? any interesting playtests or stories?
  * any levels from other games inspire your approach? why those?
  * show that you can think and communicate, but don't write too much
  * link to any news coverage or awards

In addition to the above, make sure you include screenshots, a gameplay video, and a download link.&#x20;

In all likelihood, a prospective employer will probably not download and play your level unless you reach the final hiring round -- but the download link is still important, because it shows that you know how to finish and release something. It looks even better if the download page is full of user feedback and high social media metrics. Although an employer may not play your level themselves, they certainly care if other people played your level.

The more popular / commercial the project, the less documentation you will need. AAA level designers can get by with just a few screenshots because everyone already knows their work, and big studios often prevent employees from posting anything that isn't officially approved. However, if you are an unknown student / novice designer seeking their first game industry job, unfortunately no one will have such familiarity with you or your work, and you will have to work harder to convince them of your capabilities.

Do not include Minecraft builds, custom Fortnite maps, or Roblox projects in your portfolio. Even though some of the most interesting level design practice is happening in those games, unfortunately the industry generally regards these tools as unprofessional.

## How to release a project

Every game and platform will have its own community norms and conventions for publishing projects. Some mod communities might prefer something like Steam Workshop with automatic installation, while for standalone projects, you may need to host the files yourself on a free game platform like itch.io.

The basic release process for most levels / games usually looks like this:

1. **Gather media:** take screenshots, record and upload gameplay video, prep text description and credits
2. **Package** the playable project files in a .ZIP file and **upload** somewhere
   * include any additional files the level may need, with all subfolders intact
   * include a `readme.txt` file with brief description and instructions where to unzip the file
   * to make a .ZIP on Windows: `right-click on folder > Send To > Compressed folder`
   * to make a .ZIP on MacOS: `right-click on folder > Compress items`
3. **Publish** the release
   * create a project page (on itch.io, your personal site, Steam Workshop, forums, etc.) with text description, credits, screenshots, gameplay video embed, and download link
   * publicize the project page across social media, beg people to play and share it
     * Twitter (social platform favored by game industry / media journalists)
     * Discord (main community platform for gamers, especially mod communities)
     * Instagram (popular visual platform for normal people / non-game-artists)
     * ArtStation (main visual platform for game artists, essential for environment artists)

If you're selling your project, then public release is actually just the halfway point in the project's life. There will be a lot of feedback, bug reports, fixes, and patches to figure out. Players will expect maintenance and updates. If you manage it well, you might be able to relaunch the game again and again, and cultivate a healthy "long tail" of revenue over time... but if you're making a commercial release, hopefully you're not seeking business advice from a level design book, so we'll just stop here.

## How to stave off despair

Even if you do finish your project, it is very likely no one will play it. 99% of levels have a dozen players, a hundred downloads, a thousand page views at most.

This lack of massive public response can feel very disappointing, alienating, and depressing. But this experience is very common. You are not alone. If you don't have a huge popular earth-shattering success, then that doesn't make you a failure -- it makes you human.&#x20;

Remember:&#x20;

* it's ok to make maps, mods, and games for small communities and audiences... you can create for an audience of one; these are called gifts
* it's ok to work on small projects, it's ok to work on non-commercial projects
* it's ok to try something and then never finish it
* you do not need to work at a big prestigious industry game studio to be a great level designer
* level design is an art to hone for its intrinsic beauty
* the one constant in every creative field is the need for a creative [community](/appendix/communities.md) that understands the ups and downs... if it hurts, talk to someone
* you are more than one project! keep going!

## What now?

* Go map.

### Further reading: how to document / release a level

* Industry level designer [Steve Lee has a video log with level design portfolio advice](https://www.youtube.com/watch?v=wzrkPj8GBPM).
* [Valve Developer Wiki: How to Take Artistic Screenshots](https://developer.valvesoftware.com/wiki/How_To_Take_Artistic_Screenshots) is a short guide written mostly by Valve level designer Adam Foster
* [Robert Yang has blogged](https://www.blog.radiator.debacle.us/2018/04/advice-for-making-game-design-game-dev.html) about general game design / dev portfolio design considerations, with links to example portfolios.
