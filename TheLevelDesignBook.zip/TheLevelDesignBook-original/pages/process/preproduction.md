> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/process/preproduction.md).

# Pre-production

How to plan a game level with mechanics, experience goals, and pillars

## What is pre-production?

> *"Plans are of little importance, but planning is essential."* -- some guy

**Pre-production** is the early phase of a project where you generate ideas and try to figure out what the project is about. It's about answering big design questions:

* *What* are you making?
  * What will the player be able to do? (Mechanics, Experience Goals, Pacing)
  * Which parts are most important? (Pillars)
* *How* are you going to make this?
  * How did other people solve similar problems? (Research)
  * How much time do you need? Is this feasible? (Scope)

Your answers to these questions will change throughout the project, and that's OK.&#x20;

**Planning is useful but it's not magic;** you won't know what you're making until you actually make it.

## Project planning

Level planning can take many forms. Like for a small solo hobby project, planning is less important, you can write or sketch a simple basic plan and then enjoy the thrill of improvisation and discovery. But for a larger group project, planning helps everyone know what to do / what everyone needs from each other.

#### Minimal checklist

Very basic questions, enough for a quick solo jam project:

* [ ] **Elevator pitch**. Describe the core concept and what makes it interesting. 1-2 sentences.
* [ ] [**Tools**](/appendix/tools.md)**.** What engine and tools will you use? Will they work for this project? How do you know?
* [ ] [**Scope**](/process/preproduction/scope.md) **(basic)**. How long will it be? How many levels? Big or small levels? What does a "big level" mean? These are basic question about **scope**, the size and workload for a project.

#### Recommended checklist

But really, you should be able to answer these other basic questions too:

* [ ] **Pillars**. What are the 2-3 most important themes / features of this project?
* [ ] **Experience goals.** How should the player react throughout each level? An emotion, a behavior?
* [ ] **Mechanics.** What are the frequent activities / interactions / skills the player will use?
* [ ] **Asset list (basic).** What models, textures, and sounds will you need for each level? What do you have already, and what needs to be found or made?

#### Full checklist

For 3+ people or a 3+ months project, then more planning will help:

* [ ] [**Pacing**](/process/preproduction/pacing.md)**.** What happens in each level? Why? How do the levels fit together?
* [ ] [**Research**](/process/preproduction/research.md)**.** What are the inspirations / reference points for these levels? Does the group have a shared understanding and interpretation?
* [ ] [**Worldbuilding**](/process/preproduction/worldbuilding.md)**.** What is the backstory / fiction of the level? Who built these places? What logic / mood guided the construction and use?
* [ ] [**Scope**](/process/preproduction/scope.md) **(detailed)**. Every week, what will you work on, and when? What features / levels are "nice to haves" that can be cut if necessary?

In the video below, industry level designer Steve Lee talks about his process -- before drawing any layouts or opening the editor tool, he first opens a text window and writes an outline for what should happen in the level. This is the core of planning: **think about the main ideas and talk about it.**

{% embed url="<https://www.youtube.com/watch?v=0FSssDWEFLc>" %}
["How I design levels in text first, and why" (22 minutes)](https://www.youtube.com/watch?v=0FSssDWEFLc) video by Steve Lee, uploaded 21 June 2022
{% endembed %}

## Mechanics

A game **mechanic** is any activity, system, or tactic repeated in your game, basically any action a player routinely performs or uses. **Core mechanics** are the most basic frequent and fundamental actions / systems of a game, while less frequent activities can be called *secondary mechanics.*&#x20;

{% hint style="info" %}
People argue over the exact definition of "mechanic." This book adopts a broad inclusive definition because we don't care. But if you care, [read more about it](https://en.wikipedia.org/wiki/Game_mechanics).
{% endhint %}

Some examples of how we talk about game mechanics:

* Super Mario 64's core mechanics are running and jumping to reach the exit. Some Mario 64 levels support secondary mechanics like wall kicks for secret shortcuts.
* Doom's core mechanics involve running and shooting, with little or no jumping. Sometimes players trick monsters into shooting each other, a secondary mechanic called in-fighting.
* Thief: The Dark Project is a stealth game about avoiding enemies, with a core mechanic where loud fast footsteps attract guards. In contrast to Mario and Doom, Thief discourages fast movement, and running is a secondary mechanic.

Mario 64, Doom, and Thief are all similar 3D action games about reaching the exit without dying. However these games require very different approaches to level design. Mario platforming would make for an impossible Doom level, and Doom-style hordes of monsters would make for a brutally unfair Thief level.

Do not design for the genre, do not sleepwalk into familiar patterns. Instead, design for the actual game that exists! If you're modding a game, play it for at least a couple hours, including other modders' work. Watch YouTube gameplay footage, pay attention to how other players use mechanics and systems.&#x20;

![a page from the Super Mario 64 game manual, detailing various actions and mechanics](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lu0Lt2ruOZaLIEhc6aC%2F-Lu0OSY621H8Jz2LDst-%2Fmario64_manual_scan_export.png?alt=media\&token=7014aac0-a6a5-410c-b9e1-3e4860a0df45)

### Haven't finalized mechanics yet?

It's hard to build levels without knowing the mechanics. Both mechanics and levels depend on each other, one cannot exist without the other. You can't evaluate a mechanic without testing in a level, but you also can't quite evaluate a level without finalized mechanics.

If you change your mechanics, then you'll end up with a lot of wasted work and obsolete levels that relied on discarded mechanics. But if you don't build enough test levels to measure the mechanics' potential, then you might end up with a dud mechanic that isn't interesting enough beyond the first level.

You might have to throwaway or redo levels, maybe even multiple times! It's OK. Do not think of this as wasted time or work. Instead, think of each discarded version as valuable research. This is why we call it game *development* -- development is a process that takes time. It will take time to figure out what makes for a good level and a good game.

![early design document for Donkey Kong (1981) showing mechanics, controls, and flow; by Shigeru Miyamoto (via Twitter)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MkpFP8S7JDcg3iYHtOq%2F-MkpFWqnhjc1yVFu-701%2FLDB_DonkeyKong_Miyamoto_DesignDocument_Scan.jpg?alt=media\&token=d8630b4e-8c19-4ed5-b42e-aa46a655e709)

### Build playground test maps

As part of the planning process, build **playground** [**blockout**](/process/blockout.md) **test maps:** big boxy courtyard levels filled with varied floors, room shapes, and game objects.&#x20;

These simple playground-style debug levels are vital for testing game mechanics and general feel for the game. It is especially essential if you are prototyping your own character controller and player physics, to make sure the player can comfortably move around in the game.

&#x20;   *For more on building test maps for internal use, see* [*Metrics*](/process/blockout/metrics.md)*.*

![actual internal developer metrics blockout test maps "K\_Test2" and "I\_TestM" from a French version of The Legend of Zelda: The Wind Waker, screenshots by Dark Linkaël (via tcrf.net)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FoukKfHK4tlcfHhj6vNtl%2FLDB_ZeldaWindwaker_Blockout_Metrics_TestMaps_TCRF.jpg?alt=media\&token=8f435460-862a-4e42-bf09-6d12157f4328)

### Noun-verb diagrams

Modern game developers today rarely use big "GDDs" (game design documents) nor big design bibles; *no one's going to read all that,* and docs quickly get outdated as you evolve the game. Instead, create a **noun-verb diagram** to **visually track how game systems and mechanics interact**.

> "\[Noun-verb diagrams are] useful for finding holes and questioning assumptions we were making about player motivations, and is super handy for pitching at a glance, people can understand the game so much faster with this than a bunch of bloated copy.
>
> \[...] **This diagram is&#x20;*****not*****&#x20;supposed to chart all the things that are possible, but the things you feel are important.**"
>
> \-- Leena van Deventer, ["Noun-verb diagrams"](https://cohost.org/Leena/post/297770-noun-verb-diagrams)

<div data-full-width="false"><figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2Fwv5Xj1TduELkDIevP0i1%2FLDB_DeadStaticDrive_LeenaVanDeventer_DSDnoun-verbdiagramCORE.jpg?alt=media&amp;token=aca22e02-374d-4149-b13d-70aea8e6d3e1" alt=""><figcaption><p>core gameplay noun-verb diagram for <a href="https://www.deadstaticdrive.com/">Dead Static Drive</a> by Reuben Games, <a href="https://cohost.org/Leena/post/297770-noun-verb-diagrams">via Leena van Deventer's post "Noun-verb diagrams"</a></p></figcaption></figure></div>

## Experience Goals

An **experience goal** is some kind of idea, feeling, or activity for the player. To conceptualize goals, try starting with the phrase, *"In this level, the player should \[learn/feel/do]..."*

* *In this level, the player should...* \
  *...* learn how to use the double jump ability. (Tutorial)
* *In this level, the player should...* \
  ... feel vulnerable, then reach the safehouse and feel relief. (Emotion)
* *In this level, the player should...* \
  ... dodge deadly traps and unlock a shortcut at the end. (Activity)
* *In this level, the player should...*\
  ... feel like they're escaping a medieval prison. (Fantasy)

### Advice for setting goals

**BE SPECIFIC.**&#x20;

Experience goals don't have to be complicated or profound, but a clear and specific experience goal helps you decide what to build and what is unnecessary.&#x20;

*"The player should have fun"* is a vague goal that can't drive design decisions. What type of fun? How much fun? Be more specific.

Or if the goal is to *"make the player feel fear,"* then what type of fear? There's body horror, existential horror, fear of failure, fear of rejection, mid-life crisis, etc.

**THINK FROM THE PLAYER'S PERSPECTIVE.**&#x20;

Avoid abstract experience goals. Imagine the player's perspective.

For example, *"the player should enjoy non-linearity"* focuses on an abstract structure that isn't relevant to the average player, so it isn't a useful experience goal. What do you actually mean by enjoyment or non-linearity?&#x20;

Imagine talking after a playtest. What do you hope a player says about your level? You would feel insulted if they said, "wow that was really... um... non-linear..."&#x20;

#### SECONDARY DESIGN GOALS CAN HELP.

Levels rarely have just one experience design goal. Even a tutorial level benefits from storytelling and mood. These secondary goals can help guide your design decisions.

For example, *"fight multiple enemies at once"*  is an encounter design goal for a level. But so much is still undefined. Where is this level set? What type of enemies?

Try adding a pacing goal: *"feel overwhelmed at first" ...* So maybe the fight should start in a small space with enemies almost surrounding the player.

Add a fantasy / storytelling goal: *"feel like defending a campsite from zombies" ...* So maybe we should research types of campsites (military? hiker? winter?) to plan the arena. Campsites have campfires, maybe there's a fire weapon... etc.

### Pillars

The most important experience goals across your entire project are **pillars** -- the most vital ideas that structurally support and justify your entire design. Design pillars help teams maintain a cohesive vision for the project, and resist "feature creep" work tasks that don't actually support your main goals.&#x20;

Pillars are a design planning tool to help you conceptualize short-term experience goals for each level or area. Each of your level's smaller experience goals and small gameplay beats should contribute to your pillars somehow, and that culminates in the grander arc of your entire game's experience.

To help internalize these big design goals, title each pillar with a pithy phrase or word. For example, the God of War (2018) internal design pillars at Sony Santa Monica were Combat, Father/Son and Exploration (see below).

![core experience goals / "pillars" for God of War (2018), presented by SIE Santa Monica Studio](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lu4KBQwhlYBmS5t08B3%2F-Lu4L3eYTLmJ2R1zNvy9%2Fgod-of-war_design-pillars_2018.jpg?alt=media\&token=00f60360-fc8e-47eb-80fb-fba092ea7969)

Because this was a big budget AAA game, their experience goals also involved production value targets like "high optical \[motion capture] fidelity."&#x20;

You might think this character animation goal has little to do with level design, but imagine a level that makes the mocap character animation look bad -- who has to change their work now, the level designer or the animator?&#x20;

Because the entire team already agreed that mocap animation should have priority as a pillar, perhaps that prior consensus means the level designer should change their level to fit the existing animation.&#x20;

In this way, pillars help us define what is important about our projects, and thus make more consistent and coherent decisions during development.

## Example: Psychonauts 2

Psychonauts 2 is a 3D platformer about exploring peoples' brains. In November 2016, Double Fine Studios made a pre-production with a vertical slice style "art test" prototype -- 5 years before the game's release in August 2021.

As depicted in their official dev documentary video series ["PsychOdyssey"](https://www.youtube.com/playlist?list=PLIhLvue17Sd70y34zh2erWWpMyOnh4UN_) episode 8, the pre-production team focused on building out a core movement set, art style, and level design in Unreal Engine 4. While much of the core platforming mechanics carried over from the original Psychonauts 1, the team wanted to experiment with new ways the player's various psychic powers could interact with the platforming gameplay -- resulting in a telekinesis-with-movable-tightrope prototype mechanic that never appeared in the final game.&#x20;

By the end of the dev cycle, there's still a lot of uncertainty and unanswered questions. Will this game be good? No one knows. The journey is just beginning.

{% embed url="<https://www.youtube.com/watch?v=eaA0P2dDHSg&list=PLIhLvue17Sd70y34zh2erWWpMyOnh4UN_&index=9>" %}
Double Fine PsychOdyssey · EP08: “A Couple Years of a Lot of Work” [(via YouTube)](https://www.youtube.com/watch?v=eaA0P2dDHSg\&list=PLIhLvue17Sd70y34zh2erWWpMyOnh4UN_\&index=9) uploaded 11 Feb 2023
{% endembed %}

## Example: Dishonored 2, "Clockwork Mansion"

Dishonored is a first person stealth action RPG series about exploring complex places. In Dishonored 2, there is a "Clockwork Mansion" level where the layout dynamically changes.&#x20;

Arkane Studios designer Dana Nightingale built a proof of concept pre-production prototype: ([Twitter thread](https://twitter.com/DanaENight/status/1448582302855045124))

> "I created this proof of concept early in 2013, long before the map was greenlit to be included in the game, basically to say "yes this could be amazing" and "yes I should work on it." It did both, but it would still be over a year before the map was officially OK'd.
>
> But sure, I could make a bunch of blocks animate however I wanted. What is possible using real level geometry? That's why I made this prototype. A bit less wild? Yes. But still clearly do-able.
>
> That prototype introduced the idea of rooms that were moved around like cargo containers and slotted into place, making the map's layout totally dynamic, but without transforming rooms. I am glad we didn't go in that direction.
>
> \[...]
>
> After nearly a year of working on other prototypes it was time to revisit the Clockwork Mansion and finally get it validated. I made a new version with fewer twisty rooms, and more emphasis on the "behind the scenes" areas..."
>
> \-- [Dana Nightingale (@DanaENight), 14 October 2021](https://twitter.com/DanaENight/status/1448582302855045124)

To give you a sense of time scales here: this level spent 7 months in pre-production, then entered final layout / blockout about 18 months later.

{% embed url="<https://www.youtube.com/watch?v=-BgynKsHKUo>" %}
video of internal Arkane prototype  ["Clockwork Mansion Proof of Concept"](https://www.youtube.com/watch?v=-BgynKsHKUo), recorded 5 Feb 2013 [by Dana Nightingale](https://twitter.com/DanaENight/status/1448582302855045124)
{% endembed %}

## To review\...

* **Mechanics** are the repeated systems and interactions of a game.&#x20;
  * **Core mechanics** are the most frequent, while secondary mechanics add occasional variety and finesse for more experienced players.
* **Experience goals** are the player-facing design goals for your levels
  * **Pillars** are the main design goals for your entire game. What do you want the player to learn, feel, or understand?
* How much planning do you need? It depends.
  * Small casual projects will be OK with small (or nonexistent) plans, big long-term projects may require a huge internal wiki.&#x20;
  * **Pre-production planning helps developers coordinate and trust each other.**
  * If you're prototyping new mechanics or game design elements, then **blockout a test map** with a big playground-style space.
* Plans help you make things, but **plans always change.** Even after preproduction, while working in the middle of the project, you will almost always adjust your plans and improvise a redesign. That is OK.

## Now what?

* Pre-production in more detail:
  * [**Research**](/process/preproduction/research.md) is vital for projects focusing on story or realism.
  * Single player projects require special attention to [**pacing**](/process/preproduction/pacing.md).
  * Projects often start too big and must be [**scoped**](/process/preproduction/scope.md) down.
  * Big narrative projects benefit from [**worldbuilding**](/process/preproduction/worldbuilding.md).
* Or you might move on to the [**layout**](/process/layout.md) phase of level design.

### Further reading and resources

* [**"A Series of First Steps - Overcoming the Digital Blank Page"** by Seth Marinello](https://www.youtube.com/watch?v=R75g3elj7y4) (GDC 2014)
* [**"An Approach to Holistic Level Design"** by Steve Lee](https://www.youtube.com/watch?v=CpOoTAVeEcU) (GDC 2017)
* [**"Finding Duskers: Innovation Through Better Design Pillars"** by Tim Keenan](https://www.youtube.com/watch?v=kzQDVtysXjA) (GDC 2017)
* [**"A Playful Production Process"**](https://www.playfulproductionprocess.com/) (2021) by Richard Lemarchand is an approachable textbook that introduces game production methods, ideal for late high school / university students.
* [Pre-production (Wikipedia)](https://en.wikipedia.org/wiki/Pre-production) is a formalized process for film and music industries.
