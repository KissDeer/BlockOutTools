> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/process/lighting/darkness.md).

# Lighting for darkness

how to light night / evening scenes for dark mood while preserving readability

When lighting scenes for night or shadowy low light conditions, game developers generally follow the film industry convention (["Hollywood Darkness"](https://tvtropes.org/pmwiki/pmwiki.php/Main/HollywoodDarkness)): **make it&#x20;*****feel*****&#x20;dark, but don't actually make it dark.**&#x20;

Early filmmakers shot their night scenes with a "day-for-night" technique: film in the early morning and artificially darken the image with a blue filter. Today, artificial lighting and better cameras mean contemporary filmmakers can shoot "night-for-night" scenes too. Some cinematographers (e.g. [Steve Yedlin for *Knives Out (2019)*](https://twitter.com/steveyedlin/status/1201278088794923008)) even combine both techniques, compositing day-for-night and night-for-night shots together to create an impressionistic look.

If we light our level "accurately" with pitch-black darkness, then players can't see where to go and become frustrated.

&#x20;*This page builds on terms and concepts from the main* [*Lighting*](/process/lighting.md) *page.*

## General night setup

In real-life, moonlight is white (reflected light from the sun)... In film and games, moonlight is blue-ish. Full moon will cast stark projected shadows, cloudy evenings will cast few shadows

Fill lights = dim subtle blueish point lights with no shadows and soft falloff

Don't apply flat ambient to all shadows; you want SOME shadows to terminate into 0% black, or else you're not using the full dynamic range. Use directional ambient

Remember: don't rely on dark albedo textures to darken the scene! Let the lights create the sense of darkness. If you burn shadows into your textures,  your textures will be less reusable and harder to relight, and you will force your lighting into overbright ranges to compensate.

Rim lighting to emphasize silhouettes while leaving most of the subject in shadow

With so much reliance on blue, blorange is common, but try to avoid vanilla blorange by introducing a third color or tweak hue ranges

![moodboard of different lighting scenarios for "Numbani" in Overwatch 2, image by Fabien Christin (via PlayOverwatch.com)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FYuZ03kyIfuuhQHxILase%2FLDB_Overwatch2_Numbani_LightingScenarios.jpg?alt=media\&token=0ac49298-8aff-45b5-9aca-2827299acde2)

In the image above from Overwatch 2, note the brightness, contrast, and color palette in the night time lighting scenario (bottom-right). What makes a night scene feel like a night scene?

* it's actually pretty bright; what makes it feel dark is increased contrast and specular
* characters are darker silhouettes vs. brighter horizon
* it's not just boring blorange; there's a lot of purple and yellow mixed in

## Shadow design

![Shadow diagram by James Gurney, from https://gurneyjourney.blogspot.com/2010/02/light-and-form-part-1\_15.html](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MDGMBCgIsDexaRfEThI%2F-MDGMgoSaS_REtGHsivE%2FJamesGurney_LightShadowDiagram.jpg?alt=media\&token=2a9bc34f-a5ed-4fa8-9bb8-d335829e3687)

## Against "Hollywood darkness" in games

Lighting your game in a "Hollywood darkness" style results in a more polished commercial feel that matches popular mainstream visual culture.

As in film, some artists purposely want to avoid this style and its implications. If that type of mood isn't appropriate for your project's experience goals (i.e. you want to make something disconcerting, confusing, jarring, visually experimental) then you may wish to disregard much of the advice on this page.

### Lighting as mechanic

Games with heavy use of dynamic lighting and flashlights, especially horror games, may want to selectively let high tension scenes go to pitch black darkness.

## Sources / Further Reading

* [**"How to Light for Darkness | 5 Cinematography Techniques"**](https://www.youtube.com/watch?v=rNggiaosjuw) is a great 15 minute introduction to lighting and production design for night scenes by cinematographer Valentina Vee. Although she focuses on film industry techniques, much of her visual thinking is applicable to games.
* **"**[**Lighting a Night Time Scene in Source 2's Hammer**](https://www.youtube.com/watch?v=xks0kAeSW9Q\&list=PLdY77XvZ-l20ZeYtAtYx7n-wOHxkyQGog)**"** is a 4-part 3.5 hour video series where environment artist [Helder Pinto](https://www.helderpinto.com/) (Crysis, Overwatch) lights a Portuguese street scene at night with extensive commentary. Much of his workflow is specific to Source 2's Hammer tool, but the general thinking is applicable to any tool or engine.
