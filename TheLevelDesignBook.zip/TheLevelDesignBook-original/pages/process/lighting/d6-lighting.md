> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/process/lighting/d6-lighting.md).

# D6 lighting

Spatial interior design lighting theory with six lighting strategies

**D6 lighting** uses the six faces of an ordinary six-sided game die (1d6) (⚀ ⚁ ⚂ ⚃ ⚄ ⚅) to help you remember different lighting strategies.&#x20;

This strategy is about lighting for [flow](/process/layout/flow.md), not just lighting from a specific view or camera perspective. It represents a more architectural and spatial approach to lighting a level, and in most cases, we encourage you to prioritize this type of lighting theory over three point lighting.

### ⚀ 1. Focal point

Place a lone light source to emphasize a specific point or place, to suggest the player approach this exact location.&#x20;

A point light treats all angles equally, while the directionality of a spotlight suggests more of a specific angle of approach or intention. Imagine a lone window, campfire, car headlights, flood light, a dramatic lone stage light angled down.

### ⚁ 2. Focal frame

Place two similar light sources next to each other to frame something in the space between. It will suggest an approach that is perpendicular to the frame.

Frame an entrance or exit. Torches, sconces.

### ⚂ 3. Path / boundary

Angle spotlights toward a wall to "wash" the surface evenly

### ⚃ 4. Space

### ⚄ 5. Space with focal point

### ⚅ 6. Space with framed path
