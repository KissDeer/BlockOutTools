> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/process/lighting/three-point.md).

# Three point lighting

Photographic / cinematic lighting theory with three light types

**Three point lighting** is lighting design theory used in film, theater, and photography, with three different types of lights:&#x20;

(1) **Key light** is the main dominant light source that illuminates most of the subject or area. In most levels, this is usually a directional light (sunlight) or a bright powerful spotlight with high falloff constant (like a floodlight). Task light.

(2) **Fill light** brightens darker areas to avoid plunging everything into shadow. To fill a game level, we usually use ambient light and (many) invisible soft dim point lights floating in the middle of the room, but wide-angled dim spotlights are also useful when you want to direct the fill and, for example, avoid any fill splashing onto the ceiling. Ambient light, wash.

(3) **Rim light** highlights edges to pop the foreground from the background. Accent light.

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M5rlFmncyIXoXRqtvCg%2F-M5rldK_iJOJoPaT8y43%2Fimage.png?alt=media\&token=4cd1c32d-6697-415b-acb0-7ac5d2a668c1)

*(And in portrait photography, sometimes a fourth **background light** brightens up the backdrop to smooth out awkward shadows from the key and fill.)*

Notice how the key light and fill light in this example are roughly perpendicular to each other, while the rim/back light is behind the subject. Pay special attention to the light positions and directions! **The light source placement, relative to other lights, determines their function.**

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M5rlFmncyIXoXRqtvCg%2F-M5rlaC0MUadbCSg1V6u%2Fimage.png?alt=media\&token=675a3dc8-656b-48b5-99e7-b666b1a4a6b5)

However, the big problem with using three point for games is that it assumes you have complete control over the camera. What if the player controls the camera?&#x20;

Three point light types depend on the light's orientation relative to the camera -- a rim light is a rim light because it grazes the subject, but if you approach from a different angle, now there's no more rimming action -- now the rim light is a key light! If it looks like a dim shadowy silhouette from the front, it'll glow like a deer in headlights from the back. The light placement matters, but the camera placement matters too.

So in order to use three point theory effectively in games with free movement and a free camera, you need to predict how the player will utilize both.

In a first person game, that means knowing roughly where the player will be walking and looking. Fortunately, we already have a tool to constrain the player's movement and rotation: it's your level layout! If you frame a subject a certain way, or limit an approach to a certain direction, then you can place lights for that perspective. **Your** [**layout**](/process/layout.md) **is a lighting tool.**

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M5rlFmncyIXoXRqtvCg%2F-M5rljQiOAZYT4u23XSA%2Fimage.png?alt=media\&token=23c2840a-b830-41ef-a359-425cfe695111)

### Cinematic lighting

The most common use of three point lighting in games is for **lighting characters in cinematics / cutscenes.** Because you have more camera control in a cutscene, you should draw upon more filmic lighting techniques -- because you're basically making a movie.

TODO: summarize text from these cinematic lighting cheat sheets by Derek L. Brand, senior concept artist on Psychonauts 2 at Double Fine <https://twitter.com/DerekLBrand/status/1440089196467609608>

![lighting characters with key lights, internal documentation used for Psychonauts 2 by Derek L. Brand https://twitter.com/DerekLBrand/status/1440089196467609608 ](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mk6R8h09gAalQRyIOXT%2F-Mk6RvVsxbLNWd_T9hjc%2FLDB_Psychonauts2_Lighting1_DerekBrand.jpg?alt=media\&token=5d141450-b698-49a7-a687-bb07121a06a0)

![lighting characters with fill lights, internal documentation used for Psychonauts 2 by Derek L. Brand https://twitter.com/DerekLBrand/status/1440089196467609608 ](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mk6R8h09gAalQRyIOXT%2F-Mk6S08Y-1L7vPDGVpCA%2FLDB_Psychonauts2_Lighting2_DerekBrand.jpg?alt=media\&token=ca07f3ec-af1c-4f71-8332-c173f9c1a8e3)

![lighting via exposure and value analysis, internal documentation used for Psychonauts 2 by Derek L. Brand https://twitter.com/DerekLBrand/status/1440089196467609608 ](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mk6R8h09gAalQRyIOXT%2F-Mk6S5Yuc4ohVDq5LUzY%2FLDB_Psychonauts2_Lighting3_DerekBrand.jpg?alt=media\&token=8bec9ef1-2186-4fba-b935-a004f7beb1eb)
