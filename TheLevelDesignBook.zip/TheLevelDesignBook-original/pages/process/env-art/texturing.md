> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/process/env-art/texturing.md).

# Texturing

covering 3D surfaces with 2D images

## What's a texture / material?

A **texture** is a 2D image that wraps around a 3D object, like an animal skin or wallpaper.  For levels, we usually apply **environment textures** to cover floors and walls in the game world.

Early 3D games used one texture per object. The color painted in Photoshop was often the same color seen in the game, it was very direct and straightforward. But today we often use multiple textures together, instead of just one.

A **material** is a group of texture maps + settings for a surface. Each texture map represents a different aspect or quality, rather than the actual color to render on screen. While there are many ways to pack textures and materials, most materials in most 3D game engines use these four main texture types:

* **Diffuse** or **albedo** (pronounced /AL-bee-doe/) is the base color of the surface
  * For transparent materials, also pack a **transparency mask** into the albedo's alpha channel
* **Normal map** or **bump map** encodes the micro-details, scratches, indentations in the surface
* **Specular map**, **glossiness**, **roughness**, **smoothness, metallic** affect shininess / reflectivity
* **Ambient occlusion** ("AO") darkens seams, cracks, and crevices that block (occlude) light

(materials diagram)

## Texture types

### World textures

**World textures** are reusable tiling images that cover the underlying foundation of level geometry. These are the main ground and wall textures used for the level.

Good world texturing usually:

* Reads well at multiple viewing distances
  * its substance is clear from short, medium, or long distances
  * interesting to look at, but not too interesting to be distracting
* Aids wayfinding (or obstructs wayfinding, if that's your design goal)
* Tiles well, without implausible seams or jarring repetition&#x20;
  * e.g. repeated wood plank edge outlines are OK, but a clearly copy-and-pasted wood grain or dirt pattern may feel artificial and strange
* Matches the [massing](/process/blockout/massing.md) of the underlying level geometry
  * e.g. don't use a brick texture for a 2 cm thick wall
* Coheres with the overall [worldbuilding](/process/preproduction/worldbuilding.md) and fiction of the level / game

![a "gradient" of different terrain textures by Marie Lazar (from 80 Level)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MJYbXqtzzgFbu3trUW6%2F-MJYmZOmk-JTX_yMsK8u%2FTerrainTextures_MarieLazar.png?alt=media\&token=dc6f5eb1-ecba-474c-84e0-9374391a2cb0)

#### Rock textures

Rock textures require special planning and design. Tectonic forces form cliffs and mountains into distinctive shapes and layers; in order for a cliff texture to seem like a plausible cliff, the texture's structure should reflect this unique geology and accentuate the cliff geometry's shape.

For low polygon cliff geometry, a rock texture with strong structure / crack layout will visually break up the rock shape and make it seem much more complicated than it really is. Divide the rock texture into layers / chunks, which is, you know, how rocks exist in real-life.

![photobashing a rock texture by offset-healing seams (left) and accentuating the crack structure (right) by Philip Klevestav (from http://www.philipk.net/tutorials/modular\_rocks/modular\_rocks.html)  ](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mc2DVnUe6rFnXE6Pn1f%2F-Mc3rS4qurdB_F7FI29H%2FLDB_RockTextureStructure_PhilipK.jpg?alt=media\&token=964bcf0f-e167-4b40-aab2-4064ffa0188e)

![resulting albedo, normal, and specular maps for a rock material, by Philip Klevestav (from http://www.philipk.net/tutorials/modular\_rocks/modular\_rocks.html) ](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mc2DVnUe6rFnXE6Pn1f%2F-Mc3t1SbsmeAHHqRK8Jt%2FLDB_RockTextureMapsExample_PhilipK.jpg?alt=media\&token=80b58937-9ffc-471a-b2a2-2d372015e903)

### Wall textures

#### Thinking modularly

Many wall textures are designed to tile horizontally, but not necessarily vertically. Edge detail at the top and bottom helps emphasize where the wall meets the ceiling and the floor, simulating ambient occlusion / the realistic accumulation of dirt.&#x20;

To take the segmentation further, keep the middle of the wall texture fairly plain. For short or tall walls, you can either add or remove subdivisions based on this repeatable middle section. A segmented / modular texture is more flexible to use.

For low polygon art styles, it is very useful to paint details and structure directly into the wall texture; that way you won't have to model or bake these details manually.

![example wall texture divided into thirds with repeatable mid section, by Ben Mathis (from http://www.poopinmymouth.com/tutorials/thirding-textures-tip.html)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mc2DVnUe6rFnXE6Pn1f%2F-Mc3mk5PLJHYyfDZDXnX%2FLDB_ThirdingWall_BenMathis.png?alt=media\&token=5b8de5c3-c4b1-47ca-b51c-29c0f2291c6f)

#### Panels

When modeling modular buildings made of panels, combine all the panel segments into one texture. Painting individual edge details (dirt, grime, shadow) can help accentuate each panel and make them feel unique / less repetitive. The panel layout should accommodate various sizes and shapes, to give more flexibility.

![all the different panels for this medieval house share a single texture, by 'gutekfiutek' for Mount and Blade (http://wiki.polycount.com/wiki/ModularMountAndBlade)from  ](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mc2DVnUe6rFnXE6Pn1f%2F-Mc3zz-DM4QwjzxAUQ3Q%2FLDB_ModularTexture_MountAndBlade_gutekfiutek.jpg?alt=media\&token=8b648318-9bce-4ce4-9532-79434adbc74a)

#### Trim sheets

Trim sheet... Sunset Overdrive "ultimate bevel" talk?

Multiple related subtextures grouped together, designed to be used together

But a trim sheet is not magic, in fact it makes the texture even more difficult to use. Really, anything can function as a&#x20;

![making a detailed rug using a trimsheet texture by Lea Kronenberger, from https://www.beyondextent.com/articles/balancing-modularity-and-uniqueness-in-environment-art](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MHHcoN6AjFvv7uizacp%2F-MHHddb5H2Mvi6cHK-8F%2FLeaKronenberger_TrimSheet_Rug.jpg?alt=media\&token=9c4e56e0-a964-46a2-88be-8bfd176687b2)

#### Hotspot UVs

A new recent trend in&#x20;

Half-Life Alyx hotspot UVs (DreamUV)

## How to make textures

Texture art for games is obviously a big topic that deserves its own book. We can't really teach you how to become a texture artist, this is a skill that people spend years learning and practicing.

Here, we will only talk about the general workflow for creating textures for levels.

&#x20;   *For links to free textures, or recommended game art books and websites, see* [*Resources*](/appendix/resources.md)*.*

### Handpainting

### Photosourcing

### Baking a sculpt

### Procedural texture synthesis

Today, Substance Designer is overwhelmingly the primary environmental texturing tool across the industry. By connecting various samplers and operations together into a node graph, artists can visually program a texture synthesis pipeline to procedurally generate many texture maps and variations at a time. If you're coming to Substance from a Photoshop background, imagine Photoshop Actions and filters on steroids.&#x20;

There are two main advantages to this workflow over the traditional handpainting method: (1) you can easily resample textures at higher resolutions at any time, (2) the modular workflow means you can reuse graphs.&#x20;

For example: if you handpaint a stone wall texture in Photoshop at 512x512, there's no easy way to sample higher resolution textures or make similar variations on that stone wall. But if you build a Substance graph to generate that stone wall, then you can set the exporter to 2048x2048 or input a different heightmap to make countless variations very quickly.

![Substance graphs and brick generator iterations (left) with different heightmap inputs (right) for Graven, by Ben "Makkon" Hale (https://3drealms.com/devblog/graven-dev-blog-4-making-procedural-pixel-textures/)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MRqGjhk8kw3pYOV7k9K%2F-MRqLJcxoVCq0M-DIQU1%2FStoneBrickSubstanceGraphs_Graven_BenMakkonHale.jpg?alt=media\&token=48f7755c-4ae6-4ff9-bb72-cc7cf69ff65b)

## How to apply textures

### Gather a palette

### Triplanar projection

### Texture alignment

It's not really a big deal

## Further reading

* [Polycount Wiki: Texture types](http://wiki.polycount.com/wiki/Texture_types). An artist-focused primer to different texture map types.

### Trims and trim sheets

* [GDC 2015: "The Ultimate Trim: Texturing Techniques of Sunset Overdrive"](https://www.gdcvault.com/play/1022324/The-Ultimate-Trim-Texturing-Techniques) by Morten Olsen (Insomniac Games) is a talk on how a relatively small environment art team created a wide variety of looks for a large open world game. Great introduction to trim sheet construction and texture variants, but today you'd probably want to model the bevels instead of normal mapping the bevel.
* [Trim Sheet Detailed Breakdown](https://medium.com/@legacykraft/trim-sheet-detailed-breakdown-bd35c78d16c3) by Shubham Kumar covers the full process. Kumar starts by gathering material reference, then measures the trim sheet metrics / grid, then synthesizes the materials in Substance and applies the trim sheet to a model.
