> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/process/env-art/psychology.md).

# Shape and color psychology

Bullshit design theories that link abstract visual phenomena to universal human behavior

**Shape psychology** and **color psychology** are theories that shapes / colors convey universal ideas and influence behavior.&#x20;

Supposedly, circles symbolize infinity, horizontal lines make you feel more stable, squares symbolize balance (but triangles symbolize stability!!) and apparently a drawing of a leaf makes you feel warm. Or something.

Listen, this is like astrology. It's fun to think about. If it makes you happier, go for it.&#x20;

But don't take it too seriously, and don't try to elevate it to a science. Because if you try to push shape and color psychology as coherent design theory, it quickly falls apart to any scrutiny.

![wow that picture of a leaf makes me feel really comfortable, yep this is great](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MlXYpTXdJlNxx9P3Y8V%2F-MlXcNHa1OtbhTQenfqZ%2FLDB_ShapePsychology_IsBad.png?alt=media\&token=168f4fdf-2eb2-48a9-aa92-8f9dbcf99723)

## Meaning isn't universal

Abstract geometric shapes and colors, by themselves, do not make all humans feel the same thing nor communicate the same ideas.

For example, let's evaluate a common color psychology claim that *"red subconsciously evokes danger,"* maybe because blood is red and red signals and red stop signs and video games flash red when you have low health. Sounds convincing... But is this still the case in China, quite possibly the largest consumer market for video games in the world, where red often signifies good luck, fortune, prosperity, and joy? And what exactly does red convey to the 8% of European men who have red-green color blindness? When farmers paint a barn red, are they trying to convey danger or intensity?

Shape and color are abstract phenomena that do not have universal meanings for everyone around the world. Instead, shapes and colors mean many different things in different situations, and this meaning depends heavily on personal context and audience.

![whoa, look at all the red things! EXTREMELY DANGEROUS! better run away if you see these!](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M2vUJZhqNrpe7NR4hgq%2F-M2vVQjkmFwbcbhQmfCk%2Fimage.png?alt=media\&token=cbac7404-f189-4e34-bdf5-3e96e3bf2657)

## Meaning is contextual

*"Horizontal lines convey stability"...* until we see a fast flowing river strewn with wreckage.

*"S-curves feel harmonious"...* unless you're speeding in a car and you have to hit the brakes to avoid careening off an unexpected S-curve road.

It is easy to imagine many situations where blanket statements about shapes or colors don't work. At worst, all these blanket statements just feel blanket wrong. At best, it vastly oversimplifies how art creates meaning.

## Meaning is cultural and learned

Imagine you're playing Fortnite and you see a green-colored item, indicating that it is "uncommon" tier. Does the color green scream "uncommon" to you? What about a purple-colored "Epic" item, did the designers use purple because that color inherently conveys rarity or epicness? And yet, a "Legendary" tier item is orange... does orange universally feel more valuable than purple? How do we reconcile these colors and meanings?

The answer is: we don't care about the specific colors and their connotations, because we know the specific color doesn't matter.

These color coding patterns have evolved as loot games like Destiny and Diablo implemented their own item tier systems. **Colors in games mean things because of genre convention**. If the color meanings feel consistent and natural, then it is more because you're immersed in a specific subset of gamer culture, not because colors have universal intrinsic meanings across all humanity.

## Games have their own psychology

And even if it wasn't bullshit, shape and color psychology would not necessarily transfer to a video game context.&#x20;

People often behave one way in the real world, but behave differently in a video game. Player behavior depends more on game patterns, mechanics, available information, cultural framing, and roleplaying persona, rather than whether a shape is round or square.&#x20;

*"Pointy things are bad!"...* until you need to collect pointy-shaped crystals to craft a valuable item.

*"Round shapes feel safe"...* until you add a dangerous enemy to your game that is round.

Game systems, and the player's knowledge of them, override whatever "natural" or "subconscious" meanings from the outside world.

## You're better off without it

For this reason, we argue that **shape / color psychology doesn't address how players play games.**

Maybe give humans a little bit more credit? No one sees a circle and thinks "wow I love that circle, I'm going to walk toward that circle now."

Some artists might argue that color psychology / shape psychology isn't supposed to be taken literally, or that these theories have value as simplistic guidelines to trick beginners into thinking about [composition](/process/blockout/massing/composition.md). To which we respond: let's make some better guidelines.

Let shape and color psychology remain as they are: convenient snake oil for fake SEO marketing blogs and consultants.

## See also

* [**Color theory**](https://en.wikipedia.org/wiki/Color_theory) is about the science of color palettes. It is not the same thing as color psychology, because (1) it's actually real, and (2) it makes smaller claims about how colors work.
* [**Semiotics**](https://en.wikipedia.org/wiki/Semiotics) is the study of signs, and it's really complicated.
