> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/process/env-art/storytelling.md).

# Storytelling

How to tell a story with level design

## Why tell a story with level design?

Many players enjoy video games for the narrative aspects. It is engaging to explore a virtual space and to meet its virtual inhabitants, and to witness how the player's actions affect the fictional game world in small or big ways. Commercial action and roleplaying games tend to emphasize the world design as a thematic "skin" to decorate levels, while walking simulators elevate these storytelling aspects above all else. Every project will emphasize environmental narratives to a different extent, based on their core pillars and design goals.

Narrative design is obviously a large complex topic that merits its own book. So here we will focus on the storytelling work that specifically level designers, environment artists, and scripters do:

* [Pacing](/process/preproduction/pacing.md) is the overall plot / sequence of events in the level.
* [Worldbuilding](/process/preproduction/worldbuilding.md) is the conceptual design of the level's setting.
* Environmental storytelling
* Choreography

## Environmental storytelling

In level design, **environmental storytelling** is about building a level to convey or imply a past event.&#x20;

While worldbuilding is concerned with the entire fictional game world at a huge zoomed-out scope, environmental storytelling focuses on individual rooms in a more granular zoomed-in sense. What happened here, in this specific room with these specific characters?

Example: Gone Home, Everybody's Gone to the Rapture

## Choreography

Environmental storytelling is useful for conveying past events or static backstory in a game, but cannot portray current events in the present time. We need a different tool: **choreography** is a form of game narrative where in-game actors move / change in front of the camera. When a character walks and talks, a car crashes through a wall, or a monster growls from the shadows -- that's a scripted sequence, usually choreographed from a tool separate from the main level editor.

Example: Half-Life 1 scripted sequence entities, Half-Life 2 FacePoser tool, Telltale chore tool, Witcher 3 choreo tool, Unity and Unreal

## Plot-shaped level design

In a broader sense, everything in the game should serve as narrative. Gameplay and puzzles are part of the narrative too. To tell an effective game story, narrative designer [Emily Short recommends](https://emshort.blog/2016/05/18/plot-shaped-level-design/) tying story tightly to a [critical path](/process/layout/flow.md#critical-path):

> Your job is to make it as hard as possible for the player to finish your game without understanding your story. \[...]

> This means that the player must encounter, and ideally make use of, every critical piece of information in the story. “Encounter” might mean “read on screen” or “hear in dialogue” or “see in a cut scene,” but encountering information is much less valuable in an interactive context than using information. So it’s best if the player needs to act on each of those critical beats.
>
> To design for this, start by identifying critical beats. What are the facts the reader has to know in order to understand this story?
>
> This is a subset, probably a very small subset, of all the facts the reader could know. Many world-building details and secondary character motivations can probably be omitted without ruining the experience. But if your story’s impact depends on the player learning the protagonist’s secret motives, then that information is vital. \[...]

> Figure out which information is vital. Make a list. Be honest with yourself and keep the list as short as possible. \[...]
>
> Once you have your list of vital data, figure out dependencies. Which facts depend on other facts to make sense? Which facts have the greatest impact if they come after other facts? If learning the protagonist’s secret motive is more effective after we see them commit a crime, that provides a motivation for ordering. Turn your list into a dependency chart.
>
> \-- Emily Short, ["Plot-shaped level design"](https://emshort.blog/2016/05/18/plot-shaped-level-design/), 18 May 2016

## To review

*

## Now what?

* Narrative design for levels ideally begins in [pre-production](/process/preproduction.md), when conceptualizing the project's core [experience goals](/process/preproduction.md#experience-goal). In [production](broken://pages/-M-a0tN0YseLJA0Q8-po), storytelling relies on a combination of [scripting](/process/scripting.md), [art passing](/process/env-art.md), and [lighting](/process/lighting.md).
* Try an environmental storytelling exercise.
