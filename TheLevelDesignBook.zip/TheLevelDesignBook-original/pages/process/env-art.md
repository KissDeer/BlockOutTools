> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/process/env-art.md).

# Environment Art

refining shapes and adding visual detail, while maintaining clarity and functionality

## What is environment art?

**Environment art** (or "env art") is the cosmetic decoration of a level or game world, while preserving its core functionality and gameplay.

This work involves building up a library of modules, props, textures, materials, and other art assets, and then **art passing** the level by painting / placing decor to supplement the underlying design.

![diagram comparing level design vs Level Design vs environment art, using process images of "Gallente Research Facility" from Dust 514 by CCP Games](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Maev3jxp4WpKXebg88n%2F-Maf5hE1bqDx4IO2HGuP%2FLDB_leveldesign_env-art_compare.jpg?alt=media\&token=a921482a-e5bf-42f5-83a6-78975cbc4078)

Before the 2000s, level designers often made their own environment art too. But today, a level designer is usually supposed to make as little visual art as possible, and the environment artist is usually supposed to wait for a mature [blockout](/process/blockout.md) before beginning an art pass. However, when working in a small team, level designers will likely have to source or make their own environment art, and vice versa.

Here **we will focus on general environment art principles** and high level concerns, so that level designers can better understand the art process and collaborate with environment artists. **This is not an environment art book.**

&#x20;    *For links to free textures, materials, and models, see* [*Resources*](/appendix/resources.md)*.*

&#x20;    *For links to dedicated environment art communities, sites, and books, see* [*Community*](/appendix/communities.md)*.*

![animated GIF showing iterated blockout and art pass process for "Deathstorm" in Sniper Elite 4 (2017) (via Twitter)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MVOe7gOtBO2fR1OaIjJ%2F-MVOeNGkYd_XvSwlSxn7%2FLDB_Sniper_Rebellion_BlockoutArtpass.gif?alt=media\&token=a10f1d36-1367-4304-b106-8253f9b9ee1a)

## How to plan env art

Before you begin an art pass, you should to be able to answer these questions:

* *Theme.* What is the time of day, climate, and location for the level?
* *Gameplay.* Which parts need emphasis? What should be simple, what should be detailed?
* *Style.* Realistic or stylized? What type of realism, what type of style?
* *Palette.* What's the overall color palette, what's the mood? What kinds of shapes?
* *Production.* Which parts need to be done first, and which should be last (or never)?

&#x20; *For more on planning, see* [*Pre-production*](/process/preproduction.md) *and* [*Research*](/process/preproduction/research.md)*.*

![internal concept art, photo reference, and silhouette studies for The Last Of Us Part 2 (2020), board by John Sweeney](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MEdasubg-PXrYhNytbq%2F-MEdcBcECdGQZHQ0wAT5%2FTheLastOfUsPart2_SantaBarbaraStyleGuide_JohnSweeney.jpg?alt=media\&token=51f23ff7-b6fc-454b-b1bd-12c1c9deae9b)

### Concept art

**Concept art** is generally any visual art used for planning the game, but not used in the game itself.&#x20;

Sometimes the goal of concept art is to convey a desired theme or overall mood, while other times it must communicate technical specifications and details for art assets. Ask yourself, is this concept art meant to inspire, or is it trying to solve a specific visual design problem?&#x20;

Inspirational mood art is most useful during pre-production (especially when pitching a commercial project to a publisher) or early production, but detailed technical art is more useful later in production.

{% hint style="danger" %}
**If you use someone's concept art, credit them** -- or even contact the artist and ask for permission before you begin. Attribution is very important if you're looking for a job; everyone knows everyone, and failing to credit someone will look like a red flag.
{% endhint %}

![first person concept art (paintover?) of "underground vault" environment concept for Portal 2 (2011)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MU_VDqMttTZDcXtyuRZ%2F-MU_YA0GtOY2NPm5i1wj%2FP2_Underground_Concept_Art_1.png?alt=media\&token=22576b90-d3a3-4fa3-b137-a95154b57441)

### Paintovers

A **paintover** is a type of concept art that starts with a 3D screenshot and then an artist literally "paints over" the underlying screenshot to visualize the next version.

It is very common to paintover a [blockout](/process/blockout.md) screenshot to plan an art pass. This workflow saves a lot of time because the artist doesn't have to manually draft the perspective calculations for basic shapes. For this reason, even 2D artists should have at least some basic knowledge of 3D art tools, so they can potentially build their own blockouts for paintovers.

Sometimes the artist fully renders some finished-looking concept art (see image above)... but usually the paintover is about providing direct feedback between artists: suggested edits, corrections, and notes (see image below).

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FjZLL7U9OOYOtRV2vb4NA%2FLDB_TheQuarry_EnvArtPaintover_AdamDencker.jpg?alt=media&amp;token=e007a3bb-4f2c-4405-b898-7d4a3124a2a9" alt=""><figcaption><p>annotated paintover with notes for "The Quarry" by Adam Dencker <a href="https://www.artstation.com/blogs/bronzegear/wdw2/the-quarry-pt6">(via Artstation.com)</a></p></figcaption></figure>

### Model sheets

A **model sheet** is a more specific type of concept art for individual art assets that includes orthographic views for production artists to work from, as well as contextual mockups to show how that asset should be used within the game.&#x20;

In the concept art / model sheet pictured below, note how we get a good sense of how this octagonal ice crystal platform model will fit into the whole environment theme. Furthermore, the orthographic top and bottom views answer the prop artist's questions about construction and color, and can be easily brought into a 3D modeling tool as reference. The orthographics emphasize the golden corner trim of each platform, while the bottom-right illustration shows how the corner trims tile together for an interlocking visual effect -- together, it helps the environment artist understand which details are important to preserve and carry over to the in-game asset.

![combination concept art, model sheet, and paintover by Sarah Morris for Spyro: Reignited](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MJYbXqtzzgFbu3trUW6%2F-MJYdCmGP_4FmO06YQco%2FConceptArt_Spyro_SarahMorris.jpg?alt=media\&token=2dfd6fe3-45bb-43a9-855b-c64c504fe257)

## Art assets

After some planning, artists produce art **assets** -- visual objects to insert directly into the level. Unlike concept art, this is what the game engine must read and what the player will see in-game.&#x20;

When producing art assets, keep in mind:

* **The Brief.** What is the task? What does this asset need to do?
* **Approval.** Who gives feedback on this asset? How will we know if it works?
* **Scope.** How much time to make this asset? Small rare details deserve less time.
* **Workflow.** How many steps to make this asset? In which tools?
* **Pipeline.** How to export art into a format that the engine can read?

Longer term projects (6+ months) with larger teams (6+ people?) should formalize this art production process to avoid costly redos, wasted work, and miscommunication. Maintain a spreadsheet or kanban board to track tasks, and move each asset through different stages of testing and team review. While all this task tracking may feel slow at first, communication and clarity are faster in the long run.

&#x20;   *For more on organizing work tasks and team communication, see* [*Production*](broken://pages/-M-a0tN0YseLJA0Q8-po)*.*

![art production process diagram with three review stages, from "Be your best you by critiquing everything your workmates do" by Hannah Mackintosh for Play By Play 2021](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MZAvYee4Ae_wPE0Nnn8%2F-MZAzVdyIKv1G212b-Oa%2FLDB_ArtProductionProcess_HannahMackintosh_PBP2021.jpg?alt=media\&token=13b76a1e-db0d-4403-b9b2-f9b4e8ed6ea6)

Most art assets for levels are either 2D textures or 3D models, but in this section we'll also talk briefly about shaders and special FX later on.

### Asset list

Before making environment art, you may need to make an **asset list,** a list of all the art assets needed for a particular scene or level. Asset lists are usually in some sort of spreadsheet format, listing each asset's priority and estimated production time.

In the image below, the artist has made an asset list spreadsheet grouped by month / week. They estimated they had about 30 hours a week to work, and prioritized a scene blockout / the most important level geometry assets first. Materials and detail props only happen later, after the foundation has been set.

![an asset list / calendar / "block plan" for a 3D scene "The Grand Bath" by Vincent Dérozier, via ArtStation](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2Fs3Zcf41Chh2bFFCep5su%2FLDB_vincent-derozier-vincentderozier-thegrandbatharticle-img05b.jpg?alt=media\&token=e797ca3f-82a7-4864-b5bb-03378bf88d37)

### Materials and textures

**Textures** are 2D images that cover the 3D surface of the map. Since the 2000s we often combine multiple textures together into **materials**, texture bundles with additional data like roughness, shininess, light emission, etc.

For environment art, texture design and layout is very important. Unlike character skins, we often reuse world textures heavily throughout levels. The ideal environment texture needs to be able to work well in many different situations: it should tile well across a surface, but also easily divide into reusable parts.

&#x20;   *For more on texturing and defining materials, see* [*Texturing*](/process/env-art/texturing.md)*.*

![texture mapping a medieval house, from Mount and Blade](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mc2DVnUe6rFnXE6Pn1f%2F-Mc3zz-DM4QwjzxAUQ3Q%2FLDB_ModularTexture_MountAndBlade_gutekfiutek.jpg?alt=media\&token=8b648318-9bce-4ce4-9532-79434adbc74a)

### Modular kit

A **modular kit** is a 3D tileset made of **modules**, environmental meshes designed to snap together in a variety of ways. Modules are most effective for buildings and structures that make regular use of repetition along a grid, but they don't work as well for organic or natural shapes.

&#x20;   *For more on how to plan, measure, and construct kits, see* [*Modular kit design*](/process/blockout/metrics/modular.md)*.*

![reusing a modular wall segment (left) to build a rounded room (right); example by Lea Kronenberger](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MHHerrgs2nPIQ70JYF0%2F-MHHfVk7B1iz103vfibN%2FLeaKronenberger_ModularAquarium.png?alt=media\&token=044ffcee-dcb1-40a2-8939-e181199a5d2a)

There are many cases where modular meshes will not connect cleanly, especially if you build off-grid or at non-90 degree angles. Nonetheless, you may still want to preserve certain angles or odd lengths, for [metrics](/process/blockout/metrics.md) reasons or to evoke a gritty dirty non-manufactured natural feel. In these cases, just let the modules freely intersect, and then cover the messy intersection with another object.

For example, imagine you had two rectangular floor meshes that meet at an odd angle -- arrange them to join seamlessly as best as you can, then cover the intersection with a wall, pillar, rock, crate, car, etc. Problem solved!

![how to join two modules at an odd angle? just cover the mess! image by Joe Wintergreen](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MbP02oa-qIyy5tjCgbG%2F-MbP1MY61xgKY_mwqJy4%2FLDB_ModularMeshes_JoeWintergreen.jpg?alt=media\&token=f71a50f4-b28a-420b-84c3-5b718ef45ca0)

### Hero props / landmarks

hero prop / hero building should ground an important place in the level

don't put hero assets in bad places... don't guitar solo a dumpster, it's a dumpster, move on with your life

For multiplayer maps, unique landmarks give identity to an area and help facilitate **callouts**, short memorable nicknames that players can use to quickly talk about different parts of the map.

Below is a hero asset by Lydia Zanotti for site B on the map Breeze in Valorant. The large tower looks important and in active use, with unique dark metal machinery that contrasts with the beige stone ruins. The design supports the game lore that "radianite" (the glowing teal substance) is an important resource to control, as well as a gameplay function leaving its bottom section free of distracting shapes or silhouettes. Most importantly, it is used only once throughout the entire map, making the area feel special and unique.

![paintover concept art, first pass model, and final art pass for Valorant by Lydia Zanotti](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Maemlrnrs4nowWUvJIe%2F-Maenf-2GMcNyr1lfPsO%2FLDB_ValorantArtPass_LydiaZanotti.jpg?alt=media\&token=ccb7a05f-ad7b-49e0-a101-248959568c1a)

### Details (props, foliage, clutter, set dressing)

#### Trees

![General Plant Tips tutorial image by Marie Lazar (pixelbutterfly.com)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MJYbXqtzzgFbu3trUW6%2F-MJYm61VZU5mmrqronrM%2FGeneralPlantTips_MarieLazar.png?alt=media\&token=392f29cc-aa28-47eb-b873-3e50413e04ab)

for tall forest trees don't put canopy on every trunk and make sure there's detail at the base <https://www.gamasutra.com/blogs/DannyWeinbaum/20170216/291658/Art_Tips_for_Building_Forests.php>

## Readability

**Readability** is about whether the player can walk around your level and "read" what they are looking at. Simplify what the player must see. Make it legible.&#x20;

The goal is for the player to understand the level as an whole place, not as a pile of random floors and wall segments.

* Does the player have enough information to understand the current game state?
  * Can they easily see enemies / game objects from a distance?&#x20;
  * Can they understand whether that enemy is idle, aggro, or hurt?
* Can the player understand where they can go vs. can't go, should vs. shouldn't go?

When a level begins in abstract [blockout](/process/blockout.md) form, it is very plain and easy to read. However, as we add additional visual details to the world, the level geometry becomes less distinct and more noisy. An art passed level that is "busy" will be "illegible" and difficult to read.&#x20;

![animated GIF showing visual development and readability for de\_cache for Counter-Strike: Global Offensive, art by Shawn Snelling, from GDC 2015: Community Level Design for Competitive CS:GO](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MR8fRL5joAtwxQl4v1u%2F-MR8hC78BZ5HCKTihHJj%2FLDB_CSGO_de-cache-readability_ShawnSnelling_GDC2015.gif?alt=media\&token=596981b0-d19e-4075-b033-71be1d6788da)

In the animated GIF above, notice how the CS map de\_cache changed from a dark high-contrast level with shadowy busy details to a brighter more evenly-shaded level with les visual contrast -- that concession to readability makes sense for that game and audience.

Some games such as escape rooms, hidden object games, and prop hunts, are all about the joy of parsing busy cluttered spaces. However, fast-paced multiplayer shooters like Counter-Strike or Valorant depend heavily on split-second reflex aiming and snap judgments, and these players would likely blame an unreadable level for their defeat.&#x20;

As you art pass a level and apply set dressing, the accumulation of these details can impact the player's understanding of the space.&#x20;

![internal style guide for ivy readability in The Last Of Us Part 2 (2020) by John Sweeney](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MEdVddyug3bU3Tk5Ibv%2F-MEdXiUXk9J1F0LNQuNE%2FTheLastOfUsPart2_IvyReadabilityStyleGuide_JohnSweeney.jpg?alt=media\&token=21c92616-3df3-4484-9f4c-578de7aa38ed)

For example, when art passing the environments in The Last Of Us Part 2, Naughty Dog artists used ivy coverage (see image above) to denote neglected closed buildings, while clearing ivy for open buildings that the player should enter. Also note how ivy flattens the structure of the facade. The player no longer has to inspect every window to wonder if it's navigable or relevant -- a building utterly consumed in ivy means it is closed, and resolves into a green blob. Thus, ivy functions as a simplifies the visual environment and serves as a navigation aid for the player. As long as all the designers and artists maintain consistency in how they use ivy, this decorative foliage effect takes on a new meaning beyond how fancy and expensive the video game looks.

But here's the secret: everything is ivy, *everything in environment art has a readability function.* When you art pass any part of a level, you are refining the visual patterns that help the player reason about spatial logic.

&#x20;    *Readability also heavily depends on* [*massing*](/process/blockout/massing.md)*,* [*metrics*](/process/blockout/metrics.md)*, and* [*composition*](/process/blockout/massing/composition.md)*.*

### Clustering

To help players parse and understand the game world more easily, try to compose the set dressing in clusters of related details. Proximity, similarity, and implied connectedness helps us see objects as groups and patterns. This corresponds to a [gestalt theory](https://en.wikipedia.org/wiki/Principles_of_grouping) of perception.

To make a rocky outcrop, place one rock, then duplicate, shrink, rotate, and slightly offset... and repeat. To make a forest, place one tree, then duplicate, shrink, rotate, and slightly offset... and repeat. You can repeat this workflow for any type of natural set dressing, or even your landscape compositions. Try to build these compositions in an asymmetrical fractal structure, to give a sense of repeated logic and consistency to the prop placement.

!["fractal" clusters of rocks, trees, terrain, and even buckets, from the Allods Online art bible by Anton Lavrushkin](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MDLePXw3Ye3OrlBz7KR%2F-MDLphnFKdRGmhR28c3X%2FAllodsOnline_Clustering.jpg?alt=media\&token=d10c6c15-aa8c-401f-b969-678b0ca32090)

### Color and value

Avoid deeply saturated colors, give space for lighting... if you make a very red texture, it can't get much redder. Some games might also reserve specific color coding too (only explosive barrels are red! only doors can be blue and orange!)

Gradients are smooth (not noisy) but still avoid flatness (there is hierarchy)

In the example GIF below of the map "Castillo" from Overwatch, notice how the ground is generally darker than the surrounding walls; wall textures are plain with minimal noisy details; red and pink are generally reserved for floor and roof planes.

![example blockout to art pass process comparison GIF of map "Castillo" by Helder Pinto (and others), for Overwatch](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FOyo51Rroc44MfJRnp5l7%2FLDB_ArtPassBlockout_Castillo_Overwatch_HelderPinto.gif?alt=media\&token=75455ccb-09cc-40f2-bbaa-a2df5de29396)

### Materiality

A material is a specific technical term for a group of textures imported into a game engine -- but more broadly, "material" also refers to **materiality** -- the general feel, substance, mass, and physical matter represented by the visual surface.&#x20;

Ideally, an environment texture should read as a distinct real world material. Does the texture truly feel like it's made of brick or rock? Is it too shiny to feel like concrete? Does the glass or wood feel brittle or strong? Being able to read a material is often important for gameplay; for instance, footstep and bullet penetration are common mechanics in tactical shooter games, and rely on players understanding the material they're walking on / shooting at.

As a general rule, most artists strive to craft textures made of clear and distinct materials. A wood texture should still look like wood from 50 meters away, and a shiny metal texture should feel different from a shiny plastic texture.

&#x20;    *For more on textures and materials, see* [*Texturing*](/process/env-art/texturing.md)*.*

![different world textures convey different surface properties and materials; textures by Marie Lazar (from 80 Level)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MJYbXqtzzgFbu3trUW6%2F-MJYmZOmk-JTX_yMsK8u%2FTerrainTextures_MarieLazar.png?alt=media\&token=dc6f5eb1-ecba-474c-84e0-9374391a2cb0)

### Avoid shape and color psychology

**Shape and color psychology** are theories that shapes / colors convey universal ideas and influence behavior.&#x20;

While artists often crave secret power over people, we argue that **shape and color psychology are not effective for level design**. Abstract geometric shapes and colors, by themselves, do not make all humans feel the same thing nor communicate the same ideas. These simplistic theories fail to capture the rich complexity of art and culture, misunderstand basic psychology, and overshadow much more useful design tools. You're better off without them.

&#x20;   *For more, see* [*Shape and color psychology*](/process/env-art/psychology.md)*.*

## How to art pass

There are many ways to approach an art pass, but here's some general advice:

* **WORK ITERATIVELY** in stages, don't try to make the 100% final version of every asset. You need to see how the art assets will relate to each other, in context, to know if an asset is "finished" or not. When surrounded by other art in the game world, sometimes a 50% finished art asset can actually be 100% "finished enough".
* **ART PASS WITH FOCUS,** don't just art pass random parts of random areas. Try to push progress along in specific parts of the level, in specific ways or themes, so you can get feedback on your changes. If you art pass haphazardly in incoherent ways, then it is more difficult for others to give you feedback.
* **START BIG**, and save smaller details for later art passes. Define your basic shapes and massing, color palette, and main themes first. Then after nailing all your fundamentals, you can finally move on to sculpting pebbles or painting grunge marks.

For each animated GIF example below, try to count the number of art pass iterations.

![series of art passes for 2D pixel art game Minit, posted by Kitty Calis (via Twitter)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M-evfaxsvlyM7PJms12%2F-M-ewT7nGJ6DE0X95O_G%2FMinit_KittyCalis_ArtPass.gif?alt=media\&token=60b63a13-5fb6-47d8-95a1-05fc2d2d7a53)

![series of art passes and iterations for a portfolio piece by Kieran Goodson (via 80 Level)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MDM6LMFqpAPY2U5YW4M%2F-MDM96X6Fn4gPcXSnxjJ%2FKieranGoodan_ThoseWhoMourn_Iteration.gif?alt=media\&token=ce82040e-b792-4fb5-843a-7fbaac4c28dd)

### Make a prop zoo / warehouse / showcase map

Similar to metric playground maps and modular kit loopback tests, the best way to validate environment art is to try using it in-game. **Make a scene or level with every prop / art asset, and walk around in it.**

Charles Boury, art director on Caravan Sandwitch, offers this advice for showcases:

> *I typically create: ShowcaseCharas for every character, ShowcaseProps for an Ikea-style overview of every game props, ShowcaseMats for a grid-view of every material in different light conditions, and ShowcaseUI for a scene where I can play with every UI element.*
>
> *Note the word "every." Exhaustive lists let you oversee the game content and build confidence. When you work on, say, the pickup UI, you can test it with all pickable items. When you ask yourself, "Is the color red used on a character?", or when the team asks you a specific question like, "how many props use complex collisions instead of simple and why?", you can answer confidently.*

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FrRMCa2UK0choS1zjI9EL%2FLDB_EnvArt_CharlesBoury_Road96_PropShowcaseScene.jpg?alt=media&amp;token=4fe85b1c-b8db-40d3-90b7-f2ebaae925cf" alt=""><figcaption><p>in-editor screenshot of the ShowcaseProps scene for Road 96, by Charles Boury via <a href="https://charlesboury.fr/articles/scene-setup-for-art-direction.html">"Scene setup for art direction"</a></p></figcaption></figure>

> *As an art director, I'm pushing for a specific style. I don't focus on a single prop or character. I'm constantly looking for the big picture, the artistic unity. So how can I make my life easier for this goal?*
>
> *I want to see an organised arrangement of all the props to check their palette, silhouette and level of details. A nice warehouse would be neat, with all the game props, nicely grouped by category, arranged on a grid, so I can compare them and chose witch one to improve. What parts of the game need more consistency? How can I play with this kit to create something unique?*
>
> \-- Charles Boury, from ["Scene setup for art direction"](https://charlesboury.fr/articles/scene-setup-for-art-direction.html)

<div data-full-width="true"><figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F8yWTahQjStAIhlk0dyyw%2FLDB_EnvArt_CharlesBoury_CaravanSandwitch_PropWarehouseScene.jpg?alt=media&amp;token=878d9366-e06b-45b2-adbd-529095284ae0" alt=""><figcaption><p>in-editor screenshot of the prop warehouse test level for Caravan Sandwitch, by Charles Boury via <a href="https://charlesboury.fr/articles/scene-setup-for-art-direction.html">"Scene setup for art direction"</a></p></figcaption></figure></div>

## Example art passes

### "Icebox" for Valorant (Riot Games)

Because Valorant is a competitive multiplayer shooter that depends on precise map [balance](/process/combat/balance.md), Riot tailored their art pass process to preserve the level designer's blockout as much as possible. Before entering art production and detailing phases, Valorant maps go through extensive month-long greybox ([blockout](/process/blockout.md)) and [playtest](/process/blockout/playtesting.md) phases as well as several initial *art blockout* passes to test color swatches and [massing](/process/blockout/massing.md). This *art blockout* gives extra time for level designers to make more changes to the level geometry, and propagate those tweaks back to the artists with minimal waste. Prolonging the blockout stage improves the final art pass and allows for more collaboration between departments.

> Before 3D artists can touch a map, our Art Lead and Creative Director work very high level with the concept artists to iterate on finding an iconic look for our maps using a series of blue-sky concepts. At this stage there's a lot of back and forth between the artist and project leadership to make sure the map follows the VALORANT narrative, is marked by visual variety, and most importantly, is something the team is really excited to be working on.
>
> After a high-level direction has been locked down, concept artists begin to tackle specific locations and call-outs on the map based on the greybox layout. At this stage, the concept artists try to get as much coverage on the map before the 3D artists jump in and begin modeling the basic shapes of the architecture.

![graybox to "art blockout" to "art production" workflow of map Icebox for Valorant (via PlayValorant.com)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MMXTx6oRpuSjL5oozQ5%2F-MMXlMVK1BXylPPgyTSE%2FValorant_LydiaZanotti_IceboxBlockoutFlow.gif?alt=media\&token=c4187993-6303-430c-bf02-8cbb4047ff9f)

> We try to model and get the basic architectural shapes into the map before starting to unwrap and texture them. When we start to add colors on the meshes, we make sure that they aren't too dark, especially in interior spaces. The objective here is to maintain gameplay integrity by making sure that the environment doesn't impede with clarity, and that the characters are always clearly visible.
>
> As far as texturing goes, we primarily use tiling textures and trim sheets on our buildings and large structures. These are created using a variety of programs such as Zbrush, Substance Designer, Substance Painter, and Photoshop. We do use custom textures on props when needed, such as the coffee machine in the kitchen, or the forklift near A-site.
>
> \[...] To help with visual noise, we make sure that our materials are similar in value and there isn't too much contrast or darkness. We can also improve clarity by using lights to illuminate dark areas, or to spotlight spaces where you would want the most visibility possible, such as a Spike plant site or a commonly peeked corner.
>
> \-- from ["The Art of Valorant Map Environments"](https://playvalorant.com/en-us/news/dev/the-art-of-valorant-map-environments/) by Lydia Zanotti

![progression of "Kitchen" area in "Icebox" from blockout to art blockout; the hallway becomes a room! (via PlayValorant.com)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MMaJShq300eEuVgAbnc%2F-MMaSudK0YXoK1BdAEST%2FValorant_LydiaZanotti_IceboxKitchenBlockout.gif?alt=media\&token=421ac229-937a-4c4d-a68e-b477ab8b46e3)

## To review\...

**Environment art** is about decorating and refining the visuals of a level.

Industrial artists tend to do a lot of planning in the form of **concept art**, **paintovers**, and **model sheets**. Based on those plans, they generate an **asset list** so they can figure out how much work they have to do.

Common environment **art assets** include **world textures**, **modular kits**, **hero props**, and  general **set dressing** props like foliage and clutter.

When making assets, artists should consider **readability**: how an object's visual appearance suggests affordance (functionality and usefulness). To improve readability, **cluster** details together in groups, pay attention to **color and value**, and make sure **materials** read clearly.

We argue strongly **against** [**shape and color psychology**](/process/env-art/psychology.md).&#x20;

**How to art pass**:

* focus on swapping-in big important common core objects / shapes first
* do not try to finish each asset 100% one-by-one, instead it's better to **work iteratively:** get multiple objects to 50%, then step back and evaluate

## Now what?

* Continue on to [**Release**](/process/release.md).
* ~~Stop reading a level design book, and go find an environment art book / website instead~~.
* Read more about a certain aspect of environment art in more detail...

### Env art in detail

Working environment artists often specialize in one aspect:

* **Modeling and sculpting.** Hard surface architecture and props, or nature and foliage?
* [**Lighting**](/process/lighting.md) heavily affects how players perceive shape, depth, space, and mood.
  * *Is that wall far away or close by? Is this room shallow or deep? Is it scary?*
* [**Texturing**](/process/env-art/texturing.md) is important for reading shape, surfaces, and materials.
  * *Is that wall made of wood or metal? ... Alien metal? Are there aliens nearby?*

[**Storytelling**](/process/env-art/storytelling.md) and set dressing give a sense of place / lived-in feel.

After an art pass, levels often require [**optimization**](/process/env-art/optimization.md).

## Further reading

Remember, this is a level design book, not an env art book. You should definitely go somewhere else to learn more.

* For links to environment art sites, see [Communities: Environment Art](/appendix/communities.md).
* [Environment Art blog](https://environmentart.wordpress.com/) by Rogelio Olguin (discontinued since 2016, but still lots of good stuff)
