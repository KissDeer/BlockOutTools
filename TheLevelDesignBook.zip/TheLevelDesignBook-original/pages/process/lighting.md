> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/process/lighting.md).

# Lighting

How to light a game level with functional lighting strategies

**Lighting design** is about placing lights in the game world to create visual depth, evoke mood, and provide information to help players play. Poorly lit spaces often feel stale, flat, unfinished, or confusing.&#x20;

Since lighting is so important for readability, we recommend a lighting pass during / soon after establishing core gameplay in [blockout](/process/blockout.md) or [scripting](/process/scripting.md) phase.

The industry usually categorizes lighting as an aspect of [environment art](/process/env-art.md), but here we will focus less on graphics and more on the *design* and *function* of lighting. **What do lights say and do?**

![lighting study blockout by Harley Wilson (via Artstation)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mh1jhg_FeQx6xy8Qe6b%2F-Mh1l4etNtZek9bhQ0N1%2Fharley-wilson-lightstudies-gallery-a.jpg?alt=media\&token=48dcc7f9-03af-4696-8802-0815142c8258)

In the study above by Harley Wilson, **lights tell us a lot about the game world and help us play:**

* [Worldbuilding](/process/preproduction/worldbuilding.md). Recessed down-lights along a wall suggest a fancy modern gallery.&#x20;
* [Massing](/process/blockout/massing.md). Cooler grays wash a gallery wall, warmer lamps highlight counters, dim down-lights mark a shadowy corner. Lights divide this area into three sub-areas.
* [Circulation](/process/layout/flow/circulation.md). The far wall is dark, maybe it leads to a backdoor or a closet. It's probably not a primary exit, which would be lit more prominently.

## What is video game lighting?

In real-life, **light** is visible energy that interacts with surfaces. It is an elegant system; with the core physics of energy and photons, you can derive all other complex light effects.

In contrast, **video game lighting is NOT elegant.** It's a fake-as-hell fucking mess, secretly made of many different subsystems in a game engine:

* **Light sources:** base layer of direct illumination, based on light angle and position
* **Shadows:** objects occlude (block) light and project shadow maps onto other objects
* **Materials:** the color, texture, opacity, and reflectivity of 3D surfaces
* **Postprocess:** screenspace effects like color correction, bloom, and HDR eye adaptation
* **Reflections**: true reflectivity requires re-rendering the scene; most games use approximations
* **Baking:** developers pre-render lightmaps and reflection data

!["What is light vs how games simulate it" slide from "Invisible Intuition: How To Light A Level" by Robert Yang for GDC 2018](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M5r9p0t_N4YdGAGzU72%2F-M5rGJ1UKaoauOapkH68%2Fimage.png?alt=media\&token=a62c3f84-ea68-4e1b-8494-03c35f615ce4)

Imagine making a rainbow with a prism. In real-life, you shine a ray of light through a prism and a rainbow "automatically" emerges because that's how photons and physics work.

But in a video game, a prism effect would be a mess of hacks:

* Refracting glass material + screen space reflection for prism shape
* Ray FX, white beam and rainbow painted separately in Photoshop
* Glow sprites where beams intersect prism
* Caustic projections / translucent AO for nearby surfaces

This is not an elegant universe of photons interacting with surfaces. In the list above, notice that we're not even using any light sources! It's all "fake"!

![spotlight casting shadows in Unreal Engine 4, by Oskar Świerad (via UnrealArtOptimization.com) ](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MDFrS7d2iceRHGyB9iy%2F-MDG7b0dncAtcCji6NGu%2FOskar%C5%9Awierad_UE4_SpotlightShadow.jpg?alt=media\&token=3f64a7f0-e637-4abb-99f7-eeabcc4f1073)

**Lighting a video game is about picking and choosing only what you need.** In most game engines you can set one light to turn off shadows, or set another light to disable reflectivity. This is essential for [optimization](/process/env-art/optimization.md).

It's enough to make a real-life physicist vomit. "But light without shadows or reflectivity doesn't make any sense," cry the physicists. Haha, silly physicists! This is video game land!

{% hint style="info" %}
*Graphics programmers are secretly bothered as much as physicists. Tech like raytracing is about trying to make game lighting more elegant. Maybe in 10 years it will be.*
{% endhint %}

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FChB7rIKaR9AgeCaZzVlP%2FLDB_LightingShadowVolume_ShadowMap_ToyStory3.jpg?alt=media&amp;token=de0fa0f5-c859-4d06-9957-b5a88d59d77a" alt=""><figcaption><p>(left) <a href="https://commons.wikimedia.org/wiki/File:Shadow_volume_illustration.png">Shadow volume illustration</a> by Rainwarrior, CC BY-SA 3.0; (right) slide from <a href="https://advances.realtimerendering.com/s2010/Ownby,Hall%20and%20Hall%20-%20Toystory3%20(SIGGRAPH%202010%20Advanced%20RealTime%20Rendering%20Course).pdf"><em>Toy Story 3: The Video Game Rendering Techniques</em></a><em>; both from</em> <a href="https://30fps.net/pages/videogame-shadows/">"Classic 3D videogame shadow techniques" by Pekka Väänänen</a></p></figcaption></figure>

### A brief history of light

The sun and the moon (reflecting light from the sun) are the most common *natural light sources*.

There are also *artificial light sources* like controlled fires, gas lamps, incandescent light bulbs... and in the 21st century, there's energy-efficient fluorescent lights and LED lighting.

However, this is not just a story of technology and progress. The light bulb did not make the sun obsolete, and the LED does not make fire obsolete. We still like sunny days and romantic candle-lit dinners.&#x20;

Fire has not disappeared from the world. Instead, the meaning and use of fire has changed. Lighting design is about understanding how light conveys these ideas, moods, and emotions.

![various light sources throughout history: sunlight, fire, gas lamp, incandescent, fluorescent, LED](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M5r9p0t_N4YdGAGzU72%2F-M5rOSXBlcuTxveLWskH%2Fimage.png?alt=media\&token=44a99633-1044-4933-ad0d-22d77eeb3628)

## **What is lighting design?**

**Real-life lighting design** is the art / science of placing light sources to account for context and functionality, whether for an office or a moody restaurant.&#x20;

Real-life professional lighting designers assess building plans and coordinate with architects. They shop in catalogs published by light fixture manufacturers, with detailed technical specifications and lab-tested light falloff charts / standardized IES profiles that they can test in 3D simulations. They must also balance local laws and building codes about minimum light levels, budget, maintenance plans, energy use, and sustainability.&#x20;

![light fixture catalog with distribution curves / falloff charts in standard candelas (cd) from the Daeyang Electric catalog](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M5r9p0t_N4YdGAGzU72%2F-M5rOgrDrZy0fKl83cAh%2Fimage.png?alt=media\&token=53bce699-b568-4804-ad4a-d746761ac5fd)

Because eyes adapt to nearby light levels, it is difficult to guess how bright a room actually is, so lighting designers often approximate a quick measurement with the [lumen / zonal cavity method](https://en.wikipedia.org/wiki/Lumen_method). For a more accurate reading on-site, they also use handheld [light meters](https://en.wikipedia.org/wiki/Light_meter) to measure scientific units like [lux](https://en.wikipedia.org/wiki/Lux) / [lumens](https://en.wikipedia.org/wiki/Lumen_\(unit\)) / [candelas](https://en.wikipedia.org/wiki/Candela).

Some game engines are increasingly adopting this technical / scientific lighting approach. However, we must be vigilant: **real-life lighting design has fundamentally different goals vs. video game lighting design.**

### Real-life vs. video game lighting design

| REAL-LIFE LIGHTING                         | GAME LIGHTING                        |
| ------------------------------------------ | ------------------------------------ |
| Runs on electricity                        | Also runs on electricity             |
| Must obey laws of physics                  | Pick and choose laws; godless        |
| Follow local regulations                   | No regulations, only gamer norms     |
| Infinite light sources, infinite rendering | Optimize for fewest light sources    |
| Long-term, you live in it                  | Short-term, you visit it             |
| Glare is literally painful to look at      | Glare makes your game worth $60      |
| Comfort, safety, usability, reliability    | Drama, detail, clarity, plausibility |

![recommended reflectance and luminance ratios for real-life classrooms, from IESNA Lighting Handbook 9th edition ](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MLZHB4Gq5K71kSeQI2x%2F-MLZIVnpEd3umSOztVXz%2FClassroomTaskLighting_IES-Handbook-9thEdition.jpg?alt=media\&token=21f767fc-09ed-4acc-9a60-f9ba113ec64a)

## Light sources

Since game lighting is so complicated, we will mostly focus on the fundamentals of lighting design for level designers: *placing light sources.*

* Core light source types
* Static vs. dynamic light sources
* Fixture vs. light source

### Core light source types

Almost every game engine uses these four core light source types:&#x20;

* **Ambient light** is the default minimum amount of light in the world. Not really realistic.
* **Directional light** casts constant light from a direction, like sunlight downwards from the sky.
* **Point lights** (omnidirectional / "omni" light) are like light bulbs, throws light in all directions.
* **Spotlights** cast a cone of light in a certain direction from a certain position.

(TODO: light source diagram)

Together, these light sources form a complete domain of basic lighting tools:

|                            | *Global, affects everything* | *Local, affects nearby things* |
| -------------------------- | ---------------------------- | ------------------------------ |
| *Shines in all directions* | **Ambient light**            | **Point light**                |
| *Shines in one direction*  | **Directional light**        | **Spotlight**                  |

Other light shapes are just variations on these core types.&#x20;

* Area lights are wide flat rectangular spotlights
* Tube lights are long point lights
* Emissive materials / "texture lighting" use self-illuminated pixels like point lights

### Static vs dynamic

A **static light** does not change at all, while a **dynamic light** can change in color, intensity, direction, or position.&#x20;

Static lighting is almost always better for framerate because the engine can "bake" lighting data like lightmaps and reflections -- but rebaking constantly gets annoying, and lighting data can consume a lot of memory.

In contrast, dynamic light means the level can change and react, enabling switchable moving lights and day-night cycles -- but if there's too many light sources, then it might overload the player's machine and the framerate will suffer.

![lightmap UV charts for the "New York City" map in Overwatch 2, image by Bruce Wilkie (via PlayOverwatch.com)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FvVVA3kCJa59h55eVl6kJ%2FLDB_Overwatch_NewYork_LightingLightmapUV.jpg?alt=media\&token=b30f5298-f8b0-4976-8286-95d45587cda7)

### Fixture vs light source

A **light fixture** is a visible plausible source of light, like a light bulb or a fireplace. But a window with sunlight is also like a fixture. Within a game level, this is usually like an architectural feature or a decorative lamp prop.&#x20;

This is not the same as an in-engine light source, which is actually an invisible source of light with no apparent cause. It often looks kind of weird, and simply doesn't happen in real-life.

A **motivated light** is a light source with a plausible fixture.&#x20;

Note that a *single fixture may actually motivate multiple invisible in-engine light sources.* In the image pictured below by Harley Wilson, there are only two visible light fixtures: an orange fireplace and a blue-gray window. *But what looks like two lights is actually 11+ light sources!*&#x20;

![medieval lighting study with light entities by Harley Wilson (via Artstation.com)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mh1jhg_FeQx6xy8Qe6b%2F-Mh1lkxbVgbUXAxBnb8b%2Fharley-wilson-natlight-b.jpg?alt=media\&token=1874b909-60db-4a01-bec9-a70b46939966)

## Lighting theory

Here are two ways of approaching lighting design:

* **Three point lighting:** common theory for 2D media like film and photography
* **D6 lighting:** more abstract but more 3D, for architects and interior designers

### Three point lighting

**Three point lighting** is a lighting theory with three types of lights:&#x20;

* **Key light:** the primary light source
* **Fill light:** softer secondary light source to brighten up shadows
* **Rim light:** an accent to highlight objects and edges

While these core concepts are useful, it has limitations for level design. This technique comes from photography and film, so it assumes linear fixed 2D screen compositions -- not an interactive 3D space that a viewer navigates freely.

&#x20;    *For more about this 2D lighting theory, see* [*Three point lighting*](/process/lighting/three-point.md)*.*

![Three point lighting is common in studio photography and portraiture](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M5rlFmncyIXoXRqtvCg%2F-M5rlaC0MUadbCSg1V6u%2Fimage.png?alt=media\&token=675a3dc8-656b-48b5-99e7-b666b1a4a6b5)

### D6 lighting

**D6 lighting** is a lighting theory focused on coverage and space, inspired by a six sided die. Each side represents a lighting strategy, for a total of six strategies:

1. Focal point ⚀&#x20;
2. Focal frame ⚁
3. Path ⚂
4. Area ⚃
5. Area with focal point ⚄
6. Area with path ⚅

This theory has more applications for architecture and level design, however it's obscure and less known than three point theory.

&#x20;    *For more about this 3D lighting theory, see* [*D6 lighting*](/process/lighting/d6-lighting.md)*.*

![lighting study blockout breakdown by Harley Wilson (from Artstation.com)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mh1mNI_tiSCuAbzXquW%2F-Mh1mXYcMcyZcqKv8emk%2Fharley-wilson-lightstudies-gallery-breakdown.jpg?alt=media\&token=33df6952-da49-4a01-abc6-b551d822ecdc)

## How to light a level

Lighting can be very time-consuming, so don't attempt to do final lighting all at once. Instead, build flexibility into your workflow, and work iteratively.&#x20;

We recommend lighting in four passes:

* Global lights
* Wayfinding / critical path lights
* Gameplay / combat encounter lights
* Detail and mood lighting

### 1. Global lights

Begin with an initial pass at any global key lights and fill lights: skylight, ambient light, and any skybox / atmospherics.

If you are using any emissive materials as key lights, e.g. a glowing river of lava, then configure this light source as well.

If your desired look involves baked indirect light, run an initial low quality light bake immediately. Some fancy global illumination solutions (e.g. UE5 Lumen) may be able to light the entire game world with just one sunlight-like directional light.

### 2. Wayfinding / critical path lights

Next, ensure any important entrances / exits along the [critical path](/process/layout/criticalpath.md) are well-lit from the desired approach. You will likely need to use local light sources, e.g. place a light fixture next to a doorway.

Build a hierarchy. Big important exits should have more important looking lighting, while secondary spaces should have dimmer less focused lights.

![brightly lit doorways help players understand the flow of the room; from "Functional Lighting" by Magnar Jenssen ](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M5ruGTmxK9H3eCYQsFt%2F-M5ruNrN3D_AxRnWf-xQ%2Fimage.png?alt=media\&token=160aa72b-c2d5-45f6-bd15-141b81d413b3)

### 3. Gameplay lights

Lighting to foreshadow encounters (enemy approach, battle line, possible strategies and flanks)

Lighting to highlight puzzle elements and suggest areas to explore

![strong spotlight draws attention to enemy silhouettes; from "Functional Lighting" by Magnar Jenssen ](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M5rqI6V5Agj7jeWbPt3%2F-M5rrW4E6fHXAg2VRzKi%2Fimage.png?alt=media\&token=e49e8af5-af56-4e3f-b5f1-6b7ad8545b7b)

### 4. Detail and mood lighting

Fine tune and tweak everything, but don't spend too long, it probably looks good enough, and if you tweak it too much you might destroy the effect from a previous pass.

(TODO: images and examples?)

## Common lighting design problems

### Shadows are too dark after a light bake?

Your albedo textures might be too dark. If the textures are too dark, then any resulting light bounces will be faint, no matter how bright your lights are. Unless you have specific stylistic or technical reasons to do otherwise, your main diffuse textures should usually be in the 50-100% brightness range. See ["Texturing Values for Environments"](https://environmentart.wordpress.com/2016/06/13/texturing-values-for-environments-part-1/) by Rogelio Olguin, and the old Epic Games UDK docs ["Epic Games Texturing Guidelines"](https://docs.unrealengine.com/udk/Three/TexturingGuidelines.html).

![dark albedo texture (top) vs midtone albedo texture histogram (bottom), from "Epic Games Texturing Guidelines" ](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MDGbZbTuuEIVkJG1HA_%2F-MDGeWgGPxEz0otOHsOt%2FEpic_UDKWiki_TextureGuidelines_HistogramAlbedo.jpg?alt=media\&token=d5b6d670-a058-42e2-a6e2-936e038b0d02)

![Comparing a scene with dark albedo texture (left) vs. midtone albedo texture (right), from "Epic Games Texturing Guidelines" ](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MDGRaZ_a1Kw1oOBonuI%2F-MDGYkCBeFZlKSdnD6Kq%2FEpic_UDKWiki_TextureGuidelines_AlbedoComparisonScene.jpg?alt=media\&token=c650e9a5-768b-4e4b-9342-88b3ab49779a)

## Lighting examples

TODO: showcase different contexts (industrial vs residential) and moods (scary, comfy)

![lighting variations diagram for level design by Simon "Sock" O'Callaghan](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MktJBZLbAxA14EASwco%2F-MktJXhYMCPZnDxYaXiN%2FLDB_Lighting_Sock_SimonOCallaghan.jpg?alt=media\&token=0da0413a-45a0-42b4-951d-2a0a7a70f529)

## Lighting example: Ratchet and Clank - Rift Apart

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F5MxD1YuBjG0cMwxtGd9t%2FLDB_LightingWorkflowDiagram_RatchetAndClankRiftApart.jpg?alt=media&amp;token=4a497ad9-1394-438a-8097-2a02ab83cb49" alt=""><figcaption><p>Lighting workflow overview for Ratchet and Clank: Rift Apart, from <a href="https://www.youtube.com/watch?v=geErfczxwjc">GDC 2022: Recalibrating Our Limits: Lighting on 'Ratchet and Clank: Rift Apart' (via YouTube)</a></p></figcaption></figure>

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FQXcAhmVUCbOq5Z1HMAyf%2FLDB_LightingExposure_RatchetAndClankRiftApart_GDC2022.jpg?alt=media&amp;token=85a15e8b-d2b9-4ea8-86ab-ade854a5b206" alt=""><figcaption></figcaption></figure>

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F0fCSdPoqQUZUfnzTjIMm%2FLDB_LightingShadows_RatchetAndClankRiftApart_GDC2022.jpg?alt=media&amp;token=080cfdb1-a4c7-4ac6-961b-5aabd0d9f50e" alt=""><figcaption></figcaption></figure>

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F5YfbuBcONnQD9qq3iibu%2FLDB_LightingOptimizationProfiling_RatchetAndClankRiftApart_GDC2022.jpg?alt=media&amp;token=b7e83cc4-008a-4e31-8806-c5afcdca2f28" alt=""><figcaption></figcaption></figure>

## To review\...

**Lighting** gives visual depth to a scene, allowing players to gauge distances and distinguish shapes. Because it serves a very important gameplay function, you should do a **lighting pass** early in the level design process, before a proper art pass.

Video game lighting tech is a crude illusion that approximates real-life light. Many game lighting effects do not actually use any lighting systems.

There are 4 core light source types: **ambient, directional, point, and spotlight.** These lights can be *static* or *dynamic,* and **motivated** by a visible **light fixture** or *unmotivated* without any visible source.

The most common lighting theory is three point lighting, which defines **key lights**, **fill lights**, and **rim lights** based on the light's orientation to the camera and subject.

To light a level, work gradually over several lighting passes. Do global lights first, then light for wayfinding, and then for gameplay, and finally any last details or moods.

## Now what?

* Move on to [Environment Art](/process/env-art.md).
* Lighting is traditionally the most performance-heavy visual aspect of a level. After a lighting pass, you'll want to do an [optimization](/process/env-art/optimization.md) pass.

## Further reading on lighting

### Game lighting

* ["Functional Lighting"](http://magnarj.net/article_funclight.html) by Magnar Jenssen is about lighting levels to aid readability for typical shooter gameplay.
* ["Gamma and Linear Space"](https://www.kinematicsoup.com/news/2016/6/15/gamma-and-linear-space-what-they-are-how-they-differ) by Kinematic Soup covers an important but often neglected aspect of game graphics: color space and gamma curves.
* [GDC 2022: Recalibrating Our Limits: Lighting on 'Ratchet and Clank: Rift Apart' by Anna Roan and Brian Mullen (via YouTube)](https://www.youtube.com/watch?v=geErfczxwjc) is a great overview of how many AAA lighting artists work today, with lots of process and iteration examples.&#x20;

### General CG lighting

* [Blender Conference 2022: The Secrets of Photorealism by Andrew Price (via YouTube)](https://www.youtube.com/watch?v=Z8AAX-ENWvQ) is a video intro to lighting 3D scenes for photorealistic look. Color temperature, falloff, materials, and optics / post process.

### Real world lighting design

* *The Architecture of Natural Light,* by Henry Plummer. Monacelli Press: 2009.
* [*IESNA Lighting Handbook*](https://openlibrary.org/books/OL58383M/The_IESNA_lighting_handbook), 9th edition (2000). edited by Mark S. Rea.
