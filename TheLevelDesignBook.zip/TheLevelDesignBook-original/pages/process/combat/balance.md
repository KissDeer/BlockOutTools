> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/process/combat/balance.md).

# Map balance

The player's options throughout the level, the fairness of where the player can go

## Why balance a level?

**Map balance** is the real and perceived fairness of player positioning throughout a level. Will the player blame themselves for not understanding how to use the level, or will they blame the level designer for putting them in an impossible situation?

A well-balanced level supports a variety of play styles and keeps players invested in the outcome, while a poorly balanced map might drive players to quit out of frustration or apathy.

Although we can generalize balance to apply to any level, balance is mostly important for combat-oriented levels and competitive multiplayer maps.&#x20;

#### Single player has no balance

For games about defeating an AI opponent, the idea of "balance" makes no sense. Almost all cooperative "Player vs Enemy" (PvE) and single player games are purposely unbalanced in the players' favor.

Enemy AI will purposefully take bad positions with obvious weaknesses because the game is designed to be completed promptly. Here, a "fair" level gives players ample information and opportunity to triumph. **The purpose of the AI opponent is to lose in an interesting way.** Essentially we must rig the game in the players' favor, and give the player compelling opportunities to rig it further.

So when we talk about map balance, we mean *multiplayer map balance,* not single player / PvE.

&#x20;   *For more on single player / PvE / co-op combat, see* [*Encounter*](/process/combat/encounter.md) *instead.*

## Game balance

First let's review the basics of general game balance.

### Counters

In [rock paper scissors (RPS)](https://en.wikipedia.org/wiki/Rock_paper_scissors) each move **counters** another. Competitive games frequently rely on a RPS metaphor for balance. Fighting games like Street Fighter boil down to Attack Throw Block (attack beats throw, throw beats block, block beats attack). Strategic war games like Starcraft are Infantry Artillery Cavalry (infantry beats cavalry, cavalry beats artillery, artillery beats infantry). This pattern varies across games and genres (Melee, Spellcaster, Ranged... Shotgun, Sniper, Rifle... Tank, Support, DPS... Carry, Top, Mid, Jungler, Support).

From this perspective, **balance means offering counters.** If the player never has any possible counters for their opponent's move or strategy, then the system is unbalanced. **Any balanced counter system needs 3+ options**, so that countering a counter (["yomi"](http://sirlingames.squarespace.com/articles/yomi-layer-3-knowing-the-mind-of-the-opponent.html)) is a third option distinct from their original first option as well as their opponent's second option. (e.g. "Rock Paper" doesn't work.)

![diagram comparing Rock Paper Scissors vs Attack Throw Block (right image by David Sirlin, from https://www.sirlin.net/articles/designing-yomi)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mcc3b3rR1ccj1YueH1G%2F-Mcc6-KgUdn3xnL5DyUh%2FLDB_RockPaperScissors_YomiCounter_Balance.png?alt=media\&token=922d7177-248d-4735-8ede-d08a18324e55)

### Dilemmas, payoffs, dominant strategies

The prisoner's dilemma is a 1950s thought experiment designed by a US military think tank and it is a core concept in [game theory](https://en.wikipedia.org/wiki/Game_theory):

> Two members of a criminal gang are arrested and imprisoned. Each prisoner is in solitary confinement with no means of communicating with the other. \[...] Each prisoner is given the opportunity either to betray the other by testifying that the other committed the crime, or to cooperate with the other by remaining silent. The possible outcomes are:
>
> * If A and B each betray the other, each serve two years in prison
> * If A betrays B but B remains silent, A will be set free and B will serve three years in prison
> * If A remains silent but B betrays A, A will serve three years in prison and B will be set free
> * If A and B both remain silent, each serve only one year in prison

Here are the possible outcomes expressed as a **payoff matrix**, where years in prison are expressed as negative points and the goal is to maximize the highest score:

|                                | B stays silent (cooperate)       | B betrays (defect)                |
| ------------------------------ | -------------------------------- | --------------------------------- |
| **A stays silent (cooperate)** | A: **-1** year,  B: **-1** year  | A: **-3** years,  B: **0** years  |
| **A betrays (defect)**         | A: **0** years,  B: **-3** years | A: **-2** years,  B: **-2** years |

In this standard version of prisoner's dilemma, game theorists argue that players should always defect. Why? Imagine you are A. If B cooperates, then you should defect, because 0 years in prison is better than 1 year in prison; and even if B defects, then you should still defect, because 2 years in prison is better than 3 years in prison.&#x20;

{% embed url="<https://www.youtube.com/watch?v=S0qjK3TWZE8>" %}
the Prisoner's Dilemma was most popularly dramatized in the UK game show Golden Balls' final round "Split or Steal"
{% endembed %}

For this reason, defecting is a **dominant strategy** because it doesn't matter what the other player does. Always defecting will earn you a win at best, and a tie at worst. In terms of costs / points, you literally cannot lose if you always betray the other player. To understand why, [watch the most famous moment from the UK game show Golden Balls](https://www.youtube.com/watch?v=S0qjK3TWZE8), where contestant Nick Corrigan uses this dominant strategy against fellow contestant Ibrahim Hussein to sublime effect.

From this perspective, **balance means avoiding dominant strategies in your system**, and a dominant strategy is a play pattern that earns the highest theoretical payof&#x66;**.** If there is a dominant strategy, then theoretically all rational players will choose it, which makes the rest of the strategies irrelevant, and thus, unbalanced.

### Feedback loops

A heater is a simple self-balancing system. When a heater detects that it is too cold, it heats up; when the heater detects that it is too hot, it stops heating itself. In [system dynamics](https://en.wikipedia.org/wiki/System_dynamics), this *negative feedback loop* is a **balancing loop** because it stabilizes the system's state. In contrast, imagine a heater that heats up more when it gets hotter, eventually catching on fire and burning down a house -- this is a *positive feedback loop*, a **reinforcing loop** that strengthens its own effect.

In games, **balancing loops help weaker players recover from mistakes**. For example, racing games often "rubber band" those in last place by gifting them faster speed bonuses (e.g. an AI car in Gran Turismo) or better items (e.g. a blue shell powerup in Mario Kart), thus making a race feel more exciting and competitive. However, this can also lead to accusations of unfairness, or drawn-out matches that feel like artificial stalemates. **Reinforcing loops help stronger players increase their advantage,** like in any game where resources beget even more resources (e.g. in Counter-Strike, money buys better guns, which make kills easier, which earns more money, which buys better guns... etc.).

(feedback loop diagram)

### Balancing for feel

Game balance may now seem like a mathematical thing you can prove -- if all the counters and feedback loops and numbers add up, then your game or level is now perfectly balanced!&#x20;

Behold, the *perfectly balanced* payoff matrix for standard rock paper scissors:

|                      | B plays Rock   | B plays Paper  | B plays Scissors |
| -------------------- | -------------- | -------------- | ---------------- |
| **A plays Rock**     | A: 0  ,  B: 0  | A: 0  ,  B: +1 | A: +1  ,  B: 0   |
| **A plays Paper**    | A: +1  ,  B: 0 | A: 0  ,  B: 0  | A: 0  ,  B: +1   |
| **A plays Scissors** | A: 0  ,  B: +1 | A: +1  ,  B: 0 | A: 0  ,  B: 0    |

In theory, rock paper scissors is *perfectly balanced* and all options are always equally viable. There is no reinforcing loop that causes a runaway streak of winning, past rounds do not affect future rounds. Does that *perfect balance* make rock paper scissors the greatest game ever made? On the contrary, some might say the perfect balance ultimately makes it a boring game to play! All the moves feel the same, there's no way to take a big risk for a big reward streak, and 33% of the possible outcomes result in nothing happening.

Unbalanced counters, dominant strategies, or out-of-control negative feedback loops aren't necessarily bad in a game. If a dominant strategy makes our experience goals happen, then go ahead and keep the dominant strategy in there. Even if it's less of a dilemma, using a dominant strategy can still feel dramatic and impactful. Victories may not feel triumphant unless they are big victories.

{% tabs %}
{% tab title="example: "Chicken"" %}
In the [chicken game](https://en.wikipedia.org/wiki/Chicken_\(game\)) we imagine two cars driving toward each other, with a very exciting shared penalty if both cars "defect" and collide in a crash.

|                               | B swerves (cooperate)   | B stays straight (defect)            |
| ----------------------------- | ----------------------- | ------------------------------------ |
| **A swerves (cooperate)**     | A: **0**  ,  B: **0**   | A: **-1**  ,  B: **+1**              |
| **A stays straight (defect)** | A: **+1**  ,  B: **-1** | (Crash) A: **-1000**  , B: **-1000** |
| {% endtab %}                  |                         |                                      |

{% tab title="example: "Avalanche"" %}
What if we wanted "rock" to feel like a big dramatic decision?

|                      | B plays Rock              | B plays Paper      | B plays Scissors    |
| -------------------- | ------------------------- | ------------------ | ------------------- |
| **A plays Rock**     | A: **-10**  ,  B: **-10** | A: 0  ,  B: **+5** | A: **+15**  ,  B: 0 |
| **A plays Paper**    | A: **+5**  ,  B: 0        | A: 0  ,  B: 0      | A: 0  ,  B: +1      |
| **A plays Scissors** | A: 0  ,  B: **+15**       | A: +1  ,  B: 0     | A: 0  ,  B: 0       |
| {% endtab %}         |                           |                    |                     |

{% tab title="example: "Journey"" %}
Journey is a game where players can "chirp" near each other to recharge the other player's jump energy. Cooperation is a clear dominant strategy here, but that's the point.

|                              | B chirps (cooperate)      | B doesn't chirp (defect)  |
| ---------------------------- | ------------------------- | ------------------------- |
| **A chirps (cooperate)**     | A: +1 jump  ,  B: +1 jump | A: +0 jump  ,  B: +1 jump |
| **A doesn't chirp (defect)** | A: +1 jump  ,  B: +0 jump | A: +0 jump  ,  B: +0 jump |
| {% endtab %}                 |                           |                           |
| {% endtabs %}                |                           |                           |

This is all just to say: **a balanced game / level is often undesirable.**

(todo: image)

### Fairness

**Fairness** is the player's overall psychological perception of balance. Even in a balanced system, players may still perceive unfairness -- or players might think an unbalanced system is fair.&#x20;

A balanced PvP map provides opportunities to both attackers and defenders, with trade-offs and counters to occupying any given territory. **Competitive multiplayer maps should offer teams an average near-equal \~50% win rate.**

In general, **prioritize fairness over balance.** It is less about perfect math, and more about understanding the player's experience and response. Unless you want to take a specific stance as an artist, then players are the source of truth. If all your players say 2+2=5, then consider changing the math in your game.

{% hint style="info" %}
Game designers define "fairness" differently. [David Sirlin defines fairness](https://www.sirlin.net/articles/balancing-multiplayer-games-part-3-fairness) as "players of equal skill have an equal chance to win, no matter their start conditions."
{% endhint %}

(image: fairness)

#### Match / tournament design

Map balance and fairness always happens within the larger context of the entire game. Rules and procedures affect how players use the map, especially in competitive multiplayer.

* *Switching sides.* Map balance matters less when teams switch sides / roles during the game, because theoretically, all players have equal opportunity to exploit (or suffer) any imbalance. This approach is common in many sports, where teams switch sides at half time.
* *Tier lists.* Very common for MOBAs and fighting games. Sort different levels, characters, or equipment into "tiers" and balance only within that tier. e.g. B-ranked options should have rough parity with each other, but no one would expect a C-rank choice to defeat an S-rank choice. Sirlin argues all S-tier or F-tier characters should be redesigned.
* *Tournaments.* There's a whole science to bracket design for competitive multiplayer tournaments, which you could argue is basically meta level design. Open or closed, round robin, elimination? What if one team is better at a certain map than another? Can teams veto maps? What's the map pool?

![photo of the Green Monster wall at Fenway Park by "wallyg" under CC-BY license (https://commons.wikimedia.org/wiki/File:Fenway\_Park\_Home\_Plate\_and\_Green\_Monster.jpg)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-McaVWLt_nkih5Ya50T-%2F-McbqF6h76ItCgKoVVJo%2FLDB_FenwayPark_GreenMonster.jpg?alt=media\&token=6e039296-41c4-4ab5-88d8-40bd69fbf9d9)

For example, pictured above is the ["Green Monster"](https://en.wikipedia.org/wiki/Green_Monster), an unusually tall green wall at the back of left field at Fenway Park, a Major League Baseball field in Boston, USA. In terms of level design and map balance, the Green Monster offers a huge advantage to the defensive team on the field; the Green Monster is so tall (11.3 meters) that it is very difficult for a batter to hit a home run over the wall.

But within the larger context of an entire baseball game with multiple innings where teams repeatedly switch roles, it is *fair* because both teams will be at a similar disadvantage. **The overall game design frames how we understand balance**, and sometimes map balance is even somewhat irrelevant.

(Baseball nerds debate whether the Green Monster is bad for batters. Batters can aim for the wall and bounce the ball off of it, which is more difficult for left fielders to catch. [Left-handed pitchers often suffer worse stats at Fenway](https://www.forbes.com/sites/danschlossberg/2018/10/24/green-monster-curse-both-series-teams-let-lefties-decide/?sh=2369897b52ca) because right-handed batters score more of these "wall ball doubles".)

## Map balance

Balancing various parts of a level involves comparing the **utility** of the area, the **cost** of accessing it, and the **information** available to players.

* **Utility:** Is this area useful or interesting? Why would a player go here or stay here?
* **Cost:** Is this area easy to reach or stay in? Do players need a lot of time / resources to do so? If the player is here, does that leave another place vulnerable?
* **Information:** Are players aware this area exists? How much info must players track or memorize to utilize this area? Are there hidden costs? *Is it fun to misunderstand what happens?*

Our goal in level design is *not* to maximize utility. A "perfect" map area that's always useful *(high utility)* and easy to reach *(low cost)* in an obvious location *(visible info)* isn't actually desirable in level design because all "rational" players will inevitably use it and rely upon it as a dominant strategy Why build the rest of the map if players won't use it?

Ideally, every part of the map should have a specific usefulness that depends on the game state, with situational weaknesses to discourage players from staying for too long, filtered through limited information that lets players make entertaining mistakes.

### Territory / map control

A player's **territory** is the area of the level that they can track, defend, and generally benefit from. Note that the player does not necessarily have to be present inside the area in order to defend or benefit from it. The concept of territory is more abstract than that, it's more about who controls access to that area, and who can comfortably move into the area.

For example, a&#x20;

Every game with players and space can support a theoretical player-driven "meta" understanding of territory. When you play the board game Monopoly and accrue many adjacent properties, that area can be considered your territory. When you play basketball and have enough defenders near the basket, that area (the "paint") is now under your control.

Team-based game modes with many players tend to formalize territory with king of the hill (KOTH) styled control points (CP), payload carts, or battle royal circles.

**Map control** is the proportion of the player's territory against their opponent's territory. If you have much more territory and claim more key positions in the map, you have more map control.

![map control diagram with "P" (player) on left, and "E" (enemy) territory on right -- from "The Door Problem of Combat Design" by Andrew Yoder ](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MaE772K0MViEPpgnix1%2F-MaE7KkewAoItNRLzmYC%2FLDB_AndrewYoder_doorproblem_foothold_mapcontrol.png?alt=media\&token=760dc20b-ee3d-407b-ae72-6db411790c6f)

### Chokepoints

Territories are usually bounded by **chokepoints**, smaller areas or passages that can be defended to deny territory to an enemy.

In multiplayer PvP maps, distribute 3-4 chokepoints across the map, one chokepoint per lane. It should be impossible to cover all chokepoints from a single point.

For example, in the Counter-Strike map de\_cache, the top lane (A) has two small chokepoints, the mid lane has one big chokepoint, and the bottom lane (B) has one big chokepoint. The Counter-Terrorist (CT) team's job is to protect the orange bombsites, which both begin firmly within their territory (the left side of the battle line). CTs have a safe way to rotate from mid to A, but Ts can attack A from two chokepoints. B is closer to both CTs and Ts, but rotating from B takes longer.

|            | Ts go A         | Ts go Mid    | Ts go B         |
| ---------- | --------------- | ------------ | --------------- |
| CTs go A   | Fight           | Ts control B | CTs must rotate |
| CTs go Mid | CTs can cover A | Fight        | CTs can flank B |
| CTs go B   | CTs must rotate | Ts control A | Fight           |

![battle line and chokepoint breakdown on de\_cache by Sal Garozzo and Shawn Snelling for Counter-Strike: Global Offensive, from GDC 2015: Community Level Design for Competitive CS:GO](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MR3IUVTh0_k_FOBougY%2F-MR8VnbBbPkGXTb2XStj%2FLDB_CSGO_de-cache-chokepoints_SalGarazzo_GDC2015.jpg?alt=media\&token=0edf99f6-e403-430d-9f86-7bc8815eeed1)

#### PvE territory

&#x20;   *For more on designing with NPCs and AI, see* [*Encounter design*](/process/combat/encounter.md)*.*

For single player / PvE game modes, territory is&#x20;

#### PvP map control

For competitive multiplayer (PvP) maps, maintaining map control is about defending key positions, and "denying" resources or important areas to opponents -- or, conversely, "pushing" into enemy territory to get more map control for you or your team. In this way, territory in multiplayer design is very fluid and constantly changing.

In duel, deathmatch, or free-for-all multiplayer modes, territory and map control are rarely formalized within the game system. Instead, territory is a more player-driven understanding of how players flow around the map.

(rapha video)

To help coordinate more than a handful of players, team-based multiplayer shooters feature game modes that formalize territory in the form of control points, moving payloads, or battle royale circles.

For combat games, it is also effective to conceptualize sightlines in terms of territory to defend. Which positions can be easily defended with a wide sightline, while which areas leave players vulnerable to a surprise attack? (FMPONE CS:GO talk)&#x20;

Sniper alleys offer very long sightlines for long range attacks or suppression, while close quarters areas offer shallow sightlines. Most multiplayer combat games try to balance their maps with a mix of short and long sightlines, and cover is an easy way to tune the effectiveness of a particular sightline.&#x20;

Some loose guidelines for measuring the effectiveness of a tactical position:

* Can a hostile player sneak up on them? Are all possible enemy sightlines within a single defender's field of view?
* Is cover spaced far apart, or close together?
* Does the defending player have a height advantage?

A position that is easily defended with high tactical value and no obvious weaknesses is a “camping spot.” In the 1990s, multiplayer FPS gamers complained a lot about campers; today, Call of Duty: Modern Warfare free for all is basically a game about moving between camping spots. There are no firm universal rules about cover design because every game will feature different weapons and different combat styles.

That said, this book would like to suggest one firm universal rule about cover design: avoid “cover boxes”. A cover box is any repetitive object at waist-height with a boxy shape, and we encourage level designers to experiment with new cover shapes, or reconcile cover most seamlessly with the surrounding architecture. See also: Time to crate (TTC)

who controls what areas, where the player thinks they can go

single player combat, multiplayer combat

sometimes formalized with "bases" and "capture points", but territory always exists in any game with conflict

sometimes the conflict is "human vs world"... walking sims have walls, the walls are not part of the player's territory, etc.

flowchart / graph / value diagram

## Symmetry

In multiplayer PvP level design, the most straightforward way to balance a map is to use **symmetry,** to copy an identical layout / base / territory for each team.

### Bilateral symmetry

Take one half of the map, duplicate it, and then flip the copy or rotate it 180 degrees. Sew up the seams and connect the shared boundaries along the middle axis of symmetry. The most common type of symmetry used in level design.&#x20;

Feels "artificial", requires extensive thoughtful art passing to differentiate the two areas

example: 2fort, iceworld, MOBA maps

### Radial symmetry

Take part of the map, duplicate it, then move and rotate it. If desired, repeat more than once. This is a much more rare type of symmetry, because its strength is in how it accommodates more than two teams, yet most multiplayer games only field two opposing teams.&#x20;

example: ???

### Asymmetrical balance

More "realistic"

This is really hard to get right and it's very time consuming, and this is why CS:GO level design is really hard

## How to balance a level

Balancing a level involves a lot of back and forth between modifying your level and playtesting it, over and over again. This process is called *iteration.*

1. [**Layout**](/process/layout.md) the level, with attention to [flow](/process/layout/flow.md).
2. [**Blockout**](/process/blockout.md) the level, with attention to [metrics](/process/blockout/metrics.md).
3. [**Playtest**](/process/blockout/playtesting.md) multiple sessions with different sets of players.
4. **Collect feedback** and combine with personal observations.
5. Iterate another pass on the **blockout**.
6. **Playtest** again.
7. Repeat steps 4-6.

## Tuning

**Tuning** is the process of tweaking angles, sizes, and distances until the level feels balanced.

If something isn't working, but don't know what to do with it, then err on making it more powerful. If you make it weaker, players will simply use it less, and you won't get any data or feedback on it.

On the first pass, double or halve the value. Small differences cannot be felt.

### Time to kill (TTK)

### Travel time and flow

#### Trick jumps

*Trick jumps* and unorthodox flow can offer a difficult and time-consuming route for players to flank their opponents. When designing these optional routes, balance the risk of failing the route with the reward.

For example, in the trick jump pictured below on de\_cache for Counter-Strike: Global Offensive, a CT player must (1) run on the garage overhang, (2) jump with mid-air control around a corner onto an air conditioning unit, then (3) jump onto a junction box and onto a roof to sneak behind an opponent.&#x20;

The co-designer Sal Garozzo notes that this trick jump is helpful but time consuming and risky. If you spend too long trying to complete the trick jump, then you leave your team at a disadvantage, and also the enemy players will constantly hear you jumping on these loud metal surfaces. Trick jumps are best when they're not obligatory -- optionally a teammate could boost you up to the roof as well.

![CT trick jump on de\_cache for Counter-Strike: Global Offensive, from GDC 2015: Community Level Design for Competitive CS:GO](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MR8_1AnqcYLZ7-s7oog%2F-MR8bgSxIGuToo3ILw6I%2FLDB_CSGO_de-cache-trick-jump_SalGarozzo_GDC2015.jpg?alt=media\&token=9ed84df9-9580-4376-ac2d-cf3bf1d659b1)

### Sightlines and cover

&#x20;   *For more on managing the player's view, see* [*Metrics*](/process/blockout/metrics.md) *and* [*Composition*](/process/blockout/massing/composition.md)*.*

A **sightline** is an imaginary uninterrupted line that connects the player’s camera position to an important part of the level within the player's **field of view.**

A large busy view with many deep sightlines will overwhelm the player about what is relevant, while offering only a few shallow sightlines will leave players ignorant and unable to plan movement.&#x20;

For PvE gameplay, err on too much cover. You generally want to offer more options and routes for the player to defeat enemies. If there is only one clear path with cover, then the gameplay will feel more rote and less creative.

For PvP gameplay, err on too little cover. The game mode will likely already support ways for players to create their own cover (Counter-Strike: Global Offensive features smoke grenades and flashbangs, Overwatch features tank enemies and shield mechanics) and too much cover will make it too difficult to track what's happening.

![sightline analysis on de\_cache by Sal Garozzo and Shawn Snelling in Counter-Strike: Global Offensive, from GDC 2015: Community Level Design for Competitive CS:GO ](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MR8WB5rVfnBQdXWxFL3%2F-MR8WkVWev9aDknYqIcS%2FLDB_CSGO_de-cache-sightlines_SalGarazzo_GDC2015.jpg?alt=media\&token=917a0ee2-1f24-48e2-ba98-5acb8ed7896c)

Good sightline design involves:

* Balancing the rate of visual information that the player must process and track
* Varying the quantity and length of sightlines; different areas should afford different visibility
* Offer multiple sightlines to the same **landmark** from different vantage points

(corners diagram)

When balancing sightlines, pay special attention to corners. A rounded / beveled corner offers wider sightlines than a sharper corner. Imagine someone was chasing you: it's difficult to break line of sight along a curved hallway, while a sharp T-junction with blind corners lets someone easily break a sightline and escape.

### Cover

When map geometry exists mainly to break sightlines and hide from projectiles, then it functions as **cover**. Some common types of cover:

* **Soft cover** visually obscures the fighter, blocking sight but not projectiles \
  *examples: water, foliage, shadows, grates, thin walls / doors in games with bullet penetration mechanics*
* **Hard cover** protects the fighter from projectiles, and usually blocks sightlines as well.\
  *examples: bulletproof transparent glass window, thick opaque walls or terrain*
* **Half cover** is a waist-high object that protects the top-half of a standing figure (exposing their head, torso, and weapon) or an entire crouching figure. Half-cover depends on elevation; an attacker firing from a higher vantage point will be able to hit even a crouching figure, while an attacker from a lower vantage point might have trouble seeing even a standing figure.&#x20;
* **Full cover** is a tall object that fully protects someone standing. However, in most first person shooters, a defender behind full cover cannot easily see or fire back without stepping out of cover.

(cover diagram)

Cover boxes are easy to parse but feel artificial and unnatural

Use slopes to create cover

#### Cover is mechanic-dependent

Again, just like anything in level design, our definitions depend on how the game implements its mechanics.

For example, Counter-Strike features a bullet penetration mechanic ("wallbanging") that lets players shoot through thin objects made of weak materials. So while a corrugated metal wall or wooden board might function as *hard cover* in most games, these thin objects function as *soft cover* in Counter-Strike.&#x20;

On the CS:GO map de\_crown, co-designer Sal Garozzo notes that this double-door chokepoint (pictured below) has these thin rectangular wooden cutouts specifically to offer players a trade-off: they can shoot through these walls to make sure no one is hiding there to ambush them on the other side... but if they try to wallbang and no one is there, then they have wasted some bullets and also made a loud gunfire sound that gives away their position. Wallbanging transforms cover into a betting mechanic.

![wallbang spots on de\_crown for Counter-Strike: Global Offensive, from GDC 2015: Community Level Design for Competitive CS:GO](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MR8bzN9xy91CckHz-8u%2F-MR8eAKGEa-6QaLG4HCS%2FLDB_CSGO_de-crown-wallbang_SalGarozzo_GDC2015.jpg?alt=media\&token=86d2363f-8b1b-4c7c-ad67-bfc9d3d9e29b)

### Height / grading

Height advantage (and ceiling) and explosive radius, gravity and grenades

### Game feel

For the multiplayer team shooter Wolfenstein: Enemy Territory, players complained the two teams' weapons were [unbalanced](/process/combat/balance.md). Supposedly one team's Thompson submachine gun was more powerful than the other team's MP40 gun. Now within the game code, the guns literally had the same stats and damage tuning values. But when Splash Damage designers analyzed the player stats, they discovered players were indeed getting more kills with the Thompson vs the MP40 *even though there was no functional gameplay difference between the two weapons.* The players were right about the effect, even though it seemed like they were wrong about the reasoning.

The only differences were the 3D models and the sounds. So to balance the two guns, the developers made the Thompson sounds "less bass-y". That's it.

{% embed url="<https://www.youtube.com/watch?v=RDxiuHdR_T4>" %}

There are two main takeaways about playtesting and game balance here:

* Players are often correct about the "effect" of a design problem, but may not be able to accurately identify the cause. Suggestions are often wrong, but the underlying problem that prompted the suggestion is real. Data can help confirm player perceptions, but does not necessarily imply the design solution.
* Game design and balance is not just a technical mathematical science, but also a conceptual psychological art. What might seem one type of problem could actually be caused by something else. A holistic view of your game is crucial.

## Against map balance

We balance maps because supposedly good balance makes for a more enjoyable game experience. But what if bad balance still makes for enjoyable levels?

In the early 2000s when multiplayer FPS culture centered around dedicated servers,&#x20;

D-Day style beach landing assault maps are all about the massive unbalance of power. It wouldn't fulfill the Omaha Beach fantasy unless you died 10 times in the spawn area.

Frustration is about expectation and attitude. If players enjoy losing, then amplifying that loss will result in even more enjoyment, right?

### Masocore

## Now what?

* read about Flow and Encounters
* try a layout balancing exercise

## Further reading

### Game balance

* ​["Design in Detail: Changing the Time Between Shots for the Sniper Rifle from 0.5 to 0.7 Seconds for Halo 3"](https://www.youtube.com/watch?v=8YJ53skc-k4) by Jaime Griesemer from GDC 2010 is a classic highly-recommended game design deep dive into weapon balance and Halo's multiplayer design.
* ["The Heresy of Zone Defense"](https://www.thomascummins.com/the-heresy-of-zone-defense) (1995) by Dave Hickey is one of the greatest pieces of sportswriting of all time, exploring how rules, players, and territory work(ed) in US pro basketball. But keep in mind the NBA legalized zone defense in 2001 and adopted the [three-second rule](https://en.wikipedia.org/wiki/Three_seconds_rule): *"no offensive player, with or without the ball, could remain in the key, for three seconds or more."*
* ["Hearthstone's Card Balance Philosophy"](https://web.archive.org/web/20210320033238/https://playhearthstone.com/en-us/news/12383909) by Eric Dodds, lead designer of Hearthstone, lists several factors that go into balancing a popular card game. Although these design principles do not directly relate to level design, it's still a helpful lens into general game balancing philosophy.&#x20;
* ["Game Balance and Yomi"](https://www.sirlin.net/articles/game-balance-and-yomi) by David Sirlin is about balancing a competitive card game called Yomi, and how Sirlin approaches tiers. He also disagrees with some of the conventional balancing advice on this page, so if you're a balance nerd, definitely check out his take.

### Map balance

* [Matthew "Lunaran" Breit wrote about map balance](https://web.archive.org/web/20080211132953/http://www.lunaran.com/page.php?id=187) as it pertained to Quake multiplayer arena maps circa 1999, and was pretty influential among level designers and competitive players. Today he's slightly embarrassed about it all and disavows much of it, but we think it's funny to watch him squirm, so we're linking to it anyway. Even if he was wrong, enough people believed he was right.
