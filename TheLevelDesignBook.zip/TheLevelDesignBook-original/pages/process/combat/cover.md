> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/process/combat/cover.md).

# Cover

Shapes that block sightlines, offer protection in combat and stealth games

## **What is cover?**

**Cover** is any object or structure that blocks a sightline or shields someone from attack.&#x20;

If a game has projectiles and walls, then it also has cover. It's an almost unavoidable feature in [combat](/process/combat.md) games, as old as the genre itself.&#x20;

However, cover implementation can vary from a simple arcade-like feel to a complex cover system with animation and scripting markup. Like any combat mechanic, the rest of the core game design can all affect how players actually use cover.

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F89P2hCiT74Hj1oaHmIn6%2FLDB_CoverIllustration.png?alt=media&amp;token=451c7e3e-2199-47d8-a166-1cbb0835625a" alt=""><figcaption><p>illustration of two different cover gameplay styles; cover as a maneuver (<em>around</em> cover) vs. cover as a tactic (<em>with</em> cover)</p></figcaption></figure>

### A brief history of cover in games

*Space Invaders (1978)* has cover. But your time is better spent shooting, out of cover. Early first person shooters like *Doom (1993),* *Quake (1996),* and *Unreal (1998)* all feature this similar arcade-like focus on speedy shooting, where you sometimes take cover briefly before running and gunning again. Dodging is often a better strategy than standing still behind cover. Here, **cover is a maneuver**.

More "realistic" shooters like *Half-Life (1998)* and *Counter-Strike (1999)* have a faster time-to-kill and so crouching behind cover is essential, and you need less shooting time anyway. Here, **cover is a tactic** that slows down all combat. You shoot *from* cover, instead of *around* cover. *Halo (2001)* later used a regenerating shield mechanic to stabilize this duck-and-cover rhythm further, directly rewarding the player for taking cover.

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FjSiAAlrohXqclj0YqDtU%2FLDB_CombatCoverHistory_SpaceInvaders_HalfLife_MetalGearSolid.jpg?alt=media&amp;token=f1e2842e-aa1f-4789-919c-cbbf6ae1b2b1" alt=""><figcaption><p>screenshots of (left) Space Invaders (1978), (center) Half-Life (1998), and (right) Metal Gear Solid (1998)</p></figcaption></figure>

In early 3D third person action games like *Metal Gear Solid (1998)* characters can hug walls or crouch behind crates. Here, taking cover becomes more of a distinct action / mode that characters enter into. This marks the beginnings of a cover system, though used more for stealth instead of combat.

The somewhat obscure *Kill Switch (2003)* is the first generally recognized **cover shooter** with its formalized **cover system**, a mechanic where characters can dynamically snap to cover, posing their body and hitboxes to the cover geometry. *Gears of War (2006)* later popularized the cover system to define the modern cover shooter genre as we know it today, now common in series like The Last of Us, The Division, and Uncharted.

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FvAWr1gt4vLCDecSggyKX%2FLDB_CoverShooterHistory_KillSwitch_GearsOfWar.jpg?alt=media&amp;token=3d71a3b8-0ea8-4e95-ae10-6b8ad5f8aa8f" alt=""><figcaption><p>gameplay screenshots of early cover shooters; (left) Kill Switch (2003) and (right) Gears of War (2006)</p></figcaption></figure>

### Cover is movement

The function of cover will depend on how players move around it / with it / through it.

* **Cover as maneuver**, briefly stand behind an obstacle when you're not running and gunning, in fast-paced games with arcade feel. Occasional use for mob management. *Moving **around** cover.*
* **Cover as tactic,** a general strategy where you regularly duck and cover, in realistic action games especially "gritty" 2000s shooters. Slows down otherwise rapid time-to-kill. *Moving **with** cover.*
* **Cover as system**, an integral mechanic where being in-cover is a distinct state, in third-person cover shooters with body awareness. Cover is the default combat mode. *Moving **through** cover.*

## Cover design

After the core combat and cover implementation is decided, level designers usually focus on just two aspects of cover design:

* **cover shape**: geometry of an individual cover object, usually a wall or a box-like shape.
* **cover placement**: overall [layout](/process/layout.md) of cover shapes in an arena or encounter.

## Cover shapes

Cover can take on a variety of shapes and functions. Sometimes cover is a distinct object, sometimes it is more like a general feature of a [landscape](/process/blockout/massing/landscape.md).

* Primary aspects: **Height**, **Width**, **Solidity**, and **Facing**.
* Secondary aspects: **Verticality**, **Corners**, **Permanence**, and **Authorship**.

### Height (Half / Low vs. Full / Tall)

<div align="left" data-full-width="false"><figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F86aB3zmsFHdgandINWTw%2FLDB_CoverDiagram_HeightHalfFull.png?alt=media&amp;token=d61552d7-57ac-451c-a037-cac629e21854" alt="" width="188"><figcaption></figcaption></figure></div>

You can shoot over or jump over waist-height tables, but taking cover requires staying down and close.&#x20;

Tall cover protects against elevated attackers but standing / sidestepping out can expose more.

### **Width** (Narrow vs. Wide)

<div align="left"><figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F7XoCWFAMoz7pQli26L8P%2FLDB_CoverDiagram_WidthNarrowWide.png?alt=media&amp;token=802fe7de-5969-4948-a835-b5c27e2cf46b" alt="" width="188"><figcaption></figcaption></figure></div>

Shallow narrow cover can leave you exposed, while deep wide cover provides reliable protection.&#x20;

**Exposure** is useful to weaken NPC positions, make somewhere more dangerous, or encourage more movement.

### **Solidity** (Soft vs. Hard)

<div align="left"><figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FRslXjZpC5xWYeJqieCyO%2FLDB_CoverDiagram_SoliditySoftHard.png?alt=media&amp;token=f9714699-e6d6-4e8e-a9d4-02dbe6d98182" alt="" width="188"><figcaption></figcaption></figure></div>

NPCs ignore you in non-solid soft cover like bushes or tall grass, but PvP is less generous.&#x20;

**Softness varies.** Energy shields / bulletproof windows block bullets but not sight; grates block movement but not bullets; Counter-Strike has bullet penetration ("wall banging").

### **Facing** (Directional vs. Freestanding)

<div align="left"><figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FfSAWx6gCS8mzBrI49G5j%2FLDB_CoverDiagram_FacingDirectionalFree.png?alt=media&amp;token=70622a89-a5c4-4772-a9cd-ed76c46d10f5" alt="" width="188"><figcaption></figcaption></figure></div>

Directional cover leaves blind spots for attackers to **flank** or defending teammates to cover you, good for a frontline.&#x20;

Free standing cover often leads to "ring around the rosie" dances, circling in duels, better for a climactic last stand. See [Angled movement](#angled-movement).

### **Verticality** (Trench vs. Elevation)

<div align="left"><figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FGIfGtKbMj3FKHzzLrsMU%2FLDB_CoverDiagram_VerticalityTrenchElevation.png?alt=media&amp;token=c09a85df-4e06-44c8-b892-7b3d229d5a68" alt="" width="188"><figcaption></figcaption></figure></div>

It feels good to clear a trench of NPCs, but usually feels bad yourself to get pinned down by a sniper or turret.&#x20;

Elevation gives a stronger height advantage depending on **angle of attack.** See also [Flow: Verticality](/process/layout/flow/verticality.md).

### **Corners** (Sharp vs. Round)

<div align="left"><figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F3z3Nb1xFyD5aL2Qd7wQL%2FLDB_CoverDiagram_CornerSharpRound.png?alt=media&amp;token=7d41638e-0e04-49f6-aa92-072ec7e9801e" alt="" width="188"><figcaption></figcaption></figure></div>

Sharp "blind corners" (90+ degrees) protect you even up close.&#x20;

Rounded corners leave you more exposed depending on the **curvature**. Longer curves are harder to hide behind. See also [Angled movement](#angled-movement).

### **Permanence** (Dynamic vs. Static)

<div align="left"><figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FGFtHvw8ukM2in6PQeT7j%2FLDB_CoverDiagram_PermanenceDynamicStatic.png?alt=media&amp;token=ecaac213-35fe-496a-8894-2983e2e9ef34" alt="" width="188"><figcaption></figcaption></figure></div>

Most cover is permanent and static, but **breakables** give temporary semi-hard cover like in F.E.A.R or Dark Souls.&#x20;

**Moving cover** (especially half cover) should move slow (a payload cart) or be huge (a long train) or else it's hard to use.

### **Authorship** (Designer vs. Player)

<div align="left"><figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FhcdLUNpndDbLmN6ownkv%2FLDB_CoverDiagram_Authorship.png?alt=media&amp;token=165bb661-2d74-4739-ad44-3d9921f9801a" alt="" width="188"><figcaption></figcaption></figure></div>

Fortnite lets you **build** hard cover; Counter-Strike has **utility** (smoke grenades) to create soft cover. These games' maps have less developer authored cover because players fill-in open space with their own cover.

## Cover construction

### Cover metrics

&#x20;    *For more on general level design measurements, see* [*Metrics*](/process/blockout/metrics.md)*.*

**Cover metrics** are specific sizes and measurements to standardize cover objects.

Consistent cover is useful for combat games that want to avoid ambiguity, or any action game with a cover system / body awareness animations that need to make assumptions about cover shapes.

For Uncharted 4, Naughty Dog designers made sure all their cover objects and wall heights conformed to three height ranges:

* *High cover.* Standing head height object, 1.75 or more meters.
* *Low cover.* Standing waist height object, 1.0-1.25 meters.
* *Not cover.* Knee-height object at 0.5 meters or less

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F0t8moeFiB8b0HE0zeQJT%2FLDB_Uncharted_CombatCoverMetrics_EmiliaSchatz.jpg?alt=media&amp;token=8c33aed7-be00-4aec-a330-0000af897608" alt=""><figcaption><p>annotated screenshot diagram with different cover height ranges in Uncharted 4, from <a href="https://80.lv/articles/defining-environment-language-for-video-games/">"Defining Environment Language for Video Games" by Emilia Schatz (via 80.lv)</a></p></figcaption></figure>

In contrast, **fuzzy cover** is a cover object that feels ambiguous or inconsistent.

In the brutal unfair action RPG Dark Souls, sometimes you think you're safely protected behind cover but then you suddenly get one-shot killed anyway. Or consider a military sim shooter like ARMA, where you can actively control your stance in detail, dynamically adjusting pose and leaning to conform to cover, requiring mastery in a serious mil-sim way.

So it all depends on your experience design goals. What do you want your cover to do? What are your mechanics? Are you making an Uncharted, a Dark Souls, an ARMA, or something else entirely?

(TODO: fuzzy cover examples)

### Cover scripting

The simplest cover implementations don't need special scripting. You build a wall or place a crate and the cover is ready for use.

More complex cover implementations need some scripting markup to help NPC AI use cover. Half-Life used **nodes**, possible fighting positions hand-placed by level designers. Half-Life 2 and Gears of War 1 implemented several types of specialized **cover nodes,** to signal the correct character animations to use for the cover system.

Most games today would automate some or all of this cover markup process:

* [Modular](/process/blockout/metrics/modular.md) workflow: reuse hand-authored cover markup by reusing tiles or prefabs.
* Baking workflow: automatically detect and bake cover markup, related to a navigation mesh ("navmesh") baking pass. Allow hand-authored overrides for edge cases.

&#x20;    *For more on NPC AI and nodes, see* [*Scripting: Navigation*](/process/scripting/nav.md)*.*

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FplXXW6rT1rVkesIRGcup%2FLDB_CoverScripting_NodeExamples_HalfLife_GearsOfWar.jpg?alt=media&amp;token=5fdbaf9f-5d8d-4b24-a238-3d9b7179e96a" alt=""><figcaption><p>(left) in-game debug visualization of hand-placed cover node network in map d3_c17_07 in Half-Life 2, <a href="https://developer.valvesoftware.com/wiki/File:D3_c17_07_hints.jpg">screenshot by Tom Edwards via Valve Developer Wiki</a>; (right) editor screenshot of hand-placed cover nodes in a Gears of War mod, <a href="http://www.nickurko.com/Gears-of-War-Stalactites-Nick-Urkos-Portfolio">screenshot by Nick Urko via nickurko.com</a></p></figcaption></figure>

## Cover placement

Different games needs different cover [layouts](/process/layout.md).

* **Genres** like third person stealth have different cover needs vs. a first person shooter.
  * In stealth: cover is a player tool to manage enemies, information, and visibility.
  * In combat: all of the above, but also, cover is hard protection from enemy fire.
* **Mechanics** strongly affect cover layout.
  * Depending on damage systems / friendly fire, larger enemies can act as moving cover.
* **Multiplayer** maps use cover as part of [map balance](/process/combat/balance.md), but single player levels can have "unfair" cover tailored for specific [encounters](/process/combat/encounter.md) and player paths.

<div data-full-width="false"><figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FAWAJyGvLmtM89TZdFDOv%2FLDB_CombatCoverLayoutDiagram_StealthVsShooter_Iuliu-CosminOniscu.png?alt=media&amp;token=4608434b-3e94-4cca-bcad-cc7fdedcc75c" alt=""><figcaption><p>(left) typical layout for a stealth game vs. (right) typical layout for a cover shooter; adapted from diagrams <a href="https://iuliu-cosmin-oniscu.medium.com/how-to-handle-cover-placement-d10580faac66">by Iuliu-Cosmin Oniscu via blog post "How to handle cover placement"</a></p></figcaption></figure></div>

Consider these cover layouts for a stealth game (above left) and for a shooter (above right):

| Stealth cover layout              | Cover shooter layout                          |
| --------------------------------- | --------------------------------------------- |
| Enemies begin exposed and unaware | Enemies begin unexposed, behind cover         |
| Enemies control middle            | Middle is "no man's land"                     |
| Rushing through = no cover        | Rushing through = some cover, viable          |
| Side path is critical path        | Optional side path for observant players      |
| Side path has vulnerable gaps     | Side path offers zero vulnerability as reward |

Imagine swapping these layouts. They could work OK, but players would behave differently.

If we played the stealth layout in a shooter, the player might headshot the defenseless enemies on sight and ignore the cover entirely. If we played the shooter layout in a stealth game, beginner players may fail to notice the guards hidden behind cover -- or if the guards were noticeable then the protected side paths would feel obvious and easy, like for a tutorial or the start of a mission.

This hints at the difficulty of level design for combat-stealth games. Ideally, all cover placement must support two very different play styles / game states.

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2Fx76uNeRIuQrd120psE15%2FLDB_CombatCoverScreenshot_DeusExHumanRevolution.jpg?alt=media&amp;token=940fcc38-418c-4e4a-acf5-b0859429f4d2" alt=""><figcaption><p>cover system combat gameplay screenshot from action-stealth game Deus Ex: Human Revolution (2011)</p></figcaption></figure>

### **Less cover is better**

Often **less cover is better**. Cover blocks sightlines, which prevents players from noticing what's happening. Defense feels meaningless if you don't know what to defend against.

* In a single player encounter, enemy cover should usually leave NPCs somewhat exposed somehow, or else the player won't notice them.
* Too many wide tall cover objects can create confusing maze-like [flow](/process/layout/flow.md) and [wayfinding](/process/blockout/wayfinding.md), which is usually bad for most action games.

For Gears of War, Epic Games designers argued **"in general, low cover is better than tall cover"** in a multiplayer cover shooter context:

> *"In general, low cover is better than tall cover. \[With a wall] generally your interactions are limited to the ends of the wall \[and] you’re also greatly limiting player visibility and separating the player from all the action going on over the wall.*
>
> *If you lower the wall you’ve drastically increased the options for the player. They are now aware of things going on over the wall and can be on the lookout for flanks and enemy movement. They can pop up and shoot from anywhere along the wall, giving them far more choices in firing positions. They can stay crouched and feel sneaky as they maneuver for a better shot. And of course they can mantle over the wall. As soon as they start moving along a high wall they are detached and simply traversing the map, but with a low wall they’re still fully involved in the match."*
>
> \-- Epic Games, ["Multiplayer Map Theory (Gears of War)"](https://docs.unrealengine.com/udk/Three/GearsMultiplayerMapTheory.html)

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FNLb7jnxsdbrkVoDXA5OC%2FLDB_CombatCover_gearsofwar1_Gridlock_layout.jpg?alt=media&amp;token=6947eb78-68a6-4918-9444-d804d3df8613" alt=""><figcaption><p>official layout diagram of Gears of War 1 team multiplayer map "Gridlock", by Epic Games</p></figcaption></figure>

Gridlock is a team multiplayer map for the cover shooter Gears of War. It's the most influential map in the series, and the only map that has been in almost every sequel.

Epic Games attributes its success to its open spaces and usage of low cover:

> > *"Gridlock is the clearest example of \[visible flanking]. With the abundance of low cover, lines of sight are running all over the map, allowing a good player to constantly be aware of enemy positions and potential flanks.*&#x20;
> >
> > *\[... You'll] often see a firefight rotate in orientation, occupying the same space, but with action happening on a different axis.*&#x20;
> >
> > *\[... Maps like this] have such long view distances that they reward the observant players who can see which direction the enemies scatter to once they leave the spawn areas."*
> >
> > \-- Epic Games, ["Multiplayer Map Theory (Gears of War)"](https://docs.unrealengine.com/udk/Three/GearsMultiplayerMapTheory.html)

### Angled movement

Cover depends on **angles** -- the combatants' sightlines as they rotate around corners.

To visualize the angles, imagine the edge of the corner as the central **axis** / **pivot**. As you rotate around the corner, your view angle gradually gets wider -- but so does your possible exposure.

Real-life militaries and police call this **"slicing the pie"**: sidestepping around a corner, gradually accumulating more sightline "slices" of a room until you've cleared all angles.

<div data-full-width="false"><figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F0fe96eQXT98LPguEPdeA%2FLDB_DoorKickersGuide_CombatCoverSlicingThePie.gif?alt=media&amp;token=5eae8ad5-831a-423e-9ae0-eadf16c15288" alt=""><figcaption><p>animated GIF of  "slicing the pie" to clear a room; footage from Door Kickers, <a href="https://steamcommunity.com/sharedfiles/filedetails/?id=200580844">via "The Kickers Tactical Guide" by TrialBySnu</a></p></figcaption></figure></div>

**Directional cover** limits possible angles (how much "pie" you can have) while **freestanding cover** supports multiple angles (360 degrees of pie!) but that also means you have to choose which angles to defend against.

For example, in Counter-Strike on Dust2's B site, both directional and freestanding cover have different vulnerability:

> *"... there is a **cubby** in the wall where a large wooden gate is shut. This recess is deep enough for a player to hide behind the post and use it as cover against an attack from the upper tunnels \[highlighted in blue].*
>
> *... once the attacker has cleared the cubby, they can’t use this same cover against the defenders. The cover offered by this cubby is only useful against upper tunnels \[in blue]. Even worse, the cubby is exposed from the defender archway \[in purple, and window in red], which means attackers can’t use this cover when they are holding the B site against a defender retake..."*

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FpbV4iQsftKCAxpp5FNwL%2FLDB_CoverDiagram_AndewYoder_Dust2CounterStrike_AnglesSightlinesDirectional.jpg?alt=media&amp;token=715a3efd-afb4-4171-8c17-8a53ef69240a" alt=""><figcaption><p>(left) <strong>cubby</strong> perspective toward Upper Tunnels, (right) overview screenshot showing different angles, with Window in red and Defender Arch in purple; screenshots <a href="https://andrewyoderdesign.blog/2022/04/14/a-few-kinds-of-cover/">by Andrew Yoder (via blog post "Judge A Map By Its Cover")</a></p></figcaption></figure>

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FfftzCBYgnvhKv39xsJPw%2FLDB_CoverDiagram_AndewYoder_Dust2CounterStrike_AnglesSightlines.jpg?alt=media&amp;token=5f3d4524-7616-4b0f-b777-db9945fafd35" alt=""><figcaption><p>(left) <strong>tall box</strong> perspective toward Upper Tunnels, (right) overview screenshot showing different angles, with Window in red and Defender Arch in purple; screenshots <a href="https://andrewyoderdesign.blog/2022/04/14/a-few-kinds-of-cover/">by Andrew Yoder (via blog post "Judge A Map By Its Cover")</a></p></figcaption></figure>

> *"... a player can use the **tall box** to hide from upper tunnels \[in blue], or to hide from window \[in red] and defender arch \[in purple].*
>
> *Freestanding cover leaves options open. A player can choose to peek from either side, loop around it, or disengage. They can choose to hold close to the cover and try to peek wide and fast, throwing their opponent’s aim, or they can try to back off and play from range. So long as they are in an even fight, they have options to play that cover to their advantage. Even in a 1v2, freestanding cover can help the outnumbered player juke and stay alive, burning precious seconds off the clock.*
>
> *Because of this versatility, freestanding cover tends to work best on objective sites where players may duel or attempt to run the clock down."*
>
> \-- Andrew Yoder, ["Judge A Map By Its Cover"](https://andrewyoderdesign.blog/2022/04/14/a-few-kinds-of-cover/)

Even if you're not playing a military shooter, you're still probably strafing around corners in a similar way, limiting your exposure as you clear the corner.

Note how rounded corners or curved hallways would leave fewer angles to hide.

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FYW3bcz9DjG6uoBmeTtRR%2FLDB_MOUT_Cover_RoomClearing_SlicingThePie.png?alt=media&amp;token=3c58dc67-e38d-4dc3-80fd-fa3273a28f82" alt=""><figcaption><p>room clearing diagrams A-38 and A-47 from <a href="https://www.marines.mil/News/Publications/MCPEL/Electronic-Library-Display/Article/900535/mcrp-12-10b1/">US Marine Corps Warfighting Publication (MCWP) 3-35.3, Military Operations on Urbanized Terrain (MOUT)</a></p></figcaption></figure>

## Against cover

Sometimes ~~**less**~~ ***no*****&#x20;cover is better.**

In a tutorial or boss fight, you may prefer a very simple flat open arena design to teach the player clearly, or to keep focus on the setpiece or story moment. Cover blocks sightlines, *which can be bad* when you want the player to notice or track something.

Sometimes it's best to keep an area "empty" and open, to allow for more player expression or systems to fill-in. Like a Fortnite map provides plenty of empty space for players to build their own cover.

Or consider Counter-Strike's Dust2 map:

> *"If you aren’t familiar with the specifics of Counter-Strike, the empty stretch of road on long A may look like bad level design. In Call of Duty, this area would be a death trap, and common Call of Duty layout patterns would suggest the area needs flank routes and more cover here. However, in Counter-Strike these paths are possible in exchange for utility..."*

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FBitcSvkTRNdkwidJoR6x%2FLDB_Dust2_CombatCoverSmoke_AndrewYoder.jpg?alt=media&amp;token=d0c77b1a-8c18-4333-9ceb-0cf1c71b6eb0" alt=""><figcaption><p>screenshot of player-deployed smoke grenade used on "Long A" path in Counter-Strike 2's Dust2 map; <a href="https://andrewyoderdesign.blog/2022/04/14/a-few-kinds-of-cover/">by Andrew Yoder from blog post "Judge A Map By Its Cover"</a></p></figcaption></figure>

> *"... Smoke grenades deny vision. Smoking a threshold or t-junction can deny a path or allow a safe crossing. Smoking a corner create pockets of hidden information and off angles for enemies to worry about. Players can also deploy a smoke in the open, like the one pictured above, to create new angles for players to fight around. Smokes behave like cover objects in how they conceal information."*
>
> \-- Andrew Yoder, ["Judge A Map By Its Cover"](https://andrewyoderdesign.blog/2022/04/14/a-few-kinds-of-cover/)

### Cover boxes

Repetitive standardized cover can lead to a **cover box** feel -- spaces that feel strangely artificial with numerous conveniently-spaced consistently-sized rectangular objects.

If you don't mind levels feeling "videogame-y" then this often isn't a problem.

But arguably for a game like The Last Of Us which trades on immersive cinematic realism, then it can feel jarring or even patronizing when a place suddenly feels like a film set / arena waiting to swarm the player. Or maybe it's charmingly videogame-y?

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F0igKLfVFf3nsbpoJMtur%2FLDB_LastOfUs_Docks_CoverCombat_AndresRodriguez.jpg?alt=media&amp;token=456d478a-d1a8-4859-9f7f-e80429da243d" alt=""><figcaption><p>screenshot of "Docks" level from The Last Of Us with many rectangular waist-height cover objects ("cover boxes"); level by Andres Rodriguez, Johnathan Sek, Scott Greenway, and Elisabetta Silli <a href="https://www.artstation.com/artwork/xZkk4">(via Artstation)</a></p></figcaption></figure>

## To review\...

**Cover** is anything that blocks sightlines / attacks, usually in a combat or stealth context.

**Cover is movement**, which differs with core game design. Most arcade games are about moving *around* cover, more realistic games are about moving *with* cover, while cover shooters require moving *through* cover. **Emphasizing more cover = usually slows down combat.**

**Cover shapes** vary with Height *(half vs. full),* Width *(wide vs. narrow),* Solidity *(soft vs. hard),* and Facing *(directional vs. freestanding).* You can also consider Verticality *(trench vs. elevation),* Corners *(sharp vs. round),* Permanence *(dynamic vs. static),* and Authorship *(designer vs. player).*

Use **cover metrics** if you need consistent cover shapes. **Cover systems** often need consistent shapes. But sometimes **fuzzy cover** is fun too.

**Cover placement** depends on mechanics and player experience goals. A stealth game will need a different cover layout from a cover shooter, or even two stealth games may differ a lot. **Less cover is better** usually. The overall strength of a cover placement depends on **angled movement.**

**Sometimes&#x20;*****no*****&#x20;cover is best.** Open space enables more focus on a tutorial, boss, setpiece, or player-authored cover.

## Now what?

* For a single player level, cover factors into [encounter design](/process/combat/encounter.md).
* For a multiplayer map, cover is part of [map balance](/process/combat/balance.md).

### Further reading

* ["Judge A Map By Its Cover" by Andrew Yoder](https://andrewyoderdesign.blog/2022/04/14/a-few-kinds-of-cover/) is an analysis of Counter-Strike 2's most popular map Dust2, specifically its cover patterns and sightlines. Many ideas and examples from this page come from Yoder's post.
* [Multiplayer Map Theory (Gears of War) - Official UDK Docs](https://docs.unrealengine.com/udk/Three/GearsMultiplayerMapTheory.html) by Epic Games is multiplayer level design theory written for modders of the original Gears of War 1 back in 2006. Much of it is still relevant for cover shooter design today.
* ["How to handle cover placement" by Iuliu-Cosmin Oniscu](https://iuliu-cosmin-oniscu.medium.com/how-to-handle-cover-placement-d10580faac66) talks about cover layouts from a Ubisoft-ian open world perspective, with an emphasis on encounter design and pacing.
