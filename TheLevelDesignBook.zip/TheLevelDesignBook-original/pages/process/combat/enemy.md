> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/process/combat/enemy.md).

# Enemy design

prototyping different types of NPCs with specific behaviors, strengths, and weaknesses

## What is enemy design?

**Enemy design** is about prototyping different types of hostile NPCs with specific behaviors, strengths, and weaknesses.

Enemy design is often a complex collaboration between AI designers, programmers, character artists, animators, sound designers, etc. Which is far outside the scope of this level design book. Nonetheless, level designers must be able to conceptualize and theorize about enemy design, even if they're not the developers tasked with implementing the enemies.

&#x20;    *For some enemy design examples, see* [*Doom metrics*](/process/blockout/metrics/doom.md) *and* [*Quake metrics*](/process/blockout/metrics/quake.md)*.*

![Enemy rosters can be surprisingly complicated and varied; monster sprites from Doom 2 (1994) by id Software](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MaDzEb98ZiFVBU8oEwG%2F-MaE4n_mIT-wesVi6293%2FLDB_DoomMonsters.jpg?alt=media\&token=25ee7edb-9a69-42cc-8270-734008e7c54f)

## Enemy roster

Imagine we're making an action game. Here are some basic roles to fill on our **enemy roster**, the collection of enemy types and the combat roles they fulfill.

<table><thead><tr><th width="117.73879443585781">ROLE</th><th>BEHAVIOR</th></tr></thead><tbody><tr><td>Grunt</td><td>Close range melee attack player straightforward, easy to pull</td></tr><tr><td>Squad</td><td>Attack from mid-range / long range, ideally take turns as a group</td></tr><tr><td>Leader</td><td>High survivability, buffs nearby allies somehow</td></tr><tr><td>Tank </td><td>High survivability, but slower and larger (easy to hit or avoid)</td></tr><tr><td>Swarm</td><td>Small fast attacker with low health but high close-range damage</td></tr><tr><td>Sniper</td><td>Slow weak long range attacker, very vulnerable without others</td></tr></tbody></table>

![different Combine soldier designs from Half-Life 2 (2004) and Half-Life: Alyx (2020) by Valve Software](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FHVoz2SWMIURDOU4Si5za%2FLDB_HalfLife_CombineCombatDesignRoster_Encounters.jpg?alt=media\&token=5f0b3932-90c3-4b4d-9b9e-647db52abedd)

A finished working enemy NPC often requires designers, artists, and programmers to collaborate. It can be a lot of work, and it's far outside the scope of this level design book.&#x20;

Here we will focus on the combat designer / level designer's responsibility to advocate for gameplay features and readability:

* Unique **silhouette** so players can discern enemy type at mid-range (\~10+ meters away).
* Design details and animations that **telegraph** enemy state, intent, and strengths / weaknesses.
  * *example: in Skyrim, the giant feels big and slow, you must out-maneuver it and wear it down*

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FDF0e4FZEuXYrsLVUf2z5%2FLDB_CombatEnemyRoster_TeamFortress2_HowValveConnectsArtDirectionToGameplay_Gamefest08.jpg?alt=media&amp;token=37e3b016-ab2a-4afb-a6de-b1d4f2fe46f8" alt=""><figcaption><p>"Read Hierarchy" slide emphasizing character silhouette and chest-height contrast, from <a href="https://cdn.cloudflare.steamstatic.com/apps/valve/2008/GameFest08_ArtInSource.pdf">"How Valve Connects Art Direction to Gameplay" (Gamefest 2008) by Moby Francke and Randy Lundeen</a></p></figcaption></figure>

### Balancing a roster

It can be useful to organize the enemy roster with a spreadsheet / matrix:

<table><thead><tr><th width="150">ROLE</th><th width="150">SPEED<select><option value="d14d4be135804e6696be69f2b709a7f1" label="Slow" color="blue"></option><option value="e8071ccbc57e4ce1b05c8e6997f60415" label="Medium" color="blue"></option><option value="e0b5b4cca0dd440482f1c6386a3f1c98" label="Fast" color="blue"></option></select></th><th width="160">HEALTH<select><option value="08a41c46480d4f649416660d714deebf" label="Weak" color="blue"></option><option value="f7f9f194158d4cab911ef40a92a5d808" label="Average" color="blue"></option><option value="f23aa049bcb6404dabb303efaefa2eb0" label="Strong" color="blue"></option></select></th><th width="150">RANGE<select><option value="012d4590597a4a818fe472e4d3676acc" label="Close" color="blue"></option><option value="6f674bb3d7a946029b314530de063cf8" label="Mid" color="blue"></option><option value="29ab787a1212480fab2ded9741c57f26" label="Long" color="blue"></option></select></th><th>DPS<select><option value="6df5f8bee8bd402bb7974490c839916d" label="Low" color="blue"></option><option value="014b9544cf704863b1f5e45240ad13de" label="Medium" color="blue"></option><option value="7e527dfaec044bc7aa3cb5acf2f6e7e6" label="High" color="blue"></option></select></th></tr></thead><tbody><tr><td>Grunt</td><td><span data-option="e8071ccbc57e4ce1b05c8e6997f60415">Medium</span></td><td><span data-option="08a41c46480d4f649416660d714deebf">Weak</span></td><td><span data-option="012d4590597a4a818fe472e4d3676acc">Close</span></td><td><span data-option="014b9544cf704863b1f5e45240ad13de">Medium</span></td></tr><tr><td>Squad</td><td><span data-option="e8071ccbc57e4ce1b05c8e6997f60415">Medium</span></td><td><span data-option="f7f9f194158d4cab911ef40a92a5d808">Average</span></td><td><span data-option="6f674bb3d7a946029b314530de063cf8">Mid</span></td><td><span data-option="6df5f8bee8bd402bb7974490c839916d">Low</span></td></tr><tr><td>Leader</td><td><span data-option="e8071ccbc57e4ce1b05c8e6997f60415">Medium</span></td><td><span data-option="f7f9f194158d4cab911ef40a92a5d808">Average</span></td><td><span data-option="6f674bb3d7a946029b314530de063cf8">Mid</span></td><td><span data-option="014b9544cf704863b1f5e45240ad13de">Medium</span></td></tr><tr><td>Tank</td><td><span data-option="d14d4be135804e6696be69f2b709a7f1">Slow</span></td><td><span data-option="f23aa049bcb6404dabb303efaefa2eb0">Strong</span></td><td><span data-option="012d4590597a4a818fe472e4d3676acc">Close</span></td><td><span data-option="7e527dfaec044bc7aa3cb5acf2f6e7e6">High</span></td></tr><tr><td>Swarm</td><td><span data-option="e0b5b4cca0dd440482f1c6386a3f1c98">Fast</span></td><td><span data-option="08a41c46480d4f649416660d714deebf">Weak</span></td><td><span data-option="012d4590597a4a818fe472e4d3676acc">Close</span></td><td><span data-option="6df5f8bee8bd402bb7974490c839916d">Low</span></td></tr><tr><td>Sniper</td><td><span data-option="d14d4be135804e6696be69f2b709a7f1">Slow</span></td><td><span data-option="08a41c46480d4f649416660d714deebf">Weak</span></td><td><span data-option="29ab787a1212480fab2ded9741c57f26">Long</span></td><td><span data-option="7e527dfaec044bc7aa3cb5acf2f6e7e6">High</span></td></tr></tbody></table>

This can help balance the roster or point to gaps, but don't let the spreadsheet trap you into just one way of thinking. For example, in the matrix above:

* Only 1 Fast enemy? Maybe Leader should be Fast too, to feel more different vs Squad?
* There is no High-DPS Mid-Range enemy. Should there be? Would that be fun or useful?
* Is this matrix design too simple? Do we need a Size column, a Behavior column? etc.

To analyze the enemy roster in an existing game: play many levels, and then make your own spreadsheet with your own columns.

* What kind of terrain / placement works best for each enemy type?
* Which enemy types work well together? Why?
* Which enemy combinations are present in which levels?

![the Grunt, Elite, Jackal, and Hunter are distinctive Covenant faction enemies from Halo 1 (2001) by Bungie](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FwikRGFeyppGh71QsQLHO%2FLDB_Halo1_EnemyRoster_CombatEncounter.png?alt=media\&token=002f386d-5e9b-4b60-8bc6-ead3f6f32fdd)

## Enemy design advice

Some general industry consensus / advice on designing enemy types and rosters:

* *Diversity.* Each type should feel different to fight, avoid similar enemies.
* *Hierarchy.* Some types are weaker, some are stronger. Make this ranking clear.
* *Longevity.* Types should not become obsolete. A weak early-game enemy should still be interesting later on, or a mid boss should transition to become a regular type, etc.
* *Emergence.* Different combinations of enemy types should create different situations. The same tactics, used against each type in isolation, should be less effective.
* *Intelligence.* Give the illusion of intelligence and different emotional states (afraid, angry, etc.)
  * "Smart" enemies should have high survivability / health, or else they'll die before they can show off how smart they are.
* *Consistency.* Feel predictable, with clear patterns for the player to recognize and exploit.

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FUAps6vMpOvWxobyjB1M2%2FLDB_DoomCombatEnemyOrthogonalMatrix_MeaningfulChoiceInGameLevelDesign_MattiasWorch.jpg?alt=media&amp;token=374a4855-2a6a-4c96-9a59-3bac2be977d7" alt=""><figcaption><p>matrix plot of "orthogonal unit differentiation" of Doom 2 monsters, where horizontal axis is "Stay Back vs Charging" behavior and vertical axis is "Projectile vs Hitscan" attack... slide from <a href="https://www.youtube.com/watch?v=BEF4GVNzkUw">"Meaningful Choice in Game &#x26; Level Design" by Matthias Worch</a> at GDC 2014 <a href="http://www.worch.com/2014/03/23/decisions-that-matter/">(Slides PDF)</a></p></figcaption></figure>

## How to design an enemy

### 1. Define core enemy design

For most 3D action games, each enemy design needs to answer these questions, at least:

* **Health:** how strong is this enemy, how long can it usually survive?
* **Speed:** how fast does this enemy move? Slower or faster than the player?
* **Damage:** how dangerous are the enemy's attacks?
* **Range / Behavior:** does the enemy attack at close range or mid range / long range?

For an initial design, specific numbers are less important because these numbers will likely change drastically. It is enough to estimate "10% / 50% / 100%" or "low / medium / high", and tune the specific numbers later when you actually begin prototyping and playtesting.

#### HEALTH

How many resources must the player spend to disable this enemy?

Variations on health: armor / shields, stun / stagger

<div align="left" data-full-width="false"><figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Ltl6WEWlIdpFwv9uPHR%2F-Ltl7Fdr1JyF2Yg7i2O_%2Fgdc2002_halo1_tougher-smarter.png?alt=media&amp;token=832ee172-910a-4e79-b91a-f0b83c51e393" alt=""><figcaption><p>slide from a 2002 Bungie design talk about enemy design in Halo, suggesting a correlation with "tougher = smarter"</p></figcaption></figure></div>

#### RANGE / BEHAVIOR

For the 3D action game Skylanders: Spyro's Adventure, Activision-Blizzard designer Mike Stout talks about how the design team conceptualized 4 main archetypes ("Near, Far, Swarmer, Heavy") as well as their behaviors. He argues melee enemies by themselves are usually pretty boring, and ranged enemies are important for level design:

> *"Far Enemies are super simple, they're just dudes that shoot at you. But they're very interesting because environment matters \[here]. When you have Near Enemies, since they can't attack you from far away, your environment doesn't matter at all: you got them up on a ledge, behind cover -- it's all the same as fighting on a flat plane. So adding Far Enemies to a setup, and mixing them with other types, means all of a sudden your level design is going to start to matter."*
>
> \- Mike Stout, [GDC 2012: "Reaching Into the Toy-Chest: A Look into Skylanders: Spyro's Adventure's Design"](https://www.gdcvault.com/play/1015838/Reaching-Into-the-Toy-Chest)

!["Far Enemies" slide, listing core AI behaviors for a ranged enemy NPC, from GDC 2012: "Reaching Into The Toy-Chest: A Look Into Skylanders Spyro's Adventure's Design" by Mike Stout (via GDC Vault)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FM7vrEtuIuX99gobPUa1d%2FLDB_GDC2012_Skylanders_CombatFarEnemy.png?alt=media\&token=852b3154-5f00-4005-8169-9dfa97c1a0c2)

Variations on range:

* Projectile design (speed, movement pattern)
* Size (a small distant thing is harder to notice and attack vs. a big distant thing)

### 2. Blockout test arena&#x20;

* One big box room is often all you need, don't spend more than a few minutes on this
* For ranged enemies, also build raised ledge / gap / cover variations
* Simple basic all-purpose pattern for flanking and cover: iceworld 3 lane

### 3. Prototype enemy

* Create a placeholder object
  * Colored shapes like blocks and capsules that slide around
  * Pre-made assets, reuse existing character art but with a different color
* Script the behavior
  * if the game engine or tool has a robust scripting system or AI system, you may be able to prototype the enemy without editing game code directly
  * but usually, you will need to do some game programming
  * common AI scripting patterns: state machines, behavior trees, or a bunch of `if()` blocks
* Playtest the enemy prototype
  * If possible, get console commands / debug menus for spawning even more enemies in-game at runtime

### 4. Tune enemy

Once the enemy is functional in-game, your work has only just begun. You must now tune the enemy's stats and behaviors to fulfill your experience goals.&#x20;

**For early tuning passes, make only big changes.** Do not make small adjustments because you won't be able to notice such small adjustments at this early stage.

<details>

<summary><em>EXAMPLE: Imagine you're tuning an enemy's health points...</em></summary>

It has 100 health, but feels too weak and needs to be stronger. Do NOT try 115 health, that's a small change and you may not even feel any difference in the playtest. Try 200 health instead.&#x20;

* If 200 feels too strong, congratulations! You've now established a range of 100-200 to tune between. Now try 150.
* But if 200 still feels too weak, you should try 300 or even 400. Keep going until you've established a range, then reverse.

</details>

### 5. Let it rest, return later

The full enemy design process can take many years over the course of the entire project, as you gradually add new enemies, weapons, player progression, levels, etc.&#x20;

Your project team may suddenly cut a half-finished enemy type to meet an important deadline. Or maybe you'll need to demote a boss design to a weaker reusable "midboss" type. A perfectly-tuned enemy may suddenly feel obsolete or broken. This is just the nature of creativity and game design: the project will change and develop.

TODO: example, HL2 chopper

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FCjg8I3JrzyeJDRaJDDkH%2FLDB_DoomCombatEnemyFrequencyWaves_MeaningfulChoiceInGameLevelDesign_MattiasWorch.jpg?alt=media&amp;token=b6ddb647-42ca-4dca-95ca-3bb6d1bfb2d0" alt=""><figcaption><p>different frequencies / rhythms for fighting the imp, shotgunner, and chaingunner from Doom 2... slide from <a href="https://www.youtube.com/watch?v=BEF4GVNzkUw">"Meaningful Choice in Game &#x26; Level Design" by Matthias Worch</a> at GDC 2014 <a href="http://www.worch.com/2014/03/23/decisions-that-matter/">(Slides PDF)</a></p></figcaption></figure>

## Boss design

(to do)

basically the same process as general enemy design but now it's a big setpiece

except you should also keep iterating on the arena blockout while you prototype the boss

A boss doesn't have to be a new enemy type, it can be an existing enemy type with special scripting, or even a puzzle designed around an NPC. Any climactic setpiece with conflict and danger will feel like a boss fight.

## To review\...

* **Enemy design** is a lot of work and usually requires collaboration with artists and programmers to create a usable finished in-game enemy.
* **Enemy rosters** help you balance enemy types within an ecosystem. Avoid redundant enemies which do not have a clear purpose or use case.
  * **Diversity** is important. You'll likely need a mix of weak and strong, slow and fast, small and big, close range and long range, and everything in-between.
* How to design an enemy:
  1. Define core stats like **health**, **speed**, **damage**, and **range / behavior**.
  2. **Blockout** a big box test arena, but don't spend more than a few minutes making it.
  3. Prototype the enemy and **playtest**, you may need scripting or programming knowledge.
  4. **Tune** the enemy; try big changes, avoid small adjustments when prototyping.
* **Boss design** is a special case, a unique setpiece encounter tied more closely to a specific level. Keep iterating on the boss arena blockout.

## Now what?

* Consider other general [combat design](/process/combat.md) concepts.
* Use enemies for [encounter design](/process/combat/encounter.md).
