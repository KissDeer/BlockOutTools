> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/process/overview.md).

# How to make a level

Overview of general workflow and concepts for video game level design

Most 3D level design projects involve this process:

1. [**Pre-production**](/process/preproduction.md): plan out the big ideas and overall experience design.
2. [**Combat**](/process/combat.md) **(optional)**: for combat games, define how player(s) and enemy types interact.
3. [**Layout**](/process/layout.md)**:** sketch a visual top-down 2D plan for a level.
4. [**Blockout**](/process/blockout.md)**:** build a basic in-game 3D rough draft and playtest it.
5. [**Scripting**](/process/scripting.md): integrate events and behaviors (missions, quests, doors, buttons, AI)
6. [**Lighting**](/process/lighting.md)**:** arrange light sources for depth and readability
7. [**Environment Art**](/process/env-art.md): "art pass" the level with props and set dressing
8. [**Release**](/process/release.md): document, publicize, and publish the project.

If you don't know where to start, try doing everything. With more experience, you will learn when to skip or expand a phase.

![underpass in de\_dust by Dave "DaveJ" Johnston, for Counter-Strike 1.6](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lu58xf7oEP7GGmBzX1_%2F-Lu59-ymdYcYVhp24tQN%2Fresearch_dust_underpass.jpg?alt=media\&token=0a598225-b30d-46fa-8e67-f8c65e07a62a)

## Tailor the process

Every level / project has different needs. There is no single foolproof way to make a level.

* **Group projects** need more [**pre-production**](/process/preproduction.md) and planning, like [pacing](/process/preproduction/pacing.md) outlines and [layout](/process/layout.md) drawings. Without enough communication and documentation, collaborators can't collaborate.
* [**Combat**](/process/combat.md) **games / multiplayer maps** need more [**blockout**](/process/blockout.md) time to tune [encounters](/process/combat/encounter.md) and [map balance](/process/combat/balance.md) with a strong focus on [**playtesting**](/process/blockout/playtesting.md)**.**
* **Single player levels with a** [**storytelling**](/process/env-art/storytelling.md) **focus** benefit less from a long blockout period. That may sound appealing but it's actually a special hell with zero certainty. When is a story "good enough"? You'll need a lot of iterations on [scripting](/process/scripting.md) and [environment art](/process/env-art.md). If your story changes, you'll have to redo everything, and it's hard to keep everything in sync. Ever play a game where the story doesn't make sense? That's probably going to be your game too.

## Process overview

### 1. [Pre-production](/process/preproduction.md)

**Pre-production** is about planning the basic shape and scope of the project. What is the project about? What are the design goals and constraints?

Beginners often neglect project planning entirely, while experienced designers sometimes over-plan. Big commercial studios often spend months or even years in pre-production. When collaborating in a group, this phase is very important because this is when you all align your expectations. When working solo as a hobbyist, you can probably get away with less planning.

Pre-production plans are usually text documents, boards with movable cards, and spreadsheets.

&#x20;   *For more on conceptual planning, see* [*Pre-production*](/process/preproduction.md)

![photo of internal planning board for The Last Of Us (Naughty Dog), from "Videogames" at Victoria and Albert Museum](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lu4Y_E2F6Jj22AaTeoF%2F-Lu4cB1iELo7OzM1v7oa%2Fv%26a_lastOfUs_planning_board.jpg?alt=media\&token=db00790c-1290-4394-a553-15c3cc974967)

### 2. [Combat design](/process/combat.md) (optional)

If your project is about combat, then what does a typical fight look like, what is a battle made of? How do players prepare? How can you make fights feel varied and fresh?&#x20;

Combat is like any other game system or mechanic. You should define these experience design goals *before* you make levels for them.

If you're making a combat game from scratch, the fights won't "feel good" until programmers and artists make it functional and readable. You basically have to make the whole game before you'll know what the combat feels like! Because it's so much work, we recommend modding combat games so you can practice on pre-built battle-tested systems.

&#x20;    *For more on designing fights, weapons, and enemies, see* [*Combat*](/process/combat.md)*.*

&#x20;    *For a list of recommended combat games to mod, see* [*Tools*](/appendix/tools.md)*.*

![spreadsheet breakdown showing the moveset matrix for valkyrie bosses in God of War (2018), ​by Jason de Heras (via Twitter)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MWv39_9hxX4YRTiVgLr%2F-MWvAiVCuI_Tvzecv6YL%2FLDB_Encounter_Matrix_GodOfWarValkyries_JasonDeHeras.png?alt=media\&token=70e31f40-2846-46d2-a2ef-cc38d43e09c4)

### 3. [Layout](/process/layout.md)

The **layout** is the basic structure of the level, usually a flat 2D drawing of core areas and elements.&#x20;

For a small solo hobby project, a simple layout sketch, even a scribble, can be enough.

For a group / big project, detailed layout drawings are important communication tools. No one can read your mind; if you don't visualize it and talk about it, then no one will know what you want.&#x20;

Layout drawings are usually top-down 2D floor plans, but isometric / perspective drawings are common too. Remember, this isn't about being a great artist; it's about communication! The drawing is a visual plan for where the player can go and what they can do.&#x20;

&#x20;   *For more on visual space planning, see* [*Layout*](/process/layout.md)

![layout drawing of multiplayer map "Warpath" for Team Fortress Classic, by Robin Walker](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mcfk2SN77KBX1CK8_Ov%2F-McfmtS2lUdC3s1KFrgH%2FLDB_Layout_Warpath_TeamFortressClassic_RobinWalker.jpg?alt=media\&token=9c21c702-5e14-44f4-a106-83e1e560a345)

### 4. [Blockout](/process/blockout.md)

A **blockout** is a playable rough draft of the level, built with simple blocky 3D shapes in low detail.&#x20;

We prototype the basic structure of the level so we can playtest it within the game engine. Playtesting helps us decide whether the level is too small or too big, confusing or entertaining, balanced or broken, etc.

This playtesting is important for any combat game, or anything where rearranging a room can cause big changes in player behavior. If you realize a room design isn't working, then you can modify it more easily when it is made of simple shapes.

Blockout files are playable game levels / scene files loaded into the game engine.

&#x20;   *For more on in-game 3D prototyping, see* [*Blockout*](/process/blockout.md)

![blockout screenshot for a cliff level in Uncharted 4 (Naughty Dog), by Em Schatz](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LtwoKZ58xOGNTn9g_Qy%2F-Ltwq-JcDDEN7UHH9OLR%2Funcharted4_blockout_em_schatz.jpg?alt=media\&token=fe61470c-d734-4540-ab8e-a83eb330da7d)

### 5. [Scripting](/process/scripting.md)

**Scripting** is about integrating behaviors, events, and game logic into a level.

[Door scripting](/process/scripting/doors.md) is one of the most difficult problems in game development. Trains and moving platforms are even more complicated. It's better to start with buttons and collectibles.

Mission objectives, quests, cutscenes, choreography -- and any AI control / combat / [encounter design](/process/combat/encounter.md) -- often rely on scripting. If you're scared of coding, don't be afraid, many game engines and toolsets have special scripting languages and tools to simplify the programming process.

Level design culture tends to underappreciates scripters, yet scripting is what makes a level feel "alive" and is crucial for transforming a map into an experience.

&#x20;   *For more about making levels do stuff, see* [*Scripting*](/process/scripting.md)

![in an early version of Gone Home, doors didn't quite work correctly... from blog post "Code Judo" by Johnnemann Nordhagen](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MVcmniYhUKeyxyT9VDg%2F-MVcnJ7nwe4eCruqHe55%2FLDB_DoorScripting_GoneHome_JohnnemannNordhagen.jpg?alt=media\&token=ffcdfdb2-60f4-4517-b870-c80c44095d9c)

### 6. [Lighting](/process/lighting.md)

**Lighting** adds shadow and depth to a blockout, helping players understand the core shape of the level.&#x20;

Without light, the 3D game world will feel more like a flat 2D image, and it will be difficult to gauge distances or understand the full layout. Light and shadow also serve as a form of cover / layer of information essential for combat gameplay.

While the game industry usually treats lighting more as a decorative facet of environment art, we argue that lighting has crucial gameplay functions and must be crafted in deep consultation with level designers.

&#x20;    *For more on lighting design for gameplay, see* [*Lighting*](/process/lighting.md)*.*

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mh1jhg_FeQx6xy8Qe6b%2F-Mh1lkxbVgbUXAxBnb8b%2Fharley-wilson-natlight-b.jpg?alt=media&amp;token=1874b909-60db-4a01-bec9-a70b46939966" alt=""><figcaption><p>medieval lighting study with light entities <a href="https://www.artstation.com/artwork/lBLzJ">by Harley Wilson (via Artstation.com)</a></p></figcaption></figure>

### 7. [Environment Art](/process/env-art.md)

Once you have enough certainty about the overall shape and flow of the level, you can begin adding more **environment art,** or visual detail.

An **art pass** is the process of adding these details. Most projects will require multiple art passes.

Many people think art passing is the "fun part." Beginners often rush too quickly into art passing without adequate planning, layout, or blockout work. A premature art pass locks-in early design mistakes because it becomes "expensive" to change the level and thus redo all the artwork. So, resist the urge! Don't rush into an art pass!

&#x20;   *For more about making levels pretty, see* [*Environment Art*](/process/env-art.md)

![animated GIF of development process for a snowy military dock level in Sniper Elite](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MVOe7gOtBO2fR1OaIjJ%2F-MVOeNGkYd_XvSwlSxn7%2FLDB_Sniper_Rebellion_BlockoutArtpass.gif?alt=media\&token=a10f1d36-1367-4304-b106-8253f9b9ee1a)

### 8. [Release](/process/release.md)

When the project is complete, it is time to **release** and make sure it reaches your audience.

For commercial projects, the game launch is just the beginning of the nightmare -- you must continue to market and publicize the project, gauge user feedback, ship bug fixes, and even build out additional post-launch content.&#x20;

For personal portfolio projects, you must document the level design properly, or else no one will understand what you did. Without effective documentation, the project basically does not exist.&#x20;

Beginners often do not put enough time into the release phase, and assume the project will speak for itself -- *but if no one knows about it, then your work has no one to speak to.*

&#x20;   *For more on publishing a level / building a portfolio, see* [*Release*](/process/release.md)*.*

## To review

Level design usually involves multiple steps, in this general order: (1) pre-production, (2) combat design (unless it's not a combat game), (3) layout, (4) blockout, (5) scripting, (6) lighting, (7) environment art, and (8) release.

But every project is different. Sometimes you may want to skip a layout phase, or expand a scripting phase, or do environment art before scripting, etc.&#x20;

If you are early in a project or early your level design career, you should probably try doing everything until you figure out what process works best for you.

## Now what?

* Start with the beginning -- learn about [pre-production](/process/preproduction.md) for level design. Even just a little bit of planning will help a lot. It will help you figure out what the hell you're doing.
* Day-to-day, most level designers tend to focus on the [layout](/process/layout.md) and [blockout](/process/blockout.md).
