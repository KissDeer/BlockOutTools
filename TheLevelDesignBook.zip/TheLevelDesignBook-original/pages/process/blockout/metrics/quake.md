> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/process/blockout/metrics/quake.md).

# Quake metrics

player size and speed, health and damage values, common sizes and building dimensions for designing single player Quake 1 maps

Below are some core gameplay values and numbers that are useful for level design in Quake 1.&#x20;

Sometimes popular mods evolve new design norms in the community. After all, it's been more than 25 years since Quake's 1996 release. We note differences against default retail unmodded Quake ("Vanilla Quake").

&#x20;*For more on what metrics are and why they're useful, see* [*Metrics*](/process/blockout/metrics.md)*.*

&#x20;   *For lots of Quake-specific info and links, see* [*Quake resources*](/appendix/resources/quake.md)*.*

![screenshot of Quake 1 by id Software, kind of like how it appeared back in 1996](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MWwKuv36sIacrXzo8RS%2F-MWwMiIwfWDFwy2gYMXs%2Fquake1.jpg?alt=media\&token=d3172b72-6176-4e74-9225-6f7742df1516)

## Core player metrics

Quake uses the Quake Engine, obviously. So any basic scaling and metrics recommendations from the main [Metrics](/process/blockout/metrics.md) page about Quake-lineage engines (Source Engine, etc) also apply here.

* 1 Quake unit (u) = 1 inch, but not really. There is no consistent scale.
* Z-axis up
* Quake uses a "power-of-two" grid. Most mappers [blockout](/process/blockout.md) at a grid size of 64 or 32, then shift down to grid size 16 or 8 to start refining details. Use grid 4, 2, or 1 only for very small details.
* There's no crouching, sprinting, or +use key / interact button.

<table><thead><tr><th width="340">Player metric</th><th>Measurements (L x W x H)</th></tr></thead><tbody><tr><td>Collision hull size</td><td>32 x 32 x 56</td></tr><tr><td>Absolute minimum hallway width</td><td>33</td></tr><tr><td>Absolute minimum ceiling height</td><td>57</td></tr><tr><td>ViewPos / camera height above floor</td><td>46 (24u mins extent + 22u view offset)</td></tr><tr><td>Maximum run speed</td><td>320 units / second</td></tr><tr><td>Fall damage height*</td><td>256+</td></tr><tr><td>Absolute maximum step height**</td><td>18</td></tr><tr><td>Maximum climbable slope**</td><td>45 degree incline?</td></tr><tr><td>Underwater height</td><td>29+ (can die via <a href="#player-weapon-metrics">Thunderbolt discharge</a>)</td></tr><tr><td>Max jump distance (running start)***</td><td>244</td></tr><tr><td>Max standing jump height***</td><td>43</td></tr><tr><td><a href="https://quakewiki.org/wiki/Trick_Jumps">Ramp jump</a>***</td><td>96 high?</td></tr><tr><td><a href="https://quakewiki.org/wiki/Trick_Jumps">Grenade jump</a>***</td><td>~320 long - ~128 high?</td></tr><tr><td><a href="https://quakewiki.org/wiki/Trick_Jumps">Rocket jump</a>***</td><td>~320 long - ~128 high?</td></tr></tbody></table>

* \*Falling damage is -5 health if the player hits the ground at any downward vertical speed faster than 650 units / second. In practice, this means fall damage rarely kills players. To kill the player from a tall drop, create a `trigger_hurt` or `trigger_void` (implemented in some mods).
  * Consider alternate ways of punishing the player for falling (monsters below, or water, slime, lava) or maybe even just let the player fall down, explore, and find their way back up again.
* \*\* Step height and slope assumes orthogonal (90 degree) axis-aligned surfaces. Quake collision uses Axis-Aligned Bounding Boxes (AABB) with no real support for rotations, so walking up a slope along a diagonal will feel much steeper.&#x20;
  * Best practice is for ramps and slopes to be axis-aligned.
  * Many maps use Doom-style stepped terrain instead of smooth sloped terrain, partly to prevent physics problems. Monsters seem to like it better too.
* \*\*\* Jump distances and heights assume the absolute limits of a typical player.&#x20;
  * Build for a shorter jump distance / height. Most players don't have perfect reflexes and timing.
  * Don't force players to ramp jump, grenade jump, or rocket jump on the [critical path](/process/layout/flow.md#critical-path); reserve these specialty jumps for optional shortcuts or secrets.
  * Skilled players can use [bunnyhopping](https://www.quakeworld.nu/wiki/Bunnyhop) to build-up more speed and distance, change direction in mid-air, etc. But don't worry about it. Let these players break your map, it's OK.

![screenshot of a level from "Underdark Overbright" (UDOB) by Matthew 'Lunaran' Breit](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MaDzEb98ZiFVBU8oEwG%2F-MaE3nwzle80mGr3Eyy-%2FLunaran_Copper_udob1lg.jpg?alt=media\&token=b7a3a6b4-ca8f-474f-95cf-0f93f5f7c9b3)

## Common Quake building metrics

<table><thead><tr><th width="265">Building element</th><th>Recommended / typical dimensions</th></tr></thead><tbody><tr><td>Ceiling, low</td><td>64u high, bare minimum; bigger monsters won't fit</td></tr><tr><td>Ceiling, regular</td><td>128u high; recommended minimum</td></tr><tr><td>Ceiling, tall</td><td>256u+ high</td></tr><tr><td>Railing / tabletop</td><td>32u high</td></tr><tr><td>Ventilation duct</td><td>64u wide, 64u tall (there's no crouch button)</td></tr><tr><td>Hallway, regular</td><td>128u+ wide</td></tr><tr><td>Room, small</td><td>256u wide</td></tr><tr><td>Room, medium</td><td>512u wide</td></tr><tr><td>Room, large</td><td>1024u+ wide</td></tr><tr><td>Ramp</td><td>1:2 slope gradient (26.57° incline)</td></tr><tr><td>Stairs, simple</td><td>16 rise : 32 run (1:2 slope)</td></tr><tr><td>Stairs, dense</td><td>8 rise : 16 run (1:2 slope)</td></tr><tr><td>Gravity</td><td>800 units / second²</td></tr><tr><td>Low gravity</td><td>100 units / second² (in E1M8 "Ziggurat Vertigo")</td></tr></tbody></table>

## Player weapon metrics

Keep in mind this is an action game with aiming and dodging. The actual damage depends heavily on enemy behavior, available cover, height changes, enemy composition, etc. "Damage per second" is just a rough estimate.

<table><thead><tr><th width="185">Weapon</th><th width="123">Max ammo</th><th width="118">Ammo/sec</th><th width="102">Damage</th><th width="71">DPS</th><th>Range</th><th>Spread/Radius</th></tr></thead><tbody><tr><td><a href="https://quakewiki.org/wiki/Axe">Axe</a></td><td>--</td><td>--</td><td>20</td><td>40</td><td>64u</td><td>--</td></tr><tr><td><a href="https://quakewiki.org/wiki/Shotgun">Shotgun</a>*</td><td>100 Shells</td><td>-2.0</td><td>24 (4x6)</td><td>48</td><td>2048u</td><td>+/-4.4°</td></tr><tr><td><a href="https://quakewiki.org/wiki/Double-Barrelled_Shotgun">Super Shotgun</a>*</td><td>100 Shells</td><td>-2.8</td><td>56 (4x14)</td><td>80</td><td>2048u</td><td>+/-8.0°</td></tr><tr><td><a href="https://quakewiki.org/wiki/Nailgun">Nailgun</a></td><td>200 Nails</td><td>-10.0</td><td>9</td><td>90</td><td>6000u</td><td>--</td></tr><tr><td><a href="https://quakewiki.org/wiki/Super_Nailgun">Super Nailgun</a></td><td>200 Nails</td><td>-10.0</td><td>18</td><td>180</td><td>6000u</td><td>--</td></tr><tr><td><a href="https://quakewiki.org/wiki/Grenade_Launcher">Grenade Launcher</a></td><td>100 Rockets</td><td>-1.66</td><td>40-120</td><td>200</td><td>~900u</td><td>160u</td></tr><tr><td><a href="https://quakewiki.org/wiki/Rocket_Launcher">Rocket Launcher</a></td><td>100 Rockets</td><td>-1.2</td><td>40-120</td><td>150</td><td>5000u</td><td>160u</td></tr><tr><td><a href="https://quakewiki.org/wiki/Thunderbolt">Thunderbolt</a>**</td><td>100 Cells</td><td>-10.0</td><td>30</td><td>300</td><td>600u</td><td>--</td></tr></tbody></table>

* \*Shotguns are a little complicated:
  * Damage is calculated via hitscan spread; for full damage, all hitscans must hit the target.
  * The *effective range* is much lower than 2048u.
  * **Experienced Quake players use the default Shotgun more like a pistol** since it has narrow spread, faster fire, and low ammo cost.
* \*\* Firing the Thunderbolt underwater causes an explosion that kills the player. This "discharge" consumes all Cells and inflicts `cells x 35` damage. With 100 cells, that inflicts 3500 damage on *anything that can see the player underwater*... including the player.
  * but if the player has the invincibility powerup, they will survive.

{% hint style="warning" %}
In vanilla Quake, crowd control in a narrow hallway is harder than it seems -- weapons do not penetrate monsters in death animations and explosive splash damage is buggy. Recent mods like [Copper](http://lunaran.com/copper/) or [Arcane Dimensions](https://www.quaddicted.com/reviews/ad_v1_80p1final.html) fix these bugs.
{% endhint %}

![screenshot of hub level from Arcane Dimensions, by Simon 'sock' O'Callaghan et al](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MDj_ngSOdI6jitZ76zx%2F-MDjzO9IvS-gUFWrgq6l%2FArcaneDimensions.jpg?alt=media\&token=7162ef12-dc38-4cd9-8999-ab0c0869e6f2)

## Monster metrics

<table><thead><tr><th width="187">Quake Monster</th><th width="128">Health</th><th width="174">Damage</th><th width="106">Hull (WxH)</th><th>Hitbox (WxH)</th></tr></thead><tbody><tr><td><a href="https://quakewiki.org/wiki/Rotfish">Rotfish</a></td><td>25</td><td>3-6 (Bite)</td><td>32 x 56</td><td>32 x 48</td></tr><tr><td><a href="https://quakewiki.org/wiki/Rottweiler">Rottweiler</a> (dog)</td><td>25</td><td>1-24 (Bite), <br>10-20 (Jump)</td><td>64 x 88</td><td>64 x 64</td></tr><tr><td><a href="https://quakewiki.org/wiki/Grunt">Grunt</a> (shotgun)</td><td>30</td><td>1-16 (Hitscan Shotgun)</td><td>32 x 56</td><td>32 x 64</td></tr><tr><td><a href="https://quakewiki.org/wiki/Zombie">Zombie</a></td><td>60 + revives until <a href="#gibbing">gibbed</a></td><td>10 (Flesh Shot)</td><td>32 x 56</td><td>32 x 64</td></tr><tr><td><a href="https://quakewiki.org/wiki/Knight">Knight</a></td><td>75</td><td>12-18 (Sword), <br>20-30 (Charge)</td><td>32 x 56</td><td>32 x 64</td></tr><tr><td><a href="https://quakewiki.org/wiki/Enforcer">Enforcer</a> (laser)</td><td>80</td><td>15 (Laser Shot)</td><td>32 x 56</td><td>32 x 64</td></tr><tr><td><a href="https://quakewiki.org/wiki/Scrag">Scrag</a> (flyer)</td><td>80</td><td>9 (Projectile)</td><td>32 x 56</td><td>32 x 64</td></tr><tr><td><a href="https://quakewiki.org/wiki/Spawn_(monster)">Spawn</a> (blob)</td><td>80</td><td>10-20 (Jump), <br>120 (Explosion)</td><td>32 x 56</td><td>32 x 64</td></tr><tr><td><a href="https://quakewiki.org/wiki/Ogre">Ogre</a> (big dude)</td><td>200</td><td>4-12 (Chainsaw), <br>40 (Grenade)</td><td>64 x 88</td><td>64 x 88</td></tr><tr><td><a href="https://quakewiki.org/wiki/Death_Knight">Death Knight</a></td><td>250</td><td>20-36 (Sword), <br>9 x 6 (Bolts)</td><td>32 x 56</td><td>32 x 64</td></tr><tr><td><a href="https://quakewiki.org/wiki/Fiend">Fiend</a> (jumper)</td><td>300</td><td>40-50 (Jump), <br>10-15 (Claw)</td><td>64 x 88</td><td>64 x 88</td></tr><tr><td><a href="https://quakewiki.org/wiki/Vore">Vore</a> (spider legs)</td><td>400</td><td>40 ("Voreball" Homing Shot)</td><td>64 x 88</td><td>64 x 72</td></tr><tr><td><a href="https://quakewiki.org/wiki/Shambler">Shambler</a> (big furry)</td><td>600 + 50% explosive resist</td><td>10-30 (Lightning, range: 600), <br>80-120 (Claw)</td><td>64 x 88</td><td>64 x 88</td></tr></tbody></table>

### Monster collision

Quake has two collision systems. QBSP bakes **collision hulls** for basic movement clipping (entity vs world collisions), and then there's also **hitboxes** for moving objects (entity vs entity collisions). Both collision types use AABB (axis-aligned bounding box) shapes that cannot rotate.

There are three (3) world collision hull sizes:

* **hull 0: 1x1x1** ("points" like projectiles, missiles)
  * but a missile's *hitbox* is 32x32x32 (via movetype `FLYMISSILE` / `BOUNCEMISSILE`)
  * and in-game, missiles don't even use this hull, and traverse the BSP instead
* **hull 1: 32x32x56** ("small" players, humanoids)
* **hull 2: 64x64x88** (large monsters)

Meanwhile, hitbox sizes vary slightly for every monster, and are listed in the table above.

#### ADVICE: HOW TO AVOID STUCK MONSTERS

Allow more extra space beyond the monster's size or else it will have trouble moving around: **at least 16 units above ground / 16 units away from walls.** Placing monsters slightly in the air is common.

Generally, place monsters **in spaces at least&#x20;*****double*****&#x20;their width and height**.

* For example, an Ogre (64 x 88) is better in a room that's 128+ wide and 176+ tall. For ease of construction, it's common to round up the room height to an increment of 64 (192, 256).
* Fiends and Spawns jump a lot and definitely need a 128+ tall room, ideally 256.
* But sometimes less monster movement is better, it all depends on the level.

### Gibbing

**Gibbing** occurs when monsters get damaged a lot, all at once. If their health drops below a certain negative threshold quickly enough, then they turn into "gib" pieces instead of playing their death animation. This generally only happens when the player uses explosive weapons (grenade launcher, rocket launcher) or the quad damage powerup.

In vanilla Quake this mechanic only matters for zombies, who revive themselves unless they lose all their health (60) within a single frame and become gibbed. Again, the player will usually need explosives or a quad to kill the zombies permanently.

### Infighting

**Infighting** happens when a monster damages a *different* monster type, which causes the hurt monster to target the other monster instead of the player.&#x20;

For example, when an ogre's grenade accidentally hurts a fiend, the fiend will turn around and attack the ogre. But if an enforcer's laser hits another enforcer, no infighting will occur.

Melee-only monsters will never cause infighting. Only ranged monsters can.

| LESS INFIGHTING                 | MORE INFIGHTING                      |
| ------------------------------- | ------------------------------------ |
| Just melee or just ranged types | Mix melee and ranged types           |
| Fewer monsters, fewer types     | More monsters, more types            |
| Elevate / leash ranged monsters | Keep ranged monsters at ground level |
| Spread out monsters             | Pack monsters together tightly       |
| Wide open space                 | Smaller space with chokepoints       |

Frequent infighting can make encounters feel too easy and unbalanced. But sometimes infighting makes for a more interesting battle. It all depends.

It is possible to design your map to *require* infighting by placing many monsters / less ammo. However, balancing these types of combat puzzles is complicated. Make sure to set a clear player expectation that infighting is required, otherwise players will be confused why there wasn't enough ammo. We recommend designing these situations only for Hard mode.

### Skill level / difficulty levels

Quake has 4 difficulty levels: `skill 0` "Easy", `skill 1` "Normal", `skill 2` "Hard", and `skill 3` "Nightmare".&#x20;

In general, health and damage do not scale automatically with difficulty level; skills 0-2 depend on mappers to manually adjust monster count and items.&#x20;

The exception is skill 3 Nightmare, which enforces several code-level changes:

* 1996 vanilla Nightmare:
  * faster monster attack speed / frequency
  * less likely to stun monsters (enter "pain frame" animations)
  * Shambler lightning lasts 33% longer, for a maximum of 40 damage
  * Vore balls move 40% faster
* 2021 remaster / [Copper Nightmare](http://lunaran.com/copper/changes/#skill-levels):
  * all 1996 Nightmare-specific changes reverted; Hard is now identical to Nightmare
  * except the player's maximum health is now 50 instead of 100

## Item metrics

### Ammo

There are three ways to get ammo: pickup an ammo **item**, pickup a **weapon**, or pickup a **drop** from a dead monster.

<table><thead><tr><th width="251">Ammo pickup / drop</th><th width="135">Source</th><th width="131">Type<select><option value="QAcBvrlgrpxR" label="Shells" color="blue"></option><option value="Q5E6WB2ichV0" label="Nails" color="blue"></option><option value="j9hBJDPRF5i1" label="Rockets" color="blue"></option><option value="diYA4s5VKaD8" label="Cells" color="blue"></option></select></th><th>Amount</th></tr></thead><tbody><tr><td><strong>item_shells</strong></td><td><strong>Item</strong></td><td><span data-option="QAcBvrlgrpxR">Shells</span></td><td><strong>+20 (large: +40)</strong></td></tr><tr><td>weapon_shotgun</td><td>Weapon</td><td><span data-option="QAcBvrlgrpxR">Shells</span></td><td>+25</td></tr><tr><td>weapon_supershotgun</td><td>Weapon</td><td><span data-option="QAcBvrlgrpxR">Shells</span></td><td>+5</td></tr><tr><td>monster_grunt</td><td>Drop</td><td><span data-option="QAcBvrlgrpxR">Shells</span></td><td>+5</td></tr><tr><td><strong>item_spikes</strong></td><td><strong>Item</strong></td><td><span data-option="Q5E6WB2ichV0">Nails</span></td><td><strong>+25 (large: +50)</strong></td></tr><tr><td>weapon_nailgun</td><td>Weapon</td><td><span data-option="Q5E6WB2ichV0">Nails</span></td><td>+30</td></tr><tr><td>weapon_supernailgun</td><td>Weapon</td><td><span data-option="Q5E6WB2ichV0">Nails</span></td><td>+30</td></tr><tr><td><strong>item_rockets</strong></td><td><strong>Item</strong></td><td><span data-option="j9hBJDPRF5i1">Rockets</span></td><td><strong>+5 (large: +10)</strong></td></tr><tr><td>weapon_grenadelauncher</td><td>Weapon</td><td><span data-option="j9hBJDPRF5i1">Rockets</span></td><td>+5</td></tr><tr><td>weapon_rocketlauncher</td><td>Weapon</td><td><span data-option="j9hBJDPRF5i1">Rockets</span></td><td>+5</td></tr><tr><td>monster_ogre</td><td>Drop</td><td><span data-option="j9hBJDPRF5i1">Rockets</span></td><td>+2</td></tr><tr><td><strong>item_cells</strong></td><td><strong>Item</strong></td><td><span data-option="diYA4s5VKaD8">Cells</span></td><td><strong>+6 (large: +12)</strong></td></tr><tr><td>weapon_lightning</td><td>Weapon</td><td><span data-option="diYA4s5VKaD8">Cells</span></td><td>+15</td></tr><tr><td>monster_enforcer</td><td>Drop</td><td><span data-option="diYA4s5VKaD8">Cells</span></td><td>+5</td></tr></tbody></table>

* All ammo item pickups can be flagged as "large", which doubles the ammo they provide.
* [**Gibbed**](https://quakewiki.org/wiki/Gib) **monsters do not drop ammo.**
* Army grunts die to 2 shotgun shots, but drop 5 shells, resulting in +3 "profit". If you use a lot of these monsters in the level, then balance your item\_shell quantity accordingly.
* Ogres die to two rockets, but also drop two rockets, so using rockets on them is "free." Or alternatively, you can think of them as a way to exchange other ammo types for rockets.
  * For this reason, the rebalance mod Copper reduces the ogre drop to only 1 rocket.
  * But don't *require* players to use any of this "economic thinking." See [Advice](#advice).
* Nails / spikes are the only ammo type that do not drop from monsters.

### Armor

Player armor follows an overcomplicated formula, and honestly, we recommend just ignoring these details. It's not important. But for the sake of completeness:

* When the player gets hurt while wearing armor, they lose armor points (instead of health) based on the armor type's damage absorption rate.
  * *example: Red Armor will absorb 80% of the damage you receive and subtract it from your armor points instead -- in practice, that means Red Armor rarely lasts very long, even though it seems like you get more of it.*&#x20;
* If you have too much of a better armor color, then you can't pick up a worse armor color.
  * *example: if you have 114+ points of Red Armor, then you can't pickup Yellow Armor.*

<table><thead><tr><th width="176.19858156028369">Armor type</th><th width="155">Armor amount</th><th width="139">Absorption</th><th>Armor switch threshold</th></tr></thead><tbody><tr><td><a href="https://quakewiki.org/wiki/Green_Armor">Green Armor</a> <em>(item_armor1)</em></td><td>+100</td><td>~33%</td><td>--</td></tr><tr><td><a href="https://quakewiki.org/wiki/Yellow_Armor">Yellow Armor</a> <em>(item_armor2)</em></td><td>+150</td><td>~60%</td><td>50 or lower (to Green)</td></tr><tr><td><a href="https://quakewiki.org/wiki/Red_Armor">Red Armor</a> <em>(item_armorInv)</em></td><td>+200</td><td>~80%</td><td><p>113 or lower (to Yellow)</p><p>38 or lower (to Green)</p></td></tr></tbody></table>

* Green is common in single player maps
* Yellow is considered to be pretty powerful, use carefully and sparingly
* Traditionally, Red is very rare, and reserved more as a reward for a secret

### Powerups

<table><thead><tr><th width="198.08236536430832">Powerup type</th><th width="366">Effect</th><th>Duration</th></tr></thead><tbody><tr><td><a href="https://quakewiki.org/wiki/Biosuit">Biosuit</a></td><td>Breathe underwater, zero slime damage, lava does less damage</td><td>30 seconds</td></tr><tr><td><a href="https://quakewiki.org/wiki/Ring_of_Shadows">Ring of Shadows</a></td><td>Invisibility; but once you attack a monster, it sees you</td><td>30 seconds</td></tr><tr><td><a href="https://quakewiki.org/wiki/Mega-Health">Megahealth</a></td><td>+100 health, ignores max health; stack up to 250</td><td>-1 Health > 100<br>every 5 sec.</td></tr><tr><td><a href="https://quakewiki.org/wiki/Pentagram_of_Protection">Pentagram</a></td><td>Invulnerability, immune to telefrag and thunderbolt water discharge</td><td>30 seconds</td></tr><tr><td><a href="https://quakewiki.org/wiki/Quad_Damage">Quad Damage</a></td><td>All damage multiplied by 4; more likely to gib monsters</td><td>30 seconds</td></tr></tbody></table>

* in vanilla Quake, the Biosuit and Ring are considered lackluster powerups with limited benefit that depend heavily on the level designer
* the Quad is probably the most interesting powerup
  * lets the player gib zombies with just the Axe or Shotgun
  * gibs enemies more often, which means they don't drop ammo
  * but also an opportunity to conserve ammo, e.g. use 1 rocket to clear an entire room
  * splash damage from grenades / rockets can easily backfire, killing the player instantly

## Advice

* Quake monsters aren't very clever, which is part of the charm. Think of their movement more like semi-chaotic pinball rather than a tactical cover shooter.
* Give more ammo than the player will need. A first playthrough will waste ammo. If the player theoretically needs only 20 shotgun shells used with perfect economy and accuracy, then you should probably give at least 40.

&#x20;    *For more general advice on designing combat, see* [*Encounters*](/process/combat/encounter.md)*.*

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FUh80km7nbVip6So2CHFM%2FLDB_Lunaran_BalancingSkillLevelsForQuake1.png?alt=media&amp;token=4d603dcd-52cd-4e97-9e95-3a00753e4290" alt=""><figcaption><p>example of increasingly challenging shotgun placements by Lunaran from <a href="https://www.slipseer.com/index.php?threads/balancing-skill-levels-for-quake.554/">"Balancing Skill Levels for Quake"</a></p></figcaption></figure>

Lastly, here's veteran Quake modder Matt "Lunaran" Breit with some Quake-specific advice and approaches for [balancing encounters, item placement, and difficulty](https://www.celephais.net/board/view_thread.php?id=4\&start=19937\&end=19944):

> I think resisting "easier is just fewer monsters" design is the right way to go. There should be fewer monsters, just not many fewer, because too few is just plain boring. We're all Quake Experts after 20 years of this, so I think anyone playing custom maps on Easy in 2018 is doing so because they're doing it on a lunch break or a stolen evening away from the kids, and not because they can't handle more than one fiend at a time. Maybe we should think of it more as 'higher investment.' Besides, Quake gives you tons of unappreciated variables that you can tweak by skill, both obvious and subtle.
>
> * Armor makes Quake significantly easier. More reds and yellows, more often, effectively extends the player's survivability in a given fight by hundreds of HP. More Greens, or stretches without armor at all, shrink the until-death buffer to little more than the player's current health. If you do want to keep the same monster loadout on all three skills, give the Easy player several Red and Yellow armors and the Hard player only one or two Greens. They'll feel like completely different games.
> * Adding a vote for weapon pickups coming earlier or later. On Easy, the next big weapon might come before the next big encounter so the player can kick ass with it, on Medium it might be placed within it so the player has to engage to grab it, and on Hard it might only come as a reward after beating the fight entirely without it.
> * Greater monster variety leads to more ways the player can be attacked at any one time, requiring juggling more variables to avoid damage and find the safe place to be standing at any given millisecond. A shambler and a vore together are harder to handle than a pair of either. Variety also raises the chances of infighting, however.
> * The angles that enemies are presented from makes a difference. In front of the player is easier, flanking is harder, behind is bordering on unfair depending on circumstances. Below the player is a turkey shoot, eye level is straightforward, and monsters up high have a distinct advantage.
> * Quantity of resources matters, of course. Bigger medkit pools clearly make the game easier, plentiful rockets can be splashed around while rare ones are only for emergencies, etc. Nail weapon DPS is higher than SG/SSG DPS and so on.
> * Frequency of resources matters too. A steady drip lets the player feel secure, but isolated bursts create situations where the player has to stretch himself to get to the next 'island'. Depending on where he makes his errors, he might have to stretch pretty hard (eg those 'quicksave with 5 health left' or 'shambler axe dance or bust' moments). Feast-or-famine item placement can induce mild stockholm syndrome, leading to more positive reviews :)
> * Unless you're using a lot of Enforcers, maybe provide all players an early Lightning Gun and simply vary the cells provided, as a way of dealing more or fewer 'get out of jail free' cards.
> * Don't forget that the difficulty spawnflags are present on every entity. If you're using monster closets, vary the locations of the ambush triggers. Have the Hard ambushes happen when the player is in the worst possible position, and give them a leg up or more warning on easier skills (or even leave the closet open on Easy so there's no surprise at all). You might even duplicate the doors so you can set different 'speed' keys per skill, so the harder ambushes are an instant pants shitting and the easier ones are more like a countdown until the monsters come out, complete with early warning aggro sounds. Doors can be temporarily barred behind the player on hard skills while he is free to retreat from a fight on easier ones. Falling into a pit can be a mild backtracking inconvenience on easy skills but death by spikes on harder ones. How much room is there between nail shooters in this hallway? With careful use of triggerable lights and skill-specific trigger\_relays, you can even use light and darkness against the player differently.
>
> Getting crafty with what you change between difficulty levels can give you ideas for entire encounters, although don't rely on that too much for interest, because any given player is probably only going to experience one such permutation and thus won't realize the need to appreciate how different it is from any others.&#x20;
>
> Here's a method I've been using. It's really rough, and time consuming without a custom progs to do it for you, but it can be a helpful way to ground your estimates.
>
> A box of: 25 or 50 nails = 225 or 450 damage 20 or 40 shells = 440/880 dmg 6 or 12 cells = 180/360 dmg
>
> 6/12 rockets are harder to judge because of 1) splash damage and 2) zombies, but let's say every rocket is 180dmg, for 1080/2160 dmg per box.
>
> Total all the ammo you provide in the map (add 25 shells for the starter ammo, add 2 rockets per ogre and 5 shells per grunt and so on), and that's the max amount of hit point damage you are giving the player to deal. Total the starting health of all the monsters, and compare the two numbers.
>
> Researching id maps and popular custom maps reveals an average 'custom' of about \~3:1 on Easy, \~2.2.:1 on Medium, and \~1.7:1 on Hard. the id maps are generally above that curve (4/3/2:1), and custom maps tend to fall below it(2.5/2.0/1.5:1).
>
> Careful cheapskate shot-counters can finish a map with a ratio of about 1.3:1 ammo DP:monster HP, but most players will have to resort to the axe at some point and will complain of shortage. RPGSP1, which was greeted by universal reviews of "good but I ran out of ammo at the end" still had a ratio on skill 2 of 1.4:1 DP:HP.
>
> There are lots of outliers to these curves, though, because so much of it comes down to how the level design enables the player to use the weapons, as well as exploit infighting, choke points, etc. Do rockets get spent one at a time on individual zombies or can they be used to gib crowds of knights for maximum ROI? or are they useless against herds of shamblers?
>
> It also matters when the player gets the ammo. Ammo the player doesn't pick up or can't use is effectively not present in the map at all. Does it come too late to be used when it was really needed? does it come too early and get skipped? or partially wasted when picked up by a player who's already nearly maxed and getting too much at the wrong times? How much of that ammo is in secret areas?

Also keep in mind, you can toggle different platforms / walkways per difficulty, to make traversal easier or harder for the player. It's not just about item and monsters.

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FqToZrlORMAqkS6PSmQnS%2FLDB_Lunaran_BalancingSkillLevelsForQuake_2.png?alt=media&amp;token=8186f24b-3fc4-47be-a7eb-06c48120ffba" alt=""><figcaption><p>examples of Easy / Normal / Hard traversals, by Lunaran via <a href="https://www.slipseer.com/index.php?threads/balancing-skill-levels-for-quake.554/">"Balancing Skill Levels for Quake"</a></p></figcaption></figure>

## Further reading

* [Copper - Changes](http://lunaran.com/copper/changes) is an epic 5000 word design essay on Quake's design and how modder Matt "Lunaran" Breit approached his influential rebalance mod Copper.
* We have a dedicated [Quake resources](/appendix/resources/quake.md) page with a lot more info and links.

### Sources

* [QuakeWiki.org](https://quakewiki.org/wiki/Singleplayer_guide) - see list of [Monsters](https://quakewiki.org/wiki/Monsters), list of [Weapons](https://quakewiki.org/wiki/Weapons), under [GNU Free Documentation License v1.3+](https://www.gnu.org/licenses/fdl-1.3.html)
* [Quake Wiki (Fandom)](https://quake.fandom.com/wiki/Quake), under [Creative Commons CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/) license
