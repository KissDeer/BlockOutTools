> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/process/blockout/metrics/doom.md).

# Doom metrics

health and damage values, common sizes and dimensions for Doom maps

Below are some core gameplay values and numbers that are useful for level design in Doom / Doom 2.&#x20;

However, keep in mind this is an action game with aiming and dodging -- so the actual damage and damage per second (DPS) will depend heavily on enemy behavior, available cover, height changes, enemy composition, etc.

&#x20;*For more on what metrics are and why they're useful, see* [*Metrics*](/process/blockout/metrics.md)*.*

![MAP07 "Dead Simple" from Doom 2, by American McGee and Sandy Petersen](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MWwF44URjg88NMz-OF3%2F-MWwIRW8W0Iwo1pox6n-%2FLDB_Doom2_DeathSimple_Mancubus.png?alt=media\&token=9932a024-5478-4db0-91db-eb1d471405dd)

## World metrics

#### Units and scale

Doom uses a grid with power-of-two numbers (e.g. 8, 16, 32, 64, 128, 256...) and textures are designed to work in increments of 8, 16, or 32.

[Doom's graphics were designed for a 16:10 aspect ratio](https://doomwiki.org/wiki/Aspect_ratio) stretched vertically by 20% with non-square pixels for a 4:3 display. Today, this results in a lot of its art assets to appear vertically "squished". It also distorts any attempt at a coherent real world scale for Doom, which we can guess at: 16 horizontal Doom units = 10 vertical Doom units = 1 foot = 0.6 meters.

| Typical map structure                            | Width in units    |
| ------------------------------------------------ | ----------------- |
| Hallway (very narrow), crate, teleport pad       | 64                |
| Hallway (narrow), big door, wall textures        | 128               |
| Small room                                       | 256-512           |
| Medium room                                      | 512-1024          |
| Large room                                       | 1024-1536         |
| Average map size from Doom 1, Episode 1          | \~4000            |
| Maximum map size (recommended, minimal glitches) | 32767 (+/- 16384) |
| Maximum map size (technical, buggy and unstable) | 65535 (+/- 32768) |

*Maximum map size:* to calculate distances, Doom uses 16-bit signed integers which have a maximum value of +/- 32767. However, if you actually built a map that stretched from -32767 to +32767 (across 65535 units!) and somehow tricked the engine into running it, then it would still break other distance calculations like a monster's line of sight, because a value of 65535 would [overflow](https://en.wikipedia.org/wiki/Integer_overflow) past +32767 to become 0. For best results, keep all map geometry within 16384 units of the (0, 0, 0) origin.

## Weapon metrics

Doom randomly simulates damage values by rolling virtual dice with each hit. For the shotguns, there's an additional buckshot spread simulation where each pellet must connect with the hitbox for full damage.&#x20;

The damage per second (DPS) is a rough estimate based on the fire rate multiplied by the average damage per shot.

<table><thead><tr><th width="121">Weapon</th><th width="116">Type</th><th width="108">Range</th><th width="158">Fire rate / sec</th><th width="150">Damage / shot</th><th>DPS</th></tr></thead><tbody><tr><td>Fist</td><td>Melee</td><td>0-32</td><td>2 punches</td><td>2-20</td><td>22</td></tr><tr><td>Berserk Fist</td><td>Melee</td><td>0-32</td><td>2 punches</td><td>20-200</td><td>220</td></tr><tr><td>Chainsaw</td><td>Melee</td><td>0-33</td><td>9 revolutions</td><td>2-20</td><td>90</td></tr><tr><td>Pistol</td><td>Hitscan</td><td>0-512?</td><td>2.5 bullets</td><td>5-15</td><td>25</td></tr><tr><td>Shotgun</td><td>Near</td><td>0-192?</td><td>1 shot (7 pellets)</td><td><p>5-15 * 7 =</p><p>35-105</p></td><td>70</td></tr><tr><td>Super Shotgun</td><td>Close</td><td>0-128?</td><td>1 shot (20 pellets)</td><td><p>5-15 * 20 =</p><p>100-300</p></td><td>150</td></tr><tr><td>Chaingun</td><td>Hitscan</td><td>0-512?</td><td>9 bullets</td><td>5-15</td><td>90</td></tr><tr><td>Rocket Launcher</td><td>Mid / Long</td><td>128-512?</td><td>1 rocket (+ 128 range splash)</td><td><p>20-160 +</p><p>0-128</p></td><td>150</td></tr><tr><td>Plasma Gun</td><td>Mid</td><td>0-384?</td><td>12 cells</td><td>5-40</td><td>270</td></tr><tr><td>BFG 9000</td><td>Mid</td><td>0-384?</td><td>1 shot (+ 40 tracers, 1024 range)</td><td><p>100-800 +</p><p>49-87 </p></td><td>~1200</td></tr></tbody></table>

Most maps begin with players killing low health enemies with the pistol and shotgun. Eventually the player relies more on the chaingun, super shotgun, and rocket launcher, while occasionally switching to the  plasma gun for tougher enemies.

The rocket launcher, plasma gun, and BFG are usually less effective at very long range because of the lag built into their projectiles' travel time. At long distances, a monster can move out of the way before getting hit. Doom's [autoaiming](https://doomwiki.org/wiki/Autoaim) and randomized monster movement also means it can be tricky to lead shots. You can balance long range encounters toward the player's favor by placing monsters on pillars with no cover, limiting their ability to dodge the player's projectiles.

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MWwF44URjg88NMz-OF3%2F-MWwJUl5WpzfUVf-IlEy%2Fdoom-2-weapons.png?alt=media\&token=9a0f58cb-87c0-483d-a81e-de1581ac70c7)

## Monster metrics

#### Monster sight and hearing

Monsters can look in cardinal (N, E, S, W) and ordinal (NE, SE, SW, NW) directions, essentially in 45 degree increments. They have a 180 degree sight cone based on their initial facing, and can hear combat sounds based on areas bounded by [linedefs](https://doomwiki.org/wiki/Linedef) set to block sound.&#x20;

If set to "ambush" mode, monsters have a 360 degree sight cone and ignore sounds.

#### Monster movement

*Minimum hallway size* is given as `(monster width + 2) x (monster height + 2)` but in practice, your hallways should usually be much wider since monsters might "step" in larger increments, and monsters block other monsters. Narrow off-angle hallways will force monsters into slower zig-zag movements, because remember, they can only turn and move in 45 degree increments.

*Stairs* are tricky for monsters. In general, steps with long depths and shallow rises are always more dependable. Step height must always be 24 units or less (or else the monster won't cross) and minimum step depth / maximum slope is proportional to the monster width. For example, for a step that is 24u high, a trooper requires a step that is 33u deep (35 degree rise, 2:3 ratio) while a demon is wider so it requires 51u deep (25 degrees, 1:2 ratio). If you want to see the bounding box calculations yourself, see the `PCheckPosition()` and `PTryMove()` functions in [`p_map.c`](https://github.com/id-Software/DOOM/blob/master/linuxdoom-1.10/p_map.c) of the Doom source code.

To simplify building for monsters, we generally recommend:

* *Minimum hallway size:* 128 wide x 128 tall, mostly built orthogonally at 90 degree angles to align with the grid with occasional 45 degree angles.
* *Stairway step size*: 16 high x 64 deep (15 degree rise, 1:4 ratio) or 8 high x 32 deep.

#### Monster combat

Monsters will use melee attacks within 64 units of their target, though the Revenant will attempt to use a melee attack within 196 units even if the target is too far. If further than 64 units, then monsters with ranged attacks are more likely to use attack the closer they are to the player, up to a maximum distance of 2048 units. But the Arch-vile has a particularly dangerous ranged attack, so it will only attack within 896 units.

When hit, monsters have a random chance to be stunned in a [pain state ](https://doomwiki.org/wiki/Pain_state)-- weapons with fast fire rates (chain gun, plasma gun) or multiple projectiles (shotgun, super shotgun) are particularly good at stunlocking monsters and interrupting their attacks.

&#x20;  *For much more on monster behavior and debugging, see* [*"Monster behavior" on The Doom Wiki*](https://doomwiki.org/wiki/Monster_behavior)*.*

### Doom 1 monsters

<table><thead><tr><th>Monster</th><th width="93">Health</th><th width="125">Pain chance</th><th>Min. hallway size (w x h)</th><th>Min. step depth (24u high step)</th></tr></thead><tbody><tr><td>Player</td><td>100</td><td>--</td><td>33 x 58</td><td>1</td></tr><tr><td><a href="https://doomwiki.org/wiki/Zombieman">Zombieman</a> (trooper)</td><td>20</td><td>80%</td><td>42 x 58</td><td>33</td></tr><tr><td><a href="https://doomwiki.org/wiki/Shotgun_guy">Sergeant</a> (shotgun guy)</td><td>30</td><td>68%</td><td>42 x 58</td><td>33</td></tr><tr><td><a href="https://doomwiki.org/wiki/Imp">Imp</a> (fireball demon)</td><td>60</td><td>80%</td><td>42 x 58</td><td>33</td></tr><tr><td><a href="https://doomwiki.org/wiki/Lost_soul">Lost Soul</a> (flying skull)</td><td>100</td><td>100%</td><td>34 x 58</td><td>--</td></tr><tr><td><a href="https://doomwiki.org/wiki/Demon">Demon</a> / <a href="https://doomwiki.org/wiki/Spectre">Spectre</a> (fast pig)</td><td>150</td><td>71%</td><td>62 x 58</td><td>51</td></tr><tr><td><a href="https://doomwiki.org/wiki/Cacodemon">Cacodemon</a> (big flyer)</td><td>400</td><td>50%</td><td>64 x 58</td><td>--</td></tr><tr><td><a href="https://doomwiki.org/wiki/Baron_of_Hell">Baron of Hell</a> (hunky goat)</td><td>1000</td><td>17%</td><td>50 x 66</td><td>41</td></tr><tr><td><a href="https://doomwiki.org/wiki/Spiderdemon">Spiderdemon</a> (boss)</td><td>3000</td><td>13%</td><td>258 x 102</td><td>254?</td></tr><tr><td><a href="https://doomwiki.org/wiki/Cyberdemon">Cyberdemon</a> (final boss)</td><td>4000 (+50% rocket resist)</td><td>5%</td><td>82 x 112</td><td>74?</td></tr></tbody></table>

### Doom 2 monsters

Doom 2 includes all the Doom 1 monsters, and added more mid tier monsters designed to survive longer and interact with other monsters.

<table><thead><tr><th>Monster</th><th width="88">Health</th><th width="122">Pain chance</th><th width="185">Min. hallway size (w x h)</th><th>Min. step depth(24u high step)</th></tr></thead><tbody><tr><td><a href="https://doomwiki.org/wiki/Heavy_weapon_dude">Heavy weapon dude</a> (chaingunner)</td><td>70</td><td>68%</td><td>42 x 58</td><td>33</td></tr><tr><td><a href="https://doomwiki.org/wiki/Revenant">Revenant</a> (skeleton with missiles)</td><td>300</td><td>40%</td><td>42 x 58</td><td>33</td></tr><tr><td><a href="https://doomwiki.org/wiki/Mancubus">Pain Elemental</a> (big flyer, spawns Lost Souls)</td><td>400</td><td>50%</td><td>64 x 58</td><td>--</td></tr><tr><td><a href="https://doomwiki.org/wiki/Arachnotron">Arachnotron</a> (baby spiderdemon)</td><td>500</td><td>50%</td><td>130 x 66</td><td>124?</td></tr><tr><td><a href="https://doomwiki.org/wiki/Hell_knight">Hell Knight</a> (weaker Baron of Hell)</td><td>500</td><td>17%</td><td>50 x 66</td><td>41</td></tr><tr><td><a href="https://doomwiki.org/wiki/Mancubus">Mancubus</a> (big flamethrower monster)</td><td>600</td><td>31%</td><td>98 x 66</td><td>90?</td></tr><tr><td><a href="https://doomwiki.org/wiki/Arch-vile">Arch-vile</a> (flame zombie, resurrects monsters)</td><td>700</td><td>3%</td><td>42 x 58</td><td>33</td></tr></tbody></table>

### Doom monster design analysis

An influential Doomworld poster Linguica offers these helpful design thoughts on Doom monster design:

> *... Doom 2 monsters are great. They nearly all enhance the gameplay along one or more of three axes:*
>
> * ***time awareness** - what is happening that I need to immediately address?*&#x20;
> * ***immediate spatial awareness** - what is in my close vicinity right now?*&#x20;
> * ***general spatial awareness** - what is the architectural layout, like walls, buildings, etc, in my area?*&#x20;
>
> *Doom 1 enemies were designed by what we would consider today to be novice FPS players, for whom basic movement and avoidance were challenging enough, without monsters making it much more difficult. However, as a more advanced FPS player, what tactical problems do you end up having while fighting them? Beyond getting boxed into a dead end, there is practically nothing preventing you from kiting Doom monsters indefinitely with little challenge. The only problems you would run into are being progressively plinked by shotgunners (troopers aren't even worth mentioning) or splash damage from a Cyberdemon's rockets (I'm discounting the Spiderdemon as a "normal" enemy here, but it is basically a giant rapid fire shotgunner in practice anyway, so whatever).*
>
> *Now let's look at the new Doom 2 monsters and what they bring to the table:*&#x20;
>
> * *The **Chaingunner** is a "low-level" enemy that even a more advanced player needs to worry about, because especially en masse, they can really wreck you quickly. There is a **time awareness** factor because if you don't take care of them quickly, your health will be severely eroded. There is also an element of **general spatial awareness** in case you need to retreat behind cover.*
> * *The **Mancubus**'s offset fireballs mean you can't just rely on mindless strafing around projectiles and actually need to pay attention to them, or else you can end up running into one. This implicates your **immediate spatial awareness**. (Did you end up learning the "Mancubus dance" of strafing left-right-center? Then congratulations, the game taught you a new behavior.)*
> * *The **Arachnotron**'s rapid-fire plasma also implicates **immediate spatial awareness** because if you're doing any strafing back and forth, you have to watch out for "crossing the stream" and being hit in the process. Do you think it's a coincidence the Mancubus and Arachnotron are introduced in quick succession on the same level, which also includes no other enemies? I don't think so. Both enemies make you do more than the Doom 1 hallmark of simple strafing around a single fireball. The game is telling you, in case you haven't gotten the point yet, that this is not going to work anymore.*
> * *The **Pain Elemental** is a annoying enemy, yes, but it is there purely to implicate your **time awareness** - it can't even hurt you directly! Its danger to you is directly proportional to how long you let it stick around.*
> * *The **Revenant**'s homing missiles, again, mean you can't just rely on mindless strafing around projectiles and actually need to pay attention to them, which involves your immediate spatial awareness, and you also need to keep mindful of available cover so you can get rid of the homing fireball, which involves **general spatial awareness**. You could even argue it involves your **time awareness**, since if you let a large number of homing fireballs accumulate, they could end up killing you instantly. (Or, perhaps, another enemy??)*
> * *The **Archvile**'s fire attack strongly implicates your **general spatial awareness** and **time awareness** - you need to know where cover is, and you need to get there immediately. Furthermore, its secondary behavior of resurrecting dead enemies involves yet more **time awareness** - if you leave it alone too long, it's going to being back all those enemies you already went to the effort to kill.*
> * *The **Hell Knight** is the only new enemy that doesn't make the game tactically deeper along one of these axes. It's just a Baron of Hell without being quite so tedious to fight as a real Baron. This does give mappers a new option for when and how to use the Baron, though, which is a good thing.*
>
> \-- Linguica on [28 August 2014 in thread "Doom 1 or Doom 2?" on Doomworld](https://www.doomworld.com/forum/topic/94546-doom-1-or-2/?do=findComment\&comment=1300059)

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F3d1R7O1SkAlm8Aoc1gFx%2FLDB_DoomCombatEnemyAwarenessDiagram_Linguica.png?alt=media&amp;token=81cf3229-09e9-4c10-a896-b88bbb98ab95" alt=""><figcaption><p>venn diagram comparing "awareness" metrics for various Doom 2 monsters; by Linguica (<a href="https://www.doomworld.com/forum/topic/94546-doom-1-or-2/?page=29&#x26;tab=comments#comment-1300059">via Doomworld</a>)</p></figcaption></figure>

## Item Economy

### Ammo pickups

<table><thead><tr><th width="133"> </th><th>Small</th><th>Large</th><th>Default ammo</th><th>Monster drop</th></tr></thead><tbody><tr><td><strong>Bullets</strong></td><td><a href="https://doomwiki.org/wiki/Clip">Clip</a> (10)</td><td><a href="https://doomwiki.org/wiki/Box_of_bullets">Box of bullets</a> (50)</td><td><a href="https://doomwiki.org/wiki/Pistol">Pistol</a>, <a href="https://doomwiki.org/wiki/Chaingun">chaingun</a> (20)</td><td>Zombieman (5, or 10 on Hard+)</td></tr><tr><td><strong>Shells</strong></td><td><a href="https://doomwiki.org/wiki/4_shotgun_shells">4 shotgun shells</a> (4)</td><td><a href="https://doomwiki.org/wiki/Box_of_shotgun_shells">Box of shotgun shells</a> (20)</td><td><a href="https://doomwiki.org/wiki/Shotgun">Shotgun</a> (8), <a href="https://doomwiki.org/wiki/Super_shotgun">super shotgun</a> (8) (in <a href="https://doomwiki.org/wiki/Doom_II">Doom II</a>)</td><td></td></tr><tr><td><strong>Rockets</strong></td><td><a href="https://doomwiki.org/wiki/Rocket">Rocket</a> (1)</td><td><a href="https://doomwiki.org/wiki/Box_of_rockets">Box of rockets</a> (5)</td><td><a href="https://doomwiki.org/wiki/Rocket_launcher">Rocket launcher</a> (2)</td><td></td></tr><tr><td><strong>Cells</strong></td><td><a href="https://doomwiki.org/wiki/Energy_cell_(Doom)">Energy cell</a> (20)</td><td><a href="https://doomwiki.org/wiki/Energy_cell_pack">Energy cell pack</a> (100)</td><td><a href="https://doomwiki.org/wiki/Plasma_rifle">Plasma rifle</a> (40), <a href="https://doomwiki.org/wiki/BFG9000">BFG9000</a> (40)</td><td></td></tr></tbody></table>

## Sources

* This page uses data from [the Doom Wiki](https://doomwiki.org/wiki/), under CC-BY-SA 4.0 International license.
* [Map unit - The Doom Wiki](https://doomwiki.org/wiki/Map_unit)
* [Doom Metrics](http://www.trilobite.org/doom/doom_metrics.html) by Scott Ampoker
