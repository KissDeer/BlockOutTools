> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/process/blockout/metrics/modular.md).

# Modular kit design

How to measure and design modular kits, 3D tilesets for building levels

When doing a [blockout](/process/blockout.md) or [art pass](/process/env-art.md), you might use a **modular kit** -- a 3D tileset of **modules**, meshes designed to snap together. This comes from the real-life building practice of [prefabricated modular construction](https://en.wikipedia.org/wiki/Modular_building).

If you're new to 3D modeling or level design, then don't attempt to design your own kit yet. Many considerations go into designing a robust kit. Your first kit will probably be very hard to use, especially if you haven't learned from using other peoples' kits already. Instead, see our list of [Resources](/appendix/resources.md) to download a free pre-made modular kit suitable for prototyping.

But if you have experience in level design and 3D tools, then you are ready. On this page we will detail the many considerations and best practices for designing your own modular kit.

{% hint style="info" %}
Most of the info on this page comes from Joel Burgess' excellent GDC talks on designing modular kits for big open world games: ["GDC 2013: Skyrim's Modular Approach to Level Design"](http://blog.joelburgess.com/2013/04/skyrims-modular-level-design-gdc-2013.html) ([slides](http://www.slideshare.net/JoelBurgess/gdc2013-kit-buildingfinal)) and ["GDC 2016: The Modular Level Design of Fallout 4"](https://www.youtube.com/watch?v=QBAM27YbKZg) ([slides](https://www.slideshare.net/JoelBurgess/gdc-2016-modular-level-design-of-fallout-4), [video](https://www.youtube.com/watch?v=QBAM27YbKZg)).
{% endhint %}

![core architectural kit for the "Dwemer ruins" in Skyrim, image by Joel Burgess (http://blog.joelburgess.com/2013/04/skyrims-modular-level-design-gdc-2013.html)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MbP95G-5HmMHoWYwCU_%2F-MbPCnRZ5hG8N-m7rBYW%2FLDB_ModularKitZoo_JoelBurgess_Skyrim.jpg?alt=media\&token=33800a74-93d4-469c-b4eb-44c704fb609e)

![example dungeon environment built with the Dwemer kit in Skyrim, image by Joel Burgess (http://blog.joelburgess.com/2013/04/skyrims-modular-level-design-gdc-2013.html)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MbPP-21y2wJpBDQmUla%2F-MbPRwQZBzjZOk5Wo6c7%2FLDB_DwemerRuin_JoelBurgess_SkyrimCompressed.jpg?alt=media\&token=aba35fda-cd7f-4b08-8f72-f81aa13c5b64)

## 1. Pre-production

do you have a lot of level designer time, and need to reuse limited art assets many times?

planning kit percentages, decide what is most important first

how granular / chunky should the kit be? depends on what level designers need / want, more customization OR faster prototyping time?

## 2. Blockout the kit

DO NOT MAKE VARIANTS YET, just build basic pieces first

### Prototype metrics

decide on your units... build to a human scale

![player size vs environment metrics diagram, image by Joel Burgess (http://blog.joelburgess.com/2013/04/skyrims-modular-level-design-gdc-2013.html)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MbPKH6N-42OiV-DO9VZ%2F-MbPN_IgBzHktzYbUn_2%2FLDB_ModularMetrics_JoelBurgess_Skyrim.jpg?alt=media\&token=c380a2ee-77aa-43af-b162-a827f53db3bf)

### Common module types

* floor, ceiling, wall, doorway (single), doorway (double), window, corner
* platforms (landscape)
* glue
* flanges and arches (caves)
* shells (caves)

!["graybox" modular kit used for level blockouts in Skyrim, image by Joel Burgess (http://blog.joelburgess.com/2013/04/skyrims-modular-level-design-gdc-2013.html)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MbP02oa-qIyy5tjCgbG%2F-MbP6Rdo6HOddzlUrPo1%2FLDB_ModularGraybox_Transparent_JoelBurgess_Skyrim.png?alt=media\&token=4a1cd17d-c36a-4edd-bb5f-2c457385153c)

### Define a footprint

stay in footprint / bounding box

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MbPP-21y2wJpBDQmUla%2F-MbPQQLxVthRSRJr0Nci%2FLDB_ModularFootprint_JoelBurgess_Skyrim.jpg?alt=media\&token=951a8c51-8f4a-4519-9e98-e543e5e7912f)

### Asset naming

pay attention to naming, level designers and kit artists need to agree on a pattern

Epic's recommended naming scheme?

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MbPP-21y2wJpBDQmUla%2F-MbPPuNqAVxippxQETd3%2FwebNameBreakdown.jpg?alt=media\&token=56500d47-5151-474f-946e-40a363e58749)

## 3. Metrics: stress test the kit

do NOT just stop at an ideal case

collision is one of the biggest issues, make sure you can't get stuck?

### Loopback Test

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MbPP-21y2wJpBDQmUla%2F-MbPPcm4lqsQ4Y9xdCXm%2FwebLoopbackStressTest.jpg?alt=media\&token=6e4e6912-3604-4392-b39a-931922076e63)

### Stack Test

can you build multi-level environments? floors should NOT be paper thin, they have thickness and mass just like walls

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MbPP-21y2wJpBDQmUla%2F-MbPPgPOkQoF0rm9FBnr%2FwebVerticalFootprint.jpg?alt=media\&token=bcdd332c-8b15-4c3f-b5cc-2f4b610c12f3)

### Gap Test

do you have enough glue for interior kits with off-angle construction? essential for tunnel or cave kits

## 4. Art pass the kit, make variants

texture variations go a long way, and are "cheap" -- you don't have to test and validate the module geometry again

consider building a tool for easily swapping in module types, which will make art pass and remesh much faster

## Sources

As mentioned at the top of this page, much of the info here comes from two excellent GDC talks by Joel Burgess, which are a **must-read** for anyone doing modular construction:

* ["GDC 2013: Skyrim's Modular Approach to Level Design"](http://blog.joelburgess.com/2013/04/skyrims-modular-level-design-gdc-2013.html) ([slides](http://www.slideshare.net/JoelBurgess/gdc2013-kit-buildingfinal)) is the "101" introductory talk to modular kit design considerations, and how they approached building out levels for Fallout 3 and Skyrim, while avoiding the worst of Oblivion's sins.
* ["GDC 2016: The Modular Level Design of Fallout 4"](https://www.youtube.com/watch?v=QBAM27YbKZg) ([slides](https://www.slideshare.net/JoelBurgess/gdc-2016-modular-level-design-of-fallout-4), [video](https://www.youtube.com/watch?v=QBAM27YbKZg)) is the "201" intermediate talk that elaborates on what they did for Skyrim's modular kits, and expanded when building Fallout 4.

## Further reading

* ["Modular Level and Component Design" by Lee Perry](https://docs.unrealengine.com/udk/Three/ModularLevelDesign.html) for Game Developer magazine, Nov 2002. A solid article by the lead level designer on Gears of War (2006), one of the first game dev writings to detail modular construction practices -- which only began emerging in the early 2000s when brush-based CSG construction began falling out of fashion. Included here mainly for historical interest; compare against [History of the level designer](/culture/history-level-designer.md).
