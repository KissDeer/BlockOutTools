> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/process/blockout/playtesting/persona.md).

# Player persona

Different ways of classifying players and their motivations / long-term behavior

## What's a player persona?

A **player persona** is a player's long term pattern of behavior and overall motivation for playing a game.&#x20;

Classifying players under various personas / categories can help you study players and interpret [playtest](/process/blockout/playtesting.md) data.

In reality, players are never just one category. People are a complex combination of all these motivations and more.&#x20;

Nonetheless, this reductive simplicity can be useful for making design decisions and imagining your audience. Ideally, every level can satisfy every persona.

(TODO: flesh this out a lot more)

### Play style vs player persona

## Huizinga's game of politics

* Player
* Cheater
* Spoil-Sport

## Bartle's "gamer psychology"

The 1996 [Bartle Test of Gamer Psychology](https://en.wikipedia.org/wiki/Bartle_taxonomy_of_player_types) was one of the earliest attempts to classify video game players. Bartle was studying player behavior in early text-based MMOs called [MUDs](https://en.wikipedia.org/wiki/MUD), and sorted all these MUD players into four general categories:&#x20;

* **achievers** want to score the most points, maximize game progress
* **explorers** want to discover new places or systems, map-out the game space
* **killers** focus on PvP / competitive conflict with other players, sometimes unfairly
* **socializers** focus on cooperation with other players, roleplaying and fan culture

(TODO: include 4 quadrant matrix image)
