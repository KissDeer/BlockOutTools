> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/process/blockout/massing.md).

# Massing

The feel and logic of the core structural shapes

## What is massing?

In architecture, **massing** is the overall *feeling* and *logic* of shape and space. &#x20;

* Does a room feel large and heavy, or low and hidden, or light and open? Why?
* Compare two rooms. Are they close together or far apart? Why?
* Does one wall seem related to another wall? If so, how and why?

Ideally, the massing supports the building's **program**, the overall logic and function behind the building's organization.

![excerpt of massing diagram study by Christopher Drummond for remodeling the Stockholm Library (full project)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LuFK30FV0fYW2K-u9xh%2F-LuFOYOM_0AlZVN4Cmwu%2Fmassing-study_stockholm-library_christopher-drummond.png?alt=media\&token=983903d8-4383-4a75-bd6c-37ab1da8d0a8)

In the *massing diagram* above, an architect proposes a new addition to a public library. Each mass has a defined function and audience.&#x20;

The new entrance hall (orange) is at street level on the right, and the children's area (yellow) is near this entrance so that children don't walk too far or disturb others. The central open space (teal) is a long courtyard that acts as a core community space and primary [circulation](/process/layout/flow.md#circulation) with the existing library (gold), highlighting the unusual cylindrical form as people approach from the entrance.

The symmetry of the added library wings (green) matches the symmetry of the existing library. The street level retail space (dark gray) is near the entrance hall, so that people can conveniently visit both the retail and the library in the same trip. The depository (light gray) needs street level access for loading / unloading shipments, but takes advantage of wide floors with low natural light.

Now apply massing theory to levels. How will players use each area and when?

(TODO: massing diagram example for games)

(TODO: paragraph description of massing diagram example for games)

## Massing methods

#### DIMENSIONAL

The simplest way to adjust a shape is to move, rotate, or scale it in the 3D level editor. This is best with basic shapes like cubes and other 3D primitives. If you try to stretch or squeeze detailed meshes and modular kits, it will probably look weird.

![dimensional massing diagrams from "Architecture: Form, Space, and Order" by Francis Ching](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M0ee4eVuNuFAVpXzg-K%2F-M0efIvq7LPUjG7M4Osu%2FFormSpaceAndOrder_Dimensions_FrancisChing.png?alt=media\&token=cd5d2b5b-adcc-4f4d-86de-05a11d1dfb65)

#### ADDITIVE

Make more complicated shapes by combining simpler smaller shapes. This is the most common massing method in level design and real world architecture.

**Articulation:** when shapes feel separate and distinct, we say they are ***articulated**.* Articulation can make a building feel smaller when the parts feel appropriately sized for people, built at a ***human scale**.*

![additive massing diagrams from "Architecture: Form, Space, and Order" by Francis Ching](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M0ee4eVuNuFAVpXzg-K%2F-M0efLLMnCt3FTwJl-OD%2FFOrmSpaceAndOrder_Additive_FrancisChing.png?alt=media\&token=38f2146f-18d2-493d-b29f-635987a06c71)

#### SUBTRACTIVE

Carving a simpler shape into a more complex shape. This is helpful for modernist futuristic architecture, or for carving organic-feeling natural rock forms.&#x20;

Beveling / chamfering / boolean operations are key techniques in 3D modeling, but most level design tools today lack [clipping tools](https://developer.valvesoftware.com/wiki/Hammer_Clipping_Tool) or [subtractive CSG](https://en.wikipedia.org/wiki/Constructive_solid_geometry) support.

**Continuity:** in contrast to additive massing, subtractive massing often feels more ***continuous**.* Continuity unifies the entire form as one single monolithic shape. Big monoliths won't feel human-sized.

![subtractive massing diagrams from "Architecture: Form, Space, and Order" by Francis Ching](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M0ee4eVuNuFAVpXzg-K%2F-M0efNqMd22INzJcVFlH%2FFormSpaceAndOrder_Subtractive_FrancisChing.png?alt=media\&token=c9cc1074-2ae7-4996-b5f2-e2ff8fc55b55)

## Hierarchy

Some masses are more important than others. A bigger mass with a more unusual shape will feel more important than surrounding masses. If this big mass stays continuous, it can interrupt other masses and take priority over the other shapes.

In the photo below of Seinäjoki City Theater designed by Alvar Aalto and Elissa Aalto, the main body of the building feels wide and low, somewhat articulated into overlapping blocks. But what's that big brown mass erupting out behind? It is a large tall monolithic shape with unusual angles. It is a contrast with the other boxy shapes, and the color / material is different too.

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mj1ZC4lWI6F4AmlQPiI%2F-Mj1hDWHS1Vl1jYl7KcH%2FLDB_Massing_SeinajokiTheatre_AlvarAalto.jpg?alt=media\&token=20ecf91e-353e-425e-8da6-d50f1b27dd30)

![floor plan diagrams of Seinäjoki City Theater by Alvar Aalto and Elissa Aalto, from "Architecture: Form, Space, and Order" by Francis Ching](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M0i_t8ox3ptPIjZRhBq%2F-M0ia2EaUxNpCHy6h8y5%2FFormSpaceAndOrder_Seinajoki-Theater-Aalto_FrancisChing.png?alt=media\&token=5345f2c4-09d3-4e9c-b563-2179ee129d87)

In the floor plan above of the Seinäjoki City Theater, notice how the building consists of 4 main masses: three linear grids for a restaurant, backstage, and offices, orbiting around the central concert hall space (see emphasis in upper-right). For a theater, obviously the concert hall is the most important part of the program, so that's why this unusual shape defines the rest of the space.

(TODO: video game example)

## Readability

**Readability** is how the level suggests its [layout](/process/layout.md) and organization using its appearance.

A map with *high readability* arranges relatively simple shapes into clear distinct groups that the player can easily measure and memorize.&#x20;

In contrast, a map with *low readability* has a confusing structure and shape, with fragmented massing that feels like camouflage. But low readability isn't necessarily bad because less readability can still aid your design goals. Broken massing complicates a shape and divides it into smaller shapes, and sometimes that's what you want.&#x20;

!["The massing may have been broken up too much here", commentary and photo by Mark Hogan](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M-ad9W6FPRFZyTSi2T7%2F-M-adPoHtA-jpO8hLcYS%2FMassing_SanFrancisco_MarkHogan.jpg?alt=media\&token=d54aa2d9-3ccd-4f69-a375-a553ed5fa46b)

In the photo above of 580 De Haro St in San Francisco, the large residential block of townhouses has been broken into a dozen different overlapping shapes, colors, and materials, which suggests many different *young unique quirky families* live here.&#x20;

If the architect had kept it as one big continuous monolithic shape, then it would feel much bigger and less "fun", possibly diminishing the character of the surrounding neighborhood and their property values. (Or you could argue it feels like a desperate attempt to dress up some condos and mask the true nature of gentrification sweeping the city.)

Imagine 580 De Haro as a video game level. Imagine the [layout](/process/layout.md) inside. How does this massing affect the player's [wayfinding](/process/blockout/wayfinding.md) strategies?&#x20;

* Articulation: each part feels like a separate townhouse for a separate household. The townhouses probably do not connect to each other, and each interior space probably only has one front door / street level entrance each.
* Continuity: yet all these townhouses were built together and form one big overall sense of place. Although they are different, they also feel related. Maybe they have similar layouts, circulation patterns, and surface finishes inside? It wouldn't be surprising.
* Culture: in real-life, have you ever seen modern townhouses like this before? If your audience is familiar with this type of building and if your level uses realism, then they may expect the layout inside to feel plausible.

## Proportion

![numbered grid system proportions and floor plan comparison of Villa Garches by Le Corbusier, from "Architecture: Form, Space, and Order" by Francis Ching](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M0dwIHLflNEinKO_BBV%2F-M0dwQ3eV8ghLM_kWhD6%2FFormSpaceAndOrder-Ch6_VillaGarches-LeCorbusier_FrancisChing.png?alt=media\&token=407107f1-16c3-44ec-9310-332898981ef7)

Sometimes you don't even need a grid to establish proportion / a center of gravity

## **Thickness and Weight**

Thickness matters. Thin floor vs thick floor, thin cover vs thick cover, narrow lip vs wide beam

in general, avoid thin floors / walls, prone to tunneling and clipping issues

thickness as gameplay: bullet penetration and wallbanging (siege, csgo, blops4)

## **Corners**

slice the pie, sharp vs rounded (link to Balance?)... sightlines

### Simple corners

A simple corner doesn't draw attention to itself. It exists as part of a larger shape or volume. The shape and texture doesn't vary, the only thing that makes it pop is the way the light hits it.

Line of sight blocker if 90 degrees or less

If it's a subtle bevel, don't do it in blockout

![simple corners emphasize the overall shape and volume on Everson Museum by I.M. Pei, from "Architecture: Form, Space, and Order" by Francis Ching](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M0dwcqkWSkRsWr_bNWQ%2F-M0e8b22aSeLFvse2ENx%2FFormSpaceAndOrder-Ch2_EversonMuseum_Corner_FrancisChing.png?alt=media\&token=408db35a-9616-404b-a3be-07acde61813a)

### Rounded corners

corners with obtuse angles (> 90 degrees), unified shape, make the player flow / move faster around it

Opens up line of sight, less effective as cover

Great for cars and vehicles, smooth circulation

### Complex corners

Detailed reinforced corners emphasize the corner as a distinct edge, and transform the corner edge line into an object. The corner is less about the the overall volume, and now it feels like more of a place or a thing to use, with its deviation from the walls and its own distinct silhouette.

More complex corners are good for:

* framing a certain view, perspective, or vista
* making the boundary / enclosure feel more solid, permanent, and grounded
* emphasizing a corner as a cover object / line of sight blocker, where the player should dwell -- but in this case, don't over-detail it with small gaps, keep it fairly chunky and solid-feeling

![corner details emphasize the edges on Commonwealth Promenade Apartments by Mies van der Rohe and The Basilica by Palladio, from "Architecture: Form, Space, and Order" by Francis Ching ](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M0dwcqkWSkRsWr_bNWQ%2F-M0eBywDD3k7rtcpV39x%2FFormSpaceAndOrder-Ch2_Commonwealth-Basilica-Compare_FrancisChing.png?alt=media\&token=c8588956-5c42-499a-a72d-1f528dc321c4)

### Open corners

Break up the edge with an opening, to emphasize how the walls are planes that enclose an interior. If lit head-on with thick walls, the open corner can feel very subtle and barely-there, in case you don't want players to notice it at first glance.

Sneaky corners? a trap?&#x20;

very modern, very rare in traditional masonry and carpentry

When enclosed with glass: fancy airy expensive

## Avoid shape psychology

**Shape psychology** is the theory that certain shapes convey universal ideas and influence behavior.&#x20;

**This book argues strongly that shape psychology is 99% bullshit**. Abstract geometric shapes do not make all humans feel the same thing nor communicate the same ideas. Humans form mental associations with shapes based on a complex combination of genetic predisposition, personal experience, and culture.

Even if it wasn't bullshit, shape psychology would not necessarily transfer to a video game context. People often behave one way in the real world, but behave differently in a video game. Player behavior depends more on game patterns, mechanics, available information, cultural framing, and roleplaying persona, rather than whether a shape is round or square.

To design for consistent player behavior in levels, you should [**playtest**](/process/blockout/playtesting.md) instead. Do the work, instead of wishing for a magic theory to brainwash players.

&#x20;   *For more on debunking this brain poison, see* [*Shape and color psychology*](/process/env-art/psychology.md)*.*

![Shape psychology is wrong and bad and doesn't even work... trust us, you're better off without it](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MlXYpTXdJlNxx9P3Y8V%2F-MlXcNHa1OtbhTQenfqZ%2FLDB_ShapePsychology_IsBad.png?alt=media\&token=168f4fdf-2eb2-48a9-aa92-8f9dbcf99723)
