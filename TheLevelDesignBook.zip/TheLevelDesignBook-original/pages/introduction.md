> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/introduction.md).

# What is level design

What is a level, what is level design, and how to use this book

## What is a level

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FQ6fLyf3fBmZnzHP8Qm0k%2FLDB_Halo_BloodGulch_BasketballCourt.jpg?alt=media&amp;token=50234527-5221-4178-a91a-4f99e6344f08" alt=""><figcaption><p>diagram of a basketball court superimposed on overview of Blood Gulch (Halo 1), by <a href="https://twitter.com/neilsonks/status/1658549380691968003">@neilsonks (via Twitter)</a></p></figcaption></figure>

A **level** is a space where a game happens. Some examples:

* the Fortnite island, an obstacle course ("obby") in Roblox
* a basketball court, race track, or playground
* a Monopoly board, crossword puzzle, coloring book

All these game spaces set **boundaries** for players to move and interact.

Different levels offer **variation.** For example all basketball courts have similar shapes, but an outdoor court and an indoor gym offer different **experiences**, **cultures,** and **moods.**

Level designers focus on how different game spaces can make players **feel** and **behave**.

## What is level design

We define level design broadly, but with a specific disclaimer:

**Level design is the practice of planning and building spaces for video games...**&#x20;

**... usually first-person or third-person action shooters.**

This book is still useful for sidescrolling platformers, top-down strategy games, or non-combat games. But for better or worse, most level design theory engages with 3D shooters as the default medium, dating back to the invention of the level designer role during the shooter-heavy 1990s.

&#x20;   *For more about the history of the level designer role, see* [*History of the level designer*](/culture/history-level-designer.md)*.*

!["island arrival" blockout development screenshot by Em Schatz for Uncharted 4](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LtwoKZ58xOGNTn9g_Qy%2F-Ltwq-JcDDEN7UHH9OLR%2Funcharted4_blockout_em_schatz.jpg?alt=media\&token=fe61470c-d734-4540-ab8e-a83eb330da7d)

### Functional level design vs. environment art

Level designers focus on shaping player behavior. In large studios, they often write documentation, draft [layouts](/process/layout.md), build [blockouts](/process/blockout.md), observe [playtests](/process/blockout/playtesting.md), and [balance](/process/combat/balance.md) maps and [encounters](/process/combat/encounter.md).&#x20;

In contrast, an **environment artist** focuses more on graphics. They [art pass](/process/env-art.md) models, materials, set dressing, and [lighting](/process/lighting.md) to refine the level's visual appearance. While this is mostly decoration, good environment art supports experience design goals and helps players play.

So there are two ways to understand level design:

* *formal industrial sense* of capital-L capital-D "Level Design" *without environment art*
* *broad common sense* "level design" *includes environment art* / anything in a level

In this book we emphasize the *formal industrial* "Level Design" for learning purposes, but always remember that your players engage with *broad common sense* "level design" as a whole.

![diagram comparing "Level Design" vs "level design" vs "environment art", using process images of Gallente Research Facility from Dust 514](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Maev3jxp4WpKXebg88n%2F-Maf5hE1bqDx4IO2HGuP%2FLDB_leveldesign_env-art_compare.jpg?alt=media\&token=a921482a-e5bf-42f5-83a6-78975cbc4078)

### Room design vs. world design

Level designers can spend days or even weeks designing a single room.

But for a huge battle royale, open world, or MMO with hundreds / thousands of rooms, agonizing over a single room is impractical. A **world designer** considers [flow](/process/layout/flow.md) and [wayfinding](/process/blockout/wayfinding.md) for neighborhoods instead of houses, biomes instead of places, categories instead of instances. This generic approach lets players and systems breathe. But without players or systems to fill that void, the resulting world may feel empty or bland.

To build a directed or scripted experience, obsess over every room like an architect.&#x20;

But for player-heavy system-heavy games with lots of space, world design offers the lighter touch of an urban planner.

![in "Pleasant Park" in Fortnite, the individual room layout of each house matters less than the overall shape of the neighborhood](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MPphiBNyOFqTcMnqNAF%2F-MPppJ9ZGig_wxc7cSE0%2FFortnite_PleasantPark_TopDownOverview.jpg?alt=media\&token=3fd67bec-7be1-4eb5-98f7-e0a3fbc3c6d6)

### Theory vs. "go map"

This is a book, so obviously we think reading is good.&#x20;

But as with any other art, a book can only introduce you to the craft. At some point you just have to close the book and go build some levels.&#x20;

If you ask a Quake community mapper a lot of questions, there is a tradition to respond with the blunt answer: **"go map."** This curt expression might seem rude but it intends to nurture -- as if to say, "stop procrastinating, you'll figure it out; now go try to do it, you're ready."

The only way to become a level designer... is to make levels. Ideally, a lot of levels.

&#x20;   *Don't know what to make? See our list of suggested* [*Projects*](/learning/projects.md)*.*

{% hint style="info" %}
Sometimes we say "map" instead of "level." A map implies a free-form space that supports variety, while a level implies more scripted direction.&#x20;

But it's not a big deal. Use these words interchangeably.
{% endhint %}

![screenshot of start hub in Quake 1 mod Arcane Dimensions, by Simon "sock" O'Callaghan et al ](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MDj_ngSOdI6jitZ76zx%2F-MDjzO9IvS-gUFWrgq6l%2FArcaneDimensions.jpg?alt=media\&token=7162ef12-dc38-4cd9-8999-ab0c0869e6f2)

## Philosophy

This book was written with specific ideals and beliefs about level design.

### Cleaner theory

Most level design books are either too academic and conceptual, or too commercial and reductive. We aim to explain and expand the same language that working level designers use, while also remaining critical enough to prune lazy thinking.

Level designers often lack language for discussing shape and volume, and benefit greatly from the architectural concept of [massing](/process/blockout/massing.md). We cite outside concepts without realizing the deeper roots; for example, [critical paths](/process/layout/flow.md#critical-path) come from critical path method, a scoping and dependency-checking tool in engineering. When we're imprecise with words and theory, thinking and communication suffers.

![Various daylighting strategies used in architecture, by Francis Ching from "Form, Space, and Order"](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M0j1masUKQWiwiDGXN8%2F-M0j2-GH3OSU0m4JRUf2%2FFormSpaceAndOrder_Light_FrancisChing.png?alt=media\&token=a65a1dcf-1b00-47e4-b858-fea1a643e4d5)

### Zooming out

Although level designers should focus on player behavior, sometimes we must zoom out and see the big picture.

A level is a combination of spatial design, art, psychology, programming, and culture. From the player's perspective, there is no difference between level design and environment art. Anything that affects the game world is level design.

Avoid the lure of simplistic dos-and-don'ts. Levels are more than collections of rooms and cover boxes, and more than landscapes with rocks and trees sprinkled on top. A level possesses history and culture and intent, and as responsible designers we must consider the entire play experience.

![still from "An Approach to Holistic Level Design" by Steve Lee at GDC 2017](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LtwiHYWTP0HfTGol6GY%2F-Ltwj6_WXropnQEVl4pb%2Fan_approach_to_holistic_level_design_gdc2017.png?alt=media\&token=cffc6cf2-28f9-4247-b90d-46110d7ecbe5)

### Stay alive and free

The printed format tends to doom level design books to obsolescence within a few years. Fortunately, this book lives online. For the foreseeable future, we intend to continue updating the book as new developments or trends in level design emerge. Don't die.

This online book will stay free and open access until its servers shutdown -- and even then, its content will likely be archived across the internet. The level design community collectively made level design, and so it should continue to belong freely to the community. **We will never paywall this book nor sell any copies of this book.**

Unattributed book text (and unattributed images / content) are [licensed](/appendix/license.md) under a permissive Creative Commons BY-NC-SA 4.0 license. You cannot sell this book nor sell any ports / translations. **All copies, translations, and derivative works must remain free and open access.**

![all unattributed text and images are licensed under CC-BY-NC-SA 4.0](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LtfRE6vMa7dIv6OW2I1%2F-Ltf_CKhdLuJKGDXZ0IR%2Fcreative_commons_BY-NC-SA_4.png?alt=media\&token=67bdaaa2-ed85-4dc1-8933-9e00c1193c91)

## How to use this book

The book consists of four sections:

[**Process**](/process/overview.md) details core level design concepts, and it is essential for beginners and students who need to learn level design workflows and language. Most readers should start here.

[**Culture**](/culture/overview.md) covers level design trends from various perspectives, and offers short primers on the history of architecture, lighting, and other crafts adjacent to level design.

[**Studies**](/studies/overview.md) analyze and unpack how a particular level works, accompanied by diagrams and screenshots.

[**Projects**](/learning/projects.md) are self-guided tutorials and project ideas for students and hobbyists. Teachers should check [Notes for educators](/learning/notes.md).&#x20;

There's also an appendix, featuring a [**Tools** ](/appendix/tools.md)list with recommended software and game engines, and links to additional level design [**Assets and Resources**](/appendix/resources.md) (free models and textures, recommendations for other level design books, etc.) Lastly, we strongly recommend joining a level design [**Community**](/appendix/communities.md), because a book can't love you back.

![editor screenshot of an early open world blockout for Alba, by ustwo Games; image by Jessie Van Aelst](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MeE6S6RE84hTY0E4Lwf%2F-MeEBQvgO3g54xMOuO9K%2FLDB_Alba_Blockout2019_Jesse_UsTwo.jpg?alt=media\&token=c5e8dc22-5eef-44a8-bf25-44c3f605047f)

## Now what?

* **Beginners:** get a general understanding of the [Process](/process/overview.md), especially [Pre-production](/process/preproduction.md), [Layout](/process/layout.md), and [Blockout](/process/blockout.md). Then pick a [Tool](/appendix/tools.md), join a level design [Community](/appendix/communities.md), and *go map.*
* **Somewhat experienced:** read about specific topics such as [Pacing](/process/preproduction/pacing.md), [Flow](/process/layout/flow.md), [Balance](/process/combat/balance.md), [Massing](/process/blockout/massing.md), [Metrics](/process/blockout/metrics.md), and [Lighting](/process/lighting.md) that usually go neglected in most online level design tutorials.&#x20;
  * We also take a strong stance [against "leading lines"](/process/blockout/massing/composition.md) and [against shape psychology / color psychology](/process/env-art/psychology.md), arguing these theories are either misleading, ineffective, or of limited use to level designers.&#x20;
* **Very experienced:** see our critical design [Studies](/studies/overview.md), and maybe even contribute some of your own.
