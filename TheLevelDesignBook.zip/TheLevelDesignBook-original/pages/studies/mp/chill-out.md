> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/studies/mp/chill-out.md).

# Chill Out (Halo 1)

small competitive multiplayer arena

## **Why Halo 1 multiplayer?**

Bungie's "Halo: Combat Evolved" (2001) was the key launch title of the first Microsoft Xbox console, and is arguably the main reason why the Xbox gained market traction and an audience at all.&#x20;

It was also the first FPS that "worked" on a gamepad, and both its single player format (large outdoor levels, vehicles, "smart" AI) and multiplayer design (full cooperative mode, 4 player splitscreen) proved very popular and influential. The spiritual successor to Goldeneye 007 (1997).

{% hint style="info" %}
This is an edited version of Andrew Yoder's blog post ["Halo’s Multiplayer Maps and Public Parks"](https://andrewyoderdesign.blog/2017/12/09/halos-multiplayer-maps-and-public-parks/). All Chill Out video and screenshots by Andrew Yoder, used with permission.
{% endhint %}

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MLzzAlDgBE4bXDn_44W%2F-MLzzqNmTcRZd7LjGlqz%2Fhalo1_cover.jpg?alt=media\&token=31c20e9a-c3e0-407d-99da-9ab54f68e1a9)

### Systems primer

If you aren’t familiar with Halo’s standard free-for-all ("Slayer") gameplay here are the basics:&#x20;

* Run around and attack other players with a variety of guns, items, and powerups scavenged around the map. To win, get 25 kills (or sometimes 50).
* When you die, you respawn in a randomly selected position after a few seconds. However, high level Halo players understand [how to game Halo's respawn selection algorithm](https://halospawns.com/).
* Compared to other FPS games, the main identity of Halo comes from its **floaty movement** and its **regenerating shield** mechanic.&#x20;
  * *Floaty movement:* players are slow at full speed, and slow to accelerate. The jump itself goes almost as high as the player character, and the jump lasts longer than it would in Earth’s gravity. This slow movement becomes predictable, which means easy to shoot, which means there are consequences for making a bad move during a fight.
  * *Regenerating shield:* players take shield damage before they take damage to a health bar.
    * A damaged shield will start regenerating after a second, and take up to a second to complete.&#x20;
    * If the player takes damage during that regeneration time, the shield timers reset.&#x20;
    * If the shield is completely destroyed, the player is vulnerable to headshots and must wait multiple seconds before the shield starts regenerating.&#x20;
    * Some weapons deal greater damage to shields than health. Other weapons deal enough damage to effectively bypass shields. In Halo 1, the default pistol is notoriously overpowered: two headshots break an opponent’s shield, a third headshot is an instant kill.

{% embed url="<https://youtu.be/621cZJzhJN0?t=46>" %}
typical 4 player splitscreen local multiplayer free-for-all ("Slayer") match on map "Hang 'Em High", original Xbox version&#x20;
{% endembed %}

Remember: Halo was one of the first console FPS games designed for gamepad, so the slow movement speed, lack of air control, forgiving shields, and sticky aim magnetism, were crucial for easing players into the experience. It was much slower than its competitors at the time, Quake 3 Arena and Unreal Tournament. This combination of mechanics makes standard Halo multiplayer about sustained precision and deliberate movement. Tighter environments amplify these mechanics and introduce an aspect of map control and positioning that defined competitive Halo.

## **Chill Out**

Chill Out is a medium-sized interior-based map where each room feels carved out like a cave, with no exterior views or visible sky. The environment textures belong to the purple Covenant alien theme, but the architecture has the harsher angles of Forerunner architecture. It is difficult to place where this map would exist within the Halo universe.&#x20;

There is also a ground fog in the lowest rooms to help orient players vertically within the whole map. Combined with the cool color palette of soft grays, blues, and purples, this fog gives a cold impression, playing off the pun in the map’s name.

Chill Out is one of a dozen different multiplayer maps that shipped in the original Halo 1 retail version. It was neither the most hated nor the most popular level in the map cycle, but it still offers a useful way to understand how players use sightlines and maintain territory to establish map control in a multiplayer arena.

<div data-full-width="true"><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2Fy4W5PanwQKIMY2TyFusI%2FLDB_chilloutmap.webp?alt=media&amp;token=7bb0033a-e02a-4a27-8c62-6f14d0ba7912" alt="Chill Out map layout with room callouts. Green lines indicate teleport paths."></div>

### Structure

Structurally, “Chill Out” has three sections, and six rooms: Rocket, Mid, Pink, Gold, Shotgun, and Spiral.

#### Rocket

Offset from the center, there is a four-sided room with two-floor, two elevated platforms on pillars where the rocket launcher spawns, and a long ramp leading from the bottom floor to the top. From this rocket room, the top door leads to a long, sharp-angled hall that exits at pink room; this hall also has a one-way teleport to shotgun room. A lower door leads to gold room, and a small curved door leads to the shotgun room. There are also two large archways and a space above them that connects rocket room to a lower room with a broken bridge.

![Rocket Room. The door ahead leads to the shotgun room. Gold room is to the right, pink hall is above, and arches are to the left.](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FaUXyGVPMwTPaL1PRSFbd%2FLDB_Halo_AndrewYoder_ChillOut1.webp?alt=media\&token=34d672f4-d329-43be-a9f0-5a31adbd6745)

#### Mid / Bridge

The bridge room has two wide halls on the lower floor connecting to the shotgun room and to gold room. The bridge doors connect to pink room on one side, and a spiral down to shotgun room on the other. Across the room there are two large pillars with a head-height gap to shoot through, and a one-way teleport up to pink room. Together, the rocket room and bridge room make up the middle section of the map.

![Mid. The bridge to the right leads to spiral, and left leads to pink room. The lower hall on the right leads to shotgun room, and the left leads to gold room.](https://mclogeblog.files.wordpress.com/2017/12/bridge.png?w=788)

#### Pink

Pink room is where the active camouflage powerup and the sniper rifle spawn. One exit from pink room is part of the broken bridge across the middle. The other exit is up a ramp and into pink hall to the top of rocket room, with a window looking down on gold room. The window in pink hall is too small to easily jump through, and the angle offers little to shoot at, but it is effective for throwing grenades. Pink room is also small enough to be susceptible to grenades.

![Looking into pink room from pink hall.](https://mclogeblog.files.wordpress.com/2017/12/pinkroom.png?w=788)

#### Gold

Gold room mostly functions as a connection between one of the long halls from mid to the bottom of rocket room, but it also has a one-way teleport to the broken bridge at spiral. This teleport is risky because the player exits facing toward pink room with their back exposed to anyone at the spiral from the shotgun room.

![Looking into “Gold” room from the long hall. The door leads to rocket room.](https://mclogeblog.files.wordpress.com/2017/12/12-2-2017_6-43-50_pm.png?w=788)

#### Shotgun

The last section is the shotgun room and spiral ramp. Shotgun is where the overshield powerup spawns. whoever grabs it receives two extra layers of shield protection and a second of invulnerability on activation. Aside from the overshield, the shotgun room is a weak position. The shotgun itself is only beneficial in close combat, and the pistol starting weapon is more consistent across all of the map’s spaces.

![Looking into shotgun room from rocket room.](https://mclogeblog.files.wordpress.com/2017/12/shotgunroom.png?w=788)

#### Spiral

From the spiral, a player may look across the broken bridge to pink, but the opponent in pink may have the sniper rifle. The spiral is also vulnerable to grenades. From shotgun there is also a small bend to the bottom of rocket room, but it has blind spots to three sides, including above it where the rocket launcher spawns. The only other exit from shotgun room is the other long hall into mid, which is vulnerable from the top of the arches. There is also a teleport exit from pink hall to the middle of shotgun room, which can lead to unexpected close-combat fights.

![The view from spiral, while jumping.](https://mclogeblog.files.wordpress.com/2017/12/spiral.png?w=788)

### **Competitive meta**

In competitive 2v2 Team Slayer, the effect of this design is that both teams attempt to control rocket room and pink room. While players are in these rooms, the game blocks enemies from respawning nearby, which increases the likelihood they respawn in bottom mid or in shotgun room. From this setup, the team in control times pushes into the shotgun room with the overshield powerup’s respawn. For a team trapped in the shotgun room, the overshield is the best way push the enemy team and regain map positioning.

![The view from pink room.](https://mclogeblog.files.wordpress.com/2017/12/12-2-2017_6-48-43_pm.png?w=788)

If both teams are equally skilled, it is difficult to maintain this or any other setup. In 2v2s in particular, when one player dies, the other needs to move or risk facing a 2v1. Because of these power shifts, both teams must keep rotating between strong locations on the map. Some of these positions are about information more than the damage a player could deal from them. For example, at the door to the bridge from pink room, a player can see two exits from shotgun room and a clear view across rocket room, but not all at once without stepping out onto the bridge. Two of these views are too narrow to hit a running enemy more than once, yet it is a valuable position for spotting enemies. In this way, information control is linked to map control.

With competitive play, we can also think of each action a player takes as an exchange of resources. A player may exchange shield and health for a better position when they take fire, or a player may exchange a good position to get a powerup or weapon. Strong positions are those with many options with good exchange rates. Weak positions and “traps” are those where every option becomes a risk.

### **Doors, Halls, Teleports**

All of the door and hallways are long and narrow.&#x20;

Some doors are as long as they are wide, blurring the definition between a hall and a door. In the tightest of these spaces, a player can’t juke an enemy’s aim or avoid grenades.&#x20;

Some of the ceilings are so low that a player will bump their head if they jump. Due to this, a player can delay an enemy push or force a retreat by throwing a grenade into these hallways and doors. These structures also force a harder commitment than doorways in tactical shooters.&#x20;

The shield mechanics and their requirement for sustained precision in combat mean that a player must commit to entering an arena rather than poking ineffectually from the far side of a door.

![Big door from Gold to Rocket creates big blindspots.](https://mclogeblog.files.wordpress.com/2017/12/bigdoor.png?w=788)

![Long hall from overshield spawn, through mid, to gold room](https://mclogeblog.files.wordpress.com/2017/12/lowhall.png?w=788)

The map’s one-way teleports also function as a kind of doorway, but they force an even harder commitment than actual doors. In casual play, where there is too much chaos to predict the game state on the other side of the map, the teleports are like a die roll: an enemy may be camping the exit, or the player may catch their enemy off guard. As a new or infrequent player, it is hard to even remember which teleport goes where, which can be a source of surprise and even humor in the gameplay.

The teleports are also a way to escape fights, since it is not possible to shoot or throw grenades through them. Whoever enters the teleport first can step back, wait for their opponent to chase, and strike them with a melee attack. Or, the player can bounce a grenade off the teleport entrance as they walk through it, discouraging enemies from continuing the chase.

### **Friction**

One tenet of current game design is to limit the “friction” or “rough edges” that players encounter. One form of friction is to test boring skills. For example, crossing the bridge from pink room to spiral requires a careful jump, and timing it incorrectly means barely missing and falling into the open at bottom mid. There is a similar jump to the rocket platform, and another to the top of arches. These are frustrating skill checks because there is no partial failure state or room for recovery. The punishment of a slow, predictable fall from these failed jumps makes them even worse.

There are also broken chunks of the bridge on the ground of bottom mid. Although these add visual interest to an otherwise abstract map, they add literal friction to the play space. An inexperienced or distracted player trying to cross bottom mid will not realize what they are stuck on without looking down or jumping blindly, both of which cost time and may get the player killed.

We could also include the narrow hallways and low ceilings as sources of friction. These spaces feel uncomfortable. But fixing these areas, as Halo 3 did in its “Cold Storage” remaster of Chill Out, removes something from the heart of the map.

## Social context

For couch multiplayer, Chill Out is less of a coherent playfield and more like a funnel for conflict and surprise.

Imagine it is 2001 and I’m playing Halo on a couch with three friends. But after a couple matches, the skill disparity is apparent and we start improvising new goals and rules: Melee only on the map Wizard, back-whacks worth 2 points, falling-whacks worth 3? Or maybe active camouflage and sniper rifles on the map Sidewinder?

If a variant grows dull, we adapt it mid match and start shooting instead of using melee, or we start driving vehicles through the fields of invisible snipers. At this point, the group’s goal with all of these variants isn’t about who won, or who is the best.&#x20;

![screenshot of multiplayer pregame lobby menu with configurable game mode options in Halo 2](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mav1n1BvTZMwaSFP56s%2F-Mav4IIVXJZG962sSZH2%2FLDB_Halo2_MultiplayerMenu.jpg?alt=media\&token=ba647ae0-3dad-409a-969e-37f40412df30)

The variants are about adapting the rules, adding chaos and unpredictability so that even the weaker players have moments of success. If the variant instead aggravates the skill disparity, then a player may throw the match or break its rules; this kind of “trolling” behavior in local multiplayer is a way for a player to signal that they aren’t having fun.

This whole pattern of play is similar to how children on a playground will adapt tag into “freeze tag”, or “lava monster” (only the player who is “it” can touch the ground), or “metal monster” (the player who is “it” can only move around the structure where they are touching metal). This freeform play is not about winning or losing, and if the game locks into a solved state, where one player is stuck being “it”, the variant has failed and requires modification.

![loading screen with map layout for "Wizard", from Halo 1 remaster in The Master Chief Collection ](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mav1n1BvTZMwaSFP56s%2F-Mav3EDuYv6OxO2Dw0U_%2FHMCC_HCE_Wizard_Map.png?alt=media\&token=427c9ce8-391f-41ed-bbe3-38f0614c3109)

Now, if you asked me in 2001 to recommend the best map in Halo, I may have said “Wizard”. It has four sections of axial symmetry, two sets of linked teleports, a discrete first and second floor, and four powerups of two types. The teleports and symmetry create a kind of disorientation, which for casual play introduced chaos and puts a limit on tactical play. Wizard is also small enough that disorientation doesn’t matter; if the player picks a random direction and starts walking, they will find an opponent to fight. The map was also suitable to many of our game mode variants. Wizard was the go-to map for shotguns-only, or melee-only, or absurd infinite-grenade games. It also makes a great king of the hill map, due to a central pillar structure that players can only reach by jumping.

Chill Out was another key map in the rotation for our local multiplayer, but its design has more nuance to it and has stuck in my memory longer. How do we talk about multiplayer level design, is “Chill Out” good or bad? Is it a dog park to someone who wants a quiet stroll, or a playground to someone without kids?

We can list all the ways in which players play a map. We can divide a map into its components, describe their interrelations, and consider how each piece affects various players. Or we can take a narrative approach and tell stories of our times in these spaces. None of these approaches seem to fully reveal the heart of a map. But, inherently, isn’t that because a good map, like a good public park, *should* mean many things to many people?

## Videos

You can watch a **narrated tour / video version of this article** on YouTube. <https://www.youtube.com/watch?v=YUdUh0uE2V4>

{% embed url="<https://www.youtube.com/watch?v=YUdUh0uE2V4>" %}

To get a better sense of how Chill Out actually plays, you can also watch this 3v3 team deathmatch ("Team Slayer") footage: <https://www.youtube.com/watch?v=AwPwL3snINQ>

{% embed url="<https://www.youtube.com/watch?v=AwPwL3snINQ>" %}

## Further reading

* ["Design in Detail: Changing the Time Between Shots for the Sniper Rifle from 0.5 to 0.7 Seconds for Halo 3"](https://www.youtube.com/watch?v=8YJ53skc-k4) by Jaime Griesemer from GDC 2010 is a classic highly-recommended game design deep dive into weapon balance and Halo's multiplayer design.
* ["Halo and Inflexible PvP"](https://andrewyoderdesign.blog/2017/12/28/inflexible-pvp/) by Andrew Yoder critiques Halo's rigid approach to multiplayer game modes, which make it painful for casual networked pub play.
