> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/studies/sp/undead-burg.md).

# Undead Burg (Dark Souls 1)

linear single player castle level about teaching exploration patterns

{% hint style="info" %}
This article is unfinished / in active development.
{% endhint %}

## Why Dark Souls?

Dark Souls is a popular third person fantasy action RPG by From Software, first released in 2011. It is the dominant template for the "soulslike" game genre, inspiring two direct sequels as well as broadly influencing all action games hereafter with its hardcore design approach and mechanics.

While most gamers focus on its punishing difficulty, they often forget the other half of the game -- Dark Souls is also an RPG where knowledge, exploration, and grinding can compensate for low combat skills or slow reflexes. Knowing where to find a helpful item, hidden checkpoint / NPC, or an easy farming route, can make boss fights much easier. Researching the game on a wiki is a valid playstyle, and maybe even the most common way to play Dark Souls today.

From a level design perspective, this is the core aspect we will focus on: **how does Dark Souls manage and develop player knowledge?**

## Undead Burg context

After the tutorial (Undead Asylum) and hub (Firelink Shrine), an NPC tells the player to go ring a bell "up" in an church. A brief climb up into an aqueduct leads to the rooftops of Undead Burg, a dense ruined medieval castle city filled with zombie soldiers.

Undead Burg has two halves: Upper Undead Burg is the first "real" level of Dark Souls, setting expectations and core patterns for the rest of the game without anymore direct tutorial messages. Most players access Lower Undead Burg several hours afterward, so it's basically a separate level and it won't be the focus of this article.

## Upper Undead Burg structure

Upper Undead Burg is a sequence of 3 areas that leads up to a boss battle (Taurus Demon). Each area has a main [critical path](/process/layout/criticalpath.md) as well as short optional side path(s) that loops back to the critical path.

* **Rooftop Ambushes**
  * **Fog Gate Joke**
* **Breakable Merchant**
* **Bonfire and Towers**

(Note that these area names aren't official labels or community standard callouts.)

### Rooftop Ambushes

You begin at the top of the stairs (**path 1** in diagram below) with a simple fight against two melee enemies at ground level. **A short rise of stairs help highlight the critical path** across the wood bridge (**path 2**) to the fog gate in the distance.&#x20;

A third melee enemy can also walk across the bridge to help **pull** attention over, in case the big bright glowing fog gate wasn't enough. Although there's an alternate exit, it's hidden by some breakable barrels.

<div data-full-width="false"><figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F71IOKqvDrGKYrwOpgaAA%2FLDB_DarkSouls_UndeadBurgDiagram1_path1-2.jpg?alt=media&amp;token=12284585-6d1e-4d0c-9e37-223372bf79f8" alt=""><figcaption><p>diagram of first beat of Undead Burg rooftops</p></figcaption></figure></div>

This little bridge does a lot:

* **The bridge is a chokepoint**, forcing you to fight. If you try to run past the first two enemies, that third enemy may cut you off. Then you're trapped on the bridge, sandwiched between a mob. "Don't try to run past your problems," says the bridge, "or else your problems will only get worse. Face them head-on, one at a time! Don't cross this bridge until you get to it!"
* **The bridge helps hide an ambush,** gently angling your approach away from a dark doorway on the left with a fourth enemy waiting in ambush. (see screenshot below, right)... It's the first of many ambushes. Never trust a bridge.

<div align="left" data-full-width="false"><figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FflzH83bw4rtiy7L0eZ8L%2FLDB_DarkSouls_UndeadBurgScreenshot1.jpg?alt=media&amp;token=a261f0a2-4432-475d-a153-a5b533f35893" alt=""><figcaption><p>(left) screenshot of first fight with short stairs and fog gate, (right) screenshot of crossing the bridge, can't see doorway on left</p></figcaption></figure></div>

After defeating all the enemies, you stare at the fog gate and pause.

You remember the previous fog gate in the Undead Asylum tutorial level, like 15 minutes ago -- it led to the Asylum Demon boss that maybe killed you a few times. You don't feel ready for a big boss battle again so soon.&#x20;

So you run away and "procrastinate" by exploring.

Looking down from the fog gate, it's possible to notice a glowing loot pickup breadcrumb below. Some breakable barrels reveal a hidden drop (**path 3** in diagram below) down to the loot. From there it's also possible to see yet another glowing loot pickup on the bottom level.

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FSvR0DPHBDuOWtza9V9QF%2FLDB_DarkSouls_UndeadBurgDiagram1_path3-4.jpg?alt=media&amp;token=880db941-c186-49d4-a157-a5845885eed5" alt=""><figcaption><p>diagram of (optional) second beat of Undead Burg, lots of ambushes down on the lower level</p></figcaption></figure>

There's only one way back up: drop all the way down, go through a house, and climb up a ladder to the top of the castle wall to get back to where you started (**path 4**).&#x20;

But as soon as you begin, two zombies climb up from the ledge to ambush you.

After surviving the ambush, observant players might see four hanging zombies below -- a much bigger ambush in waiting.&#x20;

(TODO: screenshots for path 4)

Here it's possible to foil the ambush by attacking these hanging enemies early. The level designer could've easily hidden these hanging ambushers on the other side, but instead they're left exposed to imply that ambushes are "fair" if you're smart enough.

When you jump down from the castle wall, you end up on path 1 again. These **one-way drops / verticality enforce a one-way flow with no backtracking;** each path is separate and distinct, and **dropping to the stairs acts as a landmark.** It's like the level designer is saying, "that was a fun little side trip, but seriously now, just go through the fucking fog gate." (Path 5)

<div data-full-width="true"><figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F0HwNZnhdZnS9JYaXxwZ8%2FLDB_DarkSouls_UndeadBurgDiagram1.jpg?alt=media&amp;token=d516eb4c-3e0e-45c3-941b-bf81d5393db3" alt=""><figcaption><p>diagram of all main paths and beats in first part of Undead Burg; dead-end secondary paths are omitted</p></figcaption></figure></div>

Really, only path 1 -> 2 is the critical path. Why is most of this area "optional"?

* **Encourage exploration.** Most of Dark Souls is "optional" - the player must learn to explore side areas. Here it's obvious that there's plenty to explore, but in later levels it's much less obvious.
* **Support failure / repeat runs.** If you die before you reach the next bonfire checkpoint, you'll have to run this area again, but at least you can bypass optional areas you already explored.
* **Wayfinding via encounters.** In the first fight, the third enemy begins at the back, which helps pull the player across the bridge to the next area (the fog gate). As in many combat games, **enemies act as breadcrumbs.**

All the other encounters act as ambush training, gradually escalating in a [**teach / test / twist**](/process/preproduction/pacing.md#teach-test-twist) **pacing pattern:**

* Ambush outside fog gate - **1 enemy,** semi-predictable with standing enemy in suspicious doorway
* Ledge ambush at bottom - **2 enemies**, not predictable, hidden enemies
* Big ambush before ladder - **4 enemies**, very predictable "hidden" enemies, can be foiled

{% hint style="info" %}
**Iteration in action**

When analyzing the level data, an old level of detail (LOD) model shows two differences:

* **There used to be a house at the beginning.** Maybe there wasn't a fight here before, or maybe there wasn't a fog gate so angling the player at that building felt more important for wayfinding.
  * The roof was also a safe way to drop down from the balcony above (via path 6).&#x20;
* **The high bridge wasn't broken.** Perhaps there was another path between the buildings, or there were enemies on the bridge? Whatever it was, it was more complicated.
  {% endhint %}

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FkIXk8CnQFgit9i9fW1jI%2FLDB_DarkSouls_UndeadBurgRooftopChanges.jpg?alt=media&amp;token=dba773f9-58e5-4738-92b5-884eb19d0931" alt=""><figcaption><p>screenshot of old version of Undead Burg, with a small house and bridge intact (outlined in red)</p></figcaption></figure>

{% hint style="info" %}
**Rooftops revisited: high bridge jump**

On a return visit, you may notice a broken bridge (path 6) between two buildings. This is the most forgiving jump in the game, with a short safe fall below.&#x20;

However it's also a bit of a secret. Unlike many third person games, **Dark Souls doesn't have a jump button; jumping is a never-tutorialized mechanic** that involves a running dodge roll with light-medium equipment load. Many players discover jumping by accident while spamming dodge roll in a panic. Some never discover it at all.

Accordingly, the reward -- a light crossbow -- will seem useful only to experienced players.\
\
(TODO: image of path 6 / jump)
{% endhint %}

### Fog Gate Joke

So now there's nothing left to do except enter the fog gate. At this point, will a first-time player feel ready? Probably not. Which is the point.

#### SETTING UP THE JOKE

**Fog gates feel scary.** You can't see what's on the other side, you can get trapped on the other side and can't run away. The fog gate for the Asylum Demon boss fight was 15-30 minutes ago.

**The level has primed the player to expect ambushes everywhere**. There was literally an ambush from the other doorway! If they had to endure several ambushes already, then what's awaiting them on the other side? Probably an even worse ambush.

The player has killed 10-20 enemies to reach this point, so they're holding 500-1000 souls and they've used maybe half of their healing potions. **They'll feel like they have a lot to lose, with dwindling resources for a big fight ahead.**

#### THE PUNCHLINE

You steel your nerves and enter the fog gate... and there's no enemies. It's just an empty room with some stairs.&#x20;

Was this a joke? Was the fog gate pointless? Where's the boss? *Ha ha maybe this game isn't so hard after all!*

As you confidently ascend the stairs to the sunlight, a giant dragon suddenly swoops down from nowhere, possibly killing you in one hit if you were rushing ahead too fast.

(TODO: screenshots for empty fog gate room + dragon attack)

It's a brilliant and cruel level design joke.&#x20;

This whole beat builds up a first-time player's anxieties and expectations, seems to release anti-climactically... and then springs an unpredictable unfair instantaneous possible death from a powerful boss that can kill you in one hit, seemingly by accident. You don't even get the dignity of seeing the boss' name and health bar, instead it's just a teaser cutscene that can totally obliterate you. Unlike the silly 4-enemy failed ambush before, this is completely out of your control.

It's as if the level designer is toying with you. "I can destroy you in an instant," they say, "that is how little you matter." (It's OK if this feels erotic, because it is.)

### Breakable Merchant

(TODO: encounter screenshots)

This next area is also about exploration, except this time it's easy to miss the side route because the fight will pull you to the next area, and there's no fog gate to make you pause and explore.

It's also about breakables, featuring 3 different breakables beats.

After entering the fog gate, climbing up some stairs, and nearly getting killed by a dragon, you face the most challenging battle yet:

* **Two melee enemies** rush out from behind breakable barricades. If you haven't already realized you can break jank-looking wood junk, then hopefully these two enemies teach you.
* **A third ranged enemy** fires arrows from a tower in the back. The height is important; it elevates the archer apart from the other enemies, gives a good firing line, and leashes it to that spot. (A more difficult encounter would've let the archer maneuver and fire from different points.)
* **A fourth melee enemy** is in the back, at the stairs, so it takes a while for them to walk over and join the fight.

This is a common encounter setup throughout the game: you have to juggle nearby enemies while getting sniped at, and if you take too long then more enemies will join.

(TODO: screenshots)

The long flat walkway serves an important combat purpose: you can backpedal to funnel the melee mob down the stairs, out of range of the archer. (A less generous approach would've been a one-way drop without any space to back away.)

But the fairly open arena floor also lets you play more aggressively. More experienced players can dance around to kettle the mob, while blocking / dodging in rhythm with the archer's (slow) fire rate.

Eventually the player will rush up the stairs to get that pesky archer (path 8), following the critical path to the bonfire up ahead.

<div data-full-width="true"><figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FZ6nDDcc38yaCg0XyuH61%2FLDB_DarkSouls_UndeadBurgDiagram2.jpg?alt=media&amp;token=d742d8b6-95c8-4bb1-a235-a40329424997" alt=""><figcaption></figcaption></figure></div>

After resting at the bonfire (which respawns all the enemies) and backtracking for a return visit, this encounter is much easier. You can kill the archer immediately and fight the one melee enemy alone at the stairs, sometimes without aggroing either of the enemies facing the barricades.

From the archer's tower you can see two spearmen on the other roof. The stairs leading down are clumsily hidden by some breakable crates

&#x20;break through some crates, and go downstairs inside (path 9)

Here the merchant sells a variety of basic weapons and several consumables to make the upcoming optional midboss and/or main boss much easier. The player can also change their playstyle, resupply, or buy a key to unlock a shortcut to the boss too.&#x20;

Few games would have the gall to introduce a safe hub town area (Firelink Shrine) and then hide a much more helpful NPC halfway through a dungeon, but Dark Souls does so repeatedly. And while it may seem weird, obscure, and hostile, to hide a crucial early NPC like this, it actually provides much more convenient access when respawning from the nearby bonfire.

It's an important level design lesson: you must design for the actual game you're making. Because of Dark Souls' mechanics and aesthetics, this NPC placement makes more sense than forcing players to backtrack all the way to a central town area.

path 10

get ambushed by a melee enemy hiding behind some breakables inside

fight some weak melee enemies in a line

just like the previous loop back with path 4: climb a ladder, jump down from the roof, to feed directly back into the starting stairwell

(this pattern later gets repeated for a third time in the Taurus Demon boss fight, while also evoking the Asylum Demon plunge tutorial balcony)

### Towers and Alleys

TODO: writeup for area 3

## To review\...

**Upper Undead Burg** introduces important level design patterns / strategies / skills for the player:

**Rooftops** lead the player on a sequence of gradually escalating ambushes. Each side route is one way and feeds back toward the fog gate. When the player finally does confront the scary fog gate, it feels like a joke -- there's no enemies or boss battle, but still a surprise danger.

**Merchant** area tests whether the player is truly exploring, hiding the first merchant of the game (!) in a side area beneath some breakables. Hopefully the player remembers how the rooftops' lower area was accessible.

**Bonfire and Towers** are a sequence of bigger complex fights with ranged attackers pressuring the player from towers. The player must manage mobs and deal with threats in an optimal order. It's also the main route from the bonfire to the boss, with an unlockable shortcut if the player explored (found the merchant and bought the key)

## More links

* [Undead Burg on Noclip](https://noclip.website/#dks/m10_01_00_00;ShareData=AV-}WUe~yQ9GoyQUjLX!VZj_96nQLCUc!e}UKIiP+M\[fP9pb^09YD;\&UI2ZK+C)
