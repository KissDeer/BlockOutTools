> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/studies/sp/assassins.md).

# Assassins (Thief 1)

open world stealth single player medieval urban storytelling

## Why Thief?

Thief: The Dark Project (also known as Thief Gold, Thief 1, TDP, or simply, Thief) by Looking Glass Studios is a first person stealth game about quietly sneaking through shadows to avoid guards and steal treasure in a gritty fantasy steampunk city.

This 1998 landmark game fostered a slow methodical RPG feel that contrasted sharply with the fast arcade violence of Doom (1993) and Quake (1996). Unlike Doom or Quake, if you run through the front door and try to fight enemies in Thief, then you will quickly die. Instead, you must roleplay as a street-wise anti-hero thief who tricks the guards with distractions, or better yet, patiently observes the guards' movements and cleverly slips through the gaps between the patrol routes. Thief above all is a first person game about watching but not aiming, hiding but not running -- and sloppily improvising when all your plans go horribly wrong.

Years later, Thief prompted three sequels and inspired future generations of "immersive sims" -- games that emphasize object interaction, sprawling level design, environmental storytelling, and non-violent play styles. We study Thief because it creates a stunning sense of world and agency that is still rarely matched today.

![key art for Thief: The Dark Project showing the shadowy player character Garrett with a fire arrow](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mav5X5fQHslQaOpCXwW%2F-Mav66rGpeGASVQFJKnv%2FLDB_Thief_Cover.jpg?alt=media\&token=17f44cb0-e909-4fbe-b02c-39b6a6f00577)

## Assassins

From the very first mission of Thief (["Lord Bafford's Manor"](http://thief.wikia.com/wiki/OM_T1_Lord_Bafford's_Manor)), every level begins in a safe public territory and then a restricted private territory that you must infiltrate and loot. The public is usually an open common space where you can roam the city streets with little danger or penalty. In contrast, the private is usually well-guarded with a heavily fortified front entrance.&#x20;

The first step in most Thief missions is to map out the private area's boundaries and probe for any holes or vulnerabilities. "Casing the joint" is fundamental to the fantasy of thieving, and thus crucial to Thief's experience goals. It won't feel like sneaking unless there's a safe public outside and a risky private inside.\
\
When they begin the fourth mission "Assassins" (by Mike Ryan with assistance by Greg LoPiccolo), players are well accustomed to this public exterior vs private interior pacing pattern. That's when the designers flip the script and play with the player's expectations. Assassins both exemplifies and subverts the game's use of public vs private space, questioning who really owns a city.

![spotty medieval city street with glowing backlit windows in Assassins, from Thief: The Dark Project (1998)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mav5X5fQHslQaOpCXwW%2F-Mav771mT68ehjUIS03W%2FThief_assassins2a.jpg?alt=media\&token=dc9acd04-73e5-4361-9c11-3669101a810f)

The mission consists of four general [pacing](/process/preproduction/pacing.md) beats:

1. Intro: stand inside a shop, almost get killed by assassin NPCs
2. Follow: secretly follow assassin NPCs through the city, back to their employer
3. Mansion: sneak into their employer's mansion and steal his stuff
4. (optional) Escape: if the alarm went off, you must backtrack through the city

The layout is two parts: the city streets and the mansion. The upper-left mansion is almost half of the map, and originally it was even bigger, but late in development it had to be scoped down for memory [optimization](/process/env-art/optimization.md) to run on the game's target system requirements.

![final layout for Assassins; interior layout of Ramirez Mansion (upper-left) not shown](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MavIPJYjeTzRXCT-5P6%2F-MavR6FectKlMqVAHVPA%2FLDB_Thief_Assassins.png?alt=media\&token=88a42051-53ef-4ac9-958d-d249f17b7a92)

## Mission structure

### 1. Intro: the shop

You begin inside a shop, which is unusual in Thief. All the previous missions begin outside, usually right outside a main entrance. This room is also unusual because Thief features a shop mechanic before every mission, which is strictly treated like a separate mode in a menu screen, and it's never an actual shop location that you can visit.&#x20;

When you take a step forward, you activate a trigger that launches an arrow through the window to murder the shopkeeper. Then you overhear two assassins outside, who walk away thinking they have murdered you instead.&#x20;

Your mission objectives now change completely. Instead of breaking into a local temple, you must now follow the assassins back to their secret base without being detected. This type of bait and switch is extremely unusual, and never repeated again throughout the entire game.

![the shopkeeper Farkus before an arrow suddenly shoots through an unseen window and kills him ](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MavIPJYjeTzRXCT-5P6%2F-Mavm-lqh04TrEB7-g4Y%2FThief_Assassins_Shop.jpg?alt=media\&token=706fce90-833c-42cd-92fc-069d8557f3d2)

So already within its first minute, Assassins subverts numerous design norms in Thief. The shop was a fake shop, the mission briefing was a fake briefing, the objectives were fake objectives. These surprises foreshadow the bigger surprise near the end of the mission.&#x20;

But at this point, the player barely has any time to think (nor to loot the shop) before they must promptly leave to follow the assassins.

### 2. Follow: tailing the assassins

The game never explains how to tail the assassins back to their hideout. The lack of tutorialization for this *unannounced surprise game mode* is perhaps frustrating for contemporary players today. Players must guess the rules and strategy by trial and error, but you quickly learn there are **three ways to fail**:

* Sometimes the assassins stop and turn around to see if they're being followed. **If they see you** then they will start chasing you and you kinda fail the mission.
* If you walk or run too close to them on metal plates, it makes a loud sound. **If they hear you** and get too suspicious, then they will start looking for you and you basically fail.
* **If you trail too far behind**, then you will lose their trail and quickly get lost in the mazelike streets. If you lag too far then you will eventually trigger a hard mission failure.&#x20;
  * Most importantly, **you're given no feedback when you're in danger of failing by distance.** So players learn to err on staying closer rather than staying back -- the exact limit is never shown.

![tailing an assassin NPC in the beginning of "Assassins" in Thief: The Dark Project](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lu045u3CaCHx8tynVj0%2F-Lu04_c2FWVkns-t-waJ%2Fimage.png?alt=media\&token=0745f56a-4648-4ec5-a4be-34965f2fabd0)

This mission is the first expansive sense of the City that you get, as a vast labyrinth of narrow medieval streets and alleys without a grid pattern or signage. Here, the public sphere is unknown, huge, and overwhelming, and it is very easy to get lost. It is the only time in Thief that the City truly feels like a big city.

Note that it only *feels* like a city. Compared to any real world city, the layout is actually not very complicated. A handful of loops is enough to confuse any player.

The assassins' route from the shop to the Ramirez mansion is randomized with different branches and stopping points, but there are basically only three possible paths. When they leave the shop and cross the metal bridge at the river, they can take:

* Short path: they head west, directly to the mansion.
  * you basically skip half of the level
* Middle path: they walk north to a statue, then west toward the mansion.
  * on Hard and Expert difficulties, the assassins fork right and go around (the dashed purple line)
* East path: they walk east, then snake back to the statue.

![layout with possible assassin paths, starting from the Shop; the dotted purple path near the top right is possible only on Hard / Expert mode](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MavIPJYjeTzRXCT-5P6%2F-Mavi-h5vqwYJifyD7wH%2FLDB_Thief_Assassins2.png?alt=media\&token=3f9f1593-e51d-4fe3-8686-fc8759092b58)

#### Stealth encounter design masterpiece

Near the end of the chase, the assassins always walk through a specific archway, up a ramp, and turn the corner.&#x20;

This part is a masterpiece of stealth encounter design, condensing all of the player's sneaking know-how into a minute of tense improvisation with incomplete information.

First, you follow them through the arch. The archway's [rounded towers offer a wide field of view](http://www.blog.radiator.debacle.us/2010/07/geocomp2-neorganic-epiphany-by-dubblian.html) so you can easily notice a patch of darkness beneath the arch. The level designer clearly wants you to go there, as the lone island of safety surrounded by dangerous bright areas.

![in Thief, bright areas of light are dangerous; the player must hurry from shadow to shadow](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MLQgiGtRZaQ5n41ZGR4%2F-MLQm6DQ9PRsDTLYiRWT%2Fassassin2d.jpg?alt=media\&token=81d8e9cd-ef7c-4ff5-a976-bbe44a6f63cb)

However, that patch of darkness under the archway is misleading. It's not really safe. Your light gem indicator will glow yellow, which means you are still somewhat visible, enough to cause AI to become suspicious.

You have three options, and none of them feel good:

* Option A: If you stay under the arch at the bottom of the ramp, then the assassins might turn around, see you, and get suspicious. Fail.
* Option B: If you fallback to before the arch, then you break your sightline and you won't be able to see where the assassins went after the top of the ramp. Fail.
* Option C: If you continue up the ramp, the bright street lamp will give you away, and even if it didn't, then you also don't know if the floor material at the top will make your footsteps too noisy. Fail.

You can't stay still, you can't run away, and you can't move forward. The level designer is messing with you. It's a trap.

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MLQgiGtRZaQ5n41ZGR4%2F-MLQmBnnNCigjNFXFUxD%2Fassassin2b.jpg?alt=media\&token=fcfeeccb-f35c-44a4-b8d8-a438c7a2ef1a)

Most first-time players are paralyzed with indecision and go with Option A -- standing still and praying. The more adventurous go with Option C because they know that a narrow 90 degree corner means the assassins can't see you either, and assassins will never backtrack.

But still, how do you track the assassins from there? They could be standing right there, watching for you. You can't risk turning the corner. So instead, you have to listen.

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MLQgiGtRZaQ5n41ZGR4%2F-MLQmK4O50mnT4Yif-Eb%2Fassassin2c.jpg?alt=media\&token=a9858bbb-8af5-42b7-983e-21135928b234)

When they turn that corner and you hear the tell-tale clang of boots on metal, you freeze and listen for how many metal steps you hear. A lot of metal steps means a long metal catwalk. That's the beauty of Thief's footstep mechanic: it translates sound into space.\
\
The designers even emphasize the metal stub by putting three different floor materials together, which is pretty rare in Thief. They want you to notice the quick contrasts between stone, metal, and wood footstep sounds.

### 3. Ramirez Mansion

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MLQgiGtRZaQ5n41ZGR4%2F-MLQltfuer69ACeUV35k%2Fimage.png?alt=media\&token=7130a945-3c5a-41fe-880e-7f2454eaec30)

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MLQgiGtRZaQ5n41ZGR4%2F-MLQmpwq6N4kiv-itMw7%2Fassassins_ramirez_map_thief.jpg?alt=media\&token=fa7bef8b-d3d2-4efc-a61e-3da670d3b252)

Once you find your assassins' hideout, a castle owned by some guy named Ramirez, you're tasked with phase 2 of the mission: robbing him of everything he owns.\
\
It's unexpected. You feel like the mission should be over now, but instead it feels like two missions-in-one. (But what did you expect? How else could this have ended?)\
\
The Ramirez mansion is much easier to solve than the streets. There are only a handful of guards patrolling the top floor, which means you can control the entire area very quickly. In contrast to the really thoughtful city street design I analyzed earlier, this interior floorplan is simple and comprehensible, the main corridors are narrow and arranged somewhat symmetrically, and many of the floors are made of relatively muted stone.

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mav5X5fQHslQaOpCXwW%2F-Mav7bbczjYsfD0CYMLD%2FThief_BaffordsMap.jpg?alt=media\&token=7579d088-9735-44c5-928d-af68f8ea9bc6)

In comparing the first mansion mission (Lord Bafford's) and this, the second mansion mission you play, some differences arise:

* Bafford's place is much bigger and sprawling than Ramirez's place.
* Bafford has a throne room and separate wings with lots of art everywhere. Ramirez has a simple, compact villa plan with central courtyard; the walls are textured plainly; he has also installed hidden wall-slits to spy on guests in their bedrooms. (Creepy.)
* Bafford's basement is old. Ramirez has recently renovated his basement with an illegal animal pen and office / counting room.
* Bafford's rare treasure is a "royal scepter", and there's a guard with a gong outside. Ramirez has a "silver firepoker", and some sort of electric alarm system wired through the house. The difference in alarms is telling, and both treasures are deeply personal, phallic objects that connote power, but the "bedroom peepshow" context where you find the firepoker is more insidious. (You find it in a crawl space BEHIND the fireplace, which makes it useless for poking fires.)
* Lastly, a readable cements the comparison. In it, [Bafford apologizes for being late on payments to Ramirez](http://thief.wikia.com/wiki/Assassins:_In-game_text), which means he's lower on the totem pole than Ramirez even though his place is bigger and fancier. In this way, Looking Glass **uses reading text to complicate reading architecture** -- whoa.

<div align="center"><img src="https://3.bp.blogspot.com/-qOiJvj7D2Dg/UBcBxg_5izI/AAAAAAAABIw/oCjfMG4NcG4/s640/assassins5a.jpg" alt="compare Lord Baffords&#x27; ornate banner to Ramirez&#x27;s simpler design; Bafford tries too hard? textures from Thief "></div>

The differences in level design are forms of characterization: the "B" or "R" banners make these spaces private and personal. The oversize and overdecoration implies Bafford is obsessed with just the image of power; meanwhile, the comparatively spartan Ramirez prefers the power of power. When you're infiltrating these castles, you're actually sneaking into their heads and learning their secrets and insecurities. Think of it as a proto-Psychonauts style of environmental storytelling, the home as a metaphor for its owner.

### 4. Escape

The end of Assassins is fantastic. It's probably the best part of the entire mission. Unfortunately this is also where Looking Glass really dropped the ball.

You get to play the ending only if:

* you're playing on Hard or Expert difficulty
* you triggered the alarm in the Ramirez Mansion

It is common for many players to never trigger the alarm. Hard or Expert players will find Assassins to be a bit easier than previous missions. And in the previous mission Down In The Bonehoard, Thief's terrible climbing code forces players to quick load / quick save a lot. Combined with the zero-warning failure of the earlier part of the mission, players will be highly primed to play as perfectionists.

And if you never trip the alarm, the game never triggers the last part of the mission: Ramirez's guards take over the streets and you have to sneak past them to get back to your neighborhood.

![in the optional last phase of Assassins, the player must sneak out of the Ramirez Mansion and back to their home](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MavIPJYjeTzRXCT-5P6%2F-MavqCFeEclIVPq2GoCt%2FLDB_Thief_Assassins3.png?alt=media\&token=ceb8c16a-5c1e-444e-a843-b9b0fd4899b6)

The "get back out" portion of each Thief level is usually trivial. You backtrack through an [already-solved level](http://www.blog.radiator.debacle.us/2011/07/dark-past-part-4-useful-post-or-randy.html), past the unconscious corpses of so many guards. Even if they're still patrolling, you already know their patterns and where to hide.

But here, the game spawns overwhelming odds, about twenty new guards -- more than the number in the mansion! -- and they're all permanently alerted, randomly roaming around with zero predictability in brightly lit streets. It's an unexpected change in stakes and world state. All those corners suddenly function very differently when you're coming back from the other way. The city streets are familiar and alien at the same time.\
\
Ramirez has privatized the City: the public is now dangerous. The City starts the mission as a neutral space. Then it's a victim, bisected by Ramirez's private space, a large manor cutting through a dozen city blocks. And now the City is your enemy.&#x20;

<div align="left"><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MavIPJYjeTzRXCT-5P6%2F-MavtpbO205Kh1mO79Lo%2Fassassins6_map_city.jpg?alt=media&amp;token=40958f6d-576a-49bf-8227-37db07356aa7" alt=""></div>

## Video

You can watch a narrated tour / video version of this article here: <https://www.youtube.com/watch?v=K7e1i95VtiY>

{% embed url="<https://www.youtube.com/watch?v=K7e1i95VtiY>" %}
