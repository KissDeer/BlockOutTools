> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/studies/overview.md).

# How to study a level

Close readings and studies of influential / interesting maps and levels

In a **case study**, an author conducts an analysis of a playable level or location.&#x20;

A good case study identifies design strengths and weaknesses, considers typical player behavior, and compares it to other levels and games. These critical design essays demonstrate how to apply a lot of concepts from the [Process](/process/overview.md) section of this book.

&#x20;   *For more on our recommended methodology, see* [*Research*](/process/preproduction/research.md)*.*

{% hint style="warning" %}
This section is underdeveloped because right now we're focusing on finishing [**Book 1, Process**](/process/overview.md).
{% endhint %}

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F71IOKqvDrGKYrwOpgaAA%2FLDB_DarkSouls_UndeadBurgDiagram1_path1-2.jpg?alt=media&amp;token=12284585-6d1e-4d0c-9e37-223372bf79f8" alt=""><figcaption><p>encounter design analysis of first area in Undead Burg from Dark Souls, see full study: <a href="/studies/sp/undead-burg.md">Undead Burg (Dark Souls 1)</a></p></figcaption></figure>

## Single player studies

Analysis of various single player maps, usually highlighting [pacing](/process/preproduction/pacing.md), [storytelling](/process/env-art/storytelling.md), and [encounter design](/process/combat/encounter.md).

{% content-ref url="/pages/-MauFMANR47PctM95IOh" %}
[Single player studies](/studies/sp.md)
{% endcontent-ref %}

## Multiplayer studies

Analysis for multiplayer maps and spaces, usually highlighting [layouts](/process/layout.md), [flow](/process/layout/flow.md), and [map balance](/process/combat/balance.md).

{% content-ref url="/pages/-MauFaZuiLDXyBi\_Pw1E" %}
[Multiplayer studies](/studies/mp.md)
{% endcontent-ref %}

## Real world

Analyzing real world ("IRL") locations and structures from a level design perspective.

{% content-ref url="/pages/-MauFicTSloO6TGx7yBm" %}
[Real world studies](/studies/irl.md)
{% endcontent-ref %}
