> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/studies/irl/disneyland.md).

# Disneyland (California, USA)

critical level design primer on theme park run by the most powerful media conglomerate on Earth

Historically, industry level designers have looked to Disneyland and other theme parks as design inspirations. However, this conventional discourse rarely questions how Disneyland functions, and neglects the mountain of architectural criticism about Disneyland.

In hopes of educating the industry and elevating our discourse about theme park design, this article begins with our traditional arguments about how game developers think Disneyland works, and then transitions into contemporary real world architectural discourse about Disneyland.

![vintage map of Disneyland in 1963 from National Geographic magazine; note that the park was much smaller](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MauGVrCbUVtVRC_MKWx%2F-MauHAn5iIsvLEp4sCKH%2FLDB_Disneyland1963_Map.jpg?alt=media\&token=5b210d75-120d-4383-9228-1a2513ec84da)

## Prior level design analysis of Disneyland

The GDC 2009 talk ["Everything I Learned About Level Design I Learned From Disneyland"](https://gdcvault.com/play/1305/Everything-I-Learned-About-Level) by Scott Rogers is largely responsible for our industry's popular understanding of Disneyland. In his talk, Rogers focuses on a few core lessons with plenty of photographic examples:

* [Pacing](/process/preproduction/pacing.md): each Disneyland attraction presents several clear thematic beats as you progress through it.
* [Wayfinding](/process/blockout/wayfinding.md): Disneyland organizes each themed area around a central "weenie", a large highly visible landmark with long sightlines that draws visitors toward it. Walt Disney called them weenies because he argued these "sausages" (landmarks) attracted "dogs" (visitors).
* [Flow](/process/layout/flow.md): to give the illusion of freedom and encourage movement variation, paths often branch inconsequentially and always lead the visitors back to a critical path.
* [Storytelling](/process/env-art/storytelling.md): every attraction incorporates a consistent progression of architectural details, set dressing, and other environmental storytelling to immerse visitors as they wait in line for the ride.

Disneyland's Main Street is known mainly as an example of [forced perspective](https://en.wikipedia.org/wiki/Forced_perspective), creating an illusion of height with less space. Buildings along Main Street are built at 3⁄4 scale on the first level, then 5⁄8 on the second story, and 1⁄2 scale on the third—reducing the scale by 1⁄8 each level up.

A more recent 2019 Full Indie Summit talk ["Put A Castle In the Middle - Design Lessons from Disneyland and Zelda"](https://www.youtube.com/watch?v=7QDw0M1n5Dc) by Shane Neville emphasizes similar points: weenies, environmental storytelling, wide paths for exploration. Similar to Rogers, Neville is also a big Disney fan and takes Walt Disney's words as gospel.

![weenie analysis slides from "Everything  Learned About Level Design I Learned from Disneyland" by Scott Rogers, GDC 2009 (https://mrbossdesign.blogspot.com/2009/03/everything-i-learned-about-game-design.html) ](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MS0mpKy5XZejarKgeFu%2F-MS0nHjSs3BrnbGtg4nx%2FDisneyland_Weenies_ScottRogers_GDC2009.jpg?alt=media\&token=977ebf52-4727-43dd-ac93-94379d63a95c)

Now, their design points and assumptions aren't wrong. Many Disneyland visitors attend the park with the goal to glean lots of details and ride as many rides as possible, to be "guided" and explore a space.&#x20;

However, as level designers, we know that our intent doesn't always translate to the reality of the player experience, and the design intent behind Disneyland should not be taken at face value either. Rogers and Neville make good points, but their passionate fan-love of Disneyland doesn't give the full picture.

What if Disneyland isn't the best place to emulate? What if, in fact, it has problems and flaws? Even if Disneyland is successful, what if it isn't applicable to video games?&#x20;

And if Disney's park design team is so talented, how can we reconcile that with the embarrassing failures of [California Adventure](https://www.themeparktourist.com/features/20180603/33914/declassified-disaster-disneys-california-adventure-part-2) and [Euro Disney](https://allears.net/2020/06/18/why-disney-would-like-you-to-forget-disneyland-paris-opening-day/) -- what if Disneyland was just a fluke? If Disney can't even reliably launch new theme parks, are these theme park design principles truly useful?

{% embed url="<https://youtu.be/SFE8RlKlLCE?t=471>" %}
"Defunctland" episode about "The Failure of Euro Disneyland" and how French audiences hated what was essentially a copy of the Anaheim park, even though it was "well-crafted"; detailed discussion of Euro Disney begins at 7:50&#x20;
{% endembed %}

## "You Have To Pay For The Public Life"

The most famous piece of architectural criticism on Disneyland focuses on its larger social function within Southern California. Despite its marketing, Disneyland does not exist in a magical dimension completely detached from mundane human misery: it is located within Anaheim, California, a dense urbanized suburb in northern Orange County. We must understand Disneyland in relation to its surroundings.

In his article ["You Have To Pay for the Public Life" (1966)](https://placesjournal.org/article/you-still-have-to-pay-for-the-public-life/), postmodern architect [Charles Moore](https://en.wikipedia.org/wiki/Charles_Moore_\(architect\)) begins with three observations:

1. Most European cities, as well as many US east coast cities, follow a Mediterranean model with a large public square at its center -- open land that we all agree to set aside for communal public use. We imbue this space with a public importance, a "monumentality" that compels us to flock to that space and walk around.
2. Californian cities don't have real urban centers. Downtown Los Angeles and San Francisco have relatively little foot traffic, least of all near their comparatively lifeless city halls. The closest thing to public monumental architecture in Los Angeles is the freeway interchange.
3. Californians drive cars everywhere and "float" with little attachment to an urban center, which merges with Hollywood's promise of freedom. Artifice, fantasy, and performance sit at the center of Southern Californian culture. We can become anything we want.

Moore then critiques public architecture across California, arguing that none of it actually anchors the public. But he also allows, in his own postmodern way, that maybe walking is overrated and driving everywhere is a helluva drug. He points to the [Santa Barbara County Courthouse's](https://en.wikipedia.org/wiki/Santa_Barbara_County_Courthouse) grand arch and strangely tall walls -- a drive through film set, fake architecture that succeeds at its intent. Californian civic architecture, at its best, breaks free from the European tradition while feeling more Spanish than Spain.

![Santa Barbara Country "Courthouse" in 1965, photos by Charles Moore from "You Have To Pay For The Public Life"](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MauU5kDE387juOgsHYZ%2F-MauX7x5BddnISKSp7VV%2FLDB_SantaBarbaraCourthouse_CharlesMoore_YouHaveToPayForThePublicLife.jpg?alt=media\&token=68fb7607-de13-43ee-a2d6-7b7d07202926)

However, Moore argues that Californians actually do want to walk around in an urban center, and the proof of that is Disneyland. He was the first architect to write about it seriously, just 10 years after it opened:

> "Disneyland, it appears, is enormously important and successful just because it recreates all the chances to respond to a public environment, which Los Angeles particularly no longer has. It allows play-acting, both to be watched and to be participated in, in a public sphere. In as unlikely a place as could be conceived, just off the Santa Ana Freeway, a little over an hour from the Los Angeles City Hall, in an unchartable sea of suburbia, Disney has created a place, indeed a whole public world, full of sequential occurrences, of big and little drama, full of hierarchies of importance and excitement, with opportunities to respond at the speed of rocketing bobsleds (or rocketing rockets, for all that) or of horse-drawn streetcars. An American Main Street of about 1910 is the principal theme, against which play fairy-tale fantasies, frontier adventure situations, jungles, and the world of tomorrow. And all this diversity, with unerring sensitivity, is keyed to the kind of participation without embarrassment which apparently at this point in our history we crave. \[...]
>
> No raw edges spoil the picture at Disneyland; everything is as immaculate as in the musical comedy villages that Hollywood has provided for our viewing pleasure for the last three generations. Nice looking, handsomely costumed young people sweep away the gum wrappers almost before they fall to the spotless pavement. Everything works, the way it doesn’t seem to any more in the world outside.&#x20;

> As I write this, Berkeley, which was the proud recipient not long ago of a set of fountains in the middle of its main street, where interurbans once had run and cars since had Disneyland parked, has announced that the fountains are soon being turned off for good, since the chief public use developed for them so far has been to put detergent in them, and the city cannot afford constantly to clean the pipes. Life is not like that in Disneyland; it is much more real: fountains play, waterfalls splash, tiny bulbs light the trees at night, and everything is clean.

![Main Street USA (left) and New Orleans Square (right) at Disneyland in 1966, photos by Charles Moore from "You Have To Pay For The Public Life"](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MauGVrCbUVtVRC_MKWx%2F-MauPbmgjDjGTTkJA36M%2FLDB_Disneyland_CharlesMoore_YouHaveToPayForThePublicLife.jpg?alt=media\&token=a4fdb457-a45f-4507-ac5a-6b43bb24633d)

Moore argues that [Main Street, USA](https://en.wikipedia.org/wiki/Main_Street,_U.S.A.) is the most important part of Disneyland because it mimics what Americans want to believe about themselves, while fairy tale themed Fantasyland is the weakest part because it feels too much like make-believe. The political fantasy is more powerful than the fantastical fantasy.

Moore also reviewed various Disneyland rides in a follow-up book *The City Observed: Los Angeles—A Guide to Its Architecture and Landscapes (1984).* Here's what he said about The Haunted Mansion:

> The Haunted Mansion is a badly flawed ride, if only for the smug and supercilious treatment it bestows on ghosts, just because they are dead. Even so, it is surely one of the most skillful, sophisticated and engrossing spatial sequences on the planet. It is useful to see the ride as a progression from outside the event, where the observer and the observed are at some distance, to the inside, where the observer, mind and body, has entered into the observed, so that it finally envelops him and even at the end makes an attempt to enter him.

### Level design as privatization of public life

More than fifty years later, Moore's central analysis still bears out.&#x20;

Disneyland represents a civic promise that many Californians no longer expect from their local government. Disney can then charge middle class people for the privilege of roleplaying as if they didn't live in a failing city spiraling down in a crisis of declining public services and constant threat of drought. Clean sidewalks, functioning street fountains, and bright colors only feel remarkable when you live on a dirty sidewalk with broken fountains and peeling paint.&#x20;

To escape misery, you just have to pay for a ticket. If you can afford it.

Disneyland forces us to ask, what is ethical and socially-responsible level design? Who lives in our levels and what type of "public life" do our maps make possible? If levels are Disneylands, then what's the video game equivalent of the surrounding suburb Anaheim?

![satellite map of Disneyland (center) in context to the surrounding city of Anaheim in 2021](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MauU5kDE387juOgsHYZ%2F-MauaJbAgJa7HYzCbokp%2FLDB_Disneyland_Anaheim_SatelliteMap.jpg?alt=media\&token=81b13344-f9a4-4c30-affe-445c48facfe7)

## Architecture of reassurance

Subsequent architecture critics have since largely labored in Moore's shadow, either amplifying the social critique to condemn Disneyland's craven capitalism, or emphasizing the nihilistic postmodern attitude to embrace Disneyland as a bold future alongside beacons like Las Vegas.

In 1997, the Canadian Center of Architecture ran an exhibition ["The Architecture of Reassurance: Building the Disney Theme Parks"](https://www.cca.qc.ca/en/articles/issues/9/let-us-assure-you/32768/touring-the-architecture-of-reassurance) curated by Karal Ann Marling which sought a third way -- to trace the history of the park's development, and maybe even measure some of its influence on American urbanism:

> Primarily, Walt was dissatisfied with Los Angeles and with other American cities of his era, the 1940s and 1950s. He was dissatisfied because the American city, it seemed to him, had become an utterly chaotic environment: cars rocketing here and there, unplanned suburbs, no sense of visual coherence, no sense of safety and reassurance. Walt Disney was also interested, however, in theming. Specifically, he was interested in what the American city had been in the past, the frontier West, the life of the small town as he remembered it at the turning of the century. He was interested finally, I think, in creating a place where people could feel safe and reassured.
>
> We call this exhibition “The Architecture of Reassurance” because at every point in the design of Disney’s theme parks you feel safe, secure—you feel as though you know where you are in space.

![photo of "Main Street U.S.A." installation with concept art and models, from "The Architecture of Reassurance" (1997) at CCA. https://www.cca.qc.ca/en/articles/issues/9/let-us-assure-you/32768/touring-the-architecture-of-reassurance](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MWxrVxH54Z_YERiB63d%2F-MWxrn_EjHdocwMAhZNj%2FCCA_ArchitectureOfReassurance_MainStreetInstallation.jpg?alt=media\&token=4219fcf3-d11a-4daf-bef3-e7108261c0b5)

Harvard Design Magazine writer Tom Vanderbilt outlined the exhibition's argument in ["It’s a Mall World After All: Disney, Design, and the American Dream"](http://www.harvarddesignmagazine.org/issues/9/it-s-a-mall-world-after-all-disney-design-and-the-american-dream), again focusing on Main Street:

> Although “Main Street” is just one attraction of many in the theme parks, it was closest to Disney’s heart—it was based not on a Disney product but on Disney’s personal history and memories. It is also the attraction that most embodies “the architecture of reassurance”: all those architectural and environmental touches, ranging from harmonious color schemes to the absence of garbage (a Main Street “newspaper” was discontinued early on because the discarded copies were thought to clutter to the street) to the famous 5/8 building scale (which “made the street a toy,” as Disney put it), which work together to offer an accessible landscape where Disney and visitors alike could feel instantly “at home.” More Frank Capra than Frank Lloyd Wright, Disney’s Main Street is a populist paradise designed to make vacationers feel comfortable, not awed by the achievements of would-be fountainheads. \[...]
>
> \[...] “Main Street was aesthetically unthreatening,” writes Marling, “different, in that respect, from strip malls and real streets where every store battled with its neighbor in a disquieting cacophony of visual stimuli.” \[...] Disney was so wedded to his Main Street memory that he first tried to populate the place with the kinds of retailers one finds in a small town, rather than with the trinket vendors and fast-food outlets typical of amusement parks. “Disneyland struggled to maintain a tenant list of shoe stores and other specialized apparel shops not because people came to the park to buy loafers and underwear but because the Main Street Walt remembered used to have them,” Marling writes. But apparently visitors’ fantasies did not include buying goods available at home (and more and more in shopping malls, not on Main Street), so eventually the stores sold just Disney merchandise. \[...]

![photo of Main Street U.S.A. at Disneyland, circa 1960 by Tom Simpson; under CC-NC-ND 2.0 license](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MWxrVxH54Z_YERiB63d%2F-MWxtkYtzWQXR289AJlb%2FDisneylandMainStreet2_TomSimpson_1960.jpg?alt=media\&token=3e01a9ac-d097-4809-a0ad-67d55a68a70a)

> One of the lasting impressions from The Architecture of Reassurance is of how little is actually needed to create a sense of place—a realization apparently lost upon a generation of suburban builders. The comforting buildings of Disney’s Main Street disguise a ’50s strip-mall shell, Marling points out, while a structure like the Contemporary Hotel—a prefabricated hotel similar to the roadside chains—seemed progressive simply because a monorail passed through its lobby. The ingenious use of color, light, trompe l’oeil, and a bit of imagination go much further than do the much-hyped “utilidors,” monorails, and other grand infrastructural schemes in Disney’s parks. As in cities, the larger monuments of the park (Disney called them “wienies”) were located to orient and draw visitors—and most tourists, after all, behave much the same way in Disneyland as they do in cities: taking photos, buying things, seeking out attractions, orienting themselves by landmarks. Of course, in Walt’s parks, no maps were needed; the architecture was its own narrative. “We tell ourselves stories in order to live,” Joan Didion once wrote, and it comes as little surprise that the childhood stories lived out in real time and space in Disneyland should have endured in the adult minds of those who seek to recreate places whose true aspects were as dimly and fondly remembered as fairy tales.

For better or worse, Disneyland inspired a wave of small-town preservation and traditional urbanism across America with its safe nostalgic vision of early 1900s village life.&#x20;

### Level design of reassurance

Disneyland's appeal to nostalgia at a small toy-like scale is powerful, promising safety and predictability for the player.&#x20;

However, at this point we must ask ourselves -- will every player experience this wave of nostalgia? Does every Disneyland visitor fondly reminisce their idyllic suburban childhood -- or is that just for the visitors who experienced idyllic suburban childhoods?

Reassurance and nostalgia need older audiences. In this sense, Disneyland is for adults, not children.

![photo of Main Street U.S.A. at Disneyland, circa 1960 by Tom Simpson; under CC-NC-ND 2.0 license](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MWxrVxH54Z_YERiB63d%2F-MWxt7yWPRXAbH-DiTiG%2FDisneylandMainStreet_TomSimpson_1960.jpg?alt=media\&token=375431ba-e888-41ee-9aa6-0c772ba76313)

As an eerie parallel, the US eldercare industry has also taken note of Main Street's powerful memory function.

There are now emerging "[memory towns"](https://www.youtube.com/watch?v=7pHxxjRlzEk), fake villages built inside vacant warehouses, modeled after small 1950s US town squares. They seek to recreate walkable streets, a retro diner, and nostalgic music, all designed to stimulate the memories of Alzheimer's patients who grew up in small American towns like this.

But again, this type of IRL level design assumes a very specific type of player. What about the players who grew up in dense cities? What about the players who grew up outside of America?

![photos of Glenner Park, a "memory town" built inside a warehouse in New Jersey, USA](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Ml2YTT4K-uNXRwbRiSP%2F-Ml2hr5N7w9hifYqzrpR%2FLDB_Disneyland_GlennerPark.jpg?alt=media\&token=336252c5-f581-4866-87ab-b248db334e50)

## So what?

* Level designers have long been fascinated by Disneyland's overall hub structure, view composition, and open world crowd flow.
* But real world architects and urban theorists focus mainly on Main Street and its powerful political symbolism.

Why don't architects care about Disneyland like level designers?

* Landmarks and sightlines are not unique to Disneyland. Visit any IRL park, garden, or landscape, and you will witness similar, if not better, sightline management strategies.
* 50% of the function of Disneyland is to hide the long visitor queues for attractions. Is that what your level needs? Is your game about hundreds of people standing in line? If so, yes, study Disneyland.

From a cultural lens, this suggests the game industry (and its level designers) don't really understand the politics and communities we're invoking.&#x20;

After all, every dead game world can be understood as a failed theme park, a Euro Disney scale disaster that misunderstood its audience. Why? Not enough weenies? Is that really what makes a theme park successful or interesting?

### Public level design... isn't Level Design?

A capital-L capital-D Level Design analysis of Main Street would fail to locate its charm. If we were to [blockout](/process/blockout.md) Main Street, we would capture 0% of its appeal.&#x20;

The blockout would suggest that players enjoy walking along a linear strip mall of identical souvenir shops that all sell the same thing. Existing level design methodologies, centered around grayboxing mid-range combat encounters, have no explanatory power here. This explains why level designers have ignored Main Street -- we don't understand it.

Instead, perhaps we should learn more from Main Street as a model for building city hubs, NPC towns, and other safe zones that invite the player to dwell and hangout. Charles Moore and the Canadian Center for Architecture argue that, above all, this sense of public life / reassurance is a cultural and political appeal to a specific demographic. A social mood cultivated by people.&#x20;

How do we make spaces feel populated and maintained? Only the janitors, retail workers, tour guides, hosts, and costumed mascots can tell you -- not the architect.&#x20;

Maybe the true level design lesson of Disneyland is to recognize how hospitable game worlds depend less on level designers, and more on environment artists, level scripters, server engineers, moderators, and community managers.

## Further reading

### Video essayists

* [**Defunctland**](https://www.youtube.com/c/Defunctland) analyzes a variety of theme parks (not just Disneyland), usually from a historical perspective. Sometimes they focus on typologies across time (e.g. [the history of the ferris wheel](https://www.youtube.com/watch?v=OsJu0XA429A) that begins with the Great Exhibition of 1851). Always feels pretty comprehensive with good coverage and presentation.
* [**Poseidon Entertainment**](https://www.youtube.com/c/PoseidonEntertainment/) has more of an attraction-centric Disney / Universal fan lens, with somewhat technical deep dives into specific systems (e.g.[ critique of various Disneyland FastPass systems](https://www.youtube.com/watch?v=OdgEWudqR1U)). Less of a zoomed out historical perspective, more of a zoomed in guest-facing analysis.

>
