> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/studies/irl/stub-las-vegas-nevada-usa.md).

# (STUB) Las Vegas (Nevada, USA)

critical level design primer on the city that game design built

{% hint style="info" %}
This is a stub to remind myself to fill this in later
{% endhint %}

TODO: summarize Learning From Las Vegas
