> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/studies/mp.md).

# Multiplayer studies

design analysis and commentary for various multiplayer and player vs player (PvP) maps

<table data-view="cards"><thead><tr><th></th><th></th><th></th><th data-hidden data-card-target data-type="content-ref"></th><th data-hidden data-card-cover data-type="files"></th></tr></thead><tbody><tr><td><strong>Chill Out</strong> (Halo 1)</td><td>Layout and room design for arena shooter</td><td></td><td><a href="/studies/mp/chill-out.md">Chill Out (Halo 1)</a></td><td><a href="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FaUXyGVPMwTPaL1PRSFbd%2FLDB_Halo_AndrewYoder_ChillOut1.webp?alt=media&amp;token=34d672f4-d329-43be-a9f0-5a31adbd6745">LDB_Halo_AndrewYoder_ChillOut1.webp</a></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>
