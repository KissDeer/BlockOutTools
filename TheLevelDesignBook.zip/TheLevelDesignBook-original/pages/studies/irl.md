> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/studies/irl.md).

# Real world studies

design analysis of real world architecture, physical spaces

<table data-view="cards"><thead><tr><th></th><th></th><th></th><th data-hidden data-card-target data-type="content-ref"></th><th data-hidden data-card-cover data-type="files"></th></tr></thead><tbody><tr><td><strong>Disneyland</strong> (USA)</td><td>Rethink how level designers see theme parks.</td><td></td><td><a href="/studies/irl/disneyland.md">Disneyland (California, USA)</a></td><td><a href="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MauGVrCbUVtVRC_MKWx%2F-MauHAn5iIsvLEp4sCKH%2FLDB_Disneyland1963_Map.jpg?alt=media&amp;token=5b210d75-120d-4383-9228-1a2513ec84da">LDB_Disneyland1963_Map.jpg</a></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>
