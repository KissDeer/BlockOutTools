> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/culture/history-level-designer.md).

# History of the level designer

How the level designer role was invented and professionalized across the game industry, including its golden age in 1993-2002, and later its fall in prominence.

## Introduction

This is a history of the level designer role and the history of how we understand the work conditions and influence of level designers. Our main questions:

* How did the "level designer" emerge as an identity and work role? Which came first?
* What is / was the cultural understanding of a level designer, both inside and outside the industry?
* What is the current state of level design, and how did we get here?

This history also intersects with the history of the game industry, the history of game modding, as well as the larger history of home computing and the internet.&#x20;

## Early computing / arcade era (1973-1980)

In the early years of the game industry, many game programmers also did the design work for their own projects. "Level" referred to the arcade game's programmed difficulty level.

Early first person games like Maze War (1973) existed as research lab prototypes without any officially designated game designer, while popular first person arcade cabinets like Battlezone (1980) used procedurally generated / hardcoded levels embedded within the game code.

![screenshot of Battlezone (1980) with green wireframe landscape](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lxed8uGKmzwEAwJxKLd%2F-Lxeex3JfuWuB2SOrKX_%2Fimage.png?alt=media\&token=11b929bc-b10b-409b-adb4-91f1f975b778)

During this time, engine code and game code / content shared the same code base, or they were at least tightly coupled. There were no separate game data files to edit, so level design required extensive programming knowledge to edit the game code; there were no dedicated level editor tools for making levels, so level designers essentially did not exist. Level design was just part of the informal work performed by game designers and programmers, and thus not understood as a separate design discipline.

Computers were also just really really expensive. Only corporations and universities could afford huge computers for research, and only arcades and businesses could afford to invest in arcade cabinets by selling access to the machines. Since so few people had dedicated access to computers, of course there would be very few level designers, if any.

## Invention of the game engine (1983-1992)

In the early 1980s, computer manufacturers started selling smaller and cheaper personal computers (PCs) and consoles intended for the home market. More computers meant a larger install base of users looking for new software (especially games) as well as a community of amateur "bedroom programmers" who informally developed their own games, supposedly at home in their bedroom.

![screenshot of ZZT's (1991) built-in editor, editing a "Castle/Well" board](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LxelcVCR0LRxyvX3wC_%2F-LxeuNTUqas19VnF_YSk%2Fimage.gif?alt=media\&token=51e0c5d8-f9da-4b75-86cf-c537ff2423c6)

Lode Runner (1983) was one of the first games to include a level editor ("edit mode"), with claims that solo developer Douglas E. Smith had neighborhood children build levels and even shipped many of their levels as part of the game. Tim Sweeney's influential game ZZT (1991) also featured a [built-in editor](https://museumofzzt.com/article/175/closer-look-640x350x16-a-history-of-zzts-graphics) with integrated ZZT-OOP scripting language, nurturing a sizable community of modders and spurring Sweeney to run official level design contests.

One of the earliest popular first person shooters Wolfenstein 3D (1992) did not ship with a level editor, but the tile-based map format was simple enough for a fan named Bill Kirby to reverse engineer a functional editor called [MapEdit](https://wl6.fandom.com/wiki/MapEdit). By 1993, fans had made hundreds of custom maps and mods, prompting the developer id Software to build better mod support for its follow-ups Doom and Quake.&#x20;

![screenshot of MapEdit tool by Bill Kirby, editing "Wolf1 Map1"](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LxelcVCR0LRxyvX3wC_%2F-LxevaDo0ndg149dnFWt%2Fimage.gif?alt=media\&token=e34a3b49-f95c-4a63-aee0-f72321dc7ced)

### The game engine as social construction

Doom (1993) is widely regarded as the most influential first person shooter of all time. Its main programmer John Carmack popularized the concept of architecting a "game engine", where core engine code like file input/output and rendering was kept separate from the rest of the game code and game data. Since Doom stored its game content in .WAD files ("Where's All the Data"), players could load their own player WADs (PWADs) to mod the game, and these PWADs could swap in custom levels, graphics, sounds, etc.

Doom blossomed into a huge cultural phenomenon with a large player base and active modding community that still continues to this day. It represents the beginning of level design as an approachable amateur hobby, stimulating the growth of a level design community and culture.

But who really built that level design community and culture? Despite shipping a technical foundation for loading custom WADs, id Software did not publicly release its internal level editor [DoomEd](https://doomwiki.org/wiki/DoomEd). What use is a modding system when there are no tools for modders to use? Much like MapEdit for Wolfenstein 3D, modders were forced to once again reverse engineer their own tools like [Doom Editing Utilities (DEU)](https://doomwiki.org/wiki/Doom_Editing_Utilities).&#x20;

In this sense, we argue that modders and level designers largely invented themselves as a grassroots hacker practice, with minimal support (e.g. a pledge not to sue) from the commercial game industry.

![screenshot of Doom Editing Utilities, a fan made editor tool by Raphaël Quinet and Brendon Wyber ](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M0n89_R-NlnyGTqldIE%2F-M0n9BYuvajilb7W_wKK%2FDoomEditorUtilities.jpg?alt=media\&token=730e7321-4892-46ab-af9f-0d149b846f09)

This is also where we must question the popular historical narrative of Carmack as the patron saint of modders. id Software's prior experience with Wolfenstein 3D modders had generated several less-than-purely-altruistic business incentives to support modding more officially in Doom:

* mods extend the lifespan of a game and its "long tail" of retail sales
* modders train themselves for free, forming a convenient pool of labor to hire from
* official mod support discourages hacking / piracy (modding Wolfenstein 3D required hacking the data embedded inside the game executable, bypassing copy protection, thus mod distribution entailed piracy)

We argue that Carmack's popularization of the game engine is more effectively understood as a cultural business innovation, rather than a technical engineering achievement. Data-driven programming paradigms have existed since the 1970s, and even moddable games such as Boulder Dash Construction Kit (1986), The Bard's Tale Construction Set (1991), and of course ZZT (1991) existed well before Doom (1993). Architecturally, the WAD system is less of a groundbreaking idea, and more of a refinement of existing ideas.

What really set Doom apart was the critical mass of its mod community and fanaticism, so the keyword we'd like to emphasize is "popularize": Carmack *popularized* the social construction of the game engine, a marketing buzzword that reimagines the video game as a platform for user generated content... and it worked. Modders flocked to the game engine and invested their labor in it, and continue to do so today.

![screenshots of Cacowards 2019 winners "Hocus Pocus Doom" by Jason Allison and "Lost Civilization" by Jaska](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MDLDt1uvo-WKG2nQgOf%2F-MDLG8_IXOil33n331Uw%2FCacowards2019_HocusPocusDoom_LostCivilization.jpg?alt=media\&token=f86f63df-6d8d-4d50-aa0f-a8a91f2b1d3c)

## The golden age (1993-2002)

We argue that level design experienced a golden age from approximately 1993 to 2002. During this period, level design tools were widely available to the public, level design became a much more common pastime, and level designers enjoyed unprecedented prestige and power in game culture.

### Level designer as rockstar

During the golden age, level designers enjoyed unprecedented prestige in game culture.

Perhaps the most prominent level designer in history was co-founder of id Software and lead designer John Romero, who possessed a rockstar-like name recognition among gamers in the mid 1990s. This reputation even prompted publisher Eidos to commission a notorious magazine ad for Daikatana (2000) threatening gamers that "John Romero's About To Make You His Bitch. Suck It Down." Thus the level designer was the chief creative voice of early first person shooters and the game industry as a whole. For better or worse.

![Electronic Games (vol 2 issue 11, Jan 1995) cover, "The Doom Boom" feature, and the infamous "John Romero's About To Make You His Bitch. Suck It Down." magazine ad for Daikatana (2000)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M2OxPwpUKQJNc0CUgGA%2F-M2TxTAynEkUWYK0Qcca%2FLDB_CarmackRomero_MagazineCovers.jpg?alt=media\&token=2270dd7b-369a-4712-a1bd-7278a202927e)

{% hint style="info" %}
[Romero later apologized](https://kotaku.com/john-romero-is-so-sorry-about-trying-to-make-you-his-bi-5541406):*"You know, I never wanted to make you my bitch..."*  Also note that the 1990s were a time of [edgy ironic grungy "Gen X" marketing](https://en.wikipedia.org/wiki/OK_Soda) coinciding with [the invention of a modern male gamer identity](http://www.firstpersonscholar.com/the-gamer-identity-crisis/) that embraced harmful stereotypes.
{% endhint %}

Other Doom level designers like American McGee also garnered their own lesser amount of name recognition and power. PC Gamer commissioned official Half-Life mods by Neil Manke, plastering his name on magazine covers. The designer of the iconic Counter-Strike map de\_dust Dave Johnston won a modest following and interview requests from journalists. Cliff Bleszinski, designer of dozens of Unreal 1 and Unreal Tournament maps at Epic Games, nurtured a Romero-like rockstar public persona as CliffyB. There was even a prolific Quake mapper who called himself The Levelord and people were like, ok sure. For better or worse, these were the people who would garner fawning profiles in popular gamer magazines, back when those were still a thing.

### Level design as the final say

Everyone in the game industry, or at least those working on the big most-prestigious 3D action games, seemed to agree: level design was the most important part, and level designers enjoyed immense power and control over the final shape of the game.

> *"Level design is where rubber hits the road."* [*- Jay Wilbur, id Software business manager 1991-1997*](https://www.gamasutra.com/view/feature/131767/secrets_of_the_sages_level_design.php?page=6)\
> \
> *"A level designer has a very responsible position, because maps are where the game takes place."   -* [*John Romero in 1999*](https://www.gamasutra.com/view/feature/131767/secrets_of_the_sages_level_design.php?page=5)\
> \
> *"The LD is the one who is taking everyone else’s hard work and tying it together into a cohesive package." -* [*Cliff Bleszinski, "The Art and Science of Level Design" at GDC 2000*](https://web.archive.org/web/20021203193328/http://www.cliffyb.com/rants/art-sci-ld.shtml)

![screenshot of Valve Hammer Editor 3.5 editing the map "c1a0" from Half-Life 1, from https://developer.valvesoftware.com/wiki/File:Hammer35.png](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M2UXP5KgHS8jIc1HmOj%2F-M2UpvIOHBKtFSvq_cGL%2FLDB_ValveHammerEditor35_ValveWiki.png?alt=media\&token=ffaee266-e14a-4007-af38-539663a2a5fa)

This sense of responsibility stems from the technical importance of level designers in early game engine workflows and pipelines. Level editor tools really were where the code, graphics, audio, and story assets, all came together. Nothing existed in the game unless the level designer put it there. For example, if a designer didn't like a certain texture, sound, or AI behavior, then they could simply omit it from their levels -- and thus, it would never get used in the game.

Thus level designers had the "final say" and informal institutional veto power over game content. And when they claimed ownership over their levels, the centralized nature of level editor workflows meant they could essentially claim ownership over the whole game experience too.

### High modernism

We argue the golden age of level design culminated in 2002 with [GeoComp2](https://web.archive.org/web/20021212213700/http://www.planetquake.com/nunuk/geocomp2challengenews.htm), an unofficial Quake 3 Arena community level design competition that emphasized plain texturing, sweeping abstract geometric forms, and detailed design discussion.&#x20;

GeoComp2 entries emphasized auteurism with perceived elegance and functional purity, pairing the aesthetics of high level competitive FPS play with the tenets of modernist architecture. Most importantly, there was a conscious effort toward facilitating a detailed design language and critique.

For each entry, a community jury debated the merits of each map with specialized terminology and ideas unique to level design. Did the level designer have a fresh personal style, and attempt novel ideas that had never been seen before? How does the "brushwork" (level geometry) feel? These types of craft-oriented questions can only be asked by an advanced design community with a shared history, language, and understanding.&#x20;

![overview of "Minima" by Bengal, custom multiplayer map for Quake 3 Arena](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M-7UqIxJ-UgEAtm215l%2F-M-7XIw38c5mQp2Dcssa%2Fgeocomp2_minima1_bengal.jpg?alt=media\&token=1bd7d494-b983-4bb9-9663-532e4cdb697c)

> *"... The map is king of the hill style map split into 2 blocks interconnected with a massive array of jump pads and teleporters. The brushwork is strangely broken but architectural complete in a sort of w\[ei]rd artist way! The brushwork seems to sweep upwards offers impressive structures towering above the players. \[...] The map seems to have an nosta\[l]gic feel which almost needs to be dripping in fur. \[...] Nothing about the architecture seems to repeat and all aspects of the brushwork seems fresh and original. even thou\[gh] the map is sy\[m]metrical from left to right the architecture is not. For example the floor spaces have strange cut patterns which break the sym\[m]etrical theme of the map in a very striking way..."*
>
> \-- Simon "sock" O'Callaghan's critique of ["Minima" by Bengal](https://web.archive.org/web/20021212104852/http://www.planetquake.com/nunuk/geocomp2mapbengal.htm), for GeoComp2

![screenshot of "Minima" by Bengal, custom multiplayer map for Quake 3 Arena](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M-7UqIxJ-UgEAtm215l%2F-M-7XMoC9BSo6LbSsMw4%2Fgeocomp2_minima2_bengal.jpg?alt=media\&token=1fd2fd61-70cd-4e25-bdc2-5eb4e154826d)

The aim behind GeoComp2 was not to make a popular map, or even a "fun" map -- it was to advance the craft of level design. Any fandom for Quake 3 or id Software was secondary. This was a clear example of level designers making maps primarily for other level designers, to articulate an aesthetic that transcends the game itself.&#x20;

For this reason, we argue that GeoComp2 represents a historic milestone for how level designers viewed and organized their work. It represents a zenith of self-regard, when level designers consciously evoked the aesthetics of high modernist architects like Le Corbusier and Frank Lloyd Wright. It was a community-organized showcase for avant-garde design that emphasized concept, craft, and aesthetics, instead of commercial viability or building an audience.

### A gilded age

Final Doom was published by id Software but developed by community modder group TeamTNT. Various id-adjacent studios riding the 90s FPS boom, like Ritual Entertainment and Ion Storm, hired heavily from mod communities. Valve purchased the rights and hired the modders behind Team Fortress and Counter-Strike. Going retail or "breaking in" to the industry were seen as the just rewards for the most deserving of modders, elevated to the status of professional. This cult of meritocracy still persists in a level design culture that heavily emphasizes portfolios of shipped titles.

But for many modders, the golden age was merely a gilded age where many modders labored in obscurity for little recognition or reward. Auteurism in any industry also hurts many collaborators, who see their contributions forgotten when society credits the most famous figures for the entire project. ([Just ask Sandy Petersen](https://www.youtube.com/watch?v=w9oG2LBuMwY).)

The golden age of level design was simply the time when level design enjoyed relatively high status in game culture. Today, industry level designers are much more anonymous members of huge 100+ / 1000+ person development teams. There will never be another rockstar level designer like John Romero because the game industry now works with levels as assets instead of platforms.

(todo: insert illustration)

## Fall from grace (2003-2010)

### The end of generalism

In the golden age, level designers often served as all-in-one all-purpose developer. Doom mappers setup their own lighting, Half-Life designers choreographed their own scripted sequences, Thief: The Dark Project mission designers wrote in-game readables, and Counter-Strike mappers mixed their own ambient audio. This informal distribution of labor allowed them to claim ownership over the final product, and thus justify their auteur status.&#x20;

When one person performs several different jobs or roles on a project, this is called **generalism**. Modders, solo devs, and small indie teams still abide by generalism out of necessity. However, generalism quickly proved incompatible with ballooning AAA game budgets and production value arms races. As early as 2000, the industry already predicted a future of **specialization** in level design, with a more specific and formalized distribution of labor:

> *"... it is no longer possible for one LD to maintain "ownership" of a level as computers and gaming machines are becoming more and more capable of rendering extremely detailed environments. The talent that is hired must be comfortable with the idea of others modifying and improving their work.*
>
> *There is a direct correlation between the detail that a technology is capable of and the amount of ownership that one designer has over a particular level. With* [*Moore’s law*](https://en.wikipedia.org/wiki/Moore%27s_law) *holding true (processor speed doubles every eighteen months) and 3d accelerators constantly raising the bar the detail that game engines are capable of is staggering. It is simply impossible for one driven person to build the necessary amount of detail into level locations in the allocated time, and the more detail technology can push the more people will be required to work on levels.*
>
> *In addition to having dedicated world texture artists and environment concept designers the need will soon emerge for dedicated "prop" people; artists who create content that will fill up previously static and barren environments. \[...] Teams may soon see the addition of "scripting" people who are responsible for storyboarding in-game events as well as assisting in the design and direction of these events. \[...]*&#x20;
>
> *Right now there are companies that have artists lighting levels, as well as doing custom texture work on a per-surface basis. The level designer will evolve to the role of the glue of a project, the hub at which everything comes together."*\
> \
> \-- [Cliff Bleszinski, "The Art and Science of Level Design" at GDC 2000](https://web.archive.org/web/20021203193328/http://www.cliffyb.com/rants/art-sci-ld.shtml)

Remember how level designers were creative directors? In 2000, CliffyB wanted to "evolve" level designers into glue. Evolution indeed!

However, some level designers didn't enjoy being the glue, because it turns out when the game falls apart, you end up blaming the glue.

![slides from "Unscaping the Goat" by Ed Byrne for Level Design In A Day, GDC 2011](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M-73MHnzxtdPZU63KUV%2F-M-7RvL0GEdTTZJUzygs%2Fimage.png?alt=media\&token=447e6456-fa00-41fc-8be0-eff7e9f7e90c)

In his GDC 2011 talk "Unscaping the Goat", industry designer Ed Byrne alluded to a culture of blame in AAA game studios. Because artists, game designers, and programmers, had well-established tools, duties, and deliverables, they would blame level designers and their vaguely-defined informal labor for complex problems. As Bleszinski predicted, a single "level owner" could no longer claim so much responsibility and control over the experience. It was time for level designers to step down from their once-privileged position.

### Shift to specialization

Many of Bleszinski's predictions came true across the entire industry. Big budget game studios today routinely hire huge teams of dedicated environment artists, prop artists, lighting artists, and level scripters. Industry level designers today rarely paint their own textures, model their own props, setup their own lighting, or choreograph their own cutscenes.

Yet Bleszinski also seems to have underestimated how much level designers would specialize. Industry level designers today also routinely do not build their own blockouts, nor setup their own NPCs and battles -- instead, we now have dedicated level architects, level builders, combat designers, encounter designers, and mission designers.

![2001 Crytek "3D-Level Designer" job post from https://web.archive.org/web/20010404230927/http://www.crytek.de/hp/jobs.htm#level](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M-73MHnzxtdPZU63KUV%2F-M-7P0-W7pF8xMK9K2qe%2Fimage.png?alt=media\&token=f586e8be-08fe-4abd-8031-6afe3089fe70)

In 2001, a company called Crytek put out a job posting for a "3D-Level Designer" to work on their new game Far Cry. According to this ad (see above) a level designer was someone with experience using 3DS Max, art skills, and a degree in architecture.

![excerpt of 2008 Crytek "Level Designer" job post from https://web.archive.org/web/20080725092336/http://www.crytek.com/jobs/frankfurt/level-designer/](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M-73MHnzxtdPZU63KUV%2F-M-7Nv3by-PcNZjB4Nrk%2Fimage.png?alt=media\&token=f43f7f4f-d853-42e6-ab42-338289e0ae00)

In 2008, Crytek put out another job posting to work on Crysis. Now a level designer was someone versed in "systemic design", "systemic sensory based AI Systems", "simulation design"... in contrast with 2001, there was now no mention of 3D art or architecture.

![excerpt of 2012 Crytek "Technical Level Designer" job post from https://web.archive.org/web/20120725093804/http://crytek.com/career/offers/overview/frankfurt/design-content/technical-level-designer](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M-73MHnzxtdPZU63KUV%2F-M-7M6sayE-DQpV7p-fj%2Fimage.png?alt=media\&token=8a95dae5-5e61-4d99-9480-5e1dd7c85365)

Then in 2012, Crytek was looking to hire... a tech level designer, someone who would work with programmers to optimize levels, perform maintenance, and profile implementations, perhaps in the same sense as a tech artist.

At the bottom of the ad, it listed "prior level design experience" as an optional preference! Wait, so now making levels would be "nice to have" for a level design position? Level design specialized so hard that it necessitated a level design position that didn't require experience in level design!

As a major engine vendor with thousands of employees at its height, we argue that Crytek's changing attitude was somewhat representative of industry practice as a whole:&#x20;

Level design started as an artistic visually-oriented discipline inherited from real world architecture, but after escalating project scopes and industry-wide shifts toward specialization, it has now fragmented into dozens of specializations increasingly divorced from the original holistic conception of level design.

### The last level editor (2004)

Half-Life 2 (2004) was a landmark first person shooter that popularized the use of physics-based gameplay and detailed facial animation. Its level designers still had substantial control over level geometry, texturing, lighting, and scripting with an editor tool called Hammer. The underlying game engine Source 1 descended from idTech1, the core tech for Quake and Half-Life, and so it was the last major game engine to rely heavily on mid 1990s building techniques known as [CSG](https://en.wikipedia.org/wiki/Constructive_solid_geometry) / [BSP](https://en.wikipedia.org/wiki/Binary_space_partitioning).&#x20;

As designer Joe Wintergreen [argues in the video below](https://www.youtube.com/watch?v=xOBEy-zIotE), this type of construction might feel a bit old and primitive today, but it supports a wide range of expressive construction without forcing level designers to learn specialized 3D art tools. This workflow also promoted a tight loop between level geometry and gameplay iteration.

{% embed url="<https://www.youtube.com/watch?v=xOBEy-zIotE>" %}

For this reason, we argue that Hammer was essentially "the last level editor" because it hit a sweet spot of public availability, popularity, functionality, technology, and market conditions. Since its initial release in 2004, no other tool for any other game has attained quite the same traction or influence. Just take a look at the sorry state of our [Tools](/appendix/tools.md) page! It's sad how much is broken, and how little we can recommend.

A variety of factors have sunk any would-be successors to Hammer:

* restrictive and exploitative EULA, ceiling on future utility and output
* editor tools withheld to preserve developer monopoly on DLC
* oversimplified editor with severe limits, not what devs actually use
* game is unpopular or obscure, no sustainable community of users or players
* depends on proprietary middleware / servers, not feasible to release publicly

### Multipurpose game engines (2010+)

Recall the importance of the level editor to the level designer's consolidation of power during the golden age. The level editor was literally where you binded assets and code together to implement gameplay.

Today, that binding function has become the main focus of generalized multipurpose game editors integrated into modern 3D game engines Unity, Unreal, and Godot. The game editor is where artists and coders do their work too, it's no longer reserved solely for the level designer.&#x20;

In fact, these tools don't even have robust built-in 3D construction capability anymore. Industrial hyperspecialization meant level construction was now understood an art task, not a generalized design task -- prompting middleware engine providers to neglect construction tools. The continued lack of these tools perpetuates the cycle of sidelining level designers.&#x20;

It's ironic that this tool design descends from level editor tools, yet level designers arguably can't really use them to do level design today.&#x20;

![screenshot of the popular Unity v3.0 (2010) editor interface, and its total lack of built-in 3D tools beyond a transform gizmo](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MDk0NSnnCrvZ7cVSzNM%2F-MDk62fWsbmv6UmJDtyb%2FUnity3_2010_EditorScreenshot.jpg?alt=media\&token=2a747fa1-080b-4474-9219-cfc6bdb66063)

## Future(s) of level design (2011-present)

Level design is no longer just one thing, it has split into different practices and understandings:

* **Postlevel design:** popular game genres today rely much less on traditional level designers
* **Local level design:** players do informal level design for each other, rather than industry or craft
* **Retro renaissance:** return to golden age construction and design values

### Postlevel design

We argue that Hammer was essentially the last level editor tool. Maybe there are no new level editor tools because *traditional level designers are no longer needed* for many popular game genres today.

Consider [the perceived decline of big-budget AAA commercial single player 3D action games in the late 2010s](https://www.forbes.com/sites/davidthier/2017/10/18/star-wars-visceral-yes-aaa-single-player-games-are-dying-thats-fine/), the rise of the multiplayer battle royale format, and [the second death of the immersive sim genre](https://www.pcgamer.com/the-future-of-immersive-sims/) -- a FPS-RPG hybrid subgenre that relied heavily on detailed level design. Perhaps popular trends and game genres have simply moved on, and the types of games that "need" traditional capital-L capital-D Level Designers are gradually losing relevance (and/or market value to investors.)

Minecraft (2011) is the most popular first person game of all time, and Fortnite (2017) is perhaps the most popular shooter game of all time. Yet for our purposes, it is debatable whether Minecraft or Fortnite have level design. Minecraft relies on [procedural generation](https://en.wikipedia.org/wiki/Procedural_generation) to seed randomized spaces without specific experience design intended by a human designer. [Pacing](/process/preproduction.md#pacing) emerges from statistical resource distributions defined by [biome](https://minecraft.gamepedia.com/Biome) code. ["Building"](https://www.minecraft.net/en-us/article/raeyzeus-top-5-building-tips) is understood as a game system and amateur communal activity, not as level design. As for Fortnite, yes, players scavenge for resources in a developer-authored landscape, but gameplay quickly escalates into player-built forts and towers. Does level design meaningfully exist in a game where players routinely ignore the authored terrain and build their own level?

{% embed url="<https://www.youtube.com/watch?v=bo8UElCrg3Y>" %}
"Minecraft building" shares many concerns with level design, but it is also clearly not level design
{% endembed %}

This reality would've been utterly unthinkable back in the golden age of level design. Imagine going back in time to 1993 and telling celebrity rockstar level designer John Romero that the most popular first person game of all time in 2011 does not rely on professional level designers building content in a level editor tool. This genre framing was inconceivable back in the 1990s, but in the 2010s it is the new normal.

The contemporary games as a service (GaaS) model emphasizes huge monolithic landscapes that go through dynamic seasons and demographic changes, instead of streams of static level content. Planning individual rooms is now safely below their concern. Is that still level design, as understood for the past 30-40 years? Obviously no.

This conception of world design, community design, season design -- it's bigger than a video game level, and demands a very different skillset. Thus the postlevel designer is less like an architect, and more like a city planner, festival organizer, TV show runner, or climate engineer.

### Local level design

By most professional design standards, the Counter-Strike 1.6 community map [fy\_iceworld](https://www.rockpapershotgun.com/2020/04/22/the-legacy-of-fy_iceworld-counter-strikes-divisive-and-hugely-popular-custom-map/) is poorly made. It is very small and symmetrical, team spawns have direct visibility to each other, the texturing and lighting are flat and bland, and there is basically zero detail or set dressing.

Yet despite all these markers of low quality and poor taste, Iceworld is one of the most popular and iconic maps of all time. Its frantic scramble and quick turnover is genuinely fresh compared to the official mapcycle. Every CS 1.6 player knows this map, and even [Call of Duty: Modern Warfare cloned it](https://callofduty.fandom.com/wiki/Shipment).&#x20;

![screenshot of counter-terrorist team spawn in fy\_iceworld for Counter-Strike 1.6, by Fantasy](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MDLDt1uvo-WKG2nQgOf%2F-MDLPuvnUj9miU2lJtfi%2Fyang_fy_iceworld01-guns.jpg?alt=media\&token=4e9fdb45-8683-488c-b62e-252146271741)

As a counterweight to the heavily professionalized "serious" auteur level designer identity, we must also consider the more anonymous designers who built maps for their own gamer clans, favorite servers, local [PC bang](https://en.wikipedia.org/wiki/PC_bang), and IRL friend groups. This type of community design practice ignores formal questions of supposed "good taste" or production value. Instead, these are spaces for fostering shared social moods, the equivalent of a childhood treehouse or clubhouse.

Iceworld is a great example of **local level design,** informal level design that emphasizes a social context above any larger obligation to craft or career. Other examples of local level design include marriage proposal maps like [the Gary Hudston Project for Portal 2](https://www.youtube.com/watch?v=o8SdYz7cq04) or the achievement trap joke maps like [achievement\_all\_v4 for Team Fortress 2](https://www.youtube.com/watch?v=vb_9vxXyqdU). Here, the formal level design and professional craft matter less than the cultural story surrounding it.

### Retro renaissance

(TODO: include Doom history too? Doomworld, Cacowards, community memory)

In 2010, [Quakespasm](http://quakespasm.sourceforge.net/) debuted as a modern "source port" engine that embraces backwards compatibility and eschews "unfaithful" graphics upgrades, unlike heretical Quake engine forks like DarkPlaces or FTEQW that use modern shader aesthetics. [TrenchBroom](https://kristianduske.com/trenchbroom/) debuted in 2011 as a modern multiplatform open source level editor that breaks from Worldcraft / Hammer lineage. The community mega mod [Arcane Dimensions](http://www.simonoc.com/pages/design/sp/ad.htm) launched in 2015 represents some of the strongest design work in Quake's history. This critical mass of new tools, resources, and community have triggered and sustained a Quake renaissance for the past decade.

Much like historical renaissances and the larger indie games movement, the Quake renaissance represents a return / rebirth of perceived classical values retrofitted onto modern culture, economy, and technology. It is also a reaction against several contemporary trends:

* **rejection of modern aesthetics** for "pure" low poly geometry on a fixed color palette, with carefully calibrated nostalgia (yes to colored lighting; no to 8-bit transparency)
* **embrace of amateurism** counters industrial hyperspecialization; professional game developers miss the freedom of non-commercial generalist design
* **resistance to platform capitalism** reconstructs Quake as a community-owned open source platform that is "worthless" to Quake's corporate IP holders
* **level design for level designers** (e.g. [high modernism of GeoComp2](/culture/history-level-designer.md#high-modernism)) avoids [context collapse](https://www.zephoria.org/thoughts/archives/2013/12/08/coining-context-collapse.html) of modern social networks, both players and designers share deep history and memory

![screenshot of Arcane Dimensions (2015-2018), a modern Quake mod emblematic of "retro renaissance" http://www.simonoc.com/pages/design/sp/ad.htm](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MDj_ngSOdI6jitZ76zx%2F-MDjzO9IvS-gUFWrgq6l%2FArcaneDimensions.jpg?alt=media\&token=7162ef12-dc38-4cd9-8999-ab0c0869e6f2)

### The end of history?

To be sure, there are still many new projects with great level design today, and there will be many more to come. However, we question whether future generations of new level designers can emerge without proper access to tools and resources. How many great potential designers are we losing? What else can level design become?

In this history, we traced factors that enabled a golden age of level design:

* available tools -- free developer-grade editor that enables expressive construction
* sustainable audience -- large creative communities of supportive players and designers
* artistic control -- generalist self-sufficiency to build and finish projects independently

The extinction of level editors, the rise of closed platforms and games as services, the shift toward hyperspecialization, and the popularity of postlevel design genres, all threaten the future of the level designer.

We don't foresee any of these industry trends reversing. Level design will steadily become less relevant and eventually drift out of public memory as another forgotten art, like sign painters or telegraph operators. And maybe that's OK.
