> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/culture/overview.md).

# Level design as culture

Thinking about level design more broadly, as history / community

Video games are always changing. This means that level design is also always changing. The "Culture" section of this book seeks to understand patterns and trends in level design:

* What does "level design" mean to different people?
* How do other disciplines and industries relate to level design?
* What are other ways to think about level design, beyond a "craft" lens?

{% hint style="warning" %}
Currently, this section is not the main focus of the project. We want to finish [**Book 1, Process**](/process/overview.md) first.
{% endhint %}

However, we do have a few pages here to give you a sense of what we're aiming for -- a mix of historical analysis, research, and cultural criticism.

* [History of the level designer](/culture/history-level-designer.md)
* [History of encounter design](/culture/unfinished-pages/history-encounter-design.md)
* [Zero player level design ](/culture/zero-player.md)
