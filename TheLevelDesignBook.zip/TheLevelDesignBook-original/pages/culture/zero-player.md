> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/culture/zero-player.md).

# Zero player level design

Essay about acrobatic community-made levels where players perform zero input

In racing games like TrackMania and platforming games like Super Mario Maker, users have built complex “Press Forward” and “Auto-Mario” levels that propel the player’s game character to perform dazzling feats of acrobatic virtuosity, but with trivial or minimal player input.&#x20;

We argue this type of “zero player level design” complicates typical ideas of gameplay and players: these zero player levels are playful design objects that play with not-playing, and emphasize the virtuosity of architectural choreography.

{% hint style="info" %}
&#x20;This article first appeared in [*VGA Reader Vol. 3*](https://vgagallery.org/vga-reader) as [“Dancing About Architecture: on Zero Player Level Design"](https://vgagallery.org/vga-reader-articles/dancing-about-architecture-on-zero-player-level-design) and has since been edited for inclusion in this book.
{% endhint %}

![Screenshot of the player’s car careening through elaborate PF “Hyperion’s Wrath” in Trackmania Nations Forever, from YouTube video “Trackmania \[PF\] - Hyperion’s Wrath | PRESS FORWARD” by user L4Bomb4, uploaded April 18, 2016.](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Ml2Wt5iE9RXJMSKpPRh%2F-Ml2YHu8w1O1RRcJhIK2%2Fzeroplayer03_hyperions_wrath%2B\(1\).png?alt=media\&token=dfa402bd-aa3b-447e-b70b-2c11dbe499ce)

## On local level design

Many contemporary video games feature robust built-in editor tools that let players build new levels without the need for any specialized professional software or hardware. The accessibility and immediacy of these tools often attracts people who do not usually consider themselves to be game designers, and new design patterns often emerge organically out of these casual player-designer communities. These passionate amateurs use level design very differently from the industrial developer’s canonical design patterns, constituting a practice that I call "local level design.”&#x20;

Local level design often happens in a very specific context and community to the original game. For example, in 2010, Valve changed how players unlocked items in its first person multiplayer shooter Team Fortress 2; to earn new upgrades, players suddenly had to grind achievement goals, such as killing a certain amount of enemies using a specific weapon. In response, the player community quickly established achievement grinding servers with specially designed achievement farming maps so that players could easily fulfill these achievement goals and acquire these upgrades more quickly than during typical unfocused play. Officially, Valve strongly disapproved of these new achievement servers and maps, arguing that it was tantamount to a cheat or an exploit.&#x20;

![Figure 1, screenshot of a large cat shooting lasers at players in Team Fortress 2 achievement trap map "achievement\_all\_v4" from YouTube video "Team Fortress 2 - Laser Death Cat" by user jasonrawr uploaded Jun 25, 2010 https://www.youtube.com/watch?v=vb\_9vxXyqdU](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MTL-COGEHYHWbDfIw3b%2F-MTL0EzlKC-wNsJw4zGc%2Fzeroplayer01_achievement_all_v4.png?alt=media\&token=055bd8fe-aa8b-47ae-bcda-f8088ced281e)

As a rebuttal to this moral crisis, a user named The303 made “achievement\_all\_v4”, a novel achievement trap map where everything seems like a normal achievement farming map for a few minutes, until a giant monstrous invincible cat erupts from the ground and attacks every player with powerful laser beams and cannons. At the end, any surviving players on the entire server are wiped-out via nuclear detonation. The goal of the map was clearly to trick players into thinking they were going to play on an achievement grinding map, but then punish them in a highly visible and humorous way.&#x20;

Both the achievement grinding map and the ensuing achievement trap are clear examples of local level design as a form of discourse, and in this case, these maps acted as a moral dialogue reflecting on the community’s actions. It exemplifies how users frequently invent new ways of understanding the game's core building blocks and assumptions, thus discovering entirely new ways to use the game’s design language.

I want to talk about a form of local level design that has emerged across several different games and genres: the “zero player level” that paradoxically calls for minimal or trivial player input to complete successfully.&#x20;

These levels complicate typical ideas of player agency in games, and center the player-designer as an elegant choreographer rather than a wry commentator or skilled performer. This phenomenon intersects with how these communities develop (or debate) a game’s design language, how they understand the boundaries of their various design practices, and how the player community maintains its identity.

{% embed url="<https://www.youtube.com/watch?v=vb_9vxXyqdU>" %}

## Press Forwards (PFs) in TrackMania

Nadeo’s TrackMania racing games feature a built-in track editor prominently featured in the game’s advertising materials and main menu. To facilitate file sharing, the game client automatically downloads new user-made custom tracks when the player connects to a multiplayer server. A community-run database called TrackMania Exchange also lets players upload and archive their track files, and serves as a social hub for players to discuss and analyze favorite tracks and building techniques.

TrackMania games usually feature a hundred or more tracks built by Nadeo that gradually increase in length, complexity, and difficulty. Early TrackMania games even forced players to race these tracks to earn currency, which they could use to unlock new blocks for the track editor. For new players, these pre-built included tracks establish a design norm of commonly accepted track design patterns, and many custom player-built tracks rely on these stock tracks to tutorialize certain skills and driving maneuvers. Later TrackMania games have since formalized track design into three game modes / genres: Race (tracks that emphasize competition with other cars), Platform (tracks that emphasize tricky jumps and drops), and Puzzle (tracks where progression and checkpoints are unclear).&#x20;

![Figure 2, screenshot of the player's car driving through typical-looking stock track "D02-Race" in Trackmania Nations Forever, from YouTube video "Free Steam Games - #2 TrackMania Nations Forever ( + Gameplay )" by user TechmsTutorials uploaded Aug 4, 2012 https://www.youtube.com/watch?v=pZIoYjsotK0](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MTL-COGEHYHWbDfIw3b%2F-MTL1XRcgXPR6_myl0Kf%2Fzeroplayer02_trackmania_nations_forever.jpg?alt=media\&token=a0d9c146-9bca-45b4-975a-fcf5d693d387)

Notably, Nadeo does not include the community favorite “press forward” (PF) tracks in its taxonomy.&#x20;

Instead of challenging players to hone their reflexes and wits on the track, the PF beckons the player to simply hold down the "forward" button and watch what happens as a more passive spectator. Through no skill of their own, the player’s car executes amazing stunts and maneuvers based on the track’s delicate Rube Goldberg-like orchestra of serendipitous aerodynamics -- a car might spin 1080 degrees in the air before barely grazing a ramp in just-the-right-way to land perfectly on the track below. Paradoxically, if the player makes any kind of choice like letting go of the "forward" key, or (god forbid) turning left by 0.1 degrees, any miniscule deviance leads to a disastrous crash.&#x20;

The only way to fail a PF track is to play it and to make an actual choice. Successfully completing a PF requires the player essentially to give up their agency in the game world. In this sense, it is clear why Nadeo has sought to suppress the press forward. This is a radical design practice that resists the intended mode of playing TrackMania. It is a surprisingly existential video game world that basically punishes players for trying to wield any agency or control, and furthermore trivializes the achievements of skilled drivers who race on “normal” tracks. When virtuosity is guaranteed, it is no longer virtuous! The PF strikes at the heart of a local level design community and asks us, what makes a strong player community -- players or designers?

{% embed url="<https://www.youtube.com/watch?v=uK7Y7zyP_SY>" %}
Figure 3, video of the player's car careening through elaborate PF "Hyperion's Wrath" in Trackmania Nations Forever
{% endembed %}

The “play” and “skill” of the press forward is less about its performance, and more about its construction. The most widely-acclaimed PFs seem to focus on sheer size with complex level-over-level intersections and unanticipated improvisation of non-standard track pieces. For instance, ThunderClap’s PF “Hyperion’s Wrath” somehow directs the player’s vehicle to hit the track at a strange angle, drive across it seemingly sub-optimally, fall off, spin erratically, skid along a decorative chrome statue, and then land perfectly on a half-pipe. The design goal is to create a sort of uncanny performance that a human player could probably never achieve on a track that is otherwise invisible and illegible to humans. Instead, the track performs itself, and human players are merely its instrument.

There is a notable variant on the PF: the “press nothing” (PN) which requires players to press absolutely nothing on the keyboard. These track designs accelerate the player’s car without any player input, usually with a path of “boost pad” track blocks placed directly after the player start. However, PNs are much less popular than PFs, perhaps because cars gradually lose velocity as they proceed through the track; to maintain sufficient speed, a PN designer must dedicate substantial space to boost pads at regular intervals, which compares unfavorably to the PF’s aesthetic of surreal immediacy.&#x20;

![Figure 4, screenshot of a user building a simple incomplete track in the Trackmania Nations Forever editor, from YouTube video "Trackmania Nations Forever Editor Tratě \[CZ\]" by user LuccassCZ uploaded Sep 14, 2012 https://www.youtube.com/watch?v=JlNU1yecz7M](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MTL-COGEHYHWbDfIw3b%2F-MTL2DyB0989zo0OlAuk%2Fzeroplayer04_trackmania_nations_forever_editor.jpg?alt=media\&token=72fe62f1-448c-4cc2-9f2b-0f441b6cd265)

## Auto-Marios in Super Mario Maker

Nintendo’s Super Mario Maker series (SMM) features a user community actively managed (sometimes too much or too little, depending on who you ask) by its developers, inviting its users to build new courses using the common building blocks and platformer tropes of the popular Super Mario games.&#x20;

In a big departure from typical Mario games, the SMM games de-emphasize completing a pre-made sequence of levels.&#x20;

While Super Mario Maker 2 does feature a humorous story mode where Mario must rebuild an accidentally demolished castle by completing various “jobs” (pre-made example courses built by Nintendo), these one-off job courses are clearly meant to demo various game mechanics, powerups, and building patterns, and do not feature any coherent storyline or progression like other Super Mario games.

SMM 2’s main menu button layout echoes this shift away from playing Nintendo’s stock courses: the first option at the top is “Course Maker”, followed by “Story Mode”, “Course World” (to browse other users’ levels), and finally “CourseBot” (a utilitarian menu to manage your existing course files and downloads).

![Figure 5, screenshot of main menu sidebar with Course Maker button listed before Story Mode in Super Mario Maker 2, from "Super Mario Maker 2 - Gameplay Walkthrough Part 1 - Story Mode and Course World! (Nintendo Switch)" by user ZackScottGames uploaded Jun 28, 2019 https://www.youtube.com/watch?v=ISWqMgouaxs](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MTL-COGEHYHWbDfIw3b%2F-MTL2ipEAVw-08BxJ0XK%2Fzeroplayer05_smm2_menu.png?alt=media\&token=ebc07611-65b2-4869-a66f-b5b9c595a412)

The demo courses are just one of Nintendo’s attempts to develop a shared design language and/or impose design norms upon the SMM community. SMM2 in particular features a new community “tag” system, where users can attach labels to describe courses.&#x20;

When a course evokes the common platformer gameplay of the Mario series, users are supposed to tag it as “Standard”. Meanwhile, courses about slow methodical deduction with minimal screen scrolling garner a “Puzzle-Solving” tag, and a “Speedrun” tag implies heavy use of quick skillful continuous movement against a timer. Note the similarities to Nadeo’s TrackMania track categories (Race, Platform, Puzzle). Also note that some course tags can be merely descriptive, such as the “Short and sweet” tag.

There are two crucial constraints to SMM2’s tagging system:&#x20;

(1) a course can have a maximum of two primary tags to be displayed in the main browser menu

(2) tags are predefined (and localized) by Nintendo, which means users cannot invent their own tags. Instead, grassroots community genres must be labeled directly in the course title, which limits the discoverability of these levels by the rest of the global SMM community.

![Figure 6, screenshot of course browsing interface in Super Mario Maker 2 with each thumbnail image, course title, play stats, and tags, from from "Super Mario Maker 2 - Gameplay Walkthrough Part 1 - Story Mode and Course World! (Nintendo Switch)" by user ZackScottGames uploaded Jun 28, 2019 https://www.youtube.com/watch?v=ISWqMgouaxs](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MTL-COGEHYHWbDfIw3b%2F-MTL3GwMaaayR_zt0eST%2Fzeroplayer06_smm2_course_browser.jpg.png?alt=media\&token=5bb17917-a73d-4fb6-af24-6447403c6de0)

The tagging limitations predictably lead to heated genre debates within the SMM2 community. What is allowed under a Standard tag, and would a Spanish-speaking player understand this tag differently when it is localized as “Tradicional”? Can a Standard course feature Puzzle-Solving and Speedrun sections as well? What does it mean when Nintendo refuses to bestow official tags upon certain community genres, such as the popular “Kaizo” courses that focus on comically unfair difficulty? Yes, SMM2’s tags are a big improvement from SMM1’s lack of filters and categorization, but certainly this new form of classification is not without its own problems.&#x20;

Unlike the relative popularity of PFs / PNs in TrackMania, the SMM community heavily prefers its own variant of the PN, the “Automatic” level, or “Auto-Mario.” Auto-Mario courses depart from typical Standard, Puzzle-Solving, or Speedrun frames, and require players to press absolutely nothing on the game controller. While such automatic levels were an unofficial genre devised by the SMM1 community, the existence and use of an official “Auto-Mario” tag in SMM2 now represents an official canonization, as well as hope that Nintendo actually pays attention to community output.

“Keep” courses are the SMM equivalent of the PF track in TrackMania. Keep Walks, Keep Runs, Keep As, Keep Bs, all encourage the player to continually hold right or to jump and continually build-up speed, and the tutorial is right there in the title. These courses are less popular than the typical no-input Auto-Mario course, likely because there are already a wide variety of ways for SMM designers to maintain velocity and to redirect the player -- so requiring the player to hold down a button is not as necessary as in TrackMania.

![Figure 7, screenshot of Mario traversing a busy screen full of koopa paratroopas and trampolines in Auto-Mario course "Bane-darake no zenjidōmario ritānzu" in Super Mario Maker 2, from YouTube video "バネだらけの全自動マリオ リターンズ by そよもぎ - Super Mario Maker 2 - No Commentary" by user NinThumbWorldArchive uploaded July 4, 2019 https://www.youtube.com/watch?v=EFRdX3PM6ro](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MTL-COGEHYHWbDfIw3b%2F-MTL42rwmpHHQZ012QnV%2Fzeroplayer07_smm2_banedarake.png?alt=media\&token=1c9cde88-762c-4bc0-80b5-318796e76d45)

Auto levels often rely heavily on the trampoline object, which can either push the player left / right or up / down. The most common way to begin the Auto level is to place a trampoline a few tiles above the player’s start position, so that when the trampoline falls due to gravity, it instantaneously propels the player to the right.&#x20;

The trampoline’s versatility leads many users to design trampoline-themed Auto-Mario courses, like in user So yo mogi’s (そよもぎ) course “Bane-darake no zenjidōmario ritānzu” (バネだらけの全自動マリオリターンズ) (“The Return of Auto Mario: Full of Springs”) where they use dozens of trampolines to create complex emergent behaviors, like cannons that shoot trampolines that bounce on other trampolines, with a perfectly timed trampoline that pushes Mario narrowly through the split-second gap between the dozen bouncing trampolines.&#x20;

This interest in complex simulations has culminated in Auto “RNG” (Random Number Generator) courses that players can complete only if a very rare randomly-generated object or interaction occurs, such as with user Phenotype’s course “Lucky Draw” which relies on a 1-in-7.5-million chance for a series of magikoopa enemies to all randomly conjure coins instead of any other object. As the course title suggests, Lucky Draw is basically a slot machine built with Mario blocks, and at this time of writing only 35 plays (of 18,000,000+ attempts around the world) have been successful. The only viable player strategy is to leave the Nintendo Switch console running the course constantly, overnight, as if it were mining for cryptocurrency or training a machine learning network. In this way, the Auto RNG completely negates the typical Mario player’s platforming skills in favor of exposing the game engine’s machinations.

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MTL-COGEHYHWbDfIw3b%2F-MTL4OliWlMIQk4JZR6r%2Fzeroplayer08_smm2_luckydraw.png?alt=media\&token=adcab054-669b-4b9d-8928-39f33d971ed2)

## Dancing about architecture

Unlike most levels which center the player’s performance, the zero player level’s very shape and geometry is the performance. That performance is a dance, a movement in space to a rhythm.&#x20;

Some Auto-Mario levels even double as “Music” tagged courses, which use special music note blocks that can sequentially activate to play a song. In Media Molecule’s game Little Big Planet, creators also used the in-game editor to create no-input “music levels” roller coaster rides with long walls of motion-activated music. Metanet Software’s indie platformer N also featured fan-made Don’t Do Anything (DDA) levels -- and Metanet’s advertising for the sequel N++ focused on photographs of dancers.&#x20;

Players, player-designers, and developers of these games all seem to relate this activity to music and dance. Which makes sense, because so much of zero player level design involves embodied intuition. Every TrackMania PF designer must reach a minimum fluency with TrackMania’s car physics and handling, for how else can they predict how a certain ramp will cause the car to turn at a certain rate and launch at a certain speed? The only way is through trial and error, practice, and patience. Every PF represents at least days of painstaking playtesting and repeated rehearsal -- if not weeks, months, or in the case of the PF Hyperion’s Wrath, two years of work.

![Figure 9, screenshot of "Mario's Trail" visualizing Mario's path and trajectory in the Super Mario Maker 2 course editor, from YouTube video "Hot Tips For Course Maker In Super Mario Maker 2" by user GameSpot uploaded Jun 28, 2019  https://www.youtube.com/watch?v=rX7-JANlWak](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MTL-COGEHYHWbDfIw3b%2F-MTL50MY-N_ge5Xmhn8I%2Fzeroplayer09_smm2_mariotrail.png?alt=media\&token=63bf5088-4013-422c-afeb-97ce3bfc5b96)

The Super Mario Maker course builder helpfully visualizes the player's jumps and trajectory, helping course creators fine-tune their object placement. This type of debug feature is surprisingly rare for most level editors; common first person shooter level design tools like Hammer or Radiant do not readily visualize dimensions or the player’s capabilities, and common industry level design practice places the onus on the level designer to memorize and measure the exact distances (or “metrics”) for how far the player can jump or move in the space.

The musician Martin Mull famously argued that "writing about music is like dancing about architecture." I argue that zero player level design is essentially a form of “dancing about architecture” because the game’s virtual architecture is performing and activating itself, channeled through the player-designer’s phenomenological experience of the game feel.&#x20;

In level design we often argue that we must learn more from architecture as a field. When industry practitioners invoke this refrain, they usually mean the formal rigor of architectural drafting and planning processes.&#x20;

However, level design already shares workflows and techniques with architectural visualization and CAD practices. The architecture we need in games is the architecture that understands itself as the intersection of social theory, economics, and art.&#x20;

Level design is more than just a 3D blockout for a AAA shooter franchise. Level design is also the history of design trends in TrackMania or Super Mario Maker; level design is how casual designers wield casual creator tools and understand themselves as artists; level design is the rich study of how we experience and inhabit spaces. So yes, let’s learn more from architecture. See you on the dance floor.<br>
