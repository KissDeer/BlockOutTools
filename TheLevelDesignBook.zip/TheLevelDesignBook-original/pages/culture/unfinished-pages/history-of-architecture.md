> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/culture/unfinished-pages/history-of-architecture.md).

# History of architecture

overview of 10,000+ years of building, construction, and civilization

The history of architecture is obviously very complicated and beyond the scope of this book. This page is just a minimal summary to help you guide your own research.

When studying historical architecture, the simplest question we can ask is: **why did they build it like that back then?** There's usually at least three explanations:

* **People:** society, culture, religion, warfare
* **Geography:** climate, water, food, resources, materials
* **Technology:** literacy, education, engineering, physics

{% hint style="info" %}
A lot of our info comes from the book ***"A Global History of Architecture"*****&#x20;by Francis D. K. Ching, Mark M. Jarzombek, and Vikramaditya Prakash.** It has much more detail and insight than this summary. We strongly recommend reading it.
{% endhint %}

Some things to keep in mind when we think about old buildings:

* **It used to be colorful.** Ancient peoples painted buildings just like we do today. A thousand years later, ruins look gray and bare today, but they didn't always look like that.
* **Ancient wood buildings have not survived.** But that doesn't mean they never existed.
* **History is biased towards fancy architecture, rather than common "vernacular architecture."** Yet game worlds often center on everyday homes and workplaces rather than monuments.&#x20;

## 3500 BCE

During the late "Stone Age" or Neolithic Period (10000 BCE - 2500 BCE), humans around the world began living in small tribal / clan settlements, usually near rivers and lakes.&#x20;

They built 1-floor single room homes on shallow foundations with stones, mud, wood, and/or thatch. Sometimes a moat / ditch surrounded the village for defense and drainage ([Banpo](https://en.wikipedia.org/wiki/Banpo)). Larger villages might've had granaries to store food ([Mehrgarh](https://en.wikipedia.org/wiki/Mehrgarh)), or focused on industrial specialization like mining ([Çatalhöyük](https://en.wikipedia.org/wiki/%C3%87atalh%C3%B6y%C3%BCk)). Most used some kind of pottery, but some were "aceramic" and relied on baskets ([Caral-Supe](https://en.wikipedia.org/wiki/Caral-Supe_civilization)). Religion was usually small and personal, like a household shrine or a small village temple to a mother goddess.

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FD8JWVLzQqDZSOZhZGZ10%2FLDB_GlobalHistoryOfArchitecture_Banpo.jpg?alt=media&amp;token=fb4e0da9-f7ba-46e6-a89c-2517ef38d9ac" alt=""><figcaption><p>(left) reconstructions of a mud-wood circular dwelling with firepit in center, (right) larger meeting hall from Banpo, China circa 4500 BCE; from A Global History of Architecture, 2nd edition</p></figcaption></figure>

In the few rare big cities that did exist (10,000-40,000 people), rulers and elites needed more complicated religions and bureaucracies to maintain control. They justified their authority with bigger and taller palaces, temples, and gates, made of more luxurious materials -- like kiln-fired brick and tile requires burning a lot of wood ([Uruk](https://en.wikipedia.org/wiki/Uruk)). But still, most settlements / regions were not unified under a single power -- instead they were fragmented, diverse, and egalitarian.

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FIdIWxBV3LENvAb7zmdCd%2FLDB_GlobalHistoryOfArchitecture_CatalHuyuk.jpg?alt=media&amp;token=cb80a711-a0f3-4ca5-979c-5c4314d39dba" alt=""><figcaption><p>(left) diagram of a housing pattern, (center) typical house made of mud brick + oak beams, and (right) typical household family shrine with bull horns set in clay; from Çatalhöyük, Turkey circa 3000 BCE; from A Global History of Architecture, 2nd edition</p></figcaption></figure>

## 2500 BCE

During the "Bronze Age" (3000 BCE - 1200 BCE), bigger settlements became more common. Ancient cities have evidence of urban elite -- bigger compounds with rarer materials and objects.

The [Indus Ghaggar-Hakra civilization](https://en.wikipedia.org/wiki/Indus_Valley_Civilisation) built big cities like [Mohenjo-Daro](https://en.wikipedia.org/wiki/Mohenjo-daro) with complex drainage systems built into large platforms of millions of bricks laid in an urban grid. Yet despite the complex organization and labor it would've required, the city layout is private and hierarchical, with little evidence of a central ruler or religious authority (like any other ancient city).

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F9om1PDb7O8qTqlY8OZ8N%2FLDB_MohenjoDaro_TheCambridgeWorldHistory.jpg?alt=media&amp;token=f9281a07-1d5c-4d92-8b5e-408e05b0e425" alt=""><figcaption><p>notice how most buildings rarely open onto streets, and instead face interior courtyards with limited public access points; from a partial reconstructed city plan of Mohenjo-Daro circa 2500 BCE, from The Cambridge World History (2015)</p></figcaption></figure>

In Mesopotamia, the [Ziggurat at Ur](https://en.wikipedia.org/wiki/Ziggurat_of_Ur) was an architectural milestone with monumental stairs and platforms assembled as abstract [massing](/process/blockout/massing.md) -- the temple evokes a unified vision and aesthetic, and it is possibly the first example of formal architecture in human history. Again, the sheer number of bricks implies a lot of resources, labor, and social organization.&#x20;

There were also other similarly monumental architecture milestones around the world at this time, in Egypt ([Pyramid of Djoser](https://en.wikipedia.org/wiki/Pyramid_of_Djoser)), Malta ([Ġgantija](https://en.wikipedia.org/wiki/%C4%A0gantija)), England ([Stonehenge](https://en.wikipedia.org/wiki/Stonehenge)), and Peru ([Pirámide Mayor](https://www.arqueologiadelperu.com.ar/caral_a.htm)). All these wonders served a religious / ritual center function. However we still don't know much about these places / societies.

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F2NOhWln7S5CCTLp7fcq4%2FLDB_ZigguratOfUr_PublicDomain.jpg?alt=media&amp;token=109fd346-39c2-4c88-bf54-075f8eab2b4a" alt=""><figcaption><p>(left) reconstructed drawing of Ziggurat at Ur, and (right) temple complex plan with ziggurat surrounded by walls, from A History of Architecture on the Comparative Method (1898) by Banister Fletcher, under public domain</p></figcaption></figure>

## 1500 BCE

The Ghaggar-Hakra River dried up, and unknown invaders overran Mesopotamia; other powers began developing around the Mediterranean.

The ruler Ramses I consolidated [Egyptian "New Kingdom"](https://en.wikipedia.org/wiki/New_Kingdom_of_Egypt) power and religion at [Karnak](https://en.wikipedia.org/wiki/Karnak), a city-temple complex along the Nile River. Temples followed a linear [critical path](/process/layout/criticalpath.md). Festival parades / "processions" entered temples through majestic [pylon gates](https://en.wikipedia.org/wiki/Pylon_\(architecture\)) engraved and painted with the pharaoh's great deeds, expressing both power and cosmology in an iconic trapezoidal shape. After passing through more pylons, courtyards, and chambers, the path forked to an innermost sanctum with a [Ka statue](https://en.wikipedia.org/wiki/Ka_statue) to absorb religious offerings. The [Temple at Abu Simbel](https://en.wikipedia.org/wiki/Abu_Simbel), the pinnacle of Egyptian rock temples, also features an inner sanctuary with a sacrificial altar, illuminated by the light of the rising sun at dawn.

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FAhq4lCHraZcVneMJ8tuk%2FLDB_TempleAtKarnak_BannisterFletcher.png?alt=media&amp;token=4175ba39-c98d-47bd-a107-c93b95ee8a62" alt=""><figcaption><p>note the sequence of pylons in this drawn reconstruction of <a href="https://en.wikipedia.org/wiki/Precinct_of_Amun-Re">Precinct of Amun-Re</a> ("Karnak Temple") circa 1500 BCE, from A History of Architecture on the Comparative Method (1898) by Banister Fletcher under public domain</p></figcaption></figure>

Egyptian columns were highly symbolic and inspired Greek and Roman designs. Lotus / papyrus pattern columns mark sacred spaces, giving form to creation myths about the earth holding up the sky -- the bundled reeds and plant motifs evoke the Nile River, its stability and permanence.&#x20;

As with much other ancient architecture, the stone columns would've been covered with stucco and painted with vivid colors, that have since decayed and faded with time.

(TODO: add note about windows)

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FighBVNue1likh2bGkDde%2FLDB_LuxorColumns_DiegoDelso_LOrnementPolychromeAlbertRacinet.jpg?alt=media&amp;token=f04e0770-9636-44bd-b1e6-0fe7e0f0f836" alt=""><figcaption><p>(left) photo of papryus-styled columns at Temple of Luxor <a href="https://commons.wikimedia.org/wiki/File:Templo_de_Luxor,_Luxor,_Egipto,_2022-04-01,_DD_23.jpg">by Diego Delso (CC-BY-SA)</a>; (right) scan of color painted Egyptian columns from L'Ornement Polychrome by Albert Racinet (1888) under public domain</p></figcaption></figure>

A Minoan priest-king ruled at the [Palace at Knossos](https://en.wikipedia.org/wiki/Knossos), a large multi-tiered complex surrounding a central north-south courtyard. This miniature city also had warehouses, temples, and residences with built-in ventilation and drainage. Stone walls were covered in mud / straw / plaster and painted with frescoes, and round tapered wooden columns were painted red with blue capitals. Like the Egyptians, the Minoans built a critical path entry sequence with specific views and symbols starting from the west porch, up a great stairway, and into a throne room.

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FRghmxweJ7NmGhuK5q2kR%2FLDB_Knossos_AlenaBuis.jpg?alt=media&amp;token=5363421b-4fe0-458a-842a-b2ff83d69dde" alt=""><figcaption><p>illustrated reconstruction of Palace at Knossos circa 1500 BCE, from A Global History of Architecture, 3rd edition</p></figcaption></figure>

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FirHGKKxCnfEoRNC6aIyq%2FLDB_GlobalHistoryOfArchitecture_Knossos.jpg?alt=media&amp;token=0469a8a2-c575-403e-a5ba-229530e37173" alt=""><figcaption><p>(left) diagram of entry sequence from west porch to state rooms; (right) photo of a reconstructed "Grand Staircase" at Knossos; images from A Global History of Architecture, 2nd edition</p></figcaption></figure>

## 800 BCE

Olmec, La Venta, Chavin de Huantar, Teopantecuanitlan

Zhou Dynasty China, Ritual Complex at Fengchu / Wangcheng

Babylon, Ishtar Gate

## 400 BCE

Classical Greece, Doric order transition from wood to stone inspired by Egypt... Temple of Apollo / temenos at Delphi... Ionic order is parallel, not after... Acropolis at Athens

Great Stupa at Sanchi

Temple of Horus, Xianyang Palace

## 0 CE

Rome... adapt greek forms, concrete, Vitruvius... Roman Urban Villa at Pompeii, Palace of Domitian at Palatine Hill, The Colosseum

Qin / Han Dynasty China

Teotihuacan
