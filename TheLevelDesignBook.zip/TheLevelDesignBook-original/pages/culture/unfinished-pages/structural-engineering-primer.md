> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/culture/unfinished-pages/structural-engineering-primer.md).

# Structural engineering primer

TODO: summarize some bits from Why Buildings Stand Up

Game example: <https://tf2maps.net/threads/guide-a-primer-on-basic-structures.38329/>
