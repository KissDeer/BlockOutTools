> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/culture/unfinished-pages/history-of-environment-art.md).

# History of environment art

(unfinished stub)

Early 20th century modernist architects debated: what is the soul of a building?

The architect Louis Sullivan famously argued in an article "The Tall Office Building Artistically Considered" (1896) that a boxy featureless industrial office building had its own beauty that was timeless and universal -- that *"form follows function."*&#x20;

So this is one (outdated) way to understand environment art: extra details and ornament, form *WITHOUT* function.

&#x20;    *For more on modernist architects being wrong, see* [*History of architecture*](broken://pages/-MLooZAdq0kjd2pikSeL)*.*

(TODO: compare art nouveau vs. modernist architecture image)

More directly, env art has roots in two crafts: model miniatures and film set construction.

People used to play with physical doll houses, model trains, and Warhammer battles. You had to assemble and paint the pieces yourself, but that construction and customization was part of the fun. It must be beautiful, but it must also be usable for play.

The film industry used to build physical film sets / FX with matte paintings and prop design. Some env art terminology (like "hero prop") even comes from the film industry. Many artists have worked in both film and games, and these industries / traditions converge more every day.

(TODO: train miniatures, film set miniatures, etc.)
