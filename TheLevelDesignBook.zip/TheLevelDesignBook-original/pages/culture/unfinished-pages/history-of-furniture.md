> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/culture/unfinished-pages/history-of-furniture.md).

# History of furniture

## Understanding furniture

Most furniture has at least one of four functions: (1) sitting, (2) tabling (work, display), (3) storing, (4) sleeping. But function is just one way to think about furniture. Furniture and its placement also reflects social status, wealth, culture, technology, climate, and personal expression. When we craft and place virtual furniture in our levels, it reflects all these understandings.

In level design, furniture is certainly crucial for environmental storytelling narratives and set dressing in an art pass, but it also implies a formal gameplay function. If you're playing a contemporary cover shooter and you see an antique wooden chair, then you would understand it as movable soft cover. If you're playing a game with crafting and salvage systems, you might break down the chair for a small amount of wood. If you're playing a battle royale or prop hunt multiplayer game, then a misplaced chair would suggest someone has visited that location. Furniture is part of the game state!

Two brief disclaimers:

1. This history is biased toward a Western understanding of furniture, and as with most material histories, it's also biased toward rich people because their objects get preserved and studied.&#x20;
2. We approach furniture from the needs of a level designer. This page is less about the specific history, and more about how to furnish your level effectively, organized by historical time period and culture.

{% hint style="info" %}
**This page is still unfinished**, it has my incomplete writing notes and summary.
{% endhint %}

## Prehistoric furniture (6000 BC - 3000 BC)

Neolithic artifacts depict people sitting, like the [Seated Woman of Çatalhöyük](https://en.wikipedia.org/wiki/Seated_Woman_of_%C3%87atalh%C3%B6y%C3%BCk).&#x20;

.

## Ancient furniture (3000 BC - CE 600)

It's hard to know a lot about ancient furniture because most wood pieces have decayed / disappeared. Our knowledge of ancient furniture comes from historical accounts, carvings / paintings, and rare preserved pieces from volcanic disaster sites and tombs.&#x20;

### Ancient seating

The most common piece of furniture around the ancient Mediterranean was a wooden stool with low rectangular seat and 4 legs. Common Egyptian stools had woven reed seats, and a Greek diphros often had turned (rounded) legs.

Public places had built-in stone benches, or people would bring their own X-shaped folding stools.&#x20;

Chairs were generally reserved for upper class or the elite. Greek thrones, klismos, and klinai had elegant sweeping lines. Egyptian chairs were more angular but still very refined and clean, more advanced than a lot of medieval European furniture.

### Ancient tables

Built-in stone counters and tables were common. Greek tables were low, rectangular tops with 3 legs, usually next to a klinai for upper class dining.

Ancient containers

Ancient Egyptian furniture: didn't change much for thousands of years, but pharoahs furniture have very fine wood working, better technicals than most medieval furniture... very clean lines and shapes, almost modernist

Common ancient Greco-Roman furniture: mostly built-in benches, stools, and counters... if you did have a table, it was low and movable to stow away when you weren't using it

Rich Greco-Roman people had couches and X-shaped folding stools (imported from Egypt?) (Roman politicians)

Greco-Roman chairs symbolized power: thrones

Chairs and stools were somewhat rare in Asia and the Americas: common to sit on the floor or on a mat

## Medieval furniture (600-1500)

### Medieval Europe

rich people were basically nomadic, would move around a lot (easier to follow food than to bring food to a centralized place) so they used lots of chests, small movable furniture, and tapestries / cloths decorate the permanent furniture they'd leave in place... then pack everything up and move on to the next residence

Since rich people signaled wealth through possessions, high emphasis on sturdy chests + tiered buffets to display fancy silks, plates, and artifacts. Dye is very fancy!

Chairs still aren't super common. Throne with foot stool, raised on dais. Height is very important. Commoner can sit on a chair by themselves, but in the presence of a monarch they must sit on benches and stools, if at all. Benches are the most common seating

Rooms are mostly empty, furniture pushed to the side when not in use... Tables were brought out and setup for events / dinner, then stowed away... again, remember the furniture is purely functional, the tablecloth is the actual decorative element

Tables are long, everyone sits on one side with their backs to the wall... powerful couples sit in the middle

The one big exception is churches, which weren't nomadic, so they could have huge elaborate carvings with big heavy furniture

This is where furniture and architecture intersect; furniture carved like a building

Tools were hung on walls, free-standing wood shelves were rare (!), usually wood planks set into a wall cavity instead

## Renaissance furniture (1500-1600)

Printing press made Renaissance / study of antiquity possible... equipped with manuals, Renaissance artists make better Classical copies than Medieval artisans

Rich people are finding enough stability to settle down and permanently decorate, e.g. Venice ...&#x20;

Furniture craftsmanship now becoming complex enough to form specific guilds, e.g. joiners ... 1500s sees upholstery, drawers, and matching furniture to interiors... Queen Elizabeth orders marble-topped tables

Tables are broader and less long, everyone sits on both sides, important couple sits at the ends of the table

Carved buffet

In Spain, leather is more common than wood? (Moorish influence treats wood as a rare decorative material vs. structural material)

## Early modern furniture (1600-1800)

in Europe: rise of English and French furniture export industries, English furniture was boring but high quality, French furniture was trendy and luxuriously expensive but lower craftsmanship

in England: Lots of trade, lots of interest in India (caning seats) and China (lacquering)...  "the Chinese fashion" in 1700s... Lacquered chest on a stand... rise of ebony... large mirror (very expensive) with marble-topped side table and china displayed on top. "Japanning" is English imitation of Chinese lacquer

in France: Rise of upholstery, comfort, modern ideas of luxury (Versailles) ... Rich people bedrooms were social spaces where you receive guests (pg 84), but also now separation of public and private (e.g. petit-apartments in Versailles vs public courtly rooms), invention of the dining room

Renaissance humanism: understanding, classifying, collecting diverse materials and styles of the world... even more specialization of craft (pg. 99) ... Pinnacle of carved furniture and veneered cabinets ... rococo

## Early industrial furniture (1800-1900)

English Regency, Greek revival, French Empire (Napoleon)

in England: neo-classical counter-reaction, Invention of the classic "timeless" chair, country joiners repeated the same chair and table over and over (e.g. American Shaker ladder back, stick-back Windsor) ... Rise of middle class, good furniture becoming more common

In the US: rocking chairs offered to guests

Sprung upholstery, Chesterfield couches, new focus on comfort and coziness... birth of furniture placement and filling a room with furniture (pg 133)

Thonet bentwood chair!!!

## Modern furniture (1900-1950)

## Contemporary furniture (1950+)

## Sources

Lucie-Smith, Edward. *Furniture: A Concise History.* Thames and Hudson: 2005.

<https://en.wikipedia.org/wiki/Chinese_furniture>
