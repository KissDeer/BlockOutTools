> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/culture/unfinished-pages/history-encounter-design.md).

# History of encounter design

## Introduction

The history of [encounter design](/process/combat/encounter.md) has been barely documented because, well, encounter design itself has also been barely documented. Much of this knowledge was shared informally in hallways, around water coolers, and over internet forums -- this "field" hasn't really been formalized as "knowledge" (like in a book or a talk) until recently.

This page is our attempt at piecing together where encounter design came from, and how combat design trends have changed over the years.

{% hint style="info" %}
This is a History article. For more on encounter design itself, see [Encounters](/process/combat/encounter.md#encounter).
{% endhint %}

## Monster placement era (1993-1998)

### Doom (1993)

Early first person shooter design inherited a lot of sensibilities from Doom. In turn, Doom inherited a lot of sensibilities from an arcade design tradition of top-down 2D shooters like Robotron, Berzerk, and Tempest. In fact, it's possible to play Doom entirely from its 2D top-down "automap" view.&#x20;

![comparison of Bezerk (1980) and the top-down automap in Doom (1993) with the player in the middle and monsters as triangles](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M09qV1b3h57zyQ_rv0R%2F-M0AuEjlbX3Gw0E8wlAQ%2Fberzerk_doom_topdown_compare.jpg?alt=media\&token=22427266-8da2-4c4e-9939-99f6954567a7)

The key tenet of this era of combat design is "maneuverability as defense":

> *"... because the player moves so quickly in Doom, and because most enemy attacks are dodgeable, the player can avoid a significant amount of damage simply by moving. A skilled player can often deal with large numbers of enemies sustaining hardly a scratch. This creates a feeling that’s quite rare in modern FPS: that you are powerful because you are agile, not because you’re a tank. This frees up Doom’s encounters to feature huge numbers of enemies, to vary scenarios by mixing in different proportions of threats, and to have huge, sprawling, often non-linear spaces that the player can traverse easily."*
>
> \-- from ["Coelacanth: Lessons from Doom"](http://vectorpoem.com/news/?p=74) by Vector Poem

In Doom, all the enemies were called monsters -- so the art of placing monsters was called monster placement.&#x20;

high enemy counts across large maps... getting lost is relatively common and part of the game

fire and forget, arcade style... monsters have short predictable repetitive behavior loops... use several monster types, not just one

Monsters as guidance, e.g. chase monsters to find the exit

Monsters as map control, e.g. don't kill monsters right away, ration ammo, use monsters to infight vs other monsters

#### Further reading about encounter design in Doom

* ["The Roots of Doom Mapping: An Evolution of Level Design Through the Most Influential WADs Ever Made"](https://www.doomworld.com/25years/the-roots-of-doom-mapping/) by Not Jabba
* [Doomworld Forums > Editing Tutorials: "Monster Placement"](https://www.doomworld.com/forum/topic/73964-essayarticle-monster-placement/) by Grymmoire and Ghastly
* ["Coelacanth: Lessons from Doom"](http://vectorpoem.com/news/?p=74) by Vector Poem

### Quake (1996)

Quake continued much of Doom's ethos: constant movement across large maps, with defensive maneuverability against high enemy counts.

more control over monsters: leashing with height changes

spatial awareness is different in "true 3d" vs doom

TODO: ask Soc for diagrams?

<https://twitter.com/SimsOCallaghan/status/1164996907929952268>

<https://twitter.com/SimsOCallaghan/status/1012039880841617408>

<https://twitter.com/Mclogenog/status/1228714057840177153><br>

### Half-Life 1 (1998)

The monster placement era reached its apex in Half-Life 1 (1998), where its human soldier "grunt" AI gave a powerful illusion of squad coordination and group tactics though extensive use of animations and contextual audio barks.&#x20;

Marketing materials exaggerated Half-Life's use of sensory models ("the bullsquids can smell you!!") to sell an aura of realism. Monsters were no longer arcade obstacles, but living breathing creatures with psychology and interiority. ("What if you could talk to the monsters?")

Realism means a shift from "monsters" to "AI" and "NPCs", who now need a wider range of behaviors that "outsmart" players -- a tech-fetishizing marketing point that doesn't die, and arguably, taints combat design in first person shooters forever.

Half-Life marks the end of the monster placement era. It's the last historically influential shooter to refer to its NPCs as monsters, a remnant of Half-Life's foundation in Quake engine tech and approach of game design.

## Early encounter design (1998-2008)

Early encounter design was the game industry's attempt to begin systematizing concepts of territory and knowledge model. Hand-designed patrol routes mark a big departure from the "fire and forget" approach of monster placement.

It often involved active and laborious markup of the level, and dividing the map area into various territories and zones. We begin choreographing specific enemy movements during the battle itself, instead of simply spawning an enemy and hoping for the best.

At this point, games began devoting more engineering and processing resources to enemy AI. Developers began viewing combat AI as a separate object to design in a tool (e.g. behavior trees in a visual editor) rather than a hard-coded system embedded with the rest of the game code.  Compare Half-Life 1's C++ soldier AI code from 1998, versus a visually-authored behavior tree in \_\_\_\_\_.

This period also marks the first time that industry developers begin using the term "encounter."

### Thief: The Dark Project (1998)

#### **"Level Building for Stealth Gameplay" by Randy Smith (GDC 2006)** [**\[PDF\]**](https://www.dropbox.com/s/2klwztr4cx09d2b/Smith_LevelBuildingForStealthGameplay_GDC2006.pdf?dl=0)

An introduction to thinking about guard placement and patrols for stealth games by Randy Smith, a veteran of Looking Glass / Arkane Studios immersive sim level design. Even though it's not directly about combat, this talk is still essential for encounter design theory because it codifies a lot thinking about affordances, soft cover vs hard cover, sightlines, and blind corners, etc. This is just a strong talk in general, where Smith deconstructs a lot of examples and room diagrams.

![](https://1.bp.blogspot.com/-kIpY9uFAWuY/XbSLiEZYxVI/AAAAAAAAHP8/f_jWm0Wiq8s3FaWALb1ljqQZhRVXFvpCgCLcBGAsYHQ/s640/gdc2008_smith_challengelevel.png)

Guards maintain "territory" based on their visibility and positioning. Soft cover provides "fuzzy" situational cover within that territory, while hard cover is more reliable and static. It might seem like a lot of this talk doesn't apply to contemporary level design, since Smith's examples focus on a Thief-like game with light and shadow stealth mechanics (e.g. hide in the shadows to remain undetected by guards) and Splinter Cell and Dishonored types of [AAA immersive sims have arguably died](https://www.blog.radiator.debacle.us/2017/10/the-second-death-of-immersive-sim-2007.html). No one uses shadow-based stealth gameplay anymore!

![](https://1.bp.blogspot.com/-7ewmqF-D8dc/XbSLmDZbO6I/AAAAAAAAHQA/8VE6nMmcY_M64DditbVT5i-hUcBalXn_wCLcBGAsYHQ/s640/gdc2008_smith_path-plus-territory.png)

However, in contemporary stealth action franchises like Assassin's Creed, Uncharted, Metal Gear Solid, or Hitman 201x, soft cover still exists. They've just replaced shadow pools with tall grass clumps, which provide more readable and more discrete stealth zones than shadows ever could, while also showing-off wavy grass shaders and freeing up AAA lighting artists to do fancy stuff without worrying about the gameplay implications of their shadow patterns. The only difference is that shadows are truly systemic and intrinsic to any environment, while the omnipresence of convenient grass clumps everywhere certainly strains a game's plausibility in hilarious ways. (Suddenly every video game warehouse and military base is now set in the middle of a savannah or tallgrass prairie.)

So when Smith marks up these diagrams with shadows, just imagine he's actually talking about grass, or ponds where you hide underwater, or magical elf fog, or whatever soft cover contrivance of the week that we've embraced as an industry.

![](https://1.bp.blogspot.com/-6y6qF3kElAI/XbSMA7AssYI/AAAAAAAAHQM/XtUYv5EvuyMFP-lqE5pvOazN-3xEoAXQgCLcBGAsYHQ/s640/gdc2006_smith_open-endedness.png)

There's one crucial disclaimer at the start of Smith's talk: this is not a talk about design process. He notes that they didn't actually follow these design methods for building Thief missions. That is, they did not sketch out ideas for encounters and markup player routes, nor did they build meticulous diagrams to plan guard patrols and pools of shadow.

Instead, most of the time, they just grayboxed a space and placed some guards in an intuitive subconscious way, and playtested until it felt good. This type of thinking is most useful as a playtest analysis tool to recognize what is happening, and it should be applied loosely from the bottom-up. Don't do this in a top-down design planning way.

For an in-depth analysis of a stealth encounter case study from an actual game, see [my post about the Thief 1 level Assassins](https://www.blog.radiator.debacle.us/2012/07/thief-1s-assassins-and-environmental.html).

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lth0afU96M58vlAJt4w%2F-Lth1_yBKNjZIIaiS3oW%2Fimage.png?alt=media\&token=cd80fa7f-8435-4741-9945-fa4c7e0aafaf)

### **Halo (2001)**

#### **"The Illusion of Intelligence: The Integration of AI and Level Design in Halo" by Chris Butcher and Jaime Griesemer (GDC 2002)** [**\[PDF\]**](https://www.dropbox.com/s/nkffbyzjytpsgs8/bungie_illusionOfIntelligence_Halo1.pdf?dl=0)

Halo (2001) is probably the canonical example of large-scale PvE dynamic battle design, and this talk establishes a lot of crucial first principles. Broadly, it's about how good encounter design requires solid enemy design, and by solid enemy design, they mean:

* enemies that broadcast their state via character animations and audio barks to the player (e.g. a Grunt will scream and flee with its arms raised)
* enemies with clear predictable abilities and affordances, with differing task priorities (e.g. a Jackal will use its shield to slowly push an advance, while an Elite will seek cover)
* enemies with limited perception and memory; the player should be able to trick enemies, and notice from animation / audio that they have tricked the enemy

So the player perception of good game AI (game AI designed to lose gracefully, not machine learning AI) relies on artists and designers as much as programmers. Every modern and contemporary shooter has followed these principles, and now they feel like common sense. I argue that common sense is bullshit, and this stuff didn't used to be common sense, as seen through this talk where Bungie had to articulate and invent all this supposed common sense.

<div align="center"><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lth0afU96M58vlAJt4w%2F-Lth1McY2-vhwULdMlAY%2Fimage.png?alt=media&amp;token=d0a9d841-7bc3-4360-bd3f-45ba341c9da6" alt=""></div>

Despite this talk's importance to encounter design history, this is mostly a game design and AI talk. Yes, I know it has "level design" in the title, but if you actually read through it, there's only a few slides that touch on level design. It doesn't really talk much about actual enemy scripting, placement, or architecture. There's just a couple slides about how the Halo 1 level designers had to markup territory, fortification, battle lines, retreat lines, and firing points, but no concrete case studies / examples of the level markup or hinting.

Which is a huge shame, but to me it also demonstrates why there is no solid body of theory about encounter design. Even the originators of modern encounter design didn't think it was a level design problem! Instead, Bungie seemed to regard encounter design as primarily a game designer or AI programmer problem. This is clearly more in the "combat designer" school of thought.

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Ltl6WEWlIdpFwv9uPHR%2F-Ltl7Fdr1JyF2Yg7i2O_%2Fgdc2002_halo1_tougher-smarter.png?alt=media\&token=832ee172-910a-4e79-b91a-f0b83c51e393)

Many game designers remember this talk for this single design note on a single slide: **to make an enemy seem smarter, just give it more health**. An enemy with more health will survive longer, which helps it build more of a relationship with the player and do more stuff, which means the enemy will seem smarter.

This observation has lead to the emergence of "bullet sponge" enemies who possess large pools of health but little variation in behavior or tactics. But we can trace that back to this idea of high-health enemies to Halo 1, where survivability was meant to contribute to the player's power fantasy and prompt more diverse player tactics and situations. Perhaps when players complain about bullet sponges, they are also partly complaining about the encounter design; if bullet sponges did more, then they would cease to feel like bullet sponges.

![](https://1.bp.blogspot.com/-wsT4FgfVFH4/XbSR5YIRGKI/AAAAAAAAHQc/VBOJEUKx72Y4vzTeemn6Jy1bbesMNjqBQCLcBGAsYHQ/s640/gdc2008_halo3_canonical-encounter.png)

#### **"Building a Better Battle: The Halo 3 AI Objectives System" by Damian Isla (GDC 2008)** [**\[PDF\]**](https://www.dropbox.com/s/ngdll0gxt161p7j/bungie_buildingABetterBattle_Halo3.pdf?dl=0)

This is another Halo encounter design talk that doesn't actually talk about level design, and caters more to AI programmers and tools developers. Still, this is one of the earliest developer talks that touches on ideas of territories, phases (front, fallback, last stand), battle lines, and behavior trees (imperative) vs objectives (declarative) AI scripting models... all of this stuff forms the basis of contemporary industrial encounter design today.

All the terminology hints at consistent design language used inside Bungie itself. But we don't really have any deeper design insight unless the Bungie level designers ever give a talk! Oh well.

### Gears of War (2006)

popularizes the cover shooter

{% embed url="<https://www.gamasutra.com/blogs/ZiPeters/20150821/251625/The_Art_of_War_Gears_of_War__Knock_Knock.php>" %}

{% embed url="<https://www.gdcvault.com/play/1014376/Creating-Satisfying-Combat-Experiences-at>" %}

### Hitman: Blood Money (2006)

The apex of the first wave of Hitman games. Everything is still hand designed, but it has formalized concepts of public / private territory

#### Mette's Hitman level design talk from GDC?

## Dynamic encounter design (2007-present)

Modern encounter design is marked by an attempt to manage NPCs more systemically. Instead of handmade patrol paths, NPCs wander around automatically as a result of AI routines; instead of manual enemy placement

the use of ecosystem metaphors, coordinators, directors, and conductors. All of these AI manager systems direct NPCs to fulfill different roles during a battle.

### Bioshock (2007)

ecosystem conceit, player chooses when to engage a big daddy, encounter as a systemic player-initiated interaction

### S.T.A.L.K.E.R: Shadow of Chernobyl (2007)

A-life system, expands bioshock ecosystem ideas

### Far Cry 2 (2008)

dynamic buddy system, open world battles, stalker but more polished

### Left 4 Dead (2008)

#### **"Level Design Workshop Fundamentals: Pacing" by Matt Scott (GDC China 2012 / 2014)** [**\[PDF\]**](https://www.dropbox.com/s/t5gfess5v2bj74z/gdc2014_leveldesign_pacing_matt-scott.pdf?dl=0)

Here, an ex-Valve level designer does a case study of The White Forest Inn battle in Half-Life 2: Episode Two and details the Valve approach to pacing, which imagines gameplay as a graph of rising / falling intensities. This is less about the specifics of combat design and battles, and more about interspersing puzzle sections / story cutscene sections / quieter beats throughout the game to ensure richer variation.

So to use this methodology: separate your game into different gameplay beats, make sure you vary the different types of gameplay beats, and ensure smooth transitions between these various beats to achieve certain effects. For example, the White Forest battle begins with a quiet puzzle solving beat that turns into a giant loud ambush.

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Ltl6WEWlIdpFwv9uPHR%2F-Ltl7Uo8sYvll_0cYTjA%2Fgdc2014_valve_pacing-graph.png?alt=media\&token=65facf01-0612-4bcf-8464-899fff7cec90)

This "intensity graph" approach to encounter pacing is a common design strategy for planning overall encounter arcs in action level design. But again, this is less about designing the encounters themselves, and more about how to choreograph a series of encounters.

(TODO: include Left 4 Dead slides)

#### **"Creating Conflict: Combat Design for AAA Action Games" by Michael Barclay, Sam Howels, Pete Ellis (GDC Europe 2016)** [**\[PDF\]**](https://www.dropbox.com/s/zo7uye6nl2ji84s/gdc2016_Ellis_Peter_CreatingConflictCombat.pdf?dl=0)

This is probably one of the best basic combat encounter design talks in the industry so far.

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LtX1qT9uxspZe0aRBgD%2F-LtX9S_JeZqVlz5xv8rG%2Fgdc2016_combat_fronts.png?alt=media\&token=0079286c-7ad9-4d5c-a142-fc13d2a47fb5)

[![](https://1.bp.blogspot.com/-hjv24En0zNE/XbSjss129bI/AAAAAAAAHRA/JqAJXro5pcgKqD7zaiCfvR5I7IYZc-GvgCLcBGAsYHQ/s200/gdc2016_combat_wrestling.png)](https://1.bp.blogspot.com/-hjv24En0zNE/XbSjss129bI/AAAAAAAAHRA/JqAJXro5pcgKqD7zaiCfvR5I7IYZc-GvgCLcBGAsYHQ/s1600/gdc2016_combat_wrestling.png)

It starts with a discussion of "combat story", where the designer plots the conflict over time. Does the encounter start with an idea of impossible odds, or does it start from a position of safety that gradually escalates into danger, etc? The speakers borrow design strategies from pro wrestling choreography, likening concepts like "babyface" and "heel turn" to plotting the arc of your encounter. Think about how the balance of power shifts in martial arts movies like Police Story, and that's the model for you to plot your combat beats.

[![](https://1.bp.blogspot.com/-zQnlpQtb2s0/XbSjwtK8n6I/AAAAAAAAHRE/OB4wLcp67lI3kllvQ_CrC1HPFTsOJGmRACLcBGAsYHQ/s640/gdc2016_combat_enemy-graph.png)](https://1.bp.blogspot.com/-zQnlpQtb2s0/XbSjwtK8n6I/AAAAAAAAHRE/OB4wLcp67lI3kllvQ_CrC1HPFTsOJGmRACLcBGAsYHQ/s1600/gdc2016_combat_enemy-graph.png)

To implement those different beats, you manipulate the enemy's positioning and tactical possibilities. How much room does the enemy have to move or to flank? Does the "no man's land" help the enemies break line of sight? Is the enemy spawn protected or vulnerable? All these different affordances and factors, along with the mix of enemy types and composition, help you pace the difficulty of the battle.

Overall, this is just a strong primer to ideas of line of sight, elevation, low cover vs high cover, and general combat arena design for shooter games. But for me, the larger takeaway here is the talk's use of military terminology. [Enfilade / defilade](https://en.wikipedia.org/wiki/Enfilade_and_defilade) are just fancy French words for flanking, but when we connect it to a real world historical study of flanking, then maybe encounter designers can advance their craft and share more of a common language.

#### **"Authored vs. Systemic: Finding a Balance for Combat AI in Uncharted 4" by Matthew Gallant (GDC 2017)** [**\[PDF\]**](https://www.gdcvault.com/play/1024467/Authored-vs-Systemic-Finding-a)

Here's a more recent talk about Uncharted's encounter design tools, and it's probably the best intermediate-level encounter design talk about contemporary AAA encounter design today.

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LtXHu5gZNt05cbv1he5%2F-LtXJhy5lA9utEEjAyMr%2Fgdc2017_uncharted4_encounter-coordinator.png?alt=media\&token=4d2dffe6-dcfd-412d-8134-c550b8d0627a)

Yet again, this talk is aimed more at the AI and tools programmers who would be building these behaviors, and it's less for the level designers and scripters blocking out the combat arenas. It's the same problem that encounter design has had since 2002: every game has its own set of enemies, tools, and terminology for building encounters. It's difficult to reason generically about "best practices for battles" since every game has different goals for its battles.

Still, we can try to extract some useful general concepts about encounter design workflow:

* Battle lines will constantly shift as the player moves around. For large non-linear arenas it's best to let an "encounter coordinator" AI director dynamically figure out the battle lines and assign NPC roles, instead of trying to pre-place or pre-script too much about the battle.
* Break your combat arenas into high-level "hard points" / "zones" to anchor different Pac-man style NPC roles ("engagers" rush towards player, "ambushers" hide in a zone near the player, "defenders" stay in high value zones)

![a "hard point" debug diagram from Uncharted 4 ](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Ltl6WEWlIdpFwv9uPHR%2F-Ltl7wjEBLKUvpTtTi4C%2Fimage.png?alt=media\&token=37559c66-5e36-4cec-ac46-feec27e12160)

* For dynamic stealth encounters, level designers can place short patrol path loops that feel human (smooth line of motion, centralized around a location or zone) and then the encounter coordinator AI can dispatch NPCs to these pre-built patrol paths.
* Generate more granular hint nodes / "posts" during navmesh generation, but don't try to procedurally generate too much. Connectivity graphs and heatmap searches seemed like good ideas early in Uncharted 4 development, but to playtesters, these systems just felt like AI blackboxes without any predictable human tendencies.

## Return to nostalgia

Reaction against military realism and cover shooters, nostalgia for monster placement era

Push Forward Combat in Doom 2016

{% embed url="<https://www.gamasutra.com/blogs/TommyThompson/20180806/323715/Cyber_Demons__The_AI_of_DOOM_2016.php>" %}

Prodeus?
