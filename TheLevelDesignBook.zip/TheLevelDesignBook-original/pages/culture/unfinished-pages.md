> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/culture/unfinished-pages.md).

# (unfinished pages)

- [History of architecture](https://book.leveldesignbook.com/culture/unfinished-pages/history-of-architecture.md): overview of 10,000+ years of building, construction, and civilization
- [Structural engineering primer](https://book.leveldesignbook.com/culture/unfinished-pages/structural-engineering-primer.md)
- [History of environment art](https://book.leveldesignbook.com/culture/unfinished-pages/history-of-environment-art.md): (unfinished stub)
- [History of furniture](https://book.leveldesignbook.com/culture/unfinished-pages/history-of-furniture.md)
- [History of encounter design](https://book.leveldesignbook.com/culture/unfinished-pages/history-encounter-design.md)
