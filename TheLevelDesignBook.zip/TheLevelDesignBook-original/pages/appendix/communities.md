> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/appendix/communities.md).

# Communities

links to level design communities, websites, discords, podcasts, blogs, social media

## Find a level design community

There are many benefits to joining a level design **community**:

* help with design problems / troubleshooting tools
* provide critical feedback for your work
* motivation and encouragement

## **Ideally, join a game-specific community**&#x20;

A game specific community can offer focused help / experience, and they are much more likely to playtest your work and give good feedback.&#x20;

&#x20;    ***For game-specific level design communities, see the "Community" column in*** [***Tools***](/appendix/tools.md)***.***

![look at all these happy people sharing the same space; this too could be you if you join a level design community](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F0jlJ1bGNKOgV4yDoypPK%2FLDB_Community.jpg?alt=media\&token=48726915-02fa-4790-93ac-0ebd140330ea)

## G**eneralist level design communities**

* [**#blocktober**](https://www.gamasutra.com/view/news/306933/Devs_celebrate_the_art_of_level_design_with_Blocktober_hashtag.php) is an annual internet tradition where level designers post [blockout](/process/blockout.md) screenshots on Twitter during the month of October. The most popular tweets usually come from AAA industry level designers posting blockouts of their work from famous commercial games.
* [**MapCore**](https://mapcore.org) is one of the longest running active message boards for level design, and focuses mainly on Source Engine games (CS:GO, Team Fortress 2) but many members also regularly mod other games and use Unity and Unreal. Mix of modders and industry users.
* [**The Design Den**](https://discord.gg/tAaDrRy) is a Discord community for level designers founded by Ryan Smith.

## Environment art communities

* [**Polycount**](https://polycount.com) is best for 3D environment artists, lighting artists, and anyone concerned more with the visual side of level design. Projects skew heavily towards Unreal Engine 4 scenes with Maya / Max / ZBrush / Blender know-how. No one here will ever playtest your project, but they will happily critique screenshots or video. Mix of students and industry users.
* [**80 Level**](https://80.lv/) features news, articles, and guides for game / film / VFX artists. It is often very technical and tool focused, usually focusing on pipeline and workflow with visual-oriented breakdowns of particular scenes or projects.
* [**Beyond Extent**](https://www.beyondextent.com/) features interviews with environment artists, articles and guides, as well as a podcast. Like other CG art communities, it focuses on tools and techniques.

## Theory, writing, criticism

### Venues / publications

* [**GDC Level Design Summit**](https://www.gdconf.com/tutorial/game-level-design) (formerly Level Design Workshop, Level Design In A Day) is a full day of talks from industry and indie level designers every year. After many years it has found a medium-sized audience at GDC. Unfortunately there's no convenient list of past sessions, but maybe we'll put that together someday. \
  &#x20;    *Open submissions every summer / autumn.*
* [**Heterotopias**](http://www.heterotopiaszine.com/) is probably the premier level design criticism publication at the moment, featuring short blog posts as well as long-form features and interviews. \
  &#x20;    *Commissions and pitches year-round, pays writers.*
* [**Rock Paper Shotgun**](https://www.rockpapershotgun.com/) has hosted several design-focused series, such as [What Works and Why](https://www.rockpapershotgun.com/tag/what-works-and-why/) (game design breakdowns), [The Mechanic](https://www.rockpapershotgun.com/tag/the-mechanic/) (more game design breakdowns) and [Level With Me](https://www.rockpapershotgun.com/tag/level-with-me/) (interviews with level designers). \
  &#x20;    *Commissions and pitches year-round, pays writers.*&#x20;

![GDC is the main venue for industry level design knowledge; video still from GDC 2015 "Transitioning from Linear to Open World Design with Sunset Overdrive" by Liz England (Insomniac Games)](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F8ZkAQQ4WjR9sG8e5QLbW%2FLDB_GDC_LevelDesignWorkshop_LizEngland.jpg?alt=media\&token=05812549-5413-434d-a99d-5751f3e39da6)

### Blogs / streams / podcasts

* [**The Architectural Imagination**](https://www.edx.org/course/the-architectural-imagination) is a free Harvard-branded online course about architectural theory and history that runs every year, popular among industry level designers for its conceptual focus.
* [**Steve Lee**](https://www.youtube.com/channel/UCRT_DdZnWiUryqrOhLL7gyw) makes videos about his experience as AAA level designer and gives advice for level design portfolios and resources.
* [**Iuliu-Cosmin Oniscu**](https://iuliu-cosmin-oniscu.medium.com/) writes posts about open world AAA production and encounter systems, usually with a Ubisoft-like approach.
* [**Andrew Yoder**](https://andrewyoderdesign.blog/) blogs about encounter design and multiplayer level design. He also uploads occasional level design video commentaries on [his YouTube channel](https://www.youtube.com/user/Mclogenog).
* [**JP LeBreton**](http://vectorpoem.com/) streams [WAD Wednesdays](https://www.youtube.com/playlist?list=PLhYCywHJcxok7r4eHnUf2UELsXfhhSrBp), playing a few randomly chosen Doom levels each week.
* [**Level Design Podcast**](https://anchor.fm/leveldesign) is a podcast hosted by Mark Drew, Jonathan Wilson, Valentina Chrysostomou, and Rob McLachlan.&#x20;
* [**Level Design Lobby**](https://leveldesignlobby.libsyn.com/) is a podcast hosted by Max Pears.
* [**Game Maker's Toolkit (GMTK)**](https://www.youtube.com/user/McBacon1337) is a very popular game design analysis YouTube channel by Mark Brown. He often critiques levels and makes good points, but we want to caution you, he doesn't quite have the personal experience of actually working as a level designer.

### Screenshot accounts

Below are some fun Twitter accounts which exist solely to post screenshots of community levels; they're good to follow because seeing more levels will help you train your eye for level design, and it's fun to see what other people make.

* [@Slipseer](https://twitter.com/Slipseer) posts Quake 1 map screenshots
* [@GoldsourceGold](https://twitter.com/GoldsourceGold) posts GoldSrc (Half-Life 1 engine) map screenshots
* [@WADb0t](https://twitter.com/WADb0t) posts custom Doom WAD screenshots
* [@dot\_\_UNR](https://twitter.com/dot__UNR) posts Unreal / Unreal Tournament 1999 map screenshots
* [@Tf2Dot](https://twitter.com/Tf2Dot) posts Team Fortress 2 community map screenshots
* [@TaffingAbout](https://twitter.com/TaffingAbout) posts Thief and Thief 2 fan mission screenshots.
* [@dot\_bsp](https://twitter.com/dot_bsp) the original level design screenshot account (?) posts GoldSrc screenshots (on hiatus as of 2019)
