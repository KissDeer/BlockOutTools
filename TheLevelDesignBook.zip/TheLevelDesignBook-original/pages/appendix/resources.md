> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/appendix/resources.md).

# Assets & Resources

Where to get free art assets (models, textures, materials) for use in levels

This page lists free art assets (models, textures, materials) for use in levels.

* We only list sites with robust **free** download plans + **generic file formats** that work in most engines.
* "CC license" refers to free assets with permissive [Creative Commons](https://en.wikipedia.org/wiki/Creative_Commons_license) or [public domain](https://en.wikipedia.org/wiki/Public_domain) style licenses. Attribution may be required.
* More resources:
  * [**Books**](/appendix/resources/books.md): list of other level design books, with brief summaries
  * [**Quake resources**](/appendix/resources/quake.md): list of free texture .WADs and other Quake-specific files

## 3D models and props (free)

<table><thead><tr><th width="167.06503116428522">Site</th><th width="436.9644546233042">Content</th><th width="137" data-type="checkbox">CC license?</th></tr></thead><tbody><tr><td><a href="https://sketchfab.com/"><strong>Sketchfab</strong></a></td><td>biggest selection of free low poly + realistic + 3D scan assets on internet; quality varies; make sure to filter for "Downloadable"!</td><td>true</td></tr><tr><td><a href="https://opengameart.org/art-search-advanced?keys=&#x26;title=&#x26;field_art_tags_tid_op=or&#x26;field_art_tags_tid=&#x26;name=&#x26;field_art_type_tid%5B%5D=10&#x26;sort_by=count&#x26;sort_order=DESC&#x26;items_per_page=48&#x26;Collection="><strong>OpenGameArt</strong></a></td><td>lots of free models designed for games, but quality varies a lot</td><td>true</td></tr><tr><td><a href="https://www.kenney.nl/assets?q=3d"><strong>Kenney</strong></a></td><td>the most prolific free asset creator in games; many well-designed low poly 3D tilesets</td><td>true</td></tr><tr><td><a href="http://quaternius.com/"><strong>Quaternius</strong></a></td><td>another prolific free asset creator, lots of free low poly 3D props and characters</td><td>true</td></tr><tr><td><a href="https://www.fertilesoilproductions.com/"><strong>Fertile Soil</strong></a></td><td>lots of good low poly 3D modules / tilesets, special Unity integration but works for any</td><td>true</td></tr><tr><td><a href="https://www.blendswap.com/"><strong>BlendSwap</strong></a></td><td>free community model exchange for Blender users... it's not hard to learn how to export models from .blend to .fbx / .obj</td><td>true</td></tr><tr><td><a href="https://turbosquid.com"><strong>Turbosquid</strong></a></td><td>used to be the biggest stock 3D platform on the internet; still some good free stuff there</td><td>false</td></tr></tbody></table>

## Materials and textures (free)

<table><thead><tr><th width="173.27635497026913">Site</th><th width="424.24890532629405">Content</th><th data-type="checkbox">CC license?</th></tr></thead><tbody><tr><td><a href="https://polyhaven.com/"><strong>Polyhaven</strong></a></td><td>many free photoscanned 8k+ PBR materials, as well as high poly model library</td><td>true</td></tr><tr><td><a href="https://ambientcg.com/"><strong>ambientCG</strong></a></td><td>formerly CC0Textures; lots of solid 4k / 8k materials with PBR support</td><td>true</td></tr><tr><td><a href="https://opengameart.org/art-search-advanced?keys=&#x26;title=&#x26;field_art_tags_tid_op=or&#x26;field_art_tags_tid=&#x26;name=&#x26;field_art_type_tid%5B%5D=14&#x26;sort_by=count&#x26;sort_order=DESC&#x26;items_per_page=48&#x26;Collection="><strong>OpenGameArt</strong></a></td><td>lots of free textures designed for games with handpainted styles, quality varies</td><td>true</td></tr><tr><td><a href="https://texture.ninja/"><strong>Texture Ninja</strong></a></td><td>free photosource good for retro vibes</td><td>true</td></tr><tr><td><a href="https://texturelabs.org/"><strong>Texturelabs</strong></a></td><td>smaller collection of free photosource</td><td>true</td></tr></tbody></table>

### Prototyping blockout textures

When making the [blockout](/process/blockout.md), we recommend using gridded placeholder textures to prototype the level geometry. This helps establish consistent scale and [metrics](/process/blockout/metrics.md) for the level.

* [Gridbox Prototype Materials](https://assetstore.unity.com/packages/2d/textures-materials/gridbox-prototype-materials-129127) by Ciathyza (Unity)
* [ProtoTools](https://github.com/coderespawn/proto-tools-ue4) by Code Respawn (Unreal 4)
* [Blockout Material](https://www.tomlooman.com/updated-mockup-material-for-unreal-4/) by Tom Looman (Unreal 4)
* [Prototype Textures](https://www.kenney.nl/assets/prototype-textures) by Kenney (.png)

### Skyboxes

A skybox is a special type of 6-sided cubemap texture that gives the illusion of a distant sky background. Contemporary game engines usually use procedural sky shaders / skydomes, but sometimes the old fashioned ways are more effective.

#### Quake / Half-Life style skyboxes

* <https://www.quaddicted.com/webarchive/kell.quaddicted.com/skyboxes.html>
* <https://lvlworld.com/review/Quake%203%20Arena%20skybox%20collection>
* <http://www.simonoc.com/pages/artwork.htm>

## 2D tilesets and sprites (free)

&#x20;    *To make 2D levels, you'll usually want a tile-based level editor. See* [*Tools*](/appendix/tools.md#2d-level-editors)*.*

<table><thead><tr><th width="185.45493562231763">Site</th><th width="340.5277800177405">Content</th><th data-type="checkbox">CC license?</th></tr></thead><tbody><tr><td><a href="https://opengameart.org/art-search-advanced?keys=&#x26;field_art_type_tid%5B%5D=9&#x26;sort_by=count&#x26;sort_order=DESC"><strong>OpenGameArt</strong></a></td><td>10000+ free tileset packs and sprites, mostly retro / pixel art style but lots of variety, basically the first place to look</td><td>true</td></tr><tr><td><a href="https://www.kenney.nl/assets?q=2d"><strong>Kenney</strong></a></td><td>smooth chunky tilesets packs and sprites, very good but also very recognizable</td><td>true</td></tr></tbody></table>
