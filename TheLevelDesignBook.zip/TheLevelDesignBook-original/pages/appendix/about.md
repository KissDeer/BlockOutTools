> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/appendix/about.md).

# About this book / authors

about this book project, its authors, and any credits

The Level Design Book is a free nonprofit project run by volunteers.

## About this book

Level design is a bit of a dying art. Modern industrial workflows and the popularity of procedurally generated content mean that level design, as traditionally understood in the 1990s, feels increasingly less relevant to contemporary game genres and trends.

And yet, many games (and companies) still need level designers -- and today's beginner level designers don't have any good learning resources to use.&#x20;

The past generation of level designers came of age in the 1990s / 2000s, benefiting immensely from the unique bespoke online level design communities of Web 1.5 -- easily sharing and building knowledge with peers. Today, all that knowledge is much less accessible and discoverable. The entire internet has been commodified into a handful of all-purpose social media networks, and search engines have generally become much worse / less helpful.

There are many ways out of a dark age, but here we're going to try a renaissance model and revive the old ways: write words on a page *(and edit these words!!),* hand-curate links, and centralize information on an independent website external to a social network.

### Roadmap

* Stage 1: write a book with solid text, links, and illustrations; good coverage on all topics
* Stage 2: transform into a living book; follow inspirations like Nature of Code and Book of Shaders, which offer design tools and exercises within the text itself
  * build a simple web embeddable 3D level design tool with blockout, playtest, and basic game elements
  * interactive examples
* Stage 3: ???

## About the authors

### Core authors / editors

*These people have written the bulk of the text in this book, and collectively edit contributions.*

Robert Yang is the founder of this project. As an indie game developer, he is most well-known for his Radiator games about sexuality and intimacy. In the past, he also contributed levels to projects like Black Mesa Source, and conducted interviews with level designers for Rock Paper Shotgun. (<https://debacle.us>)

### Contributors

*These people have contributed substantial research, writing, or assets to the book.*

[Andrew Yoder](https://andrewyoderdesign.com/) has worked on Paladins and Warframe, and specializes in multiplayer social spaces and combat design.

### Additional credits

The Level Design Book logo is made of icons from The Noun Project by [Maxim Kulikov](https://thenounproject.com/term/book/787682/) and [Priyanka](https://thenounproject.com/term/architecture/2215621/).

And generally, much of the material from this book comes from many different authors. We strongly believe in the importance of crediting, and we attempt to cite and link back as much as possible. All this attributed content belongs to these respective creators.
