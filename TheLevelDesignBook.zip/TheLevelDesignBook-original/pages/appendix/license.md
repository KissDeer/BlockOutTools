> For the complete documentation index, see [llms.txt](https://book.leveldesignbook.com/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://book.leveldesignbook.com/appendix/license.md).

# License / copyright

## Copyright

All cited material, illustrations, quotes, game screenshots, video embeds, game content, etc. belong to those original creators or studios. This book includes such content for non-commercial educational purposes under [Fair Use](https://en.wikipedia.org/wiki/Fair_use) doctrine and we always attempt to credit and link back to original authors as much as possible.&#x20;

Because of the complex communal authorship of this book's material, **we will never paywall this book nor sell any copies of it.**

And for a similar reason, **we generally do not include material from other level design books,** because fair use is less clear in these cases. You should purchase and read those books instead.

&#x20;   *For a list of book recommendations, see* [*Level design books*](/appendix/resources/books.md)*.*

### DMCA

If you are one of the copyright owners impacted by our website and you want your content removed from the page, please [contact an editor](/appendix/about.md) with (1) the URL to the page in question, and (2) short description of the content to be taken down.&#x20;

## License

All **unattributed text** in this online book is hereby licensed under the [Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0)](https://creativecommons.org/licenses/by-nc-sa/4.0/) license.&#x20;

<div align="left"><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LtfRE6vMa7dIv6OW2I1%2F-Ltf_CKhdLuJKGDXZ0IR%2Fcreative_commons_BY-NC-SA_4.png?alt=media&amp;token=67bdaaa2-ed85-4dc1-8933-9e00c1193c91" alt=""></div>

You can publish or distribute this book / translations of it, whether in part or in whole, under these conditions:

* **You cannot sell the book, nor charge for access to it** (no paid subscription or license fees)
* You must **attribute us prominently within the body text of your copy, and link back to this website**
* **You must also license any of your modifications under the CC BY-NC-SA 4.0 license, and prominently state this license in the body text of your copy.**

**Content creators and video makers:** if you make a video that explains, summarizes, or paraphrases the content of this book, then please (1) audibly cite this book during the video, and (2) link back to us prominently in the video description + text chat.

**Anyone else:** attribute us with (1) "The Level Design Book", and (2) a link directly to the book page URL.

**Students:** see [How to cite this book](/appendix/license.md#how-to-cite-this-book).

## How to cite this book

If you're writing a research paper, here are common citation formats for your convenience. Make sure you replace the `ALL-CAPS` fields with your own citation data.

[**MLA format**](https://owl.purdue.edu/owl/research_and_citation/mla_style/mla_formatting_and_style_guide/mla_works_cited_electronic_sources.html)**:**

* “`PAGE TITLE`.” *The Level Design Book,* `PAGE URL`. Accessed `DAY` `MONTH` `YEAR`.

[**Chicago Style**](https://owl.purdue.edu/owl/research_and_citation/chicago_manual_17th_edition/cmos_formatting_and_style_guide/web_sources.html)**:**

* "`PAGE TITLE`", The Level Design Book, accessed `MONTH` `DAY`, `YEAR`. `PAGE URL`.

[**APA Style**](https://owl.purdue.edu/owl/research_and_citation/apa_style/apa_formatting_and_style_guide/reference_list_electronic_sources.html)**:**

* `PAGE TITLE`. (n.d.). Retrieved `MONTH` `DAY`, `YEAR`, from `PAGE URL`.

[**ACM**](https://www.acm.org/publications/authors/reference-formatting)**:**

* The Level Design Book. `PAGE TITLE`. Retrieved `MONTH` `DAY`, `YEAR` from `PAGE URL`

## License details

> This is a human-readable summary of (and not a substitute for) the [license](https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode). [Disclaimer](https://creativecommons.org/licenses/by-nc-sa/4.0/#).

> #### You are free to:
>
> * **Share** — copy and redistribute the material in any medium or format
> * **Adapt** — remix, transform, and build upon the material
>
> The licensor cannot revoke these freedoms as long as you follow the license terms.
>
> #### Under the following terms:
>
> * **Attribution** — You must give [appropriate credit](https://creativecommons.org/licenses/by-nc-sa/4.0/#), provide a link to the license, and [indicate if changes were made](https://creativecommons.org/licenses/by-nc-sa/4.0/#). You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
> * **NonCommercial** — You may not use the material for [commercial purposes](https://creativecommons.org/licenses/by-nc-sa/4.0/#).
> * **ShareAlike** — If you remix, transform, or build upon the material, you must distribute your contributions under the [same license](https://creativecommons.org/licenses/by-nc-sa/4.0/#) as the original.
> * **No additional restrictions** — You may not apply legal terms or [technological measures](https://creativecommons.org/licenses/by-nc-sa/4.0/#) that legally restrict others from doing anything the license permits.
>
> #### Notices:
>
> * You do not have to comply with the license for elements of the material in the public domain or where your use is permitted by an applicable [exception or limitation](https://creativecommons.org/licenses/by-nc-sa/4.0/#).
> * No warranties are given. The license may not give you all of the permissions necessary for your intended use. For example, other rights such as [publicity, privacy, or moral rights](https://creativecommons.org/licenses/by-nc-sa/4.0/#) may limit how you use the material.
