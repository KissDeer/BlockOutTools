> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [learning/projects/unfinished-wip-pages.md](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages.md)。

# （未完成的 WIP 页面）

- [现代战斗](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/modern-combat.md)：现代商业动作射击游戏的设计练习
- [现代潜行](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/modern-stealth.md)：包含掩体与战斗的现代潜行游戏设计练习
- [练习：直接灯光](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/exercise-direct-lighting.md)
- [练习：白板 2D](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/exercise-whiteboard-2d.md)
- [关卡设计作品集](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/level-design-portfolio.md)
- [设计测试：改编](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/adaptation.md)
- [练习：布局](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/exercise-floorplan.md)
- [练习：垂直性](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/verticality.md)
