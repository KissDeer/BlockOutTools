> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。本页的 Markdown 版本见 [learning/projects/classic-combat.md](https://book.leveldesignbook.com/learning/projects/classic-combat.md)。

# 经典战斗

用 Doom 或 Quake 练习经典射击游戏遭遇战设计

## 1. 研究

用 60 分钟游玩 Doom 1、Doom 2 或 Quake 1 的几张关卡。新手或通常不喜欢这类游戏的人可选 Doom；对射击游戏技术细节感兴趣的人可研究 Quake。Doom 无敌秘籍是 **`IDDQD`**；Quake 中按 **~** 打开控制台，输入 **`god`**。

阅读战斗设计批评，思考：Doom 的武器为何具有正交性？现代 FPS 做了什么？Quake 的护甲如何减伤？Copper 模组的设计支柱和受众是什么？

### 研究问题

哪一张关卡最喜欢，为什么？哪些武器 / 玩家战术只对某种怪物有效？哪些怪物适合在同一房间战斗，哪些组合不佳？难度为何很少改变游戏代码？哪类怪物最适合触发怪物间的内斗？

## 2. 布局

限制为 2-3 种怪物、1-2 件武器和 1-2 分钟玩法。写一个[玩家体验目标](/process/preproduction.md#experience-goal)，画出玩家与敌人出生点、物品、危险、锁门和[关键路径](/process/layout/criticalpath.md)，并考虑生命 / 弹药是否能鼓励移动。向同伴展示遭遇战提案。

## 3. 白盒

先复习 [Doom 尺度](/process/blockout/metrics/doom.md)和 [Quake 尺度](/process/blockout/metrics/quake.md)。新手可从 Doom 的 2D 编辑器开始，也可在 Quake 中进行完整 3D 建造。保持范围小，竞技场不要超过约 1024 单位，不要把时间花在装饰和灯光上。

Doom 和 Quake 怪物没有真正的寻路，因此区域要相对开阔，走廊最好宽 128 单位以上；可用地面高度差把远程敌人限制在高台上。

## 试玩与迭代

观察普通玩家能否独立完成、死亡和重开的次数，以及战斗是否保持在 1-2 分钟。记录反馈，修改一个问题，再次试玩。

## 4. 反思

总结玩家行为与最初目标的差异，记录哪些布局、怪物和资源选择有效。然后重复项目，制作另一张 Doom 或 Quake 地图，或尝试其他[项目](/learning/projects.md)。
