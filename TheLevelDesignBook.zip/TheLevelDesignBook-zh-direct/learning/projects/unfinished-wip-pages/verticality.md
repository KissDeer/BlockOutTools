> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [learning/projects/unfinished-wip-pages/verticality.md](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/verticality.md)。

# 练习：垂直性

垂直体块、高度、“Z 层级”、楼层

当然，用俯视角布局图很难规划垂直维度。因此，建筑师会绘制立面图和剖面图来表现建筑的垂直轮廓。但对于关卡设计规划来说，这样的细节太多了。要用更抽象的方式思考。

（带垂直性的布局）

* 把区域分组到主要地面 / 标高，并像绘制高度图一样上色：较暗的区域较低，较亮的区域较高。&#x20;
* 忽略所有细微的高度变化或浅层地形坡度。&#x20;
* 为坡道、楼梯以及任何接近段或平台预留足够空间。

如果你的地图由楼层上下重叠组成，请分别绘制楼层，并标注楼层之间的过渡。但对于地面楼层无关紧要的结构，例如瞭望塔，可以直接省略。绘制最能传达关卡核心想法的内容。
