> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [learning/projects/unfinished-wip-pages/adaptation.md](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/adaptation.md)。

# 设计测试：改编

在这项设计测试中，你要把一栋现实世界的建筑或一个现实地点改编成一个单人关卡。&#x20;

关注以下设计考量：

* 类型学：现实场地的主要结构模式是什么？如何在保持强烈相似性的同时简化这套逻辑？
* 体块：哪些部分给人的感觉是轻或重、薄或厚、坚固或脆弱？如何把这些特质提炼成 3D 重现？
* 游戏玩法：什么类型的机制、遭遇战、谜题和大型场景最适合这种地方？
* 范围：我们应该改编这个地点多少内容，是完整的外部空间加部分内部空间，还是反过来？
