> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。本页的 Markdown 版本见 [learning/projects/unfinished-wip-pages/modern-combat.md](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/modern-combat.md)。

# 现代战斗

为现代商业动作射击游戏进行设计练习

## 1. 研究

用 10-60 分钟分析《神秘海域 4》的战斗：遭遇战如何开始？玩家如何知道战斗开始、敌人在哪里？战斗持续多久？有哪些节拍，战斗故事与节奏是什么？战斗如何结束，玩家如何知道结束并知道下一项活动？

观看关于《神秘海域 4》战斗 AI 的开发者演讲，并研究：前作“区域”方法的优点与限制；《神海 4》原型但最终弃用的系统；受吃豆人幽灵 AI 启发的三个主要战斗角色；以及可用于其他战斗游戏的核心结论。

## 2. 布局

用 20 分钟画一场遭遇战。定义一个[玩家体验目标](/process/preproduction.md#experience-goal)，设计至少一个[大型场景](/process/preproduction.md#setpiece)和至少两个[节奏](/process/preproduction.md#pacing)节拍，标记玩家 / 敌人出生点、物品、掩体、关键[视线](/process/combat/encounter.md#sightline)以及硬点 / 区域。用 5 分钟展示提案。

## 3. 白盒

用两小时游玩一款带战斗的游戏，关注它如何设置遭遇战、敌人有哪些类型与职责。然后在目标游戏中原型化自己的遭遇战，记录哪些系统支持或限制了设计。
