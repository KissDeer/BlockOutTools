> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [learning/projects/unfinished-wip-pages/level-design-portfolio.md](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/level-design-portfolio.md)。

# 关卡设计作品集

## 完成“项目”类别中的一些项目

## 找一个网站托管商

如果负担得起，注册自己的域名

不要使用 Wix……免费 WordPress 可能更好

如果你的作品集以视觉内容为主，直接制作一个 ArtStation

## 简化网页模板

在顶部说明你是谁

删掉网页模板中所有没用的东西，只保留主页

## 创建项目页面

不要写太多

包含 3–5 张截图、一个短视频，以及指向外部网站和评论的链接

## 在移动设备上测试

想象你是一个无聊的经理，正在滚动浏览电子邮件

## （可选）注册 Twitter，至少每周使用一次

展示你在关注行业讨论和行业人士

这有助于你假装认识一些人，也有助于记住名字

## 上传简历

最多 1 页，文字通常越少越好

写上你的姓名、作品集 URL 和期望的开发岗位

不要写 GPA 或辅修专业，但列出重要奖项、助学金和奖学金

不要硬塞“技能与兴趣”部分，想象你读了 40 份这样的简历，那就不会觉得它很可爱了

省略家庭住址或电话号码，你要把这份简历放到互联网上

附上 PDF，以备对方想保存和下载等情况

你的简历有两个作用：(1) 列出工作经历和资历；(2) 给面试官提供可以询问你的内容……别让他们觉得无聊

## 定期更新作品集

每次完成项目后 / 投递申请前

## 关卡设计作品集示例

* Anthony Panecasio：<https://www.panecasio.com/>
* Magnar Jenssen：<http://magnarj.net/>
