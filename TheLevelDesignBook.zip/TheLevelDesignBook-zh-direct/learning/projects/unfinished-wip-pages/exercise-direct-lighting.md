> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [learning/projects/unfinished-wip-pages/exercise-direct-lighting.md](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/exercise-direct-lighting.md)。

# 练习：直接灯光

要培养灯光技能，应从尽可能简单的方式开始：忽略游戏引擎或渲染器中所有花哨的灯光功能，改为手动放置每一个光源，包括任何反弹光或补光。这是一种劳动密集型的“老式”3D 空间打光方式，但它能迫使你思考灯光正在做什么，因此是一项有用的练习。这个工作流程也比你想象的更有现实意义；像《辐射 4》这样相对较新的游戏就没有使用预计算灯光烘焙。

用实时直接光和手动放置的间接光照亮一个简单的白盒房间。&#x20;

如果这是你第一次思考灯光，请用灰度纹理制作白盒纹理，并使用去饱和的灰度灯光。

如果想增加挑战，可以使用彩色原型纹理和彩色灯光。

禁用预计算灯光烘焙，只使用实时灯光；查阅灯光页面，了解如何设置补光
