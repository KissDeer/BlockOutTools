> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [learning/projects/unfinished-wip-pages/exercise-whiteboard-2d.md](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/exercise-whiteboard-2d.md)。

# 练习：白板 2D

阅读 David Sirlin 关于《大金刚国度》收藏品的文章

绘制一个包含收藏品的 2D 平台游戏布局

对于特定的大型场景，标出玩家屏幕的轮廓；玩家究竟能看见什么

展示并讲解计划
