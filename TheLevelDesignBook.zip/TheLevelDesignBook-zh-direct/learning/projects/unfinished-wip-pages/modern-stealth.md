> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [learning/projects/unfinished-wip-pages/modern-stealth.md](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/modern-stealth.md)。

# 现代潜行

包含掩体和战斗的现代潜行游戏设计练习

## 简介

在这个项目中，你将为一款拥有掩体系统和战斗后备方案的现代商业潜行动作游戏，研究、构思并制作一场战斗遭遇战的原型。&#x20;

{% hint style="success" %}
继续之前，确保你已经阅读过[节奏](/process/preproduction.md#pacing)、[平衡](/process/combat/balance.md)和[遭遇战](/process/combat/encounter.md#encounter)。\
我们也建议先完成[经典战斗](/learning/projects/classic-combat.md)设计练习。
{% endhint %}

## 1. 研究

### 回顾《细胞分裂：黑名单》中的潜行（10–60 分钟）

理想情况下，你已经玩过一款近期的潜行动作游戏。**如果你从未玩过这些游戏中的任何一款，那么继续之前应该先去玩一款。**至少玩过教程关卡和第一个任务，这可能至少需要一小时。

如果你已经熟悉这个类型，就花些时间回顾游戏是如何游玩的。**在 YouTube 上搜索“splinter cell blacklist gameplay”，至少观看 10 分钟游戏录像。**

观看视频时，思考以下问题：

* 《黑名单》中的大多数潜行遭遇战如何开始？玩家如何追踪敌人移动？
* 潜行遭遇战持续多长时间？它为什么感觉像一次小型潜行，或大型潜行？
* 潜行遭遇战中有没有“节拍”？节奏和幻想是什么？
* 潜行遭遇战如何结束？玩家如何知道它结束了？玩家结束时感觉如何，为什么？玩家如何知道下一个活动是什么？

### 观看这场关于《细胞分裂：黑名单》AI 的开发者演讲（30 分钟）

{% embed url="<https://www.youtube.com/watch?v=RFWrKHM0vAg>" %}

接下来观看 2014 年 GDC 演讲 [Martin Walsh 的《塑造〈细胞分裂：黑名单〉中的 AI 感知和警觉》](https://www.youtube.com/watch?v=RFWrKHM0vAg)，了解《细胞分裂》的潜行 AI 和遭遇战设计工具。可以随手记笔记，也可以参考 [PDF 幻灯片](https://www.gdcvault.com/play/1024467/Authored-vs-Systemic-Finding-a)。

每款游戏管理潜行 AI 的方式都不同，但《细胞分裂》的核心方法与其他潜行动作游戏足够相似，可以代表当前行业实践。遭遇战设计师必须理解游戏系统和 AI 工具。

### 研究问题（15 分钟）

* **对比**战斗 AI 设计与潜行 AI 设计。“好”的潜行 AI 的目的是什么？它应该推动什么类型的体验？它追踪哪些信息，又向玩家广播哪些信息？
* Walsh 交替使用“感知”和“警觉”这两个词。为什么？这两个概念之间有什么区别（如果有的话）？
*
