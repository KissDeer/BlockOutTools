> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [learning/projects/unfinished-wip-pages/exercise-floorplan.md](https://book.leveldesignbook.com/learning/projects/unfinished-wip-pages/exercise-floorplan.md)。

# 练习：布局

## 简介

这是一个绘制简单关卡布局的设计练习。

设计简报……一个 5 分钟的单人关卡，内容是解锁一扇门并离开；包含一个好的布局和一个坏的布局

## 规划

不要局限于简报

定义体验目标

列出关卡的主要节拍

## 研究

其他关卡是否做过类似的事情？

练习观察布局图……为什么要那样画？它传达了什么？

## 布局

构图

气泡图

布局
