> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [learning/projects.md](https://book.leveldesignbook.com/learning/projects.md)。

# 项目计划

本页列出各种关卡设计项目计划 / 作业。这些内容对教师规划课程很有用，对想要独自学习和练习关卡设计的任何人也很有用。

{% hint style="warning" %}
目前，我们的重点是完成[**第一册：流程**](/process/overview.md)。所以这一部分有些被忽略了。
{% endhint %}

不过，我们确实有一些接近完成的项目计划，可以让你了解我们的目标：

* [**经典战斗**](/learning/projects/classic-combat.md)：制作并思考具有经典街机风格射击战斗的 Doom / Quake 关卡设计。
