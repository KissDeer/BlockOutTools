> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。本页的 Markdown 版本见 [culture/zero-player.md](https://book.leveldesignbook.com/culture/zero-player.md)。

# 零玩家关卡设计

关于玩家几乎不输入、由关卡自动完成动作的社区创作关卡

## 本地关卡设计

关卡设计不只发生在商业工作室。玩家也会为彼此制作关卡、分享路线、练习技巧和观看他人游玩。社区规则、挑战、记录和反馈会共同塑造设计语言。

## TrackMania 的 Press Forward（PF）

在 TrackMania 的 Press Forward 关卡中，玩家通常只需按住加速，赛道几何体、斜坡、跳台和弯道会自动驱动车辆完成一连串动作。设计师控制速度、视线、落点和容错，把输入极少的体验变成路线与时机的表演。

## Super Mario Maker 的 Auto-Mario

Auto-Mario 关卡利用自动移动、弹簧、传送、敌人和平台，让马力欧在几乎没有输入时完成跳跃与连锁动作。玩家更像是观察者、校验者或节奏控制者；设计重点从“玩家要按什么”转向“系统如何连续响应”。

## 围绕建筑起舞

这些作品说明，关卡不一定必须不断要求玩家输入才有意义。空间的顺序、物理规则、摄像机和自动动作可以成为作者，玩家则通过选择是否进入、何时干预和如何理解系统参与创作。
