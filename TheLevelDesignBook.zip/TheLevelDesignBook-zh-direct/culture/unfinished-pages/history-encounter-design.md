> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。本页的 Markdown 版本见 [culture/unfinished-pages/history-encounter-design.md](https://book.leveldesignbook.com/culture/unfinished-pages/history-encounter-design.md)。

# 遭遇战设计史

## 引言

[遭遇战设计](/process/combat/encounter.md)几乎没有被记录，因为遭遇战设计本身直到最近也很少被正式记录。许多知识通过走廊、饮水机旁和互联网论坛非正式传播，而不是以书或演讲的形式存在。

## 怪物摆放时代（1993-1998）

### Doom（1993）

Doom 的玩家移动很快，大多数敌人攻击都能躲避；熟练玩家可以在几乎不受伤的情况下处理大量敌人。这让玩家因为敏捷而强大，而不是因为像坦克一样耐打，也让关卡能够使用巨量敌人、不同威胁比例和庞大非线性的空间。参见 [Coelacanth: Lessons from Doom](http://vectorpoem.com/news/?p=74)、[The Roots of Doom Mapping](https://www.doomworld.com/25years/the-roots-of-doom-mapping/)和[Monster Placement](https://www.doomworld.com/forum/topic/73964-essayarticle-monster-placement/)。

### Quake（1996）与 Half-Life 1（1998）

Quake 将 3D 空间、垂直性和更复杂的敌人关系带入实时战斗；Half-Life 进一步把脚本、叙事和遭遇战节拍结合起来。

## 早期遭遇战设计（1998-2008）

### Thief: The Dark Project（1998）

《神偷》将潜行、声音、光照、巡逻和可选路线结合起来。Randy Smith 的 [Level Building for Stealth Gameplay（GDC 2006）](https://www.dropbox.com/s/2klwztr4cx09d2b/Smith_LevelBuildingForStealthGameplay_GDC2006.pdf?dl=0) 是重要参考。

### Halo（2001）

《光环》让敌人通过动画和声音广播状态；敌人具有清晰、可预测的能力与职责，也拥有有限的感知和记忆，使玩家能够欺骗敌人并看见欺骗生效。参见 [The Illusion of Intelligence](https://www.dropbox.com/s/nkffbyzjytpsgs8/bungie_illusionOfIntelligence_Halo1.pdf?dl=0) 和 [Building a Better Battle](https://www.dropbox.com/s/ngdll0gxt161p7j/bungie_buildingABetterBattle_Halo3.pdf?dl=0)。

Gears of War、Hitman: Blood Money 等作品进一步把掩体、潜行和任务空间纳入遭遇战设计。

## 动态遭遇战设计（2007 至今）

BioShock、S.T.A.L.K.E.R.、Far Cry 2 和 Left 4 Dead 逐渐使用更具系统性的敌人行为与导演系统。Uncharted 4 的经验显示，大型非线性竞技场适合由遭遇战协调器动态调整战线和 NPC 职责，而不是把所有敌人预先放置或脚本化。

可以将战斗竞技场拆成高层“硬点” / 区域，分配接战者、伏击者和防守者等职责；潜行遭遇战可以放置短而自然的巡逻环，再让协调器把 NPC 分配到这些路径。生成导航提示点有用，但不要把过多内容交给不可预测的程序系统，因为玩家会把它当成没有人类倾向的黑箱。

## 回到怀旧

经典游戏的开放空间、清晰敌人角色、可躲避攻击和社区地图仍然提供了重要的遭遇战设计参考。现代系统可以增加变化，但不应牺牲玩家理解、预测和反制的能力。
