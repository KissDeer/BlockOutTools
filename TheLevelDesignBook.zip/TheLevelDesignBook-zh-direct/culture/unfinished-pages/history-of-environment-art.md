> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [culture/unfinished-pages/history-of-environment-art.md](https://book.leveldesignbook.com/culture/unfinished-pages/history-of-environment-art.md)。

# 环境美术的历史

TODO：研究环境美术的历史……

可以追溯到建筑、工业设计、舞台设计和其他美术形式

也可以追溯到 20 世纪早期现代主义建筑师的“形式追随功能”理念：例如 Louis Sullivan 的《高层办公建筑的艺术性考虑》（1896）和 Adolf Loos 的《装饰与罪恶》（1908）。
