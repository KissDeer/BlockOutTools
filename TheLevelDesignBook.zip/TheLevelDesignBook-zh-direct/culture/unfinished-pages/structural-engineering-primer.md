> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [culture/unfinished-pages/structural-engineering-primer.md](https://book.leveldesignbook.com/culture/unfinished-pages/structural-engineering-primer.md)。

# 结构工程入门

TODO：总结《建筑为何站立》中的一些内容

游戏示例：<https://tf2maps.net/threads/guide-a-primer-on-basic-structures.38329/>
