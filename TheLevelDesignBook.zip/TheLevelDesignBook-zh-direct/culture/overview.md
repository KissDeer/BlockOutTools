> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [culture/overview.md](https://book.leveldesignbook.com/culture/overview.md)。

# 关卡设计文化

关卡设计的趋势、历史和相邻领域
