> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [appendix/communities.md](https://book.leveldesignbook.com/appendix/communities.md)。

# 社区

关卡设计社区、网站、Discord、播客、博客和社交媒体链接

## 寻找关卡设计社区

加入关卡设计**社区**有很多好处：

* 帮助解决设计问题和工具故障
* 为你的作品提供批评性反馈
* 提供动力和鼓励

## **理想情况下，加入一个特定游戏的社区**&#x20;

特定游戏的社区可以提供更有针对性的帮助和经验，也更有可能试玩你的作品并给出有价值的反馈。&#x20;

&#x20;    ***有关特定游戏的关卡设计社区，请查看*** [***工具***](/appendix/tools.md)***中的“社区”列。***

![看看这些共享同一空间的快乐人们；只要加入关卡设计社区，你也可以成为其中一员](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F0jlJ1bGNKOgV4yDoypPK2%2FLDB_Community.jpg?alt=media\&token=48726915-02fa-4790-93ac-0ebd140330ea)

## **综合型关卡设计社区**

* [**#blocktober**](https://www.gamasutra.com/view/news/306933/Devs_celebrate_the_art_of_level_design_with_Blocktober_hashtag.php) 是一项年度互联网传统：关卡设计师在十月期间于 Twitter 发布[白盒](/process/blockout.md)截图。最受欢迎的推文通常来自 AAA 行业的关卡设计师，他们会发布知名商业游戏中的作品白盒。
* [**MapCore**](https://mapcore.org) 是历史最悠久、目前仍活跃的关卡设计论坛之一，主要关注 Source 引擎游戏（CS:GO、《军团要塞 2》），但许多成员也经常制作其他游戏的模组，并使用 Unity 和 Unreal。成员包括模组制作者和行业从业者。
* [**The Design Den**](https://discord.gg/tAaDrRy) 是由 Ryan Smith 创建的关卡设计师 Discord 社区。

## 环境美术社区

* [**Polycount**](https://polycount.com) 最适合 3D 环境美术师、灯光美术师，以及更关注关卡设计视觉一面的任何人。这里的项目非常偏向使用 Maya / Max / ZBrush / Blender 制作的 Unreal Engine 4 场景。这里没人会试玩你的项目，但他们很乐意批评截图或视频。成员包括学生和行业从业者。
* [**80 Level**](https://80.lv/) 提供游戏、电影和视觉特效美术师的新闻、文章与指南。内容通常非常技术化且侧重工具，重点往往是管线和工作流，以及对特定场景或项目的视觉向拆解。
* [**Beyond Extent**](https://www.beyondextent.com/) 提供环境美术师访谈、文章和指南，以及播客。和其他 CG 美术社区一样，它关注工具与技术。

## 理论、写作与批评

### 发表平台 / 出版物

* [**GDC Level Design Summit**](https://www.gdconf.com/tutorial/game-level-design)（以前称为 Level Design Workshop、Level Design In A Day）是每年由行业和独立开发者关卡设计师进行的一整天演讲。经过多年的发展，它在 GDC 上形成了中等规模的受众。遗憾的是，目前没有方便的往届场次列表，不过也许我们有一天会整理出来。 \
  &#x20;    *每年夏季至秋季开放投稿。*
* [**Heterotopias**](http://www.heterotopiaszine.com/) 可能是目前首要的关卡设计批评刊物，既有短篇博客，也有长篇专题与访谈。 \
  &#x20;    *全年接受委托和投稿，并向作者付费。*
* [**Rock Paper Shotgun**](https://www.rockpapershotgun.com/) 曾推出多个关注设计的系列，例如 [What Works and Why](https://www.rockpapershotgun.com/tag/what-works-and-why/)（游戏设计拆解）、[The Mechanic](https://www.rockpapershotgun.com/tag/the-mechanic/)（更多游戏设计拆解）和 [Level With Me](https://www.rockpapershotgun.com/tag/level-with-me/)（关卡设计师访谈）。 \
  &#x20;    *全年接受委托和投稿，并向作者付费。*&#x20;

![GDC 是行业关卡设计知识的主要发表平台；图片为 Liz England（Insomniac Games）在 GDC 2015 演讲“Transitioning from Linear to Open World Design with Sunset Overdrive”中的视频画面](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F8ZkAQQ4WjR9sG8e5QLbW%2FLDB_GDC_LevelDesignWorkshop_LizEngland.jpg?alt=media\&token=05812549-5413-434d-a99d-5751f3e39da6)

### 博客 / 直播 / 播客

* [**The Architectural Imagination**](https://www.edx.org/course/the-architectural-imagination) 是哈佛品牌的免费建筑理论与历史在线课程，每年开设一次。它因关注概念而受到行业关卡设计师的欢迎。
* [**Steve Lee**](https://www.youtube.com/channel/UCRT_DdZnWiUryqrOhLL7gyw) 制作关于自己作为 AAA 关卡设计师经历的视频，并为关卡设计作品集和资源提供建议。
* [**Iuliu-Cosmin Oniscu**](https://iuliu-cosmin-oniscu.medium.com/) 撰写关于 AAA 开放世界制作和遭遇战系统的文章，通常采用类似 Ubisoft 的方法。
* [**Andrew Yoder**](https://andrewyoderdesign.blog/) 撰写关于遭遇战设计和多人游戏关卡设计的博客，也会在[自己的 YouTube 频道](https://www.youtube.com/user/Mclogenog)上传关卡设计视频评论。
* [**JP LeBreton**](http://vectorpoem.com/) 主持 [WAD Wednesdays](https://www.youtube.com/playlist?list=PLhYCywHJcxok7r4eHnUf2UELsXfhhSrBp) 直播，每周随机游玩几张 Doom 地图。
* [**Level Design Podcast**](https://anchor.fm/leveldesign) 是由 Mark Drew、Jonathan Wilson、Valentina Chrysostomou 和 Rob McLachlan 主持的播客。&#x20;
* [**Level Design Lobby**](https://leveldesignlobby.libsyn.com/) 是由 Max Pears 主持的播客。
* [**Game Maker's Toolkit（GMTK）**](https://www.youtube.com/user/McBacon1337) 是 Mark Brown 主持的热门游戏设计分析 YouTube 频道。他经常批评关卡并提出不错的观点，但需要提醒的是，他并没有真正从事关卡设计工作的个人经验。

### 截图账号

下面是一些专门发布社区地图截图的有趣 Twitter 账号；值得关注它们，因为看更多关卡能帮助你训练关卡设计眼光，而且看看别人制作的东西也很有趣。

* [@Slipseer](https://twitter.com/Slipseer) 发布 Quake 1 地图截图
* [@GoldsourceGold](https://twitter.com/GoldsourceGold) 发布 GoldSrc（《半条命 1》引擎）地图截图
* [@WADb0t](https://twitter.com/WADb0t) 发布自制 Doom WAD 截图
* [@dot\_\_UNR](https://twitter.com/dot__UNR) 发布 Unreal / Unreal Tournament 1999 地图截图
* [@Tf2Dot](https://twitter.com/Tf2Dot) 发布《军团要塞 2》社区地图截图
* [@TaffingAbout](https://twitter.com/TaffingAbout) 发布《神偷》和《神偷 2》粉丝任务截图。
* [@dot\_bsp](https://twitter.com/dot_bsp) 最初的关卡设计截图账号（？），发布 GoldSrc 截图（截至 2019 年暂时停更）
