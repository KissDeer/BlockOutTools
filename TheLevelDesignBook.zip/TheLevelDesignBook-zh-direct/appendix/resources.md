> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [appendix/resources.md](https://book.leveldesignbook.com/appendix/resources.md)。

# 资产与资源

在哪里获取用于关卡的免费美术资产（模型、纹理、材质）

本页列出可用于关卡的免费美术资产（模型、纹理、材质）。

* 我们只列出提供可靠**免费**下载方案，以及适用于大多数引擎的**通用文件格式**的网站。
* “CC 许可”指以宽松的[知识共享](https://en.wikipedia.org/wiki/Creative_Commons_license)或[公有领域](https://en.wikipedia.org/wiki/Public_domain)风格许可发布的免费资产，可能需要署名。
* 更多资源：
  * [**书籍**](/appendix/resources/books.md)：其他关卡设计书籍列表及简短摘要
  * [**Quake 资源**](/appendix/resources/quake.md)：免费纹理 `.WAD` 和其他 Quake 专用文件列表

## 3D 模型和道具（免费）

<table><thead><tr><th width="167.06503116428522">网站</th><th width="436.9644546233042">内容</th><th width="137" data-type="checkbox">CC 许可？</th></tr></thead><tbody><tr><td><a href="https://sketchfab.com/"><strong>Sketchfab</strong></a></td><td>互联网上最大的免费低多边形、写实和 3D 扫描资产集合；质量各不相同；记得筛选“可下载”！</td><td>true</td></tr><tr><td><a href="https://opengameart.org/art-search-advanced?keys=&#x26;title=&#x26;field_art_tags_tid_op=or&#x26;field_art_tags_tid=&#x26;name=&#x26;field_art_type_tid%5B%5D=10&#x26;sort_by=count&#x26;sort_order=DESC&#x26;items_per_page=48&#x26;Collection="><strong>OpenGameArt</strong></a></td><td>大量为游戏制作的免费模型，但质量差异很大</td><td>true</td></tr><tr><td><a href="https://www.kenney.nl/assets?q=3d"><strong>Kenney</strong></a></td><td>游戏领域产量最高的免费资产创作者；有许多设计良好的低多边形 3D 瓦片集</td><td>true</td></tr><tr><td><a href="http://quaternius.com/"><strong>Quaternius</strong></a></td><td>另一位产量很高的免费资产创作者，有许多免费的低多边形 3D 道具和角色</td><td>true</td></tr><tr><td><a href="https://www.fertilesoilproductions.com/"><strong>Fertile Soil</strong></a></td><td>许多优质低多边形 3D 模块 / 瓦片集，特别集成 Unity，但也适用于其他平台</td><td>true</td></tr><tr><td><a href="https://www.blendswap.com/"><strong>BlendSwap</strong></a></td><td>面向 Blender 用户的免费社区模型交换平台……学习如何将模型从 `.blend` 导出为 `.fbx` / `.obj` 并不难</td><td>true</td></tr><tr><td><a href="https://turbosquid.com"><strong>Turbosquid</strong></a></td><td>曾经是互联网上最大的库存 3D 平台；现在那里仍有一些不错的免费内容</td><td>false</td></tr></tbody></table>

## 材质和纹理（免费）

<table><thead><tr><th width="173.27635497026913">网站</th><th width="424.24890532629405">内容</th><th data-type="checkbox">CC 许可？</th></tr></thead><tbody><tr><td><a href="https://polyhaven.com/"><strong>Polyhaven</strong></a></td><td>许多免费的 8K 以上照片扫描 PBR 材质，以及高多边形模型库</td><td>true</td></tr><tr><td><a href="https://ambientcg.com/"><strong>ambientCG</strong></a></td><td>原名 CC0Textures；有许多扎实的 4K / 8K 材质，支持 PBR</td><td>true</td></tr><tr><td><a href="https://opengameart.org/art-search-advanced?keys=&#x26;title=&#x26;field_art_tags_tid_op=or&#x26;field_art_tags_tid=&#x26;name=&#x26;field_art_type_tid%5B%5D=14&#x26;sort_by=count&#x26;sort_order=DESC&#x26;items_per_page=48&#x26;Collection="><strong>OpenGameArt</strong></a></td><td>大量为游戏制作的免费手绘风格纹理，质量各不相同</td><td>true</td></tr><tr><td><a href="https://texture.ninja/"><strong>Texture Ninja</strong></a></td><td>适合复古氛围的免费照片素材</td><td>true</td></tr><tr><td><a href="https://texturelabs.org/"><strong>Texturelabs</strong></a></td><td>规模较小的免费照片素材集合</td><td>true</td></tr></tbody></table>

### 白盒原型纹理

制作[白盒](/process/blockout.md)时，我们建议使用带网格的占位纹理来制作关卡几何体原型。这有助于为关卡建立一致的尺度和[尺度规范](/process/blockout/metrics.md)。

* [Gridbox Prototype Materials](https://assetstore.unity.com/packages/2d/textures-materials/gridbox-prototype-materials-129127)，作者 Ciathyza（Unity）
* [ProtoTools](https://github.com/coderespawn/proto-tools-ue4)，作者 Code Respawn（Unreal 4）
* [Blockout Material](https://www.tomlooman.com/updated-mockup-material-for-unreal-4/)，作者 Tom Looman（Unreal 4）
* [Prototype Textures](https://www.kenney.nl/assets/prototype-textures)，作者 Kenney（`.png`）

### 天空盒

天空盒是一种特殊的六面立方体贴图，能够制造远处天空背景的幻觉。当代游戏引擎通常使用程序化天空着色器 / 天空穹顶，但有时老式方法反而更有效。

#### Quake / Half-Life 风格天空盒

* <https://www.quaddicted.com/webarchive/kell.quaddicted.com/skyboxes.html>
* <https://lvlworld.com/review/Quake%203%20Arena%20skybox%20collection>
* <http://www.simonoc.com/pages/artwork.htm>

## 2D 瓦片集和精灵（免费）

&#x20;    *制作 2D 关卡时，你通常会需要基于瓦片的关卡编辑器。参见* [*工具*](/appendix/tools.md#2d-level-editors)*。*

<table><thead><tr><th width="185.45493562231763">网站</th><th width="340.5277800177405">内容</th><th data-type="checkbox">CC 许可？</th></tr></thead><tbody><tr><td><a href="https://opengameart.org/art-search-advanced?keys=&#x26;field_art_type_tid%5B%5D=9&#x26;sort_by=count&#x26;sort_order=DESC"><strong>OpenGameArt</strong></a></td><td>10000+ 个免费瓦片集包和精灵，主要是复古 / 像素艺术风格但种类很多，基本上是首选</td><td>true</td></tr><tr><td><a href="https://www.kenney.nl/assets?q=2d"><strong>Kenney</strong></a></td><td>平滑、厚重的瓦片集包和精灵，非常好用但也很容易认出来</td><td>true</td></tr></tbody></table>
