> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [appendix/license.md](https://book.leveldesignbook.com/appendix/license.md)。

# 许可 / 版权

## 版权

所有引用材料、插图、引文、游戏截图、视频嵌入、游戏内容等，均属于原作者或工作室。本书依据[合理使用](https://en.wikipedia.org/wiki/Fair_use)原则，将这些内容用于非商业教育目的，并始终尽可能为原作者署名并链接回原始来源。&#x20;

由于本书材料的共同创作过程很复杂，**我们永远不会给本书设置付费墙，也不会出售任何副本。**

出于类似原因，**我们通常不收录其他关卡设计书籍的内容，**因为这些情况下合理使用的边界更不明确。你应该购买并阅读那些书。

&#x20;   *书籍推荐列表，参见* [*关卡设计书籍*](/appendix/resources/books.md)*。*

### DMCA

如果你是受我们网站影响的版权持有人，希望从页面中移除你的内容，请[联系编辑](/appendix/about.md)，并提供 (1) 涉及页面的 URL；(2) 要求移除内容的简短描述。&#x20;

## 许可

本在线书籍中的所有**未署名文字**，特此依据[知识共享署名-非商业性使用-相同方式共享 4.0 国际许可协议（CC BY-NC-SA 4.0）](https://creativecommons.org/licenses/by-nc-sa/4.0/)授权。&#x20;

<div align="left"><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LtfRE6vMa7dIv6OW2I1%2F-Ltf_CKhdLuJKGDXZ0IR%2Fcreative_commons_BY-NC-SA_4.png?alt=media&amp;token=67bdaaa2-ed85-4dc1-8933-9e00c1193c91" alt=""></div>

你可以在以下条件下发布或分发本书 / 本书译本，无论是部分还是全部：

* **不得出售本书，也不得收取访问费用**（不得设置付费订阅或许可费）
* 必须在副本正文中显著地**为我们署名，并链接回本网站**
* **还必须依据 CC BY-NC-SA 4.0 许可协议为你的修改授权，并在副本正文中显著声明该许可。**

**内容创作者和视频制作者：**如果你制作视频来解释、总结或转述本书内容，请 (1) 在视频中以听觉方式引用本书；(2) 在视频描述和文字聊天中显著链接回我们。

**其他任何人：**请注明 (1) “The Level Design Book”；(2) 直接指向书籍页面 URL 的链接。

**学生：**参见[如何引用本书](/appendix/license.md#how-to-cite-this-book)。

## 如何引用本书

如果你正在撰写研究论文，下面是一些方便使用的常见引用格式。记得把全大写字段替换成自己的引用数据。

[**MLA 格式**](https://owl.purdue.edu/owl/research_and_citation/mla_style/mla_formatting_and_style_guide/mla_works_cited_electronic_sources.html)**：**

* “`PAGE TITLE`。”*The Level Design Book*，`PAGE URL`。访问日期：`DAY` `MONTH` `YEAR`。

[**芝加哥格式**](https://owl.purdue.edu/owl/research_and_citation/chicago_manual_17th_edition/cmos_formatting_and_style_guide/web_sources.html)**：**

* “`PAGE TITLE`”，The Level Design Book，访问日期：`MONTH` `DAY` `YEAR`。`PAGE URL`。

[**APA 格式**](https://owl.purdue.edu/owl/research_and_citation/apa_style/apa_formatting_and_style_guide/reference_list_electronic_sources.html)**：**

* `PAGE TITLE`。（n.d.）。访问于 `MONTH` `DAY` `YEAR`，来自 `PAGE URL`。

[**ACM**](https://www.acm.org/publications/authors/reference-formatting)**：**

* The Level Design Book。`PAGE TITLE`。访问于 `PAGE URL`

## 许可详情

> 这是对[许可协议](https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode)的易读摘要（不能替代正式许可协议）。[免责声明](https://creativecommons.org/licenses/by-nc-sa/4.0/#)。

> #### 你可以自由地：
>
> * **分享**——以任何媒介或格式复制并再分发材料
> * **改编**——重新混合、转换并基于材料创作
>
> 只要你遵守许可条款，许可方就不能撤销这些自由。
>
> #### 根据以下条款：
>
> * **署名**——你必须给予[适当署名](https://creativecommons.org/licenses/by-nc-sa/4.0/#)，提供许可协议链接，并[指出是否进行了修改](https://creativecommons.org/licenses/by-nc-sa/4.0/#)。你可以用任何合理方式完成，但不得暗示许可方认可你或你的使用方式。
> * **非商业性使用**——你不得将材料用于[商业目的](https://creativecommons.org/licenses/by-nc-sa/4.0/#)。
> * **相同方式共享**——如果你重新混合、转换或基于材料创作，必须依据[相同许可](https://creativecommons.org/licenses/by-nc-sa/4.0/#)分发你的贡献。
> * **不得增加限制**——不得施加在法律上限制他人进行许可协议允许行为的法律条款或[技术措施](https://creativecommons.org/licenses/by-nc-sa/4.0/#)。
>
> #### 注意：
>
> * 对于属于公有领域的材料，或依据适用的[例外或限制](https://creativecommons.org/licenses/by-nc-sa/4.0/#)允许使用的材料，你不必遵守本许可。
> * 不提供任何保证。本许可可能无法给予你预期用途所需的全部权限。例如，宣传权、隐私权或[精神权利](https://creativecommons.org/licenses/by-nc-sa/4.0/#)等其他权利可能限制你的使用方式。
