> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [appendix/resources/books.md](https://book.leveldesignbook.com/appendix/resources/books.md)。

# 推荐书目

推荐的关卡设计书籍……除了这一本

正如[前言](/introduction.md)中所说，请记住关卡设计有不同类型。因此，关卡设计书籍也有不同类型。

* **我们通常不推荐 2000 年以前出版的关卡设计书。**二十多年间发生了很多变化。游戏行业和文化已经大不相同，更不用说工具、工作流和语言了。
* 正如我们的[许可与版权](/appendix/license.md)页面所述，**我们通常避免收录其他关卡设计书中的内容。****你应该自己借阅或购买这些书。**

## 综合型关卡设计书

综合型书籍把关卡设计视为一个更大设计问题中的一个方面。这类书通常由从多个角度研究过该主题的学者撰写。&#x20;

如果你更擅长从宏观角度思考，或者对游戏行业持怀疑态度，那么这些书适合你。&#x20;

然而，拉远视角也意味着会错过更具体的技术细节。对于正在为关卡编辑器中的问题挣扎的初学者来说，这种哲学式关注可能帮助不大。

* [***An Architectural Approach to Level Design***](https://www.goodreads.com/book/show/46136052-an-architectural-approach-to-level-design) *(2014)*，Christopher Totten 著，是一本理论性很强的综合型关卡设计教材。Totten 将许多建筑教育的核心内容（基础制图、parti、视域与庇护等）与一些游戏实例联系起来，是对概念设计理论的一次很好的汇总。
* [***Level Design: Processes And Experiences***](https://www.goodreads.com/book/show/32455413) *(2017)*，Christopher Totten 编，是一本文集，收录了许多学者、批评家和开发者关于不同关卡设计主题的案例研究。这种多元调查有助于衡量我们整体上对关卡设计的理解，但所有这些不同语境在目标和方法上差异很大。一个《如龙》玩家的个人随笔，和一篇关于 PCG 方法的研究综述有什么共同点？这是个有趣的问题，然而答案未必能直接用于初学者。
* [***A Game Design Vocabulary***](https://www.goodreads.com/en/book/show/16269919-a-game-design-vocabulary) *(2014)*，Anna Anthropy 和 Naomi Clark 著，是一本全面而稳健的入门游戏设计教材，使用简洁的游戏设计语言，并包含几章关于平台跳跃游戏关卡设计的好内容。它可能是最好的 2D 关卡设计书。适合对游戏或关卡设计感兴趣、但可能不知道从何开始的初中生、高中生或青少年。

## 行业关卡设计书

行业书籍由参与过 3D AAA 动作射击游戏发行的在职关卡设计师撰写。它们的关注范围通常比综合型学者更窄，会深入具体技术和场景。对于初学者来说，这似乎比非行业学者的哲学讨论更好。

但要变得如此具体是有代价的：这些书必须对类型和受众作出许多假设，而且很少设想更大的总体理论。读起来经常像一堆随机的该做与不该做。不过，如果你的创作目标与行业一致，这里会有许多有用的建议。

* [***Hows and Whys of Level Design***](http://www.hourences.com/product/the-hows-and-whys-of-level-design-2/) *(2008)*，Sjoerd “Hourences” De Jong 著，是现有最好的 3D 关卡设计书之一，尽管其中一部分在十五多年后已经过时。然而，De Jong 是一位经验丰富的行业开发者，制作过大量 3D 关卡，他的工作经验体现在直接的建议与实例中。考虑到这本书的年代，请熟悉[关卡设计师的历史](/culture/history-level-designer.md)，否则 De Jong 对低多边形建造黄金时代的迷恋可能难以理解。
* [***Let's Design: Combat***](https://www.nextleveldesign.org/index.php?/content/news/let%E2%80%99s-design-combat-%E2%80%93-a-level-design-series-max-pears-r328/) *(2020)*，Max Pears 著，也许是历史上第一本（也是唯一一本）遭遇战设计书，里面有许多配以可爱卡通插图的图表。不过请注意，Pears 假设你制作的不只是射击游戏，而是一款具有特定敌人类型、武器等要素的相当具体的军事题材射击游戏。即便如此，他仍为战斗游戏提供了许多有用的语言和模式。
* [**Building Game Worlds**（预计 2023 年以后？）](https://www.kickstarter.com/projects/building-game-worlds/building-game-worlds/) ，Tommy Norberg 著，是一本即将出版的关卡设计书，基于[他广受欢迎的关卡设计推文](https://twitter.com/the_norberg)。坦率地说，我们认为以图片为主的形式并不理想，它经常过度简化玩家心理、抹平细节差异。不过，许多人确实从他的建议和见解中受益，因此很难忽视他有影响力的观点。

## 游戏参考书 / 艺术书

备受瞩目的 AAA 发行作品经常会推出配套的“艺术书”，展示制作过程图片和资产拆解，提供一种幕后观察。此类书籍往往关注环境美术，包含大量概念图和资产拆解。

* [***Half-Life 2: Raising the Bar***](https://www.goodreads.com/en/book/show/29692.Half_Life_2) *(2004)*，David Hodgson 著，也许是有史以来最受赞誉的游戏艺术书。2000 年代，当 Valve 还在规律制作精心打磨且保持神秘感的单人游戏时，这本书提供了一个难得的窗口，让人看到 Valve 的历史与档案。今天读起来有点令人难过：它记录的是一个早已逝去的黄金时代，那时 Valve 是鼓舞人心的设计领袖，而不只是我们仁慈的房东。
* [***The Art of Dishonored 2***](https://www.goodreads.com/en/book/show/30893077-the-art-of-dishonored-2) *(2016)*，Ian Tucker 著，追随 Valve 的接棒者 Arkane Studios，介绍他们高度投入的创作流程。Arkane 是最后几家仍在制作高规格单人叙事射击游戏、并保留黄金时代关卡设计理念的 AAA 工作室之一，许多关卡设计师仍然仰望他们。
* [***Virtual Cities: An Atlas and Exploration of Video Game Cities***](https://www.goodreads.com/en/book/show/50489392-virtual-cities) *(2020)*，Konstantinos Dimopoulos 著。它不是官方艺术书，而是城市规划师对多个电子游戏城市的研究，被包装成一本虚拟旅行指南。Dimopoulos 以现实世界游客的想象视角写作，而不是玩家或开发者的视角，因此它不太像幕后记录，更像是一份扩展的[世界构建](/process/preproduction/worldbuilding.md)分析。

## 建筑书籍

了解现实建筑的基础知识对关卡设计很有帮助。

* [***101 Things I Learned in Architecture School***](https://www.goodreads.com/book/show/1958355.101_Things_I_Learned_in_Architecture_School)，Matthew Frederic 著，是一本经典的建筑与快速设计入门书，大多数行业关卡设计师至少都浏览过。它提供了足以在聚会上谈论建筑的教育内容，而且篇幅简短，确保你真的能读完。不过，因为它太短，所以并没有真正研究任何具体建筑，这就像学习文学却不读任何书。它适合了解概念全貌，但不会给你练习应用这些概念的实例。
* [***Architecture: Form, Space and Order***](https://www.goodreads.com/book/show/58702177-architecture)，Francis Ching 著，经常被列为大学建筑课程第一年的教材，但仍然足够易懂，非建筑师也能读。Ching 自信的手绘示例鼓励读者关注永恒的基础，而不是华而不实的 CAD 美学。相较于 Frederic 的简略方法，它更具体，也更关注真实建筑。不过，Frederic 会把事情解释得非常清楚，而 Ching 更含蓄，期待读者自己完成更多思考。
* [***A Pattern Language: Towns, Buildings, Construction***](https://en.wikipedia.org/wiki/A_Pattern_Language)，Christopher Alexander 等著，是一本著名的建筑与城市设计手册，试图详细说明住宅、街区和城市的良好设计原则，例如“卧室应该有能照进日光的窗户”，或“每个街区都需要一条可步行的市场街，并配有本地咖啡馆”。对关卡设计师来说，重要的不是规则本身，而是 Alexander 的方法：他的词汇和语法是描述、设计一个世界的有力方式，对开放世界设计和世界构建非常有用。

### 建筑参考

* Grammar of Architecture

## 待复核……

* 综合型关卡设计书试图从多个角度理解关卡设计
* 行业关卡设计书关注具体类型与风格
* 建筑书籍提供第三种视角：如果你必须住在自己的关卡里呢？如果关卡设计已经有数千年历史呢？
* 试着什么都读一点，未来不会只存在于一个地方
