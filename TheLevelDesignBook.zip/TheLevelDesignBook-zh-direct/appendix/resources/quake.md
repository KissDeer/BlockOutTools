> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。本页的 Markdown 版本见 [appendix/resources/quake.md](https://book.leveldesignbook.com/appendix/resources/quake.md)。

# Quake 资源

Quake 的模型、纹理、声音、教程和其他链接

## 获取 Quake 关卡设计入门套件

推荐先安装 [TrenchBroom](https://kristianduske.com/trenchbroom/)，并使用 [Quake Mapping Starter Kit](https://www.slipseer.com/index.php?resources/quake-mapping-starter-kit.78/)。它包含开始制作地图所需的基础纹理、模型、声音和配置。

## 编辑器

* [TrenchBroom](https://kristianduske.com/trenchbroom/)：现代、免费、跨平台的笔刷关卡编辑器
* [Quake Mapping](https://www.quakewiki.net/archives/quake1/level_editing.html)：旧工具与教程归档
* [QuakeSpasm](https://quakespasm.sourceforge.net/)：适合测试地图的跨平台 Quake 引擎

## 纹理与模型

* [Quake textures](https://www.quaddicted.com/webarchive/quake.texture.showcase/)
* [Slipseer](https://www.slipseer.com/index.php)：Quake 地图与资源社区
* [Quaddicted](https://www.quaddicted.com/)：Quake 地图归档
* [Polycount](https://polycount.com/)：模型、材质和环境美术参考

## 声音

可以从 Quake 原始资产、开放许可音效库和社区资源开始，但发布前必须确认每个声音的许可证。不要因为资产能下载就默认可以重新分发。

## 制图教程与文档

* [QuakeWiki](https://quakewiki.org/wiki/Main_Page)：实体、纹理、QuakeC 和制图资料
* [TrenchBroom Manual](https://trenchbroom.github.io/manual/latest/)：编辑器官方手册
* [So you want to learn 3D level design](https://andrewyoderdesign.blog/2019/06/08/so-you-want-to-learn-3d-level-design/)
* [Quake Mapping Discord](https://discord.gg/58XqmZM)

## 编程

Quake 游戏代码使用特殊编程语言 QuakeC。它有许多历史遗留特性，学习起来可能有些棘手，但掌握后很有趣。教程和文档包括 [QuakeC basics](https://quakewiki.org/wiki/QuakeC_basics)、[QuakeC tutorials](https://quakewiki.org/wiki/QuakeC_tutorials)、[CleanFixedQuakeC](https://github.com/Jason2Brownlee/CleanFixedQuakeC)、[progs_dump](https://github.com/dumptruckDS/progs_dump_qc/) 和 [2021 re-release source](https://github.com/id-Software/quake-rerelease-qc)。

## QuakeC 工具

可以使用 [VS Code QuakeC 扩展](https://github.com/joshuaskelly/vscode-quakec)。FTEQCC 是较现代的编译器之一，提供 GUI 和命令行版本：[FTEQCC GUI](https://sourceforge.net/projects/fteqw/files/FTEQCC/fteqccgui64.exe/download)、[FTEQCC Win64](https://sourceforge.net/projects/fteqw/files/FTEQCC/win64-fteqcc.exe/download)、[更多下载](https://sourceforge.net/projects/fteqw/files/FTEQCC/)。
