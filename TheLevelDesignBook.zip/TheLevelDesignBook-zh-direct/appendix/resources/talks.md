> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [appendix/resources/talks.md](https://book.leveldesignbook.com/appendix/resources/talks.md)。

# 推荐演讲

关卡设计演讲与演示的列表 / 归档，包含视频和幻灯片链接

下面推荐的关卡设计演讲满足以下条件：(1) 来自有经验的设计师；(2) 面向其他关卡设计师；(3) 可以免费访问。

{% hint style="info" %}
*页面没有收录，并不意味着演讲不好。例如 GDC 会对演讲设置两年付费墙，所以这里没有许多近期演讲。*
{% endhint %}

演讲按主题分组，越新的排在越前面。⭐ = 特别有影响力 / 著名

* [**综合关卡设计演讲**](#综合关卡设计演讲)
* [**战斗 / 遭遇战设计演讲**](#战斗--遭遇战设计演讲)
* [**非线性 / 沙盒 / 开放世界设计演讲**](#非线性--沙盒--开放世界设计演讲)

## 综合关卡设计演讲

&#x20;    *另见：*[《如何制作一个关卡》](/process/overview.md)

| 演讲 | 年份 | 演讲简介 | 幻灯片 PDF |
| --- | --- | --- | --- |
| **Designing the Museum Flashback: 'The Last of Us Part II'**（[YouTube](https://www.youtube.com/watch?v=4vQ_HGUtZmk)，[GDC Vault](https://gdcvault.com/play/1027964/Level-Design-Summit-Designing-the)） | 2022 | Evan Hill；行走模拟关卡的[环境叙事](/process/env-art/storytelling.md)和[节奏](/process/preproduction/pacing.md)，以及 Naughty Dog 的关卡制作流程概览。 | [LastOfUsMuseum_EvanHill.pdf](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2Fn1jJoOBDuiwMMcxSXUFF%2FGDC2022_MuseumFlashback_EvanHill.pdf?alt=media&amp;token=bfd442bc-f7f1-4cae-a407-d90b98ac2d28) |
| **Just Me & My Pitch: The Confused Art of Showing a Layout**（[GDC Vault](https://gdcvault.com/play/1027998/Level-Design-Summit-Just-Me)） | 2022 | Simon-Albert Boudreault；关于迭代[布局](/process/layout.md)的抽象制作流程理论，以及如何召开设计会议。 | [JustMeAndMyPitch_Boudreault.pdf](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FZ6fA2jcGPzPtGsZASTwG%2FGDC2022_JustMeAndMyPitch_Boudreault.pdf?alt=media&amp;token=403bba80-68bd-4626-892b-72313985ef02) |
| ⭐ **Modular Level Design of Fallout 4**（[YouTube](https://www.youtube.com/watch?v=QBAM27YbKZg)，[GDC Vault](https://gdcvault.com/play/1023202/-Fallout-4-s-Modular)） | 2016 | Joel Burgess 和 Nathan Purkeypile；权威的[模块化套件设计](/process/blockout/metrics/modular.md)入门，对环境美术师必不可少。 | [Fallout4Modular_BurgessPurkeypile.pdf](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F6AoGljf7W6cWD6MiJyl2%2FGDC2016_Fallout4Modular_BurgessPurkeypile.pdf?alt=media&amp;token=c903f1c2-81eb-4d71-83b3-ce9f2a992406) |
| **Wayfinding and Storytelling**（[GDC Vault](https://gdcvault.com/play/1022117/Level-Design-in-a-Day)） | 2015 | Brendon Chung；[寻路与引导](/process/blockout/wayfinding.md)和[环境叙事](/process/env-art/storytelling.md)，不过也许更多是在讲[动线](/process/layout/flow.md)。视频很多，不推荐幻灯片。 | [WayfindingStorytelling_BrendonChung.pdf](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FWeDcQoZf70LsazAJ5qhs%2FGDC2015_WayfindingStorytelling_BrendonChung.pdf?alt=media&amp;token=efd4f795-4887-45bb-8356-ae46fa8f13e8) |
| ⭐ **Everything I Learned About Level Design I Learned from Disneyland**（[GDC Vault](https://gdcvault.com/play/1305/Everything-I-Learned-About-Level)） | 2009 | Scott Rogers；最初的主题公园关卡设计演讲。尽管它很有影响力，我们仍不同意其中许多观点，参见：[迪士尼乐园](/studies/irl/disneyland.md)。 | |

## 战斗 / 遭遇战设计演讲

&#x20;    *另见：*[《战斗》](/process/combat.md)

| 演讲 | 年份 | 演讲简介 | 幻灯片 PDF |
| --- | --- | --- | --- |
| **Creating Conflict: Combat Design for AAA Action Games**（[GDC Vault](https://gdcvault.com/play/1023860/Creating-Conflict-Combat-Design-for)） | 2016 | Michael Barclay、Pete Ellis、Sam Howels；关于战斗[节奏](/process/preproduction/pacing.md)、[遭遇战设计](/process/combat/encounter.md)和开放世界战斗的三场演讲。 | [CreatingConflictCombat_BarclayHowelsEllis.pdf](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FwESGELTFh3bvVepmczec%2FGDC2016e_CreatingConflictCombat_BarclayHowelsEllis.pdf?alt=media&amp;token=37201746-1df2-4dde-bb7c-63d807a9887c) |
| **Community Level Design for Competitive CS:GO**（[YouTube（2014）](https://www.youtube.com/watch?v=ocqmuBq4Ts4)，[GDC Vault](https://gdcvault.com/play/1021868/Community-Level-Design-for-Competitive)，[Archive.org](https://archive.org/details/GDC2015Garozzo)） | 2015 | Shawn “FMPONE” Snelling 和 Sal “Volcano” Garozzo；《反恐精英》PvP 地图中的视线与可读性。 | [CompetitiveCSGO_GarozzoSnelling.pdf](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FMBSI3YYkCaAcUQ9gVvDF%2FCompetitiveCSGO_GarozzoSnelling.pdf?alt=media&amp;token=80dd4152-8a00-4648-bda3-58ffdd72c97a) |
| ⭐ **Design in Detail: Changing the Time Between Shots for the Sniper Rifle from 0.5 to 0.7 Seconds for Halo 3**（[YouTube](https://www.youtube.com/watch?v=8YJ53skc-k4)，[GDC Vault](https://gdcvault.com/play/1012211/Design-in-Detail-Changing-the)） | 2010 | Jaime Griesemer；有影响力的[平衡](/process/combat/balance.md)和调优工作流演讲。它并不直接讨论关卡设计，但与所有战斗游戏都相关。另见：[Chill Out](/studies/mp/chill-out.md)。 | [DesignInDetailSniperHalo_Griesemer.pdf](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FBP1yp5mVWX2pNIElPApK%2FDesignInDetailSniperHalo_Griesemer.pdf?alt=media&amp;token=b26260b2-64bb-415f-a703-1495836471d6) |

## 非线性 / 沙盒 / 开放世界设计演讲

| 演讲 | 年份 | 演讲简介 | 幻灯片 PDF |
| --- | --- | --- | --- |
| **Designing Radically Non-Linear Single Player Levels**（[YouTube](https://www.youtube.com/watch?v=CTBor4rhnQs)，[GDC Vault](https://gdcvault.com/play/1025883/Level-Design-Workshop-Designing-Radically)） | 2019 | Aubrey Serr；通过沉浸式模拟实例，介绍系统化非线性沙盒[布局](/process/layout.md)的可供性理论。 | [RadicallyNonlinear_AubreySerr.pdf](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2Fsjw1Wjyj3RBJm9rNc8Cj%2FGDC2019_AubreySerr_RadicallyNonlinear.pdf?alt=media&amp;token=9cc95337-f794-475f-8f9d-6a2068a3eb4b) |
| **'Hitman' Levels as Social Spaces: The Social Anthropology of Level Design**（[YouTube](https://www.youtube.com/watch?v=SpRJuinc9AM)，[GDC Vault](https://www.gdcvault.com/play/1025879/Level-Design-Workshop-Hitman-Levels)） | 2019 | Mette Podenphant Andersen；将《杀手 2》（2018）的非线性沙盒地图[布局](/process/layout.md)视为社会学空间。 | [HitmanSocial_MettePodenphantAndersen.pdf](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F3R2CzUcZ6rdk8MSwBbe2%2FGDC2019_MettePodenphantAndersen_HitmanSocial.pdf?alt=media&amp;token=f1173881-161e-4319-b0bd-fb3986839b47) |
| **'Mooncrash': Resetting the Immersive Simulation**（[YouTube](https://www.youtube.com/watch?v=rXm5zCdiNT0)，[GDC Vault](https://gdcvault.com/play/1025732/-Mooncrash-Resetting-the-Immersive)） | 2019 | Rich Wilson；《掠食》（2017）DLC 的[节奏](/process/preproduction/pacing.md)和进度设计，将沉浸式模拟改造成半程序生成的 roguelike。 | [Mooncrash_RichWilson.pdf](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FWfnTsAbNdgo1A92lGe4U%2FGDC2019_Mooncrash_RichWilson.pdf?alt=media&amp;token=90d4c1b9-6506-4939-b120-1b01cf2fff7d) |
| **Level Design in 'Hitman': Guiding Players in a Non-Linear Sandbox**（[YouTube](https://www.youtube.com/watch?v=hc8_W2PERZE)，[GDC Vault](https://gdcvault.com/play/1023849/Level-Design-in-HITMAN-Guiding)） | 2016 | Mette Podenphant Andersen 和 Jacob Mikkelsen；《杀手》（2016）巴黎城堡关卡的教程与[寻路和引导](/process/blockout/wayfinding.md)。 | [HitmanGuiding_AndersenMikkelsen.pdf](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FdljRtpSC6bttmjA4eLpx%2FGDC2016_HitmanGuiding_AndersenMikkelsen.pdf?alt=media&amp;token=90573cfb-4cc2-4bcd-b185-e025416f810b) |

## 另见

* [Archive.org 上的 GDC Extras 归档](https://archive.org/details/gdcextras)
* [YouTube 播放列表：NYU Practice talks](https://www.youtube.com/playlist?list=PLAIAHfJvz15kI8Ow6UwWH0kI0cQqvLzzQ)
