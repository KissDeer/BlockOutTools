> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [appendix/resources/quake/how-to-package.md](https://book.leveldesignbook.com/appendix/resources/quake/how-to-package.md)。

# 如何打包 Quake 地图 / 模组

打包与发布可游玩 Quake 文件的一般规则和指南

本页介绍如何打包 Quake 地图 / 模组发行包。

这些规则和指南基于大多数 Quake 引擎的工作方式，以及数十年来逐渐形成的社区礼仪和共识。

Quake 制作于 1996 年，其核心技术已有 26 年以上。它就像一个 26 岁的人：任何糟糕或恼人的东西都已经来不及改变了。我们必须想办法与它共处。

## 文件夹和文件名

* 文件夹和文件名中不要使用空格。
* 全部使用小写字母。（有些 Quake 引擎和操作系统区分大小写，有些不区分。）
* 避免以数字或标点符号开头。
* 使用常见的 `.ZIP` 压缩格式，不要使用需要特殊工具才能打开的 `.7Z` 或 `.RAR` 等冷门格式。

## 包类型

* **地图包（简单）：**把所有内容放在 ZIP 根目录，不使用子文件夹。
  * 适合简单的单地图发布和你的第一张地图。
* **模组包（复杂）：**把所有内容放进一个模组文件夹，再将整个文件夹压缩成 ZIP。&#x20;
  * 这样可以包含自定义资产和游戏代码。
  * 小型发布也经常采用这种方式，即使它们并不是完整模组。

### 地图包（简单）

如果你只发布地图相关文件（`.BSP` / `.LIT` / `.MAP` / `.TXT`），可以使用最简单的打包方式：

**发布单张地图时，把所有文件放在 ZIP 文件的*****根目录*****，ZIP 内不要有文件夹或子文件夹。**

```
📦 myzipfile.zip
     ↳ mymap.bsp
     ↳ mymap.lit
     ↳ mymap_readme.txt
```

这是一种常见结构，玩家需要自行将其解压到正确的 maps 文件夹。若没有额外说明，我们假定该文件夹是 `/Quake/id1/maps/`。

### 模组包（复杂）

如果你使用自定义代码或资产，就应将 Quake 发行包作为模组打包：

**发布模组时，把所有文件放进 ZIP 内一个大的“模组文件夹”。**&#x20;

不过，模组文件夹必须遵循特定的文件夹名称和结构……

```
📦 myzipfile.zip
     ↳ 📁 mymodfolder
          ↳ 📁 gfx
               ↳ 📁 env
                    ↳ skybox_up.tga
                    ↳ (etc)
          ↳ 📁 maps
               ↳ mymap.bsp
               ↳ mymap.lit
          ↳ 📁 sound
               ↳ 📁 mymodname
                    ↳ mysound.wav
          ↳ progs.dat
          ↳ readme.txt
```

* 模组文件夹名必须全部由小写字母和数字组成，不能有空格。
* 地图文件（`.BSP`、`.LIT`）必须位于模组子文件夹 **`/maps/`** 中。
  * 不要使用任何子文件夹。地图必须留在 `/maps/` 根目录，否则引擎无法找到它们。
* 天空盒（`.TGA`）必须位于模组子文件夹 **`/gfx/env/`** 中。
  * 同样不要使用其他子文件夹。
* 声音（`.WAV`）必须放在模组子文件夹 **`/sound/`** 中。
  * 此处建议使用额外子文件夹。使用唯一的声音子文件夹名以避免文件冲突，例如 `/sound/mymodname/`。
* 模型（`.MDL`）必须放在 **`/progs/`** 子文件夹中。
  * 和声音一样，建议使用额外子文件夹。
* 游戏代码（`progs.DAT`）必须位于***模组文件夹根目录***。

有些模组将所有内容打包到一个 **`.PAK`** 文件中，以简化发布并避免文件夹混乱。`.PAK` 文件类似 `.ZIP` 文件，Quake 引擎会在保留文件夹结构的情况下加载其中的文件。更多信息见 [QuakeWiki.org：PAK](https://quakewiki.org/wiki/.pak)。

### 部分模组包

**发布部分模组时，将多个模组子文件夹放在根目录，但不要设置主模组文件夹。**

**必须清楚说明解压位置。**

```
📦 myzipfile.zip
     ↳ 📁 gfx
          ↳ 📁 env
               ↳ skybox_up.tga
               ↳ (etc)
     ↳ 📁 maps
          ↳ mymap.bsp
          ↳ mymap.lit
     ↳ 📁 sound
          ↳ mysound.wav
     ↳ mymod_readme.txt
```

* 适合只有少量自定义资产的情况。
* 主要用于作为大型现有模组（例如 Arcane Dimensions）的附加内容发布地图。&#x20;
  * 在发行包里包含整个父模组不切实际，用户很可能已经安装了自己的模组。
  * 但覆盖父模组已有文件被视为非常失礼，例如不要包含 `progs.dat` 文件。

## 视频教程

有关文件结构和打包的视频入门，请观看 David Spell 的视频教程[《Quake Mapping: Release Your Map》](https://www.youtube.com/watch?v=eQ911Wphy0Q)，从 4:08 开始：

{% embed url="<https://www.youtube.com/watch?v=eQ911Wphy0Q&t=248s>" %}

## 自测：Quake 打包示例

**自己判断一下。这是好例子还是坏例子？**点击箭头查看答案。

<details>

<summary><code>MyMod.zip</code> </summary>

坏。文件名使用了大写字母。

</details>

<details>

<summary><code>mymod.zip/MyMap.bsp</code></summary>

坏。文件名使用了大写字母。

</details>

<details>

<summary><code>mymod.zip/mymap.bsp</code></summary>

好。文件名全部为小写且不含空格，BSP 文件位于 ZIP 根目录，没有子文件夹。如果作者只发布地图文件，没有其他模组文件，这样是可以接受的。

</details>

<details>

<summary><code>mymod.zip/mymodfolder/mymap.bsp</code></summary>

坏。这是模组文件夹，但 BSP 不在名为 `/maps/` 的子文件夹中。

</details>

<details>

<summary><code>mymod.zip/mymodfolder/maps/mymap.bsp</code></summary>

好。所有文件和文件夹名都是小写且不含空格，BSP 位于模组文件夹 `/mymodfolder/` 的 `/maps/` 子文件夹中。

</details>

<details>

<summary><code>mymod.zip/mymodfolder/maps/mymod/mymap.bsp</code></summary>

坏。BSP 位于名为 “mymod” 的 maps 子文件夹中，Quake 引擎无法检测到地图文件。

</details>

<details>

<summary><code>mymod.zip/mymodfolder/env/skybox_up.tga</code></summary>

坏。TGA 文件在 `/env/` 中，而不是 `/gfx/env/` 中。

</details>

<details>

<summary><code>mymod.zip/gfx/env/skybox_up.tga</code></summary>

可能好。这是部分模组方式，只要用户知道应将文件解压到哪个模组文件夹，就可以工作。&#x20;

</details>

<details>

<summary><code>mymod.zip/mymodfolder/gfx/env/skybox_up.tga</code></summary>

好。天空盒 TGA 位于正确位置。

</details>

<details>

<summary><code>mymod.zip/mymodfolder/sounds/mymod/mysound.wav</code></summary>

坏。“sounds”是错误的文件夹名，必须使用 “sound”。是的，我知道。

</details>

<details>

<summary><code>mymod.zip/mymodfolder/gfx/env/skybox_up.tga</code><br><code>+ mymod.zip/mymap.bsp</code></summary>

坏。这里把一个文件放在模组文件夹中，又把地图文件放在根目录。不要混用两种方式。

</details>

## 接下来呢？

* 我们有许多[Quake 资源](/appendix/resources/quake.md)链接。
* 进一步了解一般的[发布](/process/release.md)实践。
