> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [appendix/resources/formats.md](https://book.leveldesignbook.com/appendix/resources/formats.md)。

# 文件格式

用于制图和制作模组的文件类型及其文件格式 / 规范
