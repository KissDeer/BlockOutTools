> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。本页的 Markdown 版本见 [appendix/resources/formats/map.md](https://book.leveldesignbook.com/appendix/resources/formats/map.md)。

# MAP 文件格式

Quake `.MAP` 文件的格式规范与示例解析器代码（“Valve”风格，mapversion 220）

{% hint style="warning" %}
**这是面向程序员的技术文件格式规范文章。**&#x20;
{% endhint %}

## 文件结构

MAP 是基于文本的格式。文件由实体组成；实体可以是世界实体、点实体或笔刷实体。实体用大括号包围，属性以引号包围的键值对表示，笔刷由多个平面定义。

```text
{
"classname" "worldspawn"
{
( 0 0 0 ) ( 128 0 0 ) ( 0 128 0 ) texture 0 0 0 1 1
}
}
```

每个笔刷面由三个点定义平面，再跟随纹理名称、平移、旋转、缩放和可选的纹理轴 / UV 信息。解析器必须正确处理负数、空白、引号、注释和实体属性。

## 解析建议

不要依赖固定行号或简单的字符串切割。先按字符读取并识别大括号、括号、引号和标记，再将结果解析为实体、属性和笔刷结构。保留原始纹理名及数值精度；生成 MAP 时使用明确的 mapversion。

## 参考

* [Valve MAP 文件说明](https://developer.valvesoftware.com/wiki/MAP_file_format)
* [TrenchBroom](https://trenchbroom.github.io/manual/latest/)
* [FGD 文件格式](/appendix/resources/formats/fgd.md)
