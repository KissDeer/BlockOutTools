> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。本页的 Markdown 版本见 [appendix/resources/formats/mdl.md](https://book.leveldesignbook.com/appendix/resources/formats/mdl.md)。

# MDL 文件格式

如何解析 Quake 1 模型（`.MDL`）以及在 3D 中渲染模型的 C 源代码

{% hint style="info" %}
*本页是 David Henry 的归档文章* [*“MDL file format (Quake's models)”*](http://tfc.duke.free.fr/coding/mdl-specs-en.html)*的镜像，发表于 2004 年 12 月 20 日，使用* [*GNU Free Documentation License*](https://www.gnu.org/licenses/fdl-1.3.html)*授权。*
{% endhint %}

## 概览

Quake MDL 是一种用于角色和动画模型的二进制格式。文件包含头部、皮肤、纹理坐标、三角形和帧数据。读取时先检查版本与标识，再依据头部字段分配数组并读取后续数据。

## 头部

头部包含标识、版本、缩放与平移向量、边界盒、模型名称、皮肤尺寸、皮肤数量、顶点数量、三角形数量和帧数量。不同字段的字节大小和顺序必须严格遵循格式，不能按平台默认结构布局直接猜测。

## 皮肤、顶点和三角形

皮肤通常是 8 位索引颜色数据。纹理坐标记录接缝信息；三角形记录正面标记和三个顶点索引。每个帧包含类型、边界盒、16 字节名称和压缩顶点。顶点通过头部的缩放与平移还原到模型空间。

## 动画与渲染

逐帧读取模型后，可以根据当前帧和下一帧插值顶点与法线。渲染器需要处理背面接缝的纹理坐标，并使用 Quake 调色板将皮肤索引映射为颜色。读取失败或索引超出范围时必须释放已分配资源。

## 示例代码

原文包含完整的 C / OpenGL 示例，实现 `ReadMDLModel`、`FreeModel`、`RenderFrame`、帧插值、动画、窗口初始化和 GLUT 事件循环。示例代码应作为格式参考使用，并根据现代 OpenGL、平台字节序和安全的文件读取方式进行改写。

## 另见

* [MDL file format (Quake's models)](http://tfc.duke.free.fr/coding/mdl-specs-en.html)
* [Quake 资源](/appendix/resources/quake.md)
