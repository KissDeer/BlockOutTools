> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [appendix/resources/formats/fgd.md](https://book.leveldesignbook.com/appendix/resources/formats/fgd.md)。

# FGD 文件格式

Quake 时代关卡编辑器的实体定义文件 / 制图辅助格式

**FGD** 是多种 Quake 时代关卡编辑器工具（例如 [TrenchBroom](/appendix/tools/trenchbroom.md)）使用的通用文本文件格式，用于定义实体。

**实体**基本上是任何不是静态世界几何体的游戏对象：NPC、物品、灯光、声音、门、玩家出生点等。任何能够移动、改变或产生反应的东西都可以是实体。

注意，FGD 只是增加模板和文档的编辑辅助文件。**它本身不会实现引擎中的任何游戏功能。**它的作用只是帮助关卡设计师理解和配置对象。严格来说，为某个游戏制图并不需要 FGD；理论上，你可以手动记住并验证全部关卡脚本数据。

&#x20;    *有关常见游戏对象类型和行为的更多信息，请参阅* [*脚本*](/process/scripting.md)*。*

{% hint style="info" %}
本页假定你对常见的 Quake 制图术语有一定了解。
{% endhint %}

## 历史

FGD 是 “Forge Game Data” 的缩写。这个名称源自这样的历史：Half-Life 2 的关卡编辑器 Hammer 曾经是 Half-Life 1 的编辑器 Worldcraft，而在更早之前，Worldcraft 又是名为 Forge 的 Quake 工具。

由于多家工作室、引擎和编辑器工具都使用过 FGD，所以 FGD 存在多种不同的“方言”。例如，Valve 添加了语法，以支持 Source 引擎独有的实体输入 / 输出脚本系统。**FGD 没有正式的文件规范标准。**

本页介绍 [TrenchBroom](/appendix/tools/trenchbroom.md) 用于 Quake 1 / Half-Life 引擎的核心 FGD 语法。

## 语法（基础）

FGD 是基于文本的格式。我们建议使用 UTF-8 编码以支持更多语言。TrenchBroom 要求使用不带 [BOM](https://en.wikipedia.org/wiki/Byte_order_mark) 的 UTF-8。

每个实体条目都遵循以下模式：

```clike
// comments begin with "//"
@EntityType EntitySettings() = EntityClassName : "In-Editor Help"
[
    propertyKey(propertyType) : "In-Editor Name" : defaultValue : "In-Editor Help"
]
```

下面是一个简单的实体示例：一个宽 32 个地图单位、高 64 个地图单位，并带有一个名为 “Health” 的属性的僵尸 NPC：

```clike
@PointClass size(-16 -16 -32, 16 16 32) = monster_zombie : "A humanoid zombie with 100 health (default)."
[
    health(integer) : "Health" : 100 : "Initial health points. Set to -1 to make the zombie start sleeping."
]
```

注意，编辑器内的帮助文本非常重要。应向关卡设计师说明不明显的重要功能，并提供建议或技巧。

### 实体类型与设置（基础）

FGD 有三种核心实体类型：**point（点）**、**solid（实体）**和 **base（基类）**。

* **`@PointClass`** 开始定义点实体，例如 NPC 或灯光
  * **`size`**`(minX minY minZ, maxX maxY maxZ)`\
    表示点实体的轴对齐包围盒（AABB）大小，由两个三维向量定义：最小范围（最小角点）和最大范围（最大角点）
  * **`model`**`(path, skin, frame, scale)`\
    为实体显示 3D 模型。这可能有些复杂，见[为实体显示模型](#为实体显示模型)。
* **`@SolidClass`** 开始定义笔刷实体，例如 worldspawn 或 func\_wall
* **`@BaseClass`** 开始定义实体基类模板；可以让实体“继承”一个公共基类。&#x20;
  * **`base`**`(BaseClassName1, BaseClassName2, ... )`\
    设置实体包含所列基类……也可以让一个基类包含另一个基类，因此这个功能相当强大且实用，但要小心递归。

例如，如果游戏中的所有怪物都有生命值，就可以创建一个带有生命值属性的 Monster 基类，然后让所有怪物类型包含这个 Monster 基类：

```clike
@BaseClass = Monster
[
    health(integer) : "Health" : 100 : "Initial health as a percentage."
]

@PointClass base(Monster) size(-16 -16 -32, 16 16 32) = monster_zombie : "Humanoid zombie"
[
    // zombie will automatically inherit the health property from MonsterBase
]

@PointClass base(Monster) size(-32 -32 -64, 32 32 64) = monster_troll : "Big melee monster"
[
    // troll will automatically inherit the health property from MonsterBase
]
```

### 实体属性（基础）

实体属性是带类型的键值对，遵循以下通用模式：

**`keyName(type)`**` ``: "In-Editor Display Name" :`` `**`defaultValue`**` ``: "In-Editor Help"`

* **键名：**类似变量名，通常是小写字符串
  * 有时以下划线开头，表示这是编译时属性，不会出现在游戏中
* **类型：**有四种（4 种）基本属性类型：`string`、`integer`、`choices`（多选整数[枚举](https://en.wikipedia.org/wiki/Enumerated_type)）和 `flags`（位掩码）。
  * **`flags`** 是一组布尔值（真 / 假），通过数学运算的魔法以单个数字存储（[位掩码](https://en.wikipedia.org/wiki/Mask_\(computing\))）
  * 在大多数关卡编辑器中，一个实体只能有一个 flags 属性，而且它必须名为 *“spawnflags”*
* **值：**关卡设计师在关卡编辑器中输入的任何内容

下面的笔刷实体定义展示了全部四种属性类型：

```clike
@SolidClass = func_door : "A simple sliding door"
[
    // note that there is no defaultValue specified below; default is optional
    targetname(string): "Name" : : "Named doors won't open automatically. Leave blank to open automatically."
    
    speed(integer): "Move Speed" : 60 : "How fast the door opens / closes, in map units per second."
    
    _shadow(choices): "Cast Shadows" : 1 : "Should the door block light? default: On" =
    [
        0 : "Off"
        1 : "On"
        2 : "Two Sided"
        3 : "Shadows Only" 
    ]
    
    // in most level editors, flags type MUST be called "spawnflags"
    spawnflags(flags) =
    [
        1 : "Starts Locked" : 0
        2 : "Starts Open" : 0 
    ]
    // a flag follows this syntax:
    // PowerOfTwoNumber : "Flag Label" : DefaultBoolValue
]
```

### 为实体显示模型

如果 FGD 文件指定了模型，TrenchBroom 可以为点实体显示 3D 模型。这对放置 NPC 或装饰物很有用，因为预览模型的大小、旋转和外观会很方便。

* TB 使用 Asset Importer（AssImp），对大多数 3D 格式（.OBJ、.FBX 等）提供基本支持。
* 对于 Quake .MDL 或 Half-Life .MDL 等特定模型格式，还可以根据实体属性切换纹理或预览动画帧。用法见下文。

{% hint style="warning" %}
请记住，**`model()`** 只适用于 TrenchBroom，在其他编辑器中不一定有效。
{% endhint %}

最基本的硬编码用法如下：

<pre class="language-clike"><code class="lang-clike"><strong>// this path depends on base Game Path in Game Configuration - https://trenchbroom.github.io/manual/latest/#game_configuration
</strong><strong>// as well as the Mod Configuration - https://trenchbroom.github.io/manual/latest/#map-setup
</strong><strong>model("path/to/model.file")
</strong></code></pre>

下面是来自 [Quake.FGD](https://github.com/TrenchBroom/TrenchBroom/blob/master/app/resources/games/Quake/Quake.fgd) 的硬编码模型示例：

```clike
// "monster_ogre" inherits BaseClass "Monster", size 64x64x88, model path "progs/ogre.mdl"
@PointClass base(Monster) size(-32 -32 -24, 32 32 64) model("progs/ogre.mdl") = monster_ogre : "Ogre" []
```

不过，把模型设置硬编码到 FGD 中，对于可替换的“装饰物”实体，或具有多种皮肤、脚本动画的 NPC 来说可能限制太多。

为了支持**由地图按实体定义模型显示设置**，TrenchBroom 可以解析带有类 JSON 语法（花括号、带引号的命名参数）的**动态 FGD 占位符**：

```clike
model({ "path" : MODEL, "skin" : SKIN, "frame": FRAME, "scale": SCALE })
```

将 “MODEL” 或 “FRAME” 等替换为你想使用的键值属性名称，TrenchBroom 就会将占位符替换为实际值。

下面是使用占位符的通用“装饰物”实体示例：

```clike
@PointClass size(-16 -16 -16, 16 16 16) model({ "path": model }) = prop_static : "Static Prop" 
[
	model(String) : "Model file path" : : "Set this to a 3D model file."
]
```

下面是来自 [HalfLife.FGD](https://github.com/TrenchBroom/TrenchBroom/blob/master/app/resources/games/Halflife/HalfLife.fgd) 的占位符示例：

```clike
// note: this is simplified from the actual FGD
@PointClass base(Monster) size(-16 -16 0, 16 16 72) model({ "path": "models/hgrunt.mdl", "frame": sequence }) = monster_human_grunt : "Human Grunt (camo)" 
[
	sequence(Choices) : "Animation Sequence (editor)" : 0 =
	[
		0 : "walk1"
		1 : "run"
		2 : "victorydance"
	]
]
```

TrenchBroom 的 FGD 方言还支持**条件表达式**。下面是一个带表达式的示例：

```clike
// if entity property "big" is "true" then use a different model spec
model({{
    big == "1" -> { "path": "zombie_big.mdl", "skin": 0, "frame": 13, "scale": 2 },
                  { "path": "zombie.mdl" }
}})
```

关于占位符和表达式的更多信息，请参阅 [Trenchbroom 手册 > “Display models for entities”](https://trenchbroom.github.io/manual/latest/#display-models-for-entities)。

{% embed url="<https://trenchbroom.github.io/manual/latest/#display-models-for-entities>" %}

## FGD 资源与链接

### FGD 示例

* [TrenchBroom 默认内置 FGD（通过 GitHub）](https://github.com/TrenchBroom/TrenchBroom/tree/master/app/resources/games)

### 编写 FGD

* [Valve Developer Union：**“Anatomy of an FGD (and How to Write Your Own)”**](https://valvedev.info/guides/anatomy-of-an-fgd-and-how-to-write-your-own/) 是很好的入门介绍
* [Valve Developer Union：**“Advanced FGD Editing Made Easy”**](https://valvedev.info/guides/advanced-fgd-editing-made-easy/) 展示实用技巧
* [Valve Developer Community：**“FGD”**](https://developer.valvesoftware.com/wiki/FGD) 详细介绍 Source Engine 1 特有的 FGD 扩展和问题……不过对 TrenchBroom 没什么用

### FGD 解析器

* **C++ FGD 解析器示例：**[TrenchBroom（通过 GitHub）](https://github.com/TrenchBroom/TrenchBroom/blob/master/common/src/IO/FgdParser.cpp)
* **C# FGD 解析器库：**[Sledge.Formats（通过 GitHub）](https://github.com/LogicAndTrick/sledge-formats/blob/master/Sledge.Formats.GameData/FgdFormat.cs)
