> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。本页的 Markdown 版本见 [appendix/tools/trenchbroom.md](https://book.leveldesignbook.com/appendix/tools/trenchbroom.md)。

# TrenchBroom

这款现代笔刷式关卡编辑器工具的信息与资源

[**TrenchBroom**](https://kristianduske.com/trenchbroom/)（也称 TrenchBroom 2 或 TB）是一款免费、开源、跨平台的 3D 关卡编辑器，使用现代化的 Quake 风格笔刷建造方式，并持续更新和维护。它广泛用于多个模组社区和商业项目。

## 安装

从[官方网站](https://trenchbroom.github.io/)或 [GitHub Releases](https://github.com/TrenchBroom/TrenchBroom/releases) 下载对应系统版本。首次启动时设置 Quake 或其他兼容游戏的 Game Path，再设置 Mod Configuration。

## 基础工作流

1. 创建地图并选择游戏配置。
2. 用笔刷建立墙、地板和天花板。
3. 使用顶点编辑、剪切、复制、旋转和吸附工具塑造空间。
4. 放置实体、灯光、出生点和纹理。
5. 编译地图，在目标引擎中运行并[试玩](/process/blockout/playtesting.md)。

## 重要资源

* [TrenchBroom 官方手册](https://trenchbroom.github.io/manual/latest/)
* [GitHub 仓库](https://github.com/TrenchBroom/TrenchBroom)
* [Quake 资源](/appendix/resources/quake.md)
* [FGD 文件格式](/appendix/resources/formats/fgd.md)

## 注意事项

TrenchBroom 的笔刷、实体、FGD 和编译器是不同层次的工具。FGD 只帮助编辑器显示实体模板和说明，不会实现游戏功能。发布地图前，检查编译日志、文件路径、纹理、实体属性和目标引擎版本。
