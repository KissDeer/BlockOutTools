> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。本页的 Markdown 版本见 [appendix/tools.md](https://book.leveldesignbook.com/appendix/tools.md)。

# 工具

各种关卡编辑器、可制作模组的游戏、引擎和美术工具链接

这里同时列出现代和古老的关卡设计工具：

* [**现代 3D 游戏引擎**](#现代-3d-游戏引擎)：今天常见的通用引擎工具
* [**可制作模组的游戏（推荐）**](#可制作模组的游戏推荐)：适合“认真”进行关卡设计的短名单
* [**可制作模组的游戏（全部）**](#可制作模组的游戏全部)：已知带模组工具的游戏列表
* 另外还有：[2D 关卡编辑器](#2d-关卡编辑器)、[3D 美术工具](#3d-美术工具)、[2D 美术工具](#2d-美术工具)和游戏行业常见的[规划工具](#规划工具)

## 现代 3D 游戏引擎

如今的游戏引擎很少默认包含完整关卡设计工具，因此应预期使用**自定义插件**或 [TrenchBroom](/appendix/tools/trenchbroom.md) 等**外部工具**。许多开发者也使用 [3D 美术工具](#3d-美术工具)制作[模块化套件](/process/blockout/metrics/modular.md)。有关 3D 建造技术和取舍，参见[白盒](/process/blockout.md)。

| 引擎 | 3D 建造工具 / 插件 | 脚本 | 社区 |
| --- | --- | --- | --- |
| [Godot](https://godotengine.org/) | [Func_Godot](https://github.com/func-godot/func_godot_plugin)、[Cyclops](https://github.com/blackears/cyclopsLevelBuilder)、[CSG](https://docs.godotengine.org/en/stable/tutorials/3d/csg_tools.html) | [GDScript](https://docs.godotengine.org/en/stable/tutorials/scripting/gdscript/gdscript_basics.html)、[C#](https://docs.godotengine.org/en/stable/tutorials/scripting/c_sharp/index.html) | [Godot Community](https://godotengine.org/community) |
| [Unreal](https://www.unrealengine.com/) | [Scythe](https://scytheeditor.com/)、[CubeGrid](https://docs.unrealengine.com/5.3/en-US/cubegrid-tool-in-unreal-engine/)、[Modeling Mode](https://docs.unrealengine.com/5.0/en-US/modeling-mode/) | [Blueprint](https://docs.unrealengine.com/en-US/Engine/Blueprints/index.html) | [Unreal Slackers Discord](https://unrealslackers.org/) |
| [Unity](https://unity.com/) | [ProBuilder](https://docs.unity3d.com/Packages/com.unity.probuilder@6.0/manual/index.html)、[Tremble](https://assetstore.unity.com/packages/tools/level-design/tremble-map-importer-277805)、[RealtimeCSG](https://github.com/LogicalError/realtime-CSG-for-unity) | C#、[Visual](https://docs.unity3d.com/Packages/com.unity.visualscripting@1.9/manual/index.html)、[Playmaker](https://hutonggames.com/) | [Official Unity Discord](https://discord.com/invite/unity) |

## 可制作模组的游戏（推荐）

制作游戏模组时，你可以重新利用图形、声音、代码，最重要的是核心游戏设计和调优。**我们强烈建议通过制作模组来学习关卡设计。**

**我们通常推荐 Quake 和 Doom**，因为它们有庞大活跃的社区、免费稳定的跨平台工具和经过验证的设计。推荐编辑器包括 Quake 的 [TrenchBroom](https://kristianduske.com/trenchbroom/)、Doom 的 [GZDoomBuilder](http://devbuilds.drdteam.org/doombuilder2-gzdb/) 和 [SLADE3](http://slade.mancubus.net/)，以及 Half-Life 2 / Team Fortress 2 的 [Hammer++](https://ficool2.github.io/HammerPlusPlus-Website/)。

| 游戏 | 编辑器 / 社区 | 战斗 / 脚本 |
| --- | --- | --- |
| Quake 1 | [TrenchBroom](https://kristianduske.com/trenchbroom/)，见 [Quake 资源](/appendix/resources/quake.md) | 静态；可视化实体或 QuakeC |
| Doom | GZDoomBuilder、SLADE3；[Doomworld](https://www.doomworld.com/) | 静态；ACS |
| Half-Life 2 | Hammer++；RTSL、MapLabs、TWHL | 静态 / 脚本；I/O |
| Counter-Strike 2 | Hammer 2；Mapcore、Steam Workshop | PvP；JavaScript |
| Portal 2 | Puzzle Maker；Steam Workshop | 可视化 |
| Team Fortress 2 | Hammer++；tf2maps | PvP；I/O |

{% hint style="info" %}
[战斗](/process/combat.md)模式：

* **静态：**预先放置敌人，街机式，“开火后不管”
* **脚本：**预先放置敌人，并对 AI 行为有一定控制
* **动态：**高层“导演”自动管理敌人
* **PvP：**战斗围绕其他玩家展开
{% endhint %}

## 可制作模组的游戏（全部）

以下游戏不属于推荐列表，原因可能是社区已经消失、游戏过旧 / 不受支持 / 破损 / 使用痛苦，或被行业视为“不正统”。但你的热情最重要。**最好的工具，就是你真正会用来完成项目的工具。**

可探索的工具还包括 Call of Duty、Crysis 2、The Dark Mod、Divinity: Original Sin 2、Doom 3 / 2016 / Eternal、Fallout 4、Far Cry 5、F.E.A.R、Fortnite、Gears of War、Half-Life 1、Halo Infinite、Left 4 Dead 2、Metro Exodus、Minecraft、Prodeus、Quadrilateral Cowboy、Quake 2 / 3 / 4、Roblox、Shadowrun、Skyrim、Stalker、Thief 1-3、Unreal Tournament 1999 / 4。具体编辑器和社区链接可能随游戏版本变化。

## 2D 关卡编辑器

如果引擎已有内置 2D 编辑器，通常就使用它。自定义引擎或网页项目则可能需要独立工具，常见选择是 [Tiled](https://www.mapeditor.org/) 或 [LDtk](https://ldtk.io/)。此外还有 Godot TileMaps、Unity Tilemaps / Sprite Shapes、Unreal Paper2D，以及简单而稳固的 [Ogmo](https://ogmo-editor-3.github.io/)。

## 3D 美术工具

**我们不推荐用 3D 建模工具建造关卡**，但很多人确实这样做。通常推荐免费的开源 [Blender](https://www.blender.org/)，也可以使用 Maya、3ds Max、Modo、Houdini、ZBrush 等商业工具。美术工具适合制作资产和模块化套件；关卡编辑器通常更适合处理碰撞、实体、脚本和试玩。

## 2D 美术工具

Photoshop、Krita、GIMP、Aseprite 和 Affinity Photo 都可用于纹理、概念图、图标和参考图。选择取决于格式、预算、工作流和团队协作。

## 规划工具

纸笔、白板、图像编辑器、表格、流程图工具和个人 wiki 都很有用。工具不应取代思考；先确定要回答的问题，再选择能让信息容易修改和共享的工具。
