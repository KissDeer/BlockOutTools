> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [master.md](https://book.leveldesignbook.com/master.md)。

# 《关卡设计之书》

《关卡设计之书》以易于理解、与时俱进且具有批判性的方式，汇集了 3D 电子游戏的关卡设计知识，面向所有经验水平和所有游戏引擎的设计师。

{% hint style="danger" %}
**本书仍在大幅建设中。**结构可能会频繁变化，有些页面目前可能只有很少内容，甚至没有内容。
{% endhint %}

## 最近更新

* 2025 年 11 月：小幅整理了[工具](/appendix/tools.md)和 [TrenchBroom](/appendix/tools/trenchbroom.md)
* 2025 年 1 月：新增[推荐演讲](/appendix/resources/talks.md)

## 阅读本书

<table data-view="cards"><thead><tr><th></th><th></th><th></th><th data-hidden data-card-target data-type="content-ref"></th><th data-hidden data-card-cover data-type="files"></th></tr></thead><tbody><tr><td><strong>什么是关卡设计？</strong></td><td>从这里开始阅读！</td><td></td><td><a href="/introduction.md">什么是关卡设计</a></td><td><a href="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MaE772K0MViEPpgnix1%2F-MaE7KkewAoItNRLzmYC%2FLDB_AndrewYoder_doorproblem_foothold_mapcontrol.png?alt=media&amp;token=760dc20b-ee3d-407b-ae72-6db411790c6f">LDB_AndrewYoder_doorproblem_foothold_mapcontrol.png</a></td></tr><tr><td><strong>如何制作一个关卡</strong></td><td>工作流程概览</td><td></td><td><a href="/process/overview.md">如何制作一个关卡</a></td><td><a href="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LtwoKZ58xOGNTn9g_Qy%2F-Ltwq-JcDDEN7UHH9OLR%2Funcharted4_blockout_em_schatz.jpg?alt=media&amp;token=fe61470c-d734-4540-ab8e-a83eb330da7d">uncharted4_blockout_em_schatz.jpg</a></td></tr><tr><td><strong>研究</strong></td><td>对关卡进行批判性文章与设计分析。</td><td></td><td><a href="/studies/overview.md">第三册：研究</a></td><td><a href="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F71IOKqvDrGKYrwOpgaAA%2FLDB_DarkSouls_UndeadBurgDiagram1_path1-2.jpg?alt=media&amp;token=12284585-6d1e-4d0c-9e37-223372bf79f8">LDB_DarkSouls_UndeadBurgDiagram1_path1-2.jpg</a></td></tr><tr><td><strong>工具</strong></td><td>关卡编辑器和可修改游戏列表</td><td></td><td><a href="/appendix/tools.md">工具</a></td><td><a href="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M2UXP5KgHS8jIc1HmOj%2F-M2UpvIOHBKtFSvq_cGL%2FLDB_ValveHammerEditor35_ValveWiki.png?alt=media&amp;token=ffaee266-e14a-4007-af38-539663a2a5fa">LDB_ValveHammerEditor35_ValveWiki.png</a></td></tr><tr><td><strong>资产与资源</strong></td><td>免费 2D/3D 资产、信息、其他书籍等的链接</td><td></td><td><a href="/appendix/resources.md">资产与资源</a></td><td><a href="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MbP02oa-qIyy5tjCgbG%2F-MbP6Rdo6HOddzlUrPo1%2FLDB_ModularGraybox_Transparent_JoelBurgess_Skyrim.png?alt=media&amp;token=4a1cd17d-c36a-4edd-bb5f-2c457385153c">LDB_ModularGraybox_Transparent_JoelBurgess_Skyrim.png</a></td></tr><tr><td><strong>给教育者的笔记</strong></td><td>教学建议，以及如何在课堂中使用本书</td><td></td><td><a href="/learning/notes.md">给教育者的笔记</a></td><td><a href="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FUZYFaPCUFEvOrKvMlMSe%2FLDB_PinupPhoto_SarahLeClerc_PrattArchitecture.jpg?alt=media&amp;token=4d449dba-77c8-41e5-9257-5d87ba76dba9">LDB_PinupPhoto_SarahLeClerc_PrattArchitecture.jpg</a></td></tr></tbody></table>

*本在线书籍依据* [*知识共享署名-非商业性使用-相同方式共享 4.0 国际许可协议（CC BY-NC-SA 4.0）*](https://creativecommons.org/licenses/by-nc-sa/4.0/)*，永久免费开放阅读。我们永远不会出售本书，也不会设置付费墙。如果你翻译本书的部分内容，不得出售译本或译本的访问权限。更多信息见我们的* [*许可与版权*](/appendix/license.md)*页面。*
