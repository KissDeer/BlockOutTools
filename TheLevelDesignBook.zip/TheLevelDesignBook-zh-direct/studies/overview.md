> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [studies/overview.md](https://book.leveldesignbook.com/studies/overview.md)。

# 如何研究一个关卡

对有影响力 / 有趣的地图和关卡进行细读与研究

在**案例研究**中，作者会分析一个可游玩的关卡或地点。&#x20;

优秀的案例研究会找出设计的优点与缺点，考虑典型的玩家行为，并将其与其他关卡和游戏进行比较。这些设计评论文章展示了如何应用本书[流程](/process/overview.md)部分的大量概念。

&#x20;   *关于我们推荐的方法，参见* [*研究*](/process/preproduction/research.md)*。*

{% hint style="warning" %}
本部分尚未充分发展，因为我们目前的重点是完成[**第一册：流程**](/process/overview.md)。
{% endhint %}

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F71IOKqvDrGKYrwOpgaAA%2FLDB_DarkSouls_UndeadBurgDiagram1_path1-2.jpg?alt=media&amp;token=12284585-6d1e-4d0c-9e37-223372bf79f8" alt=""><figcaption><p>《黑暗之魂》不死聚落第一区域的遭遇战设计分析，完整研究见：<a href="/studies/sp/undead-burg.md">不死聚落（《黑暗之魂 1》）</a></p></figcaption></figure>

## 单人研究

分析各种单人地图，通常强调[节奏](/process/preproduction/pacing.md)、[叙事](/process/env-art/storytelling.md)和[遭遇战设计](/process/combat/encounter.md)。

{% content-ref url="/pages/-MauFMANR47PctM95IOh" %}
[单人研究](/studies/sp.md)
{% endcontent-ref %}

## 多人研究

分析多人地图和空间，通常强调[布局](/process/layout.md)、[动线](/process/layout/flow.md)和[地图平衡](/process/combat/balance.md)。

{% content-ref url="/pages/-MauFaZuiLDXyBi\_Pw1E" %}
[多人研究](/studies/mp.md)
{% endcontent-ref %}

## 现实世界

从关卡设计的角度分析现实世界（“IRL”）的地点和结构。

{% content-ref url="/pages/-MauFicTSloO6TGx7yBm" %}
[现实世界研究](/studies/irl.md)
{% endcontent-ref %}
