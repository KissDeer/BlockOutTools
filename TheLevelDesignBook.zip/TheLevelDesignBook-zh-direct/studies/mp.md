> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [studies/mp.md](https://book.leveldesignbook.com/studies/mp.md)。

# 多人研究

对各种多人和玩家对玩家（PvP）地图的设计分析与评论

<table data-view="cards"><thead><tr><th></th><th></th><th></th><th data-hidden data-card-target data-type="content-ref"></th><th data-hidden data-card-cover data-type="files"></th></tr></thead><tbody><tr><td><strong>Chill Out</strong>（《光环 1》）</td><td>竞技场射击游戏的布局与房间设计</td><td></td><td><a href="/studies/mp/chill-out.md">Chill Out（《光环 1》）</a></td><td><a href="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FaUXyGVPMwTPaL1PRSFbd%2FLDB_Halo_AndrewYoder_ChillOut1.webp?alt=media&amp;token=34d672f4-d329-43be-a9f0-5a31adbd6745">LDB_Halo_AndrewYoder_ChillOut1.webp</a></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>
