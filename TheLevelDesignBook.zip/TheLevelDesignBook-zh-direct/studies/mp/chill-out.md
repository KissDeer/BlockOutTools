> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。本页的 Markdown 版本见 [studies/mp/chill-out.md](https://book.leveldesignbook.com/studies/mp/chill-out.md)。

# Chill Out（《光环 1》）

小型竞技多人竞技场

## 为什么研究《光环 1》多人游戏？

玩家使用地图上拾取的枪械、物品和强化道具奔跑并攻击其他玩家，先获得 25 次击杀（有时是 50 次）者获胜。死亡后数秒会在随机位置重生，但高水平玩家会研究并利用重生选择算法。相较其他 FPS，《光环》的核心身份来自**漂浮式移动**和**可再生护盾**。

## Chill Out

### 结构

地图由 Rocket、Mid / Bridge、Pink、Gold、Shotgun 和 Spiral 等区域组成。各区域围绕武器价值、跨层视线、循环路线和门 / 传送器相互连接。

### 竞技元游戏

地图控制取决于强力武器、重生位置、路线选择和玩家对空间的记忆。玩家会学习何时争夺火箭筒 / 霰弹枪，何时从中部桥梁转移，以及如何用传送器改变接近方向。

### 门、走廊、传送器与摩擦

门和走廊控制视线与节奏，传送器提供快速但不完全可预测的轮转。狭窄空间会制造摩擦，迫使玩家作出定位和武器选择；过多摩擦则会限制 PvP 反制。

## 社会语境 / 延伸阅读

* [Design in Detail: Changing the Time Between Shots...](https://www.youtube.com/watch?v=8YJ53skc-k4)，Jaime Griesemer，GDC 2010。
* [Halo and Inflexible PvP](https://andrewyoderdesign.blog/2017/12/28/inflexible-pvp/)，Andrew Yoder。
