> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [studies/irl.md](https://book.leveldesignbook.com/studies/irl.md)。

# 现实世界研究

对现实世界建筑和物理空间的设计分析

<table data-view="cards"><thead><tr><th></th><th></th><th></th><th data-hidden data-card-target data-type="content-ref"></th><th data-hidden data-card-cover data-type="files"></th></tr></thead><tbody><tr><td><strong>迪士尼乐园</strong>（美国）</td><td>重新思考关卡设计师看待主题公园的方式。</td><td></td><td><a href="/studies/irl/disneyland.md">迪士尼乐园（美国加利福尼亚州）</a></td><td><a href="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MauGVrCbUVtVRC_MKWx%2F-MauHAn5iIsvLEp4sCKH%2FLDB_Disneyland1963_Map.jpg?alt=media&amp;token=5b210d75-120d-4383-9228-1a2513ec84da">LDB_Disneyland1963_Map.jpg</a></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>
