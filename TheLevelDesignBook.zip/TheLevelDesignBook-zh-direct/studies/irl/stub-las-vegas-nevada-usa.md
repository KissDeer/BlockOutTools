> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [studies/irl/stub-las-vegas-nevada-usa.md](https://book.leveldesignbook.com/studies/irl/stub-las-vegas-nevada-usa.md)。

# （占位）拉斯维加斯（美国内华达州）

关于这座由游戏设计建造的城市的关键关卡设计入门

{% hint style="info" %}
这是一个占位页，提醒作者以后补充内容
{% endhint %}

TODO：总结《向拉斯维加斯学习》
