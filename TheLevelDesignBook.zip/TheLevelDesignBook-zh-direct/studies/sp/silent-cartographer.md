> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [studies/sp/silent-cartographer.md](https://book.leveldesignbook.com/studies/sp/silent-cartographer.md)。

# （占位）沉默制图师（《光环 1》）
