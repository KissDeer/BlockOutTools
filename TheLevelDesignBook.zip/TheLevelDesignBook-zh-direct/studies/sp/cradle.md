> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [studies/sp/cradle.md](https://book.leveldesignbook.com/studies/sp/cradle.md)。

# （占位）摇篮（《神偷 3》）
