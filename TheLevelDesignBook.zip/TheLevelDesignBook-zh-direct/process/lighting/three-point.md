> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [process/lighting/three-point.md](https://book.leveldesignbook.com/process/lighting/three-point.md)。

# 三点灯光

包含三种灯光类型的摄影 / 电影灯光理论

**三点灯光**是电影、戏剧和摄影中使用的灯光设计理论，包含三种不同类型的灯光：&#x20;

(1) **主光**是照亮大部分主体或区域的主要强光源。在大多数关卡中，它通常是方向光（阳光），或具有高衰减常数的明亮强力聚光灯（例如泛光灯）。任务灯。

(2) **补光**会提亮较暗的区域，避免所有内容陷入阴影。为游戏关卡补光时，我们通常使用环境光和漂浮在房间中央的（许多）不可见、柔和、昏暗的点光源；但当你想控制补光方向，例如避免补光溅到天花板上时，宽角度的昏暗聚光灯也很有用。环境光、冲洗光。

(3) **轮廓光**会突出边缘，让前景从背景中跳出来。强调光。

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M5rlFmncyIXoXRqtvCg%2F-M5rldK_iJOJoPaT8y43%2Fimage.png?alt=media\&token=4cd1c32d-6697-415b-acb0-7ac5d2a668c1)

（在人像摄影中，有时还会使用第四种**背景光**，提亮背景，使主光和补光产生的尴尬阴影变得平滑。）

注意，在这个示例中主光和补光大致互相垂直，而轮廓光 / 背光位于主体后方。特别注意灯光的位置和方向！**光源相对于其他灯光的放置位置，决定了它的功能。**

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M5rlFmncyIXoXRqtvCg%2F-M5rlaC0MUadbCSg1V6u%2Fimage.png?alt=media\&token=675a3dc8-656b-48b5-99e7-b666b1a4a6b5)

然而，在游戏中使用三点灯光的最大问题是，它假设你可以完全控制摄像机。如果摄像机由玩家控制呢？&#x20;

三点灯光的类型取决于灯光相对于摄像机的方向——轮廓光之所以是轮廓光，是因为它擦过主体；但如果你从另一个角度接近，就不再有轮廓效果——轮廓光现在变成了主光！如果它从正面看起来像昏暗的阴影剪影，从背面看就会像车灯照到的鹿一样发光。灯光位置很重要，但摄像机位置也很重要。

因此，要在拥有自由移动和自由摄像机的游戏中有效使用三点灯光理论，就需要预测玩家会如何利用两者。

在第一人称游戏中，这意味着大致了解玩家会在哪里行走和观察。幸运的是，我们已经有一个可以限制玩家移动和旋转的工具：那就是你的关卡布局！如果你以某种方式框住主体，或把接近方向限制在某个方向，就可以为那个视角布置灯光。**你的**[**布局**](/process/layout.md)**就是一种灯光工具。**

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M5rlFmncyIXoXRqtvCg%2F-M5rljQiOAZYT4u23XSA%2Fimage.png?alt=media\&token=23c2840a-b830-41ef-a359-425cfe695111)

### 电影式灯光

游戏中最常见的三点灯光用法，是为**过场动画 / 场景中的角色打光**。因为在过场动画中你拥有更多的摄像机控制，所以应该借鉴更多电影灯光技术——因为你基本上是在制作一部电影。

TODO：总结 Derek L. Brand 的这些电影灯光速查表文字；他是 Double Fine《脑航员 2》的资深概念艺术家 <https://twitter.com/DerekLBrand/status/1440089196467609608>

![使用主光为角色打光，Derek L. Brand 为《脑航员 2》制作的内部文档 https://twitter.com/DerekLBrand/status/1440089196467609608](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mk6R8h09gAalQRyIOXT%2F-Mk6RvVsxbLNWd_T9hjc%2FLDB_Psychonauts2_Lighting1_DerekBrand.jpg?alt=media\&token=5d141450-b698-49a7-a687-bb07121a06a0)

![使用补光为角色打光，Derek L. Brand 为《脑航员 2》制作的内部文档 https://twitter.com/DerekLBrand/status/1440089196467609608](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mk6R8h09gAalQRyIOXT%2F-Mk6S08Y-1L7vPDGVpCA%2FLDB_Psychonauts2_Lighting2_DerekBrand.jpg?alt=media\&token=ca07f3ec-af1c-4f71-8332-c173f9c1a8e3)

![通过曝光和明度分析打光，Derek L. Brand 为《脑航员 2》制作的内部文档 https://twitter.com/DerekLBrand/status/1440089196467609608](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mk6R8h09gAalQRyIOXT%2F-Mk6S5Yuc4ohVDq5LUzY%2FLDB_Psychonauts2_Lighting3_DerekBrand.jpg?alt=media\&token=8bec9ef1-2186-4fba-b935-a004f7beb1eb)
