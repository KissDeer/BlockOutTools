> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [process/lighting/darkness.md](https://book.leveldesignbook.com/process/lighting/darkness.md)。

# 为黑暗打光

如何为夜晚 / 黄昏场景打出黑暗氛围，同时保持可读性

为夜晚或阴影重重的低光环境打光时，游戏开发者通常遵循电影行业的惯例（[“好莱坞式黑暗”](https://tvtropes.org/pmwiki/pmwiki.php/Main/HollywoodDarkness)）：**让它*****感觉*****黑暗，但不要真的把它做得很暗。**&#x20;

早期电影制作人使用“日拍夜”技术拍摄夜景：清晨拍摄，再用蓝色滤镜人为压暗画面。如今，人工灯光和更好的摄影机意味着现代电影制作人也可以进行“夜拍夜”。一些摄影指导（例如《利刃出鞘》（2019）的 [Steve Yedlin](https://twitter.com/steveyedlin/status/1201278088794923008)）甚至会结合两种技术，把日拍夜和夜拍夜的镜头合成在一起，创造印象派式的外观。

如果我们用漆黑的黑暗“准确地”照亮关卡，玩家就看不见该往哪里走，并会感到沮丧。

&#x20;*本页建立在主[灯光](/process/lighting.md)页面的术语和概念之上。*

## 通用夜景设置

在现实中，月光是白色的（太阳反射的光）……在电影和游戏中，月光偏蓝。满月会投下清晰锐利的阴影，阴云密布的夜晚则几乎没有阴影

补光 = 没有阴影、衰减柔和、昏暗而微妙的蓝色点光源

不要把平坦的环境光施加到所有阴影上；你需要让**一些**阴影归于 0% 的纯黑，否则就没有利用完整的动态范围。使用有方向性的环境光

记住：不要依赖深色反照率纹理来压暗场景！让灯光制造黑暗感。如果把阴影烘焙进纹理，纹理会更难复用和重新打光，而且你会被迫把灯光调到过亮的范围来补偿。

使用轮廓光强调剪影，同时让主体的大部分保持在阴影中

过度依赖蓝色时，“蓝橙配色”很常见，但尝试通过引入第三种颜色或调整色相范围，避免千篇一律的蓝橙配色

![《守望先锋 2》“Numbani”的不同灯光场景情绪板，图片作者：Fabien Christin（来自 PlayOverwatch.com）](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FYuZ03kyIfuuhQHxILase%2FLDB_Overwatch2_Numbani_LightingScenarios.jpg?alt=media&amp;token=0ac49298-8aff-45b5-9aca-2827299acde2)

在上面《守望先锋 2》的图片中，注意夜景灯光场景（右下）的亮度、对比度和色彩调色板。是什么让夜景感觉像夜景？

* 它实际上相当明亮；让它感觉黑暗的是增强的对比度和高光
* 相比明亮的地平线，角色是更暗的剪影
* 它不只是无聊的蓝橙配色；其中混合了大量紫色和黄色

## 阴影设计

![James Gurney 的阴影图，出自 https://gurneyjourney.blogspot.com/2010/02/light-and-form-part-1\_15.html](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MDGMBCgIsDexaRfEThI%2F-MDGMgoSaS_REtGHsivE%2FJamesGurney_LightShadowDiagram.jpg?alt=media\&token=2a9bc34f-a5ed-4fa8-9bb8-d335829e3687)

## 反对游戏中的“好莱坞式黑暗”

以“好莱坞式黑暗”风格为游戏打光，会产生更精致的商业感，与流行的主流视觉文化相匹配。

和电影一样，有些艺术家会故意避免这种风格及其含义。如果这种氛围不适合项目的体验目标（也就是你想制作令人不安、困惑、突兀或视觉上实验性的内容），那么可以忽略本页的大部分建议。

### 作为机制的灯光

大量使用动态灯光和手电筒的游戏，尤其是恐怖游戏，可能希望有选择地让高张力场景进入漆黑状态。

## 来源 / 延伸阅读

* [**《如何为黑暗打光｜5 个电影摄影技巧》**](https://www.youtube.com/watch?v=rNggiaosjuw)是摄影指导 Valentina Vee 制作的、关于夜景和制作设计灯光的优秀 15 分钟入门。虽然她关注电影行业技术，但其中许多视觉思维适用于游戏。
* [**《在 Source 2 的 Hammer 中为夜景打光》**](https://www.youtube.com/watch?v=xks0kAeSW9Q\&list=PLdY77XvZ-l20ZeYtAtYx7n-wOHxkyQGog)是一套 4 集、总长 3.5 小时的视频系列。环境美术师 [Helder Pinto](https://www.helderpinto.com/)（《孤岛危机》《守望先锋》）在其中为一条葡萄牙街道制作夜景灯光，并提供大量讲解。他的许多工作流程针对 Source 2 的 Hammer 工具，但总体思路适用于任何工具或引擎。
