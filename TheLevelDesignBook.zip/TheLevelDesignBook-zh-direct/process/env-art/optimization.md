> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。本页的 Markdown 版本见 [process/env-art/optimization.md](https://book.leveldesignbook.com/process/env-art/optimization.md)。

# 优化

如何让环境美术和关卡在目标硬件上运行得更快

## 先测量

不要猜。使用统计信息和 profiler 找到真正的瓶颈，再决定改什么。性能通常受 CPU、GPU、内存、加载时间或网络影响；优化一个不是瓶颈的系统不会带来收益。

## CPU 瓶颈

可能是活动对象 / NPC 太多、脚本失控，或关卡本身太大。减少活动对象，重做过于复杂的遭遇战，调试脚本，并确认问题不是一般游戏代码造成的。

## GPU 瓶颈

可能是灯光、环境资产、材质 / 着色器太复杂，或关卡太大。减少灯光，关闭不必要的阴影，合并相同材质对象，使用 GPU instancing 和遮挡剔除，简化材质并减少纹理采样器与渲染命令。

## 环境美术检查

* 为资产制作合适的 LOD 和碰撞。
* 控制材质数量、纹理分辨率和透明材质。
* 用实例化与模块化套件减少重复数据。
* 使用可见性、流式加载和区域分割控制同时存在的内容。
* 在目标平台和真实游戏视角下测量，而不是只在编辑器视口中判断。

## 延伸阅读

* [Optimizing and Profiling Games with Unreal Engine 4](http://vincentloignon.com/blog/optimizing-and-profiling-games-with-unreal-engine-4/)
* [UE4 - Overview of Static Mesh Optimization Options](https://www.casualdistractiongames.com/post/2017/01/07/ue4-overview-of-static-mesh-optimization-options)
* [Unreal Art Optimization: Measuring Performance](https://unrealartoptimization.github.io/book/process/measuring-performance/)
* [UE4 Graphics Profiling: Measuring Performance](https://www.youtube.com/watch?v=SXLYy6D1y80)
