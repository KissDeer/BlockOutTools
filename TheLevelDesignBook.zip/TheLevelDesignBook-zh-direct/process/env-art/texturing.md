> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。本页的 Markdown 版本见 [process/env-art/texturing.md](https://book.leveldesignbook.com/process/env-art/texturing.md)。

# 纹理制作

用二维图像覆盖三维表面

## 什么是纹理 / 材质？

**纹理**是包裹在 3D 对象上的二维图像，例如动物皮肤或墙纸。关卡通常使用**环境纹理**覆盖游戏世界中的地板和墙面。

**材质**是一组纹理贴图和表面设置。常见的四类贴图是：

* **漫反射 / 反照率：**表面的基础颜色；透明材质还可把透明度遮罩放进 alpha 通道
* **法线 / 凹凸贴图：**编码微小细节、划痕和凹陷
* **高光、光泽、粗糙度、平滑度、金属度：**影响亮度与反射
* **环境光遮蔽（AO）：**使阻挡光线的接缝、裂缝和凹槽变暗

## 世界纹理

**世界纹理**是覆盖关卡几何基础的可重复平铺图像，是主要的地面和墙面纹理。好的世界纹理应在近、中、远距离都可读，既有趣又不会分散注意力，能支持（或按设计目标妨碍）寻路，平铺时没有不可信接缝或刺眼重复，并匹配底层[体块](/process/blockout/massing.md)和[世界构建](/process/preproduction/worldbuilding.md)。

岩石纹理需要特别规划。构造力量会形成独特的悬崖形状与层理，纹理结构应反映地质并强调几何形状。低多边形悬崖可以用有明显裂缝和层次的纹理打破简单形状，但不能让纹理与体块矛盾。

## 墙面纹理

许多墙面纹理设计为水平平铺，不一定能垂直平铺。顶部和底部的边缘细节可以强调墙与天花板、地板的交界，模拟环境光遮蔽和污垢堆积。中段保持相对朴素，就能根据墙高添加或删除中段重复。模块化纹理更灵活。

### 面板与 Trim Sheet

模块化建筑的面板可以共享一张纹理。绘制各面板边缘的污垢、阴影和磨损，能强调独立性并减少重复感。**Trim Sheet** 将多个相关子纹理组合在一起，便于重复使用，但它不是魔法，反而要求模型 UV 和应用规则更加准确。

## 如何制作纹理

纹理美术是需要多年学习和练习的独立技能。常见流程包括手绘、照片来源、雕刻烘焙和程序化纹理合成。如今 Substance Designer 是行业中主要的环境纹理工具之一：艺术家通过节点图连接采样器和操作，程序化生成多种纹理贴图与变体。相较手绘，它便于随时以更高分辨率重新采样，也能复用节点图。

## 如何应用纹理

* 先建立适合关卡的材质调色板。
* 对复杂地形可使用三平面投影，减少 UV 接缝。
* 注意纹理方向和对齐，但不要为了绝对对齐牺牲整体可读性。
* 用[模块化套件](/process/blockout/metrics/modular.md)和材质变体平衡重复与独特性。

## 延伸阅读

* [Polycount Wiki：Texture types](http://wiki.polycount.com/wiki/Texture_types)
* [The Ultimate Trim: Texturing Techniques of Sunset Overdrive](https://www.gdcvault.com/play/1022324/The-Ultimate-Trim-Texturing-Techniques)
* [Trim Sheet Detailed Breakdown](https://medium.com/@legacykraft/trim-sheet-detailed-breakdown-bd35c78d16c3)
