> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [process/blockout.md](https://book.leveldesignbook.com/process/blockout.md)。

# 白盒

如何通过体块、尺度规范、寻路与引导和试玩测试，制作关卡的基础 3D 版本。

## 为什么要制作白盒？

**白盒**（也称 **blockmesh** 或 **graybox**）是使用简单 3D 形体搭建的关卡 3D 粗稿，不包含任何细节或精致的美术资产。&#x20;

目标是为关卡的基础形状制作原型、进行测试并加以调整。

在下面的图片中，注意白盒版本和最终发布版本之间的差异。一个形状可能从灰色方块开始——经过数月的[试玩测试](/process/blockout/playtesting.md)和[美术处理](/process/env-art.md)后，这个方块可能变成一堆木桶……也可能被彻底删除。

![《使命召唤：现代战争》（2019）“Docks”的白盒与最终美术处理对比，作者：Brian Baker](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M-8CjOctRDm_ccN4vu9%2F-M-8Dt4KaPpenMXMsARp%2Fblocktober_CodMW2019_Docks_BrianBaker.jpg?alt=media\&token=194299e3-8f7f-438b-8295-6b1a5a149975)

白盒**支持实验**。&#x20;

删除或重建一些粗糙的白盒几何体很“便宜”，但扔掉已经完成[美术处理](/process/env-art.md)的工作就很“昂贵”且浪费。&#x20;

当你还不确定关卡结构时，最好让它保持“便宜”，直到它准备好变得“昂贵”。

你不能试玩一份设计文档或布局草图，**但可以试玩白盒**，并评估它的[动线](/process/layout/flow.md)、[平衡](/process/combat/balance.md)、[遭遇战设计](/process/combat/encounter.md)和[尺度规范](/process/blockout/metrics.md)。这是设计阶段中你终于开始发现这些想法是否可行的时刻。白盒只是开始。

> *“……如果我们考虑到《Neon White》发布时有 100 多个关卡，团队实际废弃的关卡数量是这个数字的‘两倍’，仅 [Smackdown] 这一个关卡就经历了 50 多次修改，那么整个游戏中就有数千次调整和重新设计。\[...] 三年后，Smackdown 完成了。”*
>
> *——摘自* [*《一个 Neon White 关卡是如何制作的》*](https://www.gameinformer.com/feature/2022/11/25/how-a-neon-white-level-is-made)*，Blake Hester，《Game Informer》第 350 期*

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FYgg5qtTDgMUTwNahZRZ2%2FLDB_NeonWhite_Blockout_GameInformer.jpg?alt=media&amp;token=1eef8217-5311-437c-b58d-17e7b9fa868f" alt=""><figcaption><p>《Neon White》（2022）中“Smackdown”的早期白盒，作者：Ben Esposito、Russell Honor 和 Carter Piccollo <a href="https://www.gameinformer.com/feature/2022/11/25/how-a-neon-white-level-is-made">（来自《Game Informer》）</a></p></figcaption></figure>

## 核心概念

制作白盒时，考虑以下方面：

* [**体块**](/process/blockout/massing.md)是形状传达出的总体积感和重量感。
  * *这个结构是厚 / 重，还是薄 / 轻？这是怎样的地方？*
  * [景观](/process/blockout/massing/landscape.md)需要特别考虑。
  * [构图](/process/blockout/massing/composition.md)目前在当今的关卡设计文化中被过度强调。
* [**尺度规范**](/process/blockout/metrics.md)是关卡的总体尺度、尺寸和比例。&#x20;
  * *这个区域太大还是太小？玩家能进入这个房间吗？*
  * 有用的测量示例：[Doom 尺度](/process/blockout/metrics/doom.md)、[Quake 尺度](/process/blockout/metrics/quake.md)&#x20;
* [**寻路与引导**](/process/blockout/wayfinding.md)是玩家了解地图结构的导航过程。
  * *如何帮助玩家找到* [*关键路径*](/process/layout/flow.md#critical-path) */ 关卡出口？玩家是否感到太迷路？*
* [**试玩测试**](/process/blockout/playtesting.md)是进行实验、确认关卡是否达到设计目标的过程。
  * *大多数玩家能完成关卡吗？这些* [*遭遇战*](/process/combat/encounter.md) *有效吗？它是否* [*平衡*](/process/combat/balance.md)*？*
  * 试玩测试非常重要。这正是制作白盒的全部意义。

{% embed url="<https://www.youtube.com/watch?v=5Cv30vCgPso>" %}
白盒示例视频——[“《神秘海域：失落遗产》——火车关卡早期原型”](https://www.youtube.com/watch?v=5Cv30vCgPso)，作者 Matthew Gallant
{% endembed %}

## 构建方法

游戏中有 5 种常见的 3D 关卡构建方法：

* **基本形体：**排列立方体和方盒等简单形状。
* **笔刷 / 建模：**在关卡编辑器中构建 3D 形状。
* **模块化套件：**像拼乐高一样连接预制部件。
* **雕刻：**“绘制”有机 3D 形状，适合景观。
* **样条：**创建数学曲线，让其程序化生成几何体

### 基本形体

**基本形体**是简单的 3D 形状，比如游戏编辑器内置的默认灰色立方体和方盒。&#x20;

移动 / 旋转 / 缩放这些形状。把它们排列在一起、上下堆叠，组成更复杂的形状集合。&#x20;

这是一个出人意料地强大的白盒方法。任何 3D 引擎或工具都能使用这种方法，但当你试图白盒简单方形建筑之外的内容时，就会遇到限制。&#x20;

<details>

<summary>使用基本形体制作白盒的建议……</summary>

注意[**尺度规范**](/process/blockout/metrics.md)**，**建立尺度很难。

制作**坡道**：制作一个又长、又宽、又薄的立方体，然后旋转它使其向下倾斜。制作**楼梯**：别受罪了，直接用坡道代替

制作**门口**：在两面墙之间留出空隙，不需要门框。制作**窗户**：留出类似门口的空隙，然后用一面齐腰高的矮墙填上

</details>

![Francis Ching 的体块尺度图，出自《建筑：形式、空间和秩序》](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M0ee4eVuNuFAVpXzg-K%2F-M0efIvq7LPUjG7M4Osu%2FFormSpaceAndOrder_Dimensions_FrancisChing.png?alt=media\&token=cd5d2b5b-adcc-4f4d-86de-05a11d1dfb65)

### 笔刷 / 建模

**笔刷**是在关卡编辑器中制作的简单低多边形 3D 形状。&#x20;

这是 1990 至 2000 年代整个行业的主要关卡构建方法。&#x20;

我们强烈推荐这种方法，因为它提供了最多的控制和手工感；但遗憾的是，大多数现代游戏引擎的笔刷建模工具往往很差，因此很难摸索出合适的工作流程。

<details>

<summary>使用笔刷 / 低多边形制作白盒的建议……</summary>

使用强调低多边形几何体的**3D 建模工具**。

* Unity：[ProBuilder](https://unity.com/features/probuilder) 还可以，但 [SabreCSG](https://assetstore.unity.com/packages/tools/modeling/sabrecsg-level-design-tools-47418) / [RealtimeCSG](https://realtimecsg.com/) 更专注
* Unreal：使用 [CubeGrid](https://docs.unrealengine.com/5.3/en-US/cubegrid-tool-in-unreal-engine/) + [建模工具](https://docs.unrealengine.com/5.3/en-US/modeling-tools-in-unreal-engine/)（或 [Mesh Tool](https://www.unrealengine.com/marketplace/en-US/product/mesh-tool)）
* 如果引擎可以使用 `.MAP` 或 `.BSP` 文件，就使用 [TrenchBroom](/appendix/tools/trenchbroom.md)

根据[尺度规范](/process/blockout/metrics.md)使用**大而粗的网格尺寸**，具体以*玩家宽度*为依据。

* [Doom](/process/blockout/metrics/doom.md) 或 [Quake](/process/blockout/metrics/quake.md)：玩家宽度为 32u = 将网格设为 32 或 64
* Unity：玩家宽度为 1m = 将网格设为 1 或 2
* Unreal：玩家宽度为 60uu = 将网格设为 50 / 100，或 64 / 128

</details>

![在 TrenchBroom 中使用“笔刷”进行简单 3D 建模；GIF 演示：Benoit “Bal” Stordeur](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MGiaafOL1SFz9zF9aNV%2F-MGieDp2Fm8LbDvJ1WXD%2FTrenchbroom_Bal_CreateVerts.gif?alt=media\&token=d4b48e7b-24d3-4031-a6e5-0e5d2169c7bf)

### 模块化套件

从**模块化部件**套件中拼接预制建筑部件。&#x20;

但如果套件设计糟糕或配置不当，就会很难使用。如果你是初学者，可能不该尝试制作自己的套件——先下载一个吧。

&#x20;   *关于模块化套件的规划、测量和构建，参见* [*模块化套件设计*](/process/blockout/metrics/modular.md)*。*

&#x20;   *免费模块化原型套件的下载链接，参见* [*资源*](/appendix/resources.md)*。*

<details>

<summary>使用模块化套件制作白盒的建议……</summary>

**配置网格并打开网格吸附**（操作方法：[Unity](https://docs.unity3d.com/Manual/GridSnapping.html)、[Unreal](https://docs.unrealengine.com/4.27/en-US/BuildingWorlds/LevelEditor/Viewports/ViewportToolbar/)）

* 使用依据模块尺寸设置的大而粗的网格
* 例如，如果墙体模块宽 5m，就把网格设为 5

使用**顶点吸附**精确对齐模块（操作方法：[Unity](https://docs.unity3d.com/Manual/PositioningGameObjects.html)、[Unreal](https://docs.unrealengine.com/4.26/en-US/Basics/Actors/Transform/)）

直接**下载预制套件**。

</details>

![用于制作《上古卷轴 V：天际》关卡原型的“灰盒”模块化套件，图片作者：Joel Burgess](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MbP02oa-qIyy5tjCgbG%2F-MbP6Rdo6HOddzlUrPo1%2FLDB_ModularGraybox_Transparent_JoelBurgess_Skyrim.png?alt=media\&token=4a1cd17d-c36a-4edd-bb5f-2c457385153c)

### 雕刻

大多数现代引擎都有**雕刻工具**，可以让你绘制和变形一块平面。&#x20;

我们只用它制作地形和景观等大型平滑形状；它不适合建筑等硬表面。

但如果景观是项目核心，就无法避免雕刻。

&#x20;   *关于雕刻和设计地形的更多内容，参见* [*景观*](/process/blockout/massing/landscape.md)*。*

<details>

<summary>使用雕刻制作白盒的建议……</summary>

**雕刻经常会分散初学者的注意力。**一键制作山脉既有趣又让人产生掌控感，很容易让你忘记做关卡设计。小心！不要让雕刻工具诱惑你！

**使用大笔刷尺寸**，先关注大型核心形状。

使用[设置高度（Unity）](https://docs.unity3d.com/Manual/terrain-SetHeight.html)或[拉平目标（Unreal）](https://docs.unrealengine.com/en-US/Engine/Landscape/Editing/SculptMode/Flatten/index.html)笔刷**定义地面**

先把坡度**雕刻成阶梯状台地**以定义渐变，再进行平滑。

**避免侵蚀 / 自动生成工具，**你需要控制设计。

</details>

![《魔兽世界：军团再临》中纳格兰区域的景观雕刻](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MQA2sisUAlB9q25CfTE%2F-MQAfRAYCcp_SPK5Z06u%2FLDB_WorldOfWarcraft_Nagrand_Editor.jpg?alt=media\&token=12c3c6f6-42e0-4d72-97ce-b2ac6b9f7966)

### 样条

**样条**是沿路径生成几何体的不可见曲线。&#x20;

这些曲线也是*非破坏性的*；你可以随时调整样条并重新生成其几何体。

样条非常适合白盒道路或河流等弯曲的线性形体，还可以自动变形周围的景观。&#x20;

也可以用样条生成非线性区域和建筑，但这种工作流程并不常见，通常需要定制工具。

<details>

<summary>使用样条制作白盒的建议……</summary>

和雕刻一样，**样条经常会分散初学者的注意力。**摆弄样条太有趣了，很容易让你忘记做关卡设计。不要让样条诱惑你！

**样条工具各不相同。**它们直到 2010 年代中期才变得普遍。Unreal 对 [Blueprint 样条](https://dev.epicgames.com/community/learning/tutorials/39/populating-meshes-along-a-spline-with-blueprints)有出色的内置支持。Unity 用户就没那么幸运了，只能尝试 [SplineMesh](https://github.com/methusalah/SplineMesh) 等插件，或者[自己编写样条](https://catlikecoding.com/unity/tutorials/curves-and-splines/)。

**样条不是魔法。**如果你想制作道路、河流或桥梁以外的复杂内容，通常需要定制工具和大量美术支持。

</details>

![在 Unreal Engine 4 中由样条定义、程序化生成的桥梁动画 GIF；作者：Peter Severud（来自 Artstation）](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FhGdbv9as1rObARSizSQ1%2FLDB_UE4_Spline_PeterSeverud-bridge.gif?alt=media&amp;token=3533ad65-dab7-41be-afc5-435f357ec831)

{% hint style="warning" %}
**为什么不使用 Blender、Maya、Max 或 SketchUp 等 3D 美术工具制作白盒？**

人们对此**有争议**。**我们是这样看的：3D 美术工具不允许你调整游戏玩法、碰撞、遭遇战或物品。试玩测试会变慢，频率也会降低。**

*例子：在一款未具名的 AAA 游戏中，移动一块岩石需要一个多步骤、耗时一小时的流程：(1) 加载调试版本；(2) 找到哪个文件包含这个物体；(3) 打开 Maya；(4) 编辑文件；(5) 重新编译游戏；(6) 再次加载调试版本以确认修改。*
{% endhint %}

## 如何制作白盒

下面是一个通用流程。如果你是初学者，或者刚开始一个新项目，试着把所有事情都做一遍。你会逐渐形成自己的流程和风格。

1. **绘制布局**
2. **添加地面、比例参照物和墙体**
3. **试玩测试**
4. **偏离原计划、迭代，再次试玩测试**
5. **重复第 4 步，直到完成**

### **1. 绘制**[**布局**](/process/layout.md)

没有任何计划就制作白盒可能很困难，尤其对于初学者。哪怕简单的涂鸦也能帮上很大忙。

看看下面的布局草图。左图强调每个空间的尺度，中图关注区域之间的关系，右图则是更详细的平面图。任何一种草图都可以发挥作用，都能帮助你规划白盒。&#x20;

画点东西吧！

![示例：三种相似但不同的布局绘图风格，它们或许能帮你规划白盒……任何一种都适合让你开始，尽管画点东西吧](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MJe5grxs_9aB9cQTHIv%2F-MJe8gVOx8EpDXFe1j7R%2FLDB_Blockout_LayoutSketch.png?alt=media\&token=88d63751-302f-4b0e-b967-629600c0a5e7)

### 2. 添加地面、比例参照物和墙体

在 3D 空间的中心附近（0, 0, 0）**创建一块地面**（或一个大的扁平立方体）。&#x20;

使用浅色的带网格原型纹理，这样可以目测尺寸和尺度。这个地面物体会帮助其他关卡几何体“落地”，提供地平线和上下文，让其他内容都能建立在其上。

添加一个**玩家人形比例参照物**来帮助建立尺度。&#x20;

如果没有人形资产，就制作一个大致呈人形的方块作为占位物。比例参照物有助于建立一致性和玩家的通行余量。

&#x20;   *关于常见走廊 / 墙体尺寸和人形尺寸，参见* [*尺度规范*](/process/blockout/metrics.md)*。*&#x20;

&#x20;   *免费原型和白盒纹理的链接，参见* [*资源*](/appendix/resources.md#prototyping-blockout-textures)*。*

![示例：一块灰色地面上站着一个黄色比例参照物](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MJe5grxs_9aB9cQTHIv%2F-MJeAjdNKCAHbaWFL8CD%2FLDB_Blockout_GroundPlaneWithScaleFigure.png?alt=media\&token=0a204b23-9fea-46ec-bb1b-0c0a6ee75711)

**搭建一段墙体**，高度大约是**比例参照物的 150–200%**。

如果你使用现代游戏引擎，尺寸不必精确——这里最重要的是建立比例感。&#x20;

如果你使用[模块化套件](/process/blockout/metrics/modular.md)制作白盒，只要把一个标准墙体模块放在参照物旁边。

**给墙体使用不同于地面的颜色。**颜色和亮度为理解空间由什么组成，以及不同地面和墙体平面之间的关系提供了重要上下文。如果担心颜色过度影响白盒，至少也要使用不同深浅的灰色纹理。

![示例：加入一段高度为比例参照物两倍的白色墙体](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MJe5grxs_9aB9cQTHIv%2F-MJeDELv7F2AvTzb119H%2FLDB_Blockout_WallSegment.png?alt=media\&token=d3ea7bdf-6afb-4cb0-9d4e-ece580a2af0e)

**复制并粘贴墙体**来逐渐扩展空间，直到至少拥有一个房间或走廊。有些工具提供特殊的“复制”或“克隆”命令：在 Hammer 中按住 Shift 并拖动笔刷；在 UE4 中按住 Ctrl+Shift 并拖动墙体物件。

相交没关系。乱一点也没关系。

要制作门口或窗户，只需在墙体之间留下空隙，之后再填充。入口和走廊至少应有比例参照物两倍宽。

![示例：基于第一面墙复制 / 粘贴 / 克隆出更多墙体](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MJe5grxs_9aB9cQTHIv%2F-MJeEYD8eFYH12CCC6WN%2FLDB_Blockout_DuplicateWalls.png?alt=media\&token=93a136db-26fd-4a08-a143-e6d11fa1759b)

### 3. 试玩测试

**进行一次简单的自我试玩：**在游戏引擎中，以完整的玩家重力、碰撞和移动速度**在空间中走动**。&#x20;

白盒的目的就是实验。要验证实验结果，必须测试原型。*不要只在编辑器视图中飞来飞去*，那无法帮助你想象玩家体验。

* [**体块**](/process/blockout/massing.md)**。**关卡的形状合理吗？看起来会让人困惑吗？
* [**尺度规范**](/process/blockout/metrics.md)**。**玩家能通过每一扇门和每一条通道吗？楼梯 / 坡道有效吗？玩家能跳到应该跳到的位置吗？
* [**动线**](/process/layout/flow.md)**。**移动感觉缓慢还是快速，顺畅还是复杂？什么类型的移动最符合你的设计目标？

![示例 GIF：尽快在游戏引擎中走动，试玩半成品空间](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MJe5grxs_9aB9cQTHIv%2F-MJeJ3Z58qdf26qnGLQe%2FLDB_Blockout_WalkAround.gif?alt=media\&token=7e046fea-8dfe-458a-9afd-13e5d76435ab)

### 4. 偏离原计划并迭代

**偏离原计划，并根据试玩测试作出回应。**

99% 的情况下，你的白盒不会通过一次试玩测试原封不动地保留下来。房间会感觉别扭，门口太窄，布局令人困惑。但这正是我们制作白盒的原因！&#x20;

想重建白盒的大部分区域？*去做吧。*想删除整个房间？*删掉。*需要把一个庭院拆成两个较小的区域？*你可以这么做。*&#x20;

![示例：遵循布局草图，加入更多比例参照物，搭建出更多区域](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MJeMC4-hkmZuYJmjtP_%2F-MJeORHBJk5wedNsrlFw%2FLDB_Blockout_Continue.png?alt=media\&token=74bd0d75-3415-4e0e-82fc-8ab2ddae649c)

保持开放心态，听取试玩和走动体验告诉你的事情。&#x20;

**继续添加新的比例参照物、墙体和地面。**

**然后再次试玩测试。**

![示例 GIF：原始白盒感觉太拥挤了，那么拓宽空间并删除墙体怎么样？](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MJeMC4-hkmZuYJmjtP_%2F-MJeV-8_20G-hHvLwdem%2FLDB_Blockout_Iterate.gif?alt=media\&token=11cad130-4fd5-444c-ab92-2764debc514a)

### 5. 继续迭代

保持开放心态，继续这个修改 + 试玩测试的循环。继续开发白盒：搭建，然后在其中走动，再修改，再次试玩……不断重复。这个设计过程叫作**迭代**，因为我们会制作建立在前一版本优点之上的新*迭代版本*。&#x20;

随着你逐渐搭建起越来越多的关卡内容，它随时间发生的变化可能会让你感到惊讶。让地图给你惊喜。

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MJeMC4-hkmZuYJmjtP_%2F-MJeZWyTKE3_-naKWebY2%2FLDB_Blockout_IterateAgain.png?alt=media\&token=95f125da-c5cb-437d-8c6f-87e52a936800)

## 常见白盒问题

* **（最常见）我的白盒感觉太小 / 太大。**
  * 在构建过程中使用更多比例参照物。
  * 更频繁地试玩测试，尽早发现尺度问题。
  * 太大？删除不必要的房间，压缩剩下的内容。
  * 太小？扩展最外侧的墙体，然后扩展中心区域来填满新增空间。
  * 或者删除所有内容，重新搭建。它只是白盒。
* **我感到焦虑，盯着空白的关卡编辑器屏幕，什么也做不出来。**
  * 绘制布局图，然后试着遵循那个计划。
  * 只制作一个简单房间。之后随时可以删除它。重点是摆脱空白页。在绘画中，这叫“激活画布”；在写作中，这叫[“糟糕的初稿”](https://wrd.as.uky.edu/sites/default/files/1-Shitty%20First%20Drafts.pdf)。
  * 去做点别的，之后再回到白盒。

## 白盒示例

### 《Dirty Bomb》的“Castle”（Splash Damage）

![Splash Damage 制作的《Dirty Bomb》Castle 的布局、白盒和最终版本（“Blocktober：Dirty Bomb”）](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MLDeIzewXRUNnJ5PFQB%2F-MLDhORGMq9yBPegLNFd%2FLayoutBlockoutProduction_Castle_DirtyBomb_AnthonyMassey.jpg?alt=media\&token=3c2cd3e0-af4a-43b1-8665-3233a5818ce1)

Splash Damage 的关卡设计师 Anthony “MassE” Massey 为竞技多人团队射击游戏《Dirty Bomb》设计了 Castle 地图。Massey 从现实世界伦敦塔蜿蜒的中世纪街道和类型学中汲取灵感，构思了最初的布局图（上方左图）。但注意，最终白盒（上方中图）与布局不同：曲线更少、90 度角更多，区域也更厚重。布局只是最初的引导。由于这是多人射击地图，设计团队重点围绕移动和战斗[尺度规范](/process/blockout/metrics.md)对其白盒进行了试玩测试：

> “地图尺度总是最难掌握的方面。绘制主要路径并测量这些距离很重要；我们希望玩家从出生到目标点的时间在 8 到 12 秒之间。\[...] 更长的话，玩家重生后还要跑回去，会感到沮丧。另一方面，如果时间更短，地图对 8v8 比赛来说就可能显得太小，导致混乱的游戏体验。\[...] 这一阶段对地图开发至关重要，但我们的团队遵循一条简单的经验法则：如果感觉很长，那就是太长了。”
>
> “考虑[玩家职业]是下一步。我们必须查看战斗距离，让整个武器库都能发挥作用，\[...] 同时确保战斗空间有足够的变化，使[不同能力]都能有效（例如[空袭能力]）。实际上，这意味着要考虑室外和室内区域的比例，确保[专注室外的角色能力]有效。”
>
> ——摘自 [Splash Damage 博客文章《Blocktober：Dirty Bomb》](https://www.splashdamage.com/news/blocktober-dirty-bomb/)

### 《Apex Legends》的“World’s Edge”（Respawn）

![《Apex Legends》地图“World’s Edge”的最终详细白盒（左）和最终美术处理（右）；白盒作者：Rodney Reece](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MO8sJkf5R21JCooOety%2F-MO8uy0cr2ThBu1jW33E%2FWorldsEdge-BlockoutToFinal_ApexLegends_RodneyReece.jpg?alt=media\&token=13d43a80-2f72-4a6d-9629-9183e24f0ac5)

Respawn 的关卡设计师 Rodney Reece 为第一人称大逃杀游戏《Apex Legends》的一张大型竞技多人地图“World’s Edge”制作了白盒。注意，地图从白盒（左）到美术处理（右）发生了巨大变化，不仅是主题发生了变化，布局和构图也发生了变化。

> “最初的想法是让地图被冰雪覆盖。但美术团队想把绿色带进地图，在一次会议中，Robert Taube 提议：如果震中（当时叫作 Frozen Explosion）造成了积雪，会怎么样？
>
> “优秀设计师的关键在于对新想法保持灵活。例如，美术团队提出了圆顶。在我的白盒中，它原本是一座火山。他们提出这个想法后，我调整了设计，把它纳入其中。我必须为它制作新布局，但这让地图变得更好。
>
> “但有时，一些[兴趣点]从一开始就很有趣。在这种情况下，我会对哪些内容可以改变更加坚持。Sorting Factory 就是一个很好的例子。重要的是要明确布局中哪些内容是珍贵的，哪些内容是灵活的。因为这需要一个团队！”
>
> ——[Rodney Reece 的评论（@RodneyReece7）](https://twitter.com/RodneyReece7/status/1336783331711623168)

## 反对白盒？

对于一些项目，传统白盒可能没那么有用。体验可能较少依赖空间设计，而更多依赖[美术处理](/process/env-art.md)。白盒无法验证依赖美术或其他资产的概念。

### 《Firewatch》的垂直切片（Campo Santo）

对于第一人称叙事探索游戏《Firewatch》（2016），开发者 Campo Santo 想把重点放在行走和对话等机制上；游戏概念的主要吸引力在于观看经过美术处理的风景，以及聆听配音对话。按照典型的最佳实践，他们首先制作了一个白盒来测试这些机制是否可行。然而，白盒无法帮助他们回答任何关于玩家体验的问题，因为游戏节奏从根本上说是叙事设计和环境美术问题，而不太是关卡设计问题。传统的白盒流程没有奏效。

根据环境美术师 Jane Ng 的说法，在他们*跳过白盒流程*，转而完成了一个包含美术处理环境和接近最终版对话的垂直切片原型之前，没人能确定《Firewatch》作为一种体验是否“成立”。&#x20;

![“灰盒没有回答任何重要问题”以及 Jane Ng 在 2016 年 GDC 演讲“制作《Firewatch》的世界”中的其他幻灯片](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MJsODeoivwyff8ntbp4%2F-MJsPLWJYvQjvOzsrzqG%2FBlockout_Firewatch_JaneNg_GDC2016.jpg?alt=media\&token=4e93e95d-0dbd-44d4-8444-25fec5e68761)

### 《Untitled Goose Game》的地点勘察（House House）

对于俯视角第三人称潜行解谜游戏《Untitled Goose Game》，开发者 House House 希望在 3D 中创建一个具有真实感的英国村庄。关卡设计师 Jake Strasser 从未去过英国，所以他用偶尔查阅照片参考的方式制作了初始关卡的白盒。但这种先做白盒的方法要求 Strasser 用想象力填补空白——而且因为他没有英国人的想象力，这些空白经常以细微的方式显得不可信或不真实，与他们的意图相悖。传统的白盒流程没有奏效。

因此，Strasser 改用了以[研究](/process/preproduction/research.md)为先的“地点勘察”方法。他通过 Google 街景对英国各地村庄进行详尽的虚拟游览，拍摄了大量照片。Strasser 在游戏中重现了几条村庄街道后，终于确定了适合游戏需求的结构类型，并采用了[奥福德村 Pump Street](https://goo.gl/maps/WAkqYmNRARyAEimi9)那种不寻常的侧街布局。在这里，白盒不再主要是建造空间，而是发现空间。

![“它开始更像一个有着自身特点和历史的独特地点”……出自 Jake Strasser 为 2021 年 GDC 演讲所作的《Google 地图，而不是灰盒：为〈Untitled Goose Game〉进行数字地点勘察》](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MfLamIDFl70FqTdwVLz%2F-MfLqnwVxJhTOa4jEdZf%2FLDB_UntitledGooseGame_ResearchReferenceOrford_GDC2021_Jake.jpg?alt=media\&token=2ac751ed-560a-49c9-9fff-114a6a967f11)

## 回顾要点\...

**白盒**是一个简单但可游玩的、细节极少的关卡“粗稿”。我们保持它简单、块状，以便轻松修改。

你可以使用**基本形体**、**笔刷**、**模块化套件**、**雕刻**或**样条**来制作白盒。最佳技术取决于你的引擎和项目，也可以组合多种技术。

制作白盒的方法：

1. **绘制一张**[**布局**](/process/layout.md)，哪怕很简单
2. 添加**地面、** **比例参照物**和**墙体**。&#x20;
3. 立即**试玩测试**；走动起来感觉还好吗？你现在就需要知道。
4. **偏离**原计划，**迭代并再次试玩测试**
5. **重复第 4 步。**

**最常见的问题是尺度，**尤其是对初学者而言。在游戏中试玩白盒，是了解它感觉太大还是太小的最佳方式。&#x20;

对于某些项目，例如依赖单人美术表现的叙事关卡，白盒可能没那么有帮助。

## 接下来做什么？

* 回顾白盒的[**核心概念**](/process/blockout.md#key-concepts)，例如体块、尺度规范、寻路与引导和试玩测试。
* 完成白盒的搭建和测试后，进行一次[**脚本**](/process/scripting.md)处理或[**灯光**](/process/lighting.md)处理。

### 更多白盒内容

* [GDC 2018：《无形直觉：通过白盒和灯光引导玩家并营造氛围》](https://www.youtube.com/watch?v=09r1B9cVEQY)，作者 David Shaver 和 Robert Yang。这可能是目前最符合行业标准的白盒演讲，展示了 Shaver 在顽皮狗游戏中的白盒示例，以及在 Unity 中制作的提炼示例。不过，它实际更关注[构图](/process/blockout/massing/composition.md)和[寻路与引导](/process/blockout/wayfinding.md)，而不是构建。
* [《Quake 制图技巧：构建布局》（5 分钟视频）](https://www.youtube.com/watch?v=G4tWWiuaF7g)，作者 Michael Markie。从 Quake 1 中一个非常简单的单房间白盒开始，逐步扩展它，让它更适合游玩。注意其中频繁的试玩测试和设计迭代。这是即兴白盒流程、几乎没有前期规划的优秀示例。
