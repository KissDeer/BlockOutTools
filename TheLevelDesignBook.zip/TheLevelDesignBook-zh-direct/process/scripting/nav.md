> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [process/scripting/nav.md](https://book.leveldesignbook.com/process/scripting/nav.md)。

# （占位）导航

NPC 和 AI 在关卡中移动与寻找路径的不同方式

{% hint style="info" %}
这是一个占位页，显然还非常不完整
{% endhint %}

## 什么是导航？

转向与寻路

## 转向

障碍物规避

群集

编队

## 寻路

A 星算法基础

### 节点图

也包括 AI 提示、掩体

### 导航网格

## 如何为关卡准备导航

调试工具（显示目标位置、添加 AI 跟随调试）

Recast 或网格，与手动标注的比较

基础战斗 AI 考量
