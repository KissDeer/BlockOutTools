> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [process/layout.md](https://book.leveldesignbook.com/process/layout.md)。

# 布局

如何绘制关卡的俯视角平面图，以及如何规划动线和类型学

## 为什么要设计布局？

在关卡设计中，**布局**有两个相近的含义：

1. **关卡的整体结构**；*“这个布局太让人困惑了，我不知道该往哪里走。”*
2. **用于规划的概览图**，有时因为从俯视角绘制而被称为“俯视图”；*“你画完布局了吗？我们很快就要制作白盒了。”*

布局图可以简单或复杂、符号化或具象化、抽象或具体。它可以是一张餐巾纸上的涂鸦，也可以是一张详细的平面图，一切取决于需要！&#x20;

**“好的布局图”就是任何能有效传达核心设计的图像。**&#x20;

![这些布局草图风格中，哪一种对你最有效？你需要自己决定](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MJe5grxs_9aB9cQTHIv%2F-MJe8gVOx8EpDXFe1j7R%2FLDB_Blockout_LayoutSketch.png?alt=media\&token=88d63751-302f-4b0e-b967-629600c0a5e7)

{% hint style="warning" %}
但要记住：*计划不是魔法。***布局图无法告诉你关卡是否有效**，只有[白盒](/process/blockout.md)和[试玩测试](/process/blockout/playtesting.md)才能开始回答这个问题。**布局不是关卡**，玩家永远不会游玩你的图纸。
{% endhint %}

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FvaiL2kiODhmiQDGA8cvq%2FLDB_GrandTheftAuto1_PaperPlanning_DMADesign_SteveHammond.jpg?alt=media&amp;token=92890911-141a-4f8c-9253-57a4ed009b46" alt=""><figcaption><p>开发者参考 DMA Design 制作的《侠盗猎车手 1》（1996）纸面世界地图布局，照片来自 Steve Hammond <a href="https://twitter.com/snap2grid/status/1597157105726853121">（来自 Twitter）</a></p></figcaption></figure>

## 布局概念

设计布局时，可以使用以下设计概念：

* [**动线**](/process/layout/flow.md)**是玩家在关卡中移动时的感受。**&#x20;
  * 玩家移动得快还是慢，平稳还是突然？&#x20;
  * 期望的动线取决于[体验目标](/process/preproduction.md#experience-goals)。突然的动线并不一定不好。
  * [**关键路径**](/process/layout/criticalpath.md)是完成关卡的理想路径。
  * [**流线**](/process/layout/flow/circulation.md)是现实世界建筑师思考动线的方式。
  * [**垂直性**](/process/layout/flow/verticality.md)关注如何支持垂直动线。
* [**Parti**](/process/layout/parti.md)**是布局的核心结构 / 主要想法。**
  * 贯穿整个布局的总体概念是什么？
  * 清晰的 parti 能帮助你把注意力放在设计中最重要的部分。
* [**类型学**](/process/layout/typology.md)**关注常见的布局模式和功能。**
  * 简化你思考布局的方式
  * 共享的设计词汇有助于研究其他关卡并进行沟通。

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LtlPYjCZiDNEfuNkXsO%2F-LtlQ-mSeqBgZUkoaUkl%2Fwhiteboard_test_layout_diagrams.png?alt=media\&token=2443ff77-f699-4677-8683-d361e8d0ba50)

## 如何设计布局

没有唯一最佳的布局设计方法。每个人（以及每个项目）都可以用不同方式制作布局。但如果你感到迷茫，可以试着把所有步骤都做一遍：

1. [**前期设计**](/process/preproduction.md)：定义设计目标
2. **Parti 缩略图**：构思核心形状
3. **气泡图**：可视化区域之间的大小 / 动线
4. **平面图**：更详细地绘制具体房间形状
5. **游戏玩法标注**：添加标签和设计笔记

对于小型个人游戏项目，布局规划想做多少就做多少（也可以完全不做）。

对于大型团队项目，可以尝试一起在共享白板上完成所有这些步骤。

![从抽象网格（左）到平面图（右）的绘图迭代，出自 Francis Ching 的《建筑图学》](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LzZhZmYqaSwkImMbDB0%2F-LzZinPa4XWx6zyUCuCG%2Ffrancis-ching_architectural-graphics_floorplan_process.png?alt=media\&token=fe755367-6384-4353-a296-c042380cc135)

### 1. 前期设计计划

没有任何目的就很难设计东西。在[**前期设计**](/process/preproduction.md)阶段，我们会在尝试制作之前，先定义并规划想要制作的内容。

因此，在绘制布局之前，至少要定义一个玩家的**体验目标***。*玩家应该在这个关卡中学会什么、感受什么或做什么？&#x20;

你可以写出具体的体验目标*（“教会玩家如何在科幻下水道中进行 5 分钟的二段跳”）*，也可以写得更抽象*（“感到与自然融为一体”）*。但目标越具体，设计就越容易。

![顽皮狗为规划《最后生还者》（2012）制作的节拍板；来自伦敦维多利亚与阿尔伯特博物馆的“电子游戏”展览](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lu4Y_E2F6Jj22AaTeoF%2F-Lu4cB1iELo7OzM1v7oa%2Fv%26a_lastOfUs_planning_board.jpg?alt=media\&token=db00790c-1290-4394-a553-15c3cc974967)

有了一些目标之后，就可以规划[**节奏**](/process/preproduction/pacing.md)**，**也就是帮助实现体验目标的一系列具体事件和活动。

例如，如果你的体验目标是*“逃离可怕的怪物”*，就需要把这个体验拆分成更小、更具体的**节拍**——例如*“(1) 听见门后传来婴儿哭声；(2) 发现发出婴儿哭声的僵尸熊；(3) 跳出窗户逃离怪物。”*（这个简单计划已经很有帮助了，现在我们知道需要一扇门、一扇窗和一只熊……）

&#x20;   *关于规划体验目标的更多内容，参见* [*前期设计*](/process/preproduction.md)*。*

&#x20;   *关于规划活动和节拍的更多内容，参见* [*节奏*](/process/preproduction/pacing.md)*。*

### 2. Parti 缩略图

在建筑学中，[**parti**](/process/layout/parti.md)是整栋建筑的基本形状 / 基本想法。&#x20;

&#x20;   a. 绘制一张*简单的小图*（**缩略图**）\
&#x20;   b. 用短语给它加标签

什么类型的基本形状符合你的体验目标 / 节奏计划？

Parti 可以是象征性的（“倒置的船”）、抽象的（“挖去一部分的盒子”），也可以关注人们将如何使用建筑（“核心空间隔开公共区域与私人区域”），或者关注建筑与周围环境的关系（“伸入树林的手指”）。&#x20;

当然，你也可以先**凭感觉**使用一些形状，之后再整理。重点是没有压力地开始进行视觉思考。如果你不喜欢某个 parti，也没关系，随手再画一个就好。

![出自 Matthew Frederic《我在建筑学院学到的 101 件事》的 parti 图](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LzZpDQIBkve2Jok4otA%2F-LzZrkmVIyxT5LTr7a9-%2Fmatthew-frederic_parti.jpeg?alt=media\&token=92324602-b21e-4da8-81e8-3b80e5b24a86)

#### **PARTI 缩略图建议**

* **至少绘制 5–10 张缩略图**，生成多种方案。如果你画了 100 个 parti，那么其中至少有一个*会*很好，因为不可能设计出 100 栋糟糕的建筑。画得越多，概率越站在你这边。
* **不要在每张图上花太长时间。**有时你只需要 30 秒随手画几条线，就足以表达核心想法。&#x20;
* **如果你无法给它命名，那它可能还太粗糙。**尝试换一种方式重画，或把纸旋转 180 度，从另一个角度想象它。

### 3. 气泡图

把最有前景的 parti 扩展为**气泡图**：一组不同的椭圆，每个椭圆代表一个房间。

&#x20;   a. 为 parti 的每个部分绘制一个**气泡**\
&#x20;   b. 给每个气泡加标签\
&#x20;   c. 用箭头强调某些连接或方向

气泡图的目标是建立关卡中的**比例**和**关系**。哪些内容需要很大？哪些内容需要相互连接？&#x20;

现在还不用担心细节。这里关注的是空间的逻辑。

看看下面的气泡图示例。哪些空间与客厅相连，为什么？浴室为什么在那里？卧室在哪里？如果有人不能使用楼梯，他要如何在这所房子里生活？

![芝加哥 F10 House 的气泡图示例，出自 Masengarb 等人的《建筑手册：理解建筑的学生指南》](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LzbcXUnIwglq9kzUnHW%2F-Lzinyp86WtIrkGsyOev%2Fcac_bubble_diagram.png?alt=media\&token=8b95bb98-4c5e-4de5-902b-5a9304c5187e)

#### 气泡图建议

你最初画的几张气泡图会有问题，也会提出新的问题。有些气泡会太大或太小，或者会碰到错误的气泡。可能有些气泡是你忘记添加的？也可能气泡太多？

* **坏气泡图也是好事。**这说明你及早发现了设计问题，可以再画一张，尝试另一种排列。
* **至少画 3 张气泡图**，想象多种排列和尺寸。
* **可以偏离 parti。**Parti 的目的是帮助你开始绘制气泡。如果它不再有帮助，就别再使用它。

### 4. 平面图

在建筑学中，俯视角布局图被称为**平面图**。&#x20;

&#x20;   a. 想象一条**平面剖切线**，即穿过建筑的一条假想水平切线\
&#x20;   b. 绘制这条剖切线*下方*的结构形状——墙段、门口、窗户以及重要家具或固定装置\
&#x20;   c. 要绘制剖切线*上方*的相关物体，使用虚线或点划线

在下面的图中，注意 Ching 如何使用不同的线型、线宽、阴影和色调图案来区分平面图的不同部分。Ching 加粗并加深墙体，但使用较细的线标记楼梯或表示房屋区域，使用更淡的线描绘旋转门的弧线。

![出自 Francis D. K. Ching《建筑图学》（第 6 版）的各种平面图绘制技巧](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LzZSwX6ZIpZtHzE19-c%2F-LzZazKGqOwD45_PV8lJ%2Ffrancis-ching_architectural-graphics_floorplan_collage.png?alt=media\&token=ab056328-96f9-4806-a379-fc5d99a99908)

#### 平面图绘制建议

* **从大处开始。**使用整张页面。从大型主要形状开始，逐渐细化到门窗等较小特征。不要一开始就画 100% 的细节。
* **保持方正。**矩形比奇怪的角度或弧形墙更容易建造。约 90% 以上的角应当是 90 度，并与网格对齐。
* **使用 2 种以上的线宽。**用不同线宽表示不同类型的墙。
* **笔比什么都强。**要快速绘制布局，使用笔或铅笔。
* **我们不是建筑师。**只绘制想象玩家体验所需的最少内容。

{% embed url="<https://www.youtube.com/watch?v=y5zZ2hj5tJ4>" %}

### 5. 游戏玩法标注

**标注**并给布局图的重要部分加上标签。

* [**动线**](/process/layout/flow.md)**。**对于单人关卡，绘制或标出[关键路径](/process/layout/criticalpath.md)。对于多人地图，用浅色阴影或高亮标出队伍出生区域和主要[流线](/process/layout/flow/circulation.md)。
* **区域。**标出主要区域和地标。对于竞技多人地图，开始思考可能的[“报点”](https://steamcommunity.com/sharedfiles/filedetails/?id=157442340)。
* **游戏物体。**标出对于理解玩家体验至关重要的目标、NPC、物品、陷阱等。但不要在图上塞入太多内容，让它变得杂乱。

![注意《半条命 2》Nova Prospekt 的这张等距布局图中大量的游戏玩法标注，作者 Eric Kirchmer，出自画册《半条命 2：提升标准》](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mcfk2SN77KBX1CK8_Ov%2F-Mcfkc-6rhzbaWoW__KI%2FLDB_Layout_HalfLife2_RaisingTheBar_Depot_cellblock_2.jpg?alt=media\&token=3eccc748-d463-4cb5-9fac-3cfb560d040b)

![注意《传送门 2》谜题的这张等距布局图中的玩家动线箭头，来自《Game Informer》2010 年 3 月刊](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Ml2lpnxCX2hZnIHlByj%2F-Ml2zDZvGjR_oJNK7OAJ%2FLDB_Portal2_LayoutSketch_GameInformer-March2010.jpg?alt=media\&token=32e7b599-1849-4f53-8be7-3495f6ebbdb5)

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F6Q1Fa1DrEL2Ub8SG20wL%2FLDB_HL2Episode2_Valve_WhiteboardLayoutPlanningDiagram.jpg?alt=media&amp;token=a908acff-6865-4f4c-8cd8-08a37992d7ec" alt=""><figcaption><p>Valve 实际使用的白板，包含等距布局图 + 节奏大纲，用于规划《半条命 2：第二章》……但注意，这张图与最终游戏略有不同；照片作者：Phil Co（<a href="https://www.interlopers.net/articles/phil-co-interview">来自 Interlopers.net</a>）</p></figcaption></figure>

## 布局图示例

### 《半条命 2》的“Nova Prospekt”（Valve），作者 Eric Kirchmer 和 David Sawyer

在单人第一人称射击游戏《半条命 2》（2004）进行到约三分之二时，玩家必须穿过一座名为 Nova Prospekt 的废弃监狱建筑群。这个篇章很长，充满了许多多楼层的近距离战斗遭遇战，敌人是行动迅速的小队；关卡设计让玩家大量使用“虫饵”武器，命令会飞的“蚁狮”怪物攻击敌方士兵。

* [研究](/process/preproduction/research.md)：深受加利福尼亚州旧金山的恶魔岛州立监狱启发
* [类型学](/process/layout/typology.md)：地面竞技场两侧有狭窄的猫道和监狱牢房，并经常设置闸门
* [遭遇战](/process/combat/encounter.md)：按街区、按房间设计，每个部分都有一个核心构想，为整个篇章中的蚁狮与联合军遭遇空间加入新的变化

![画册《半条命 2：提升标准》中恶魔岛地图（左）和 Nova Prospekt 牢房区气泡图（右）](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mcg6-VlseYC-ns17DbS%2F-McgRK6bSk_sfgonL5GJ%2FLDB_Layout_AlcatrazNovaProspekt_HalfLife2_RaisingTheBar.jpg?alt=media\&token=84630ad9-9e9b-44a4-969d-bc80ba3bafdc)

注意 Nova Prospekt 的规划图（上方右图）是一张相对简单的布局图，标出了区域，以及玩家可能如何逐个推进。它省略了每栋建筑内部的单独房间和走廊。这是一组关卡的布局图，而不是单个关卡的布局图。它基本上是一张气泡图，关注每个区域的占地轮廓以及它们之间的连通性。

对于单独的牢房区和遭遇战，Valve 概念美术师 Eric Kirchmer 直接把关卡设计和游戏玩法标注加入概念艺术草图中，这些草图很可能来自团队协作的白板设计会议。这些战斗遭遇战都有预期动线和理想化的关键路径“解法”，把每场战斗都视作待解决的谜题。这些草图为关卡设计师 David Sawyer 制作白盒和原型提供了有价值的设计文档。

在所有等距布局图中，注意大量的游戏玩法标注：玩家起点、关键路径箭头，以及大量帮助我们想象玩家体验的文字标签。

![画册《半条命 2：提升标准》中 Nova Prospekt 各种遭遇战的等距布局图](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mcg6-VlseYC-ns17DbS%2F-McgTM27xWImmn9l9QAt%2FLDB_Layout_NovaProspekt_HalfLife2_RaisingTheBar.jpg?alt=media\&token=fd44ff18-7e36-4917-a74a-dc65b82e030e)

### Quake 1 的“Untitled”，作者 Andrew Yoder

对于自己的单人 Quake 关卡，设计师 Andrew Yoder 反复迭代了一场包含房间中央悬挂笼子的[大型场景]遭遇战。在这里，Yoder 不断流畅地在布局和[白盒](/process/blockout.md)之间切换，有时会丢弃整个房间，再通过布局草图重新审视设计。这里有[他的一些笔记](https://twitter.com/Mclogenog/status/1248992822725926912)：

![Andrew Yoder 提供的带透视图的关卡布局草图（纸上墨水绘制）](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M65Upt-O2b9YwLtNLMw%2F-M65kTuSd3x5liuDdQmB%2FLDB_layout_sketches_AndrewYoder.jpg?alt=media\&token=4e8e94ed-91bc-47e4-9e85-ce4219e6e956)

> “我的流程是迭代，这有时意味着退回规划阶段。\[...] 有时我会花一个小时迭代某个区域，它突然*对了*。另一些时候，我花同样一个小时，却觉得，嗯，也许最好先放下它，尝试别的东西。\[...] 我怎么知道该怎么做？这是过去构建类似关卡的经验带来的直觉。还有一大堆可以用来检查的启发式方法和模式。玩家知道目标吗？他们能预见一个解法并为此规划吗？”

注意其中的编号、大量的笔记、对草图不同部分的标注，以及偶尔使用透视缩略图来澄清总体结构。关卡布局涉及高度变化时，透视缩略图尤其有用，因为高度变化很难从俯视角绘制。&#x20;

各种草图和大量标注帮助 Yoder 传达设计意图。布局过程帮助 Yoder 将设计问题用语言表达清楚。&#x20;

![Andrew Yoder 提供的 Quake 1 悬挂笼区域最终白盒截图](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M65Upt-O2b9YwLtNLMw%2F-M65lv8GFX2o33gRpysG%2FLDB_layout_blockout_AndrewYoder.jpg?alt=media\&token=0418c155-bbc4-40f9-bff5-b7c408d89c72)

### 《看门狗 2》的“Automata - TV Station”（Ubisoft），作者 Iuliu-Cosmin Oniscu

在开放世界黑客游戏《看门狗 2》中，设计师 Iuliu-Cosmin Oniscu 制作了一个包含多个目标、入口和关键路径的任务。&#x20;

在他的文章[《看门狗 2——Automata：关卡设计回顾》](https://medium.com/@iuliu.cosmin.oniscu/watch-dogs-2-automata-a-level-design-retrospective-dcb82040e454)中，他展示了游戏玩法标注很多、建筑内容很少的布局图：

![设计师 Iuliu-Cosmin Oniscu 绘制的《看门狗 2》“Automata”中 WKZ Station 的布局](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M-2PgvTr8Hr7rDfV6BC%2F-M-6peMk53PexgG01tNb%2Fwatchdogs2_oniscu_layout_example.png?alt=media\&token=e107e843-6d4c-4ab3-b1aa-f9497feded2e)

设计师的一些笔记和意图：

> *在这个特定场景中，诀窍在于玩家可以穿过激光触发警报，但也可以：*
>
> * *趁守卫背对激光巡逻时关闭激光，然后进入红色区域并悄无声息地击倒 AI。*
> * *使用安装在墙上的摄像头，通过从一个摄像头视角移动到另一个摄像头视角来侦察地点。在游戏的这个阶段，这已经是侦察室内地点的一种成熟方式。*
> * *使用无人机探索走廊并使守卫失去行动能力。*
>
> *远处的走廊中还有一些战略性放置的接线盒，可以通过黑入让两名守卫同时失去行动能力。*

注意关卡设计师的图（上图）比实际游戏实现（下图）简单得多。建筑细节、家具，甚至中立 NPC 和墙面摄像头等一些游戏玩法元素，都没有出现在布局图中。它们都与通过击倒守卫 NPC 来绕过安保这一核心体验目标的规划无关。&#x20;

这里的启示是：**不要用不必要的设计特征把布局图弄得杂乱。**

![《看门狗 2》“Automata”中完成后的 WKZ Station 大厅玩家视角，作者 Iuliu-Cosmin Oniscu](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M-2LkCYKHYhQy_1XuXO%2F-M-2NsmUiWNyeZVFMzjb%2Fimage.png?alt=media\&token=7139e238-71a5-4f16-8bbe-af3a3d2926d1)

### 《军团要塞：经典》的“Warpath”（Valve），作者 Robin Walker 等

在职业分工式多人射击游戏《军团要塞：经典》（1999）中，“Warpath”是一张控制点（“CP”）地图，由 Robin Walker 和他在 Valve 的团队共同设计。TFC 的 CP 游戏模式与现代《军团要塞 2》或《守望先锋》中的 CP 模式相似，两支队伍争夺中央通道沿线的全部控制点。

* [动线](/process/layout/flow.md)：一条中央通道加侧边路径，共 5 个控制点，带有动态出生房间
* [平衡](/process/combat/balance.md)：对称地图，所有 9 个职业都必须可行，每个 CP 都要支持进攻 / 防守
* [类型学](/process/layout/typology.md)：串珠项链，一条盘绕的长走廊，沿途点缀着每个 CP 的竞技场

![《军团要塞：经典》“Warpath”原始规划与最终关卡布局对比](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mcfk2SN77KBX1CK8_Ov%2F-McfnSGQ1XEdoh3wt1n2%2FLDB_Layout_Warpath_TeamFortressClassic_Comparison.png?alt=media\&token=d9ed50c0-c31c-455f-9532-3ddf5dc65169)

在《半条命 2》画册《提升标准》中，Walker 详细介绍了他们的流程，以及布局图如何融入协作式多人关卡设计工作流程：

> “最初的设计讨论之后，设计组会绘制地图草图，然后由关卡设计师进行搭建。初版完成后，定期试玩测试就开始了。试玩测试周期中进行了许多改动，**经常导致地图原计划发生剧烈变化。**\[...] [Warpath] 是第一张让队伍根据所控制控制区而在不同地点重生的 TF 地图，这导致了漫长的测试周期，出生点被多次移动。”  \
> ——Robin Walker，摘自《半条命 2：提升标准》，第 48 页（强调为本文所加）

在上图中，注意编号的控制点和标注的报点。每个控制点区域都像一个小型竞技场 / parti，并有特定的地标标签：狙击手平台、隧道、石拱门、兵营等。**从一开始就给地图区域命名并确定主题。**标签还突出了对地图体验目标最重要的部分。

还要注意，这张图只展示了地图的一半，对称结构在中央桥处分开。既然他们已经决定地图布局要对称，绘制整张地图就没有必要。**因此，设计约束会影响你绘制布局的方式。**

![中央桥竞技场，从蓝队狙击手平台朝南看；《军团要塞：经典》的“Warpath”](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mcfk2SN77KBX1CK8_Ov%2F-Mcfu3408LoT60uBy6uv%2FLDB_Warpath_TeamFortressClassic_Valve.jpg?alt=media\&token=ed84254d-6c73-4174-a774-ce81e7a6dbc2)

## 反对布局？

虽然布局对关卡设计来说似乎很重要，但许多关卡设计师并不绘制布局，往往会从前期设计直接跳到白盒。反对绘制布局图的理由包括：

* 你不能试玩布局图。
* 图纸是视觉文档，很快就会过时。
* 现实世界的建筑师因为不得不画布局才画布局；我们不应该盲目照搬他们。
* 3D 游戏移动更多依赖直觉，而不是计算。

对于有影响力的 3D 平台游戏《超级马力欧 64》（1996），宫本茂的团队只制作了少量概念艺术 / 布局草图，用来规划主要的节奏节拍：

> #### *……你们制作关卡地图时，会提前绘制模型 / 蓝图吗？*
>
> ***宫本：**其实完全不会。只有一些概念艺术草图，以及简短的笔记 / 备忘录。例如，我会和课程总监 Yoichi Yamada 讨论一个关卡想法，然后他会快速画一些草图。Yamada 不是艺术家，但他画的东西很怪。（笑）然后我们会查看草图并继续讨论（“哦，这里应该有一个雪人！”），再把关卡的关键元素写下来。Yamada 和其他关卡设计师会在使用软件开发工具设计关卡时回头参考这些笔记。*
>
> ——《超级马力欧 64 攻略指南》中的采访（来自 [shmuplations.com](https://shmuplations.com/mario64/)）

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FzaY5nGJuFnSmlmBK4PHY%2FLDB_Mario64_ClayDioramaLayoutBlockout_Shmuplations.jpg?alt=media&amp;token=3868642e-97c0-4ada-abae-4bc2723c178e" alt=""><figcaption><p>杂志跨页扫描图，展示《超级马力欧 64》的<a href="https://www.mariowiki.com/Bob-omb_Battlefield">“炸弹兵战场”</a>关卡泥塑立体模型；它看起来像是提前规划的吗？其实并不是！……出自《超级马力欧 64 完全通关指南》（来自 <a href="https://shmuplations.com/mario64/">shmuplations.com</a>）</p></figcaption></figure>

{% hint style="info" %}

#### 反对“反布局”？

你也可以认为宫本的方法不适用于其他类型、情况或团队。毕竟他们是 12 名彼此了解并信任的资深专业开发者，当然可以不做规划，直接即兴制作小型低多边形单人关卡。
{% endhint %}

## 回顾要点\...

**布局图**（或“布局”）是关卡结构和关键节奏节拍的初始视觉计划。你应该预期最终关卡会大幅偏离它。

1. 从基础的[**前期设计计划**](/process/preproduction.md)开始，定义期望的[体验目标](/process/preproduction.md#experience-goals)和[节奏](/process/preproduction/pacing.md)。
2. 绘制并标注[**parti**](/process/layout/parti.md)**，**即核心形状的简单缩略图。
3. 使用**气泡图**排列空间，强调总体比例和关系。
4. 绘制**平面图**，用俯视角绘制墙体和地面。&#x20;
   * 从大型简单形状开始，省略细节。使用多种线宽并为地面区域添加阴影。
   * 对于有多个楼层的房间，绘制等距视图，注意地面平面。
   * 对重要或复杂的大型场景房间，可以绘制透视图并加上标签。
5. 用玩家动线和游戏玩法笔记**标注**计划。帮助其他人想象体验，尤其是在与他人协作时。
   * 给区域命名并加标签。把关卡的每个片段都视作自己的 parti。

话虽如此，**许多关卡设计师并不绘制布局图**。试试看，如果它能帮助你思考，或者帮助团队沟通，就继续做；但不必强迫自己。

## 接下来做什么？

* 进一步阅读重要的[**布局设计概念**](/process/layout.md#layout-concepts)。
* 继续进入[**白盒**](/process/blockout.md)阶段。

### 布局相关延伸阅读

* [《Warowl 和 FMPone——为了乐趣制图》](https://www.youtube.com/watch?v=5hq4QSttI2k)，作者 3kliksphilip
