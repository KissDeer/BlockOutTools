> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [process/blockout/metrics.md](https://book.leveldesignbook.com/process/blockout/metrics.md)。

# 尺度规范

关卡的比例与距离，以及关卡给人的大小感

## 什么是尺度规范？

**尺度规范**是关卡中距离、尺寸和比例的共同约定。它决定玩家、门、楼梯、房间、掩体和武器看起来是否可信，也会改变移动速度、战斗距离和视线。

不同游戏的单位和角色速度不同，所以不要机械照搬别人的数字。先确定玩家胶囊体、相机高度、移动速度、跳跃能力和交互距离，再从这些值推导空间。

## 尺度参考

建立一套可复用的参考资产：玩家模型、门、楼梯、桌子、墙、掩体和常用房间。经常在编辑器中放置这些参考，以免每个区域都凭感觉重新估计。

尺度不只关乎真实感。较窄的空间会压缩视线并提高紧张感，较宽的空间会增加机动与选择；垂直尺度会改变观察、移动和战斗关系。

## 测量与迭代

记录关键距离：玩家看到入口的距离、遭遇战的交战距离、掩体之间的间隔、跳跃间距和目标到目标的行走时间。用玩家实际移动和试玩验证，而不是只检查编辑器网格。

## 另见

* [Doom 尺度](/process/blockout/metrics/doom.md)
* [模块化套件设计](/process/blockout/metrics/modular.md)
* [Quake 尺度](/process/blockout/metrics/quake.md)
