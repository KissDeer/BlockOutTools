> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。本页的 Markdown 版本见 [process/blockout/metrics/modular.md](https://book.leveldesignbook.com/process/blockout/metrics/modular.md)。

# 模块化套件设计

如何测量和设计模块化套件，即用于建造关卡的 3D 瓦片集

在进行[白盒](/process/blockout.md)或[环境美术](/process/env-art.md)时，你可能会使用**模块化套件**，即一组能够吸附拼接的模块网格。这来自现实建筑中的[预制模块化建造](https://en.wikipedia.org/wiki/Modular_building)。

## 先建立网格

选择一个基础网格单位，并让墙、地板、天花板、门、柱和装饰资产围绕它设计。常见资产尺寸应能整除或组合成基础单位，避免产生无法填补的缝隙。把玩家、门和楼梯作为尺度基准，先验证行走与视线，再制作细节。

## 套件组成

模块化套件应覆盖常见直段、内外角、端部、门窗、楼梯、转角和过渡件。只制作直墙会让关卡重复；只制作独特件则会失去模块化带来的速度。为可见面与背面、碰撞、材质变化和 LOD 设定一致规则。

## 连接与容差

模块的枢轴、碰撞和吸附点必须一致。测试不同组合、旋转、镜像和高度变化，确认没有 z-fighting、缝隙、穿插或不可见碰撞。为美术模块保留比白盒更大的误差容忍度，别让细节资产改变基础可玩空间。

## 另见

* [尺度规范](/process/blockout/metrics.md)
* [《模块化套件设计》推荐演讲](/appendix/resources/talks.md)
