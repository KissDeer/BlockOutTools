> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。本页的 Markdown 版本见 [process/blockout/metrics/quake.md](https://book.leveldesignbook.com/process/blockout/metrics/quake.md)。

# Quake 尺度

用于设计单人 Quake 1 地图的玩家尺寸与速度、生命值和伤害、常见尺寸及建筑尺寸

以下是 Quake 1 关卡设计有用的核心玩法数值。具体引擎、难度和模组可能改变这些值，所以发布前应在目标引擎中验证。

## 玩家参考

玩家碰撞体、视角高度、移动速度、跳跃能力与武器射程共同决定地图尺度。门、走廊、楼梯和房间应以玩家实际能够通过、观察和战斗为准，而不是只依赖编辑器网格。

## 设计参考

* 用标准玩家尺寸检查通道与门。
* 以移动时间和交战距离设计房间，而不是只按面积设计。
* 让生命、护甲、弹药和武器的分布支持遭遇战节奏。
* 在不同方向测试斜坡、升降平台、传送点和水体。

Quake 地图、实体和 QuakeC 资源见[Quake 资源](/appendix/resources/quake.md)。
