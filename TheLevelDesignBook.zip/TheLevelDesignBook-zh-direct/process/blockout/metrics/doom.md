> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。本页的 Markdown 版本见 [process/blockout/metrics/doom.md](https://book.leveldesignbook.com/process/blockout/metrics/doom.md)。

# Doom 尺度

Doom 关卡设计的玩家尺寸、速度、伤害和常见建造尺寸

## 基础参考

Doom 的地图使用整数网格和相对简单的 2D / 2.5D 空间。玩家、敌人、武器和门的尺寸决定了通道宽度、房间大小、视线与遭遇战距离。实际数值会因 Doom 版本、源端口和模组而变化，因此应把下列参考视为起点，并在目标端口中测试。

## 设计提示

用玩家和敌人尺寸建立门、走廊、楼梯、升降平台和掩体的比例。Doom 的高速移动和有限的垂直空间使开阔房间、互相连接的环路和可预测的碰撞尤其重要。不要只按截图判断距离；使用游戏内移动时间和试玩验证。

更多具体的武器、敌人和地图单位数据见原始 Doom 编辑器与源端口文档。相关主页面：[尺度规范](/process/blockout/metrics.md)。
