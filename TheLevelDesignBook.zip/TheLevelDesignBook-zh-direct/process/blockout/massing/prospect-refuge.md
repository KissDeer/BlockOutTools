> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [process/blockout/massing/prospect-refuge.md](https://book.leveldesignbook.com/process/blockout/massing/prospect-refuge.md)。

# 视域与庇护

关于人们如何寻找视野与安全感的心理学 / 建筑学理论

**视域与庇护理论**是建筑学中的一种广泛信念：人类有“天生的欲望”去寻找***视域***（有利视野 / 瞭望点）与***庇护***（能避开威胁和视线的围合处）。

在关卡中，高处平台、宽阔窗边和开阔广场可以提供视域；墙后、屋檐下、洞穴和封闭房间可以提供庇护。二者结合时，玩家能观察空间，同时感到自己受到保护。

## 谨慎使用

不要把理论当作普遍心理规律。玩家可能因为目标、资源、敌人、经验或文化背景而忽略看似安全的地方。视域也可能暴露玩家，庇护也可能限制信息。将视域 / 庇护作为空间机会，而不是行为保证，并通过[试玩测试](/process/blockout/playtesting.md)验证。

## 作为设计工具

在白盒中标记每个重要区域的观察点、隐蔽点、接近路线和危险方向。问：玩家从哪里能看到目标？敌人从哪里能看到玩家？玩家是否有足够的选择来从观察转为行动？

## 另见

* [体块](/process/blockout/massing.md)
* [掩体](/process/combat/cover.md)
* [寻路与引导](/process/blockout/wayfinding.md)
