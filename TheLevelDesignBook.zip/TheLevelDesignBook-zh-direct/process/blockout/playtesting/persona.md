> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [process/blockout/playtesting/persona.md](https://book.leveldesignbook.com/process/blockout/playtesting/persona.md)。

# 玩家画像

对玩家及其动机 / 长期行为进行分类的不同方式

## 什么是玩家画像？

**玩家画像**是玩家长期的行为模式，以及游玩游戏的总体动机。&#x20;

将玩家按不同画像 / 类别分类，有助于你研究玩家并解读[试玩测试](/process/blockout/playtesting.md)数据。

实际上，玩家从来不只属于一个类别。人是由这些动机以及更多动机复杂组合而成的。&#x20;

尽管如此，这种简化的方式仍然有助于做出设计决定，并想象你的受众。理想情况下，每个关卡都能满足每种画像。

（TODO：大幅扩展）

### 游玩风格与玩家画像

## Huizinga 的游戏政治

* 玩家
* 作弊者
* 破坏游戏者

## Bartle 的“玩家心理学”

1996 年的 [Bartle 玩家心理测试](https://en.wikipedia.org/wiki/Bartle_taxonomy_of_player_types)是最早尝试对电子游戏玩家分类的方法之一。Bartle 研究的是早期文本 MMO（称为 [MUD](https://en.wikipedia.org/wiki/MUD)）中的玩家行为，并将这些 MUD 玩家归入 4 个大类：&#x20;

* **成就者**想获得最多分数，最大化游戏进度
* **探索者**想发现新的地点或系统，绘制游戏空间
* **杀手**关注与其他玩家的 PvP / 竞技冲突，有时会不择手段
* **社交者**关注与其他玩家合作、角色扮演和粉丝文化

（TODO：加入四象限矩阵图）
