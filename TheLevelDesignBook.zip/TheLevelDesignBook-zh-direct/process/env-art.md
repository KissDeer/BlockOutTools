> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [process/env-art.md](https://book.leveldesignbook.com/process/env-art.md)。

# 环境美术

在保持清晰度和功能性的同时，细化形状并添加视觉细节

## 什么是环境美术？

**环境美术**（或“env art”）是在保留核心功能和游戏玩法的同时，对关卡或游戏世界进行的装饰性处理。

这项工作包括建立模块、道具、纹理、材质和其他美术资产库，然后通过绘制 / 摆放装饰来对关卡进行**美术处理**，补充底层设计。

![对比关卡设计、Level Design 和环境美术的图示，使用 CCP Games 为《Dust 514》制作的“盖伦特研究设施”过程图](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Maev3jxp4WpKXebg88n%2F-Maf5hE1bqDx4IO2HGuP%2FLDB_leveldesign_env-art_compare.jpg?alt=media\&token=a921482a-e5bf-42f5-83a6-78975cbc4078)

在 2000 年代以前，关卡设计师通常也会制作自己的环境美术。但如今，关卡设计师通常应尽可能少制作视觉美术，而环境美术师通常应等待成熟的[白盒](/process/blockout.md)后再开始进行美术处理。然而，在小团队中，关卡设计师很可能必须寻找或制作自己的环境美术，反之亦然。

这里**我们将关注一般环境美术原则和高层次问题**，帮助关卡设计师更好地理解美术流程并与环境美术师协作。**这不是一本环境美术书。**

&#x20;    *免费纹理、材质和模型的链接，参见* [*资源*](/appendix/resources.md)*。*

&#x20;    *专门的环境美术社区、网站和书籍链接，参见* [*社区*](/appendix/communities.md)*。*

![《狙击精英 4》（2017）“Deathstorm”反复进行白盒和美术处理的过程动画 GIF（来自 Twitter）](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MVOe7gOtBO2fR1OaIjJ%2F-MVOeNGkYd_XvSwlSxn7%2FLDB_Sniper_Rebellion_BlockoutArtpass.gif?alt=media\&token=a10f1d36-1367-4304-b106-8253f9b9ee1a)

## 如何规划环境美术

开始进行美术处理之前，你应该能够回答以下问题：

* *主题。*关卡的时间、气候和地点是什么？
* *游戏玩法。*哪些部分需要强调？哪些应该简单，哪些应该详细？
* *风格。*写实还是风格化？是哪种写实，哪种风格？
* *调色板。*整体色彩是什么，氛围是什么？有哪些形状？
* *制作。*哪些部分需要先做，哪些应该最后做（或者永远不做）？

&#x20; *关于规划的更多内容，参见* [*前期设计*](/process/preproduction.md) *和* [*研究*](/process/preproduction/research.md)*。*

![《最后生还者 第二部》（2020）的内部概念艺术、照片参考和剪影研究，画板作者：John Sweeney](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MEdasubg-PXrYhNytbq%2F-MEdcBcECdGQZHQ0wAT5%2FTheLastOfUsPart2_SantaBarbaraStyleGuide_JohnSweeney.jpg?alt=media\&token=51f23ff7-b6fc-454b-b1bd-12c1c9deae9b)

### 概念艺术

**概念艺术**通常是用于规划游戏、但不会直接用于游戏中的任何视觉艺术。&#x20;

概念艺术有时旨在传达期望的主题或总体氛围，有时则必须传达美术资产的技术规格和细节。问问自己：这份概念艺术是用来提供灵感，还是试图解决某个具体的视觉设计问题？&#x20;

启发性的氛围艺术在前期设计阶段（尤其是向发行商推介商业项目时）或制作早期最有用，但详细的技术美术在制作后期更有用。

{% hint style="danger" %}
**如果你使用了他人的概念艺术，请为其署名**——或者在开始之前联系艺术家并征得许可。如果你正在求职，署名非常重要；大家彼此都认识，不署名会像一个危险信号。
{% endhint %}

![《传送门 2》（2011）“地下金库”环境概念的一张第一人称概念艺术（涂绘？）](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MU_VDqMttTZDcXtyuRZ%2F-MU_YA0GtOY2NPm5i1wj%2FP2_Underground_Concept_Art_1.png?alt=media\&token=22576b90-d3a3-4fa3-b137-a95154b57441)

### 涂绘

**涂绘（paintover）**是一种概念艺术：从 3D 截图开始，艺术家在底层截图上直接“涂绘”，以可视化下一个版本。

在[白盒](/process/blockout.md)截图上进行涂绘，是规划美术处理的非常常见的方法。这个工作流程节省了大量时间，因为艺术家不必手动计算基础形状的透视。因此，即使是 2D 艺术家，也应至少掌握一些 3D 美术工具的基础知识，这样他们就有可能制作自己的白盒来进行涂绘。

有时艺术家会完整渲染一些看起来已经完成的概念艺术（见上图）……但涂绘通常是为了在艺术家之间提供直接反馈：提出修改、纠正和备注（见下图）。

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FjZLL7U9OOYOtRV2vb4NA%2FLDB_TheQuarry_EnvArtPaintover_AdamDencker.jpg?alt=media&amp;token=e007a3bb-4f2c-4405-b898-7d4a3124a2a9" alt=""><figcaption><p>Adam Dencker 为《采石场》制作的带注释涂绘 <a href="https://www.artstation.com/blogs/bronzegear/wdw2/the-quarry-pt6">（来自 Artstation.com）</a></p></figcaption></figure>

### 模型表

**模型表**是面向单个美术资产的一种更具体的概念艺术类型，其中包含供制作美术师参考的正交视图，以及展示该资产应如何在游戏中使用的情境模拟图。&#x20;

在下面的概念艺术 / 模型表中，注意我们如何理解这个八角形冰晶平台模型将如何融入整体环境主题。此外，顶部和底部正交视图回答了道具艺术家关于结构和颜色的问题，还可以轻松带入 3D 建模工具作为参考。正交图强调每个平台的金色边角饰条，而右下角插图展示了边角饰条如何拼接出互锁的视觉效果——这些内容共同帮助环境美术师理解哪些细节很重要，应该在游戏资产中保留并延续。

![Sarah Morris 为《小龙斯派罗：重燃三部曲》制作的概念艺术、模型表和涂绘组合](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MJYbXqtzzgFbu3trUW6%2F-MJYdCmGP_4FmO06YQco%2FConceptArt_Spyro_SarahMorris.jpg?alt=media\&token=2dfd6fe3-45bb-43a9-855b-c64c504fe257)

## 美术资产

经过一些规划后，艺术家会制作美术**资产**——直接插入关卡的视觉物体。与概念艺术不同，这些是游戏引擎必须读取、玩家将在游戏中看到的内容。&#x20;

制作美术资产时，记住以下内容：

* **简报。**任务是什么？这个资产需要做什么？
* **审批。**谁会对这个资产提供反馈？我们如何知道它有效？
* **范围。**制作这个资产需要多少时间？小而罕见的细节应当少花时间。
* **工作流程。**制作这个资产需要多少步骤？使用哪些工具？
* **管线。**如何把美术导出为引擎能够读取的格式？

较长期的项目（6 个月以上）和较大的团队（6 人以上？）应当将美术制作流程正规化，以避免昂贵的返工、浪费和沟通误解。维护电子表格或看板来追踪任务，并让每个资产经过不同的测试和团队审查阶段。所有这些任务追踪一开始可能会让人觉得慢，但从长远看，沟通和清晰度会更快。

&#x20;   *关于组织工作任务和团队沟通的更多内容，参见* [*制作*](broken://pages/-M-a0tN0YseLJA0Q8-po)*。*

![美术制作流程图，包含 3 个审查阶段，出自 Hannah Mackintosh 为 Play By Play 2021 制作的《通过批评同事的所有工作，成为更好的自己》](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MZAvYee4Ae_wPE0Nnn8%2F-MZAzVdyIKv1G212b-Oa%2FLDB_ArtProductionProcess_HannahMackintosh_PBP2021.jpg?alt=media\&token=13b76a1e-db0d-4403-b9b2-f9b4e8ed6ea6)

关卡的大多数美术资产要么是 2D 纹理，要么是 3D 模型，但在本节后面我们也会简要讨论着色器和特殊效果。

### 资产清单

制作环境美术之前，你可能需要制作一份**资产清单**，列出某个场景或关卡所需的所有美术资产。资产清单通常采用某种电子表格格式，列出每项资产的优先级和预计制作时间。

在下面的图片中，艺术家制作了一份按月 / 周分组的资产清单电子表格。他们估计自己每周约有 30 小时工作时间，并优先处理场景白盒 / 最重要的关卡几何资产。基础结构建立之后，才会处理材质和细节道具。

![Vincent Dérozier 通过 ArtStation 制作的 3D 场景“The Grand Bath”的资产清单 / 日历 / “区块计划”](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2Fs3Zcf41Chh2bFFCep5su2%2FLDB_vincent-derozier-vincentderozier-thegrandbatharticle-img05b.jpg?alt=media&amp;token=e797ca3f-82a7-4864-b5bb-03378bf88d37)

### 材质和纹理

**纹理**是覆盖 3D 地图表面的 2D 图像。自 2000 年代以来，我们经常把多张纹理组合成**材质**，即带有粗糙度、光泽度、发光等额外数据的纹理集合。

对于环境美术，纹理设计和布局非常重要。与角色皮肤不同，我们经常在整个关卡中大量重复使用世界纹理。理想的环境纹理需要在许多不同情况下都能很好地工作：它应该能在表面上平铺，同时也能轻松拆分成可复用的部分。

&#x20;   *关于纹理和定义材质的更多内容，参见* [*纹理制作*](/process/env-art/texturing.md)*。*

![《骑马与砍杀》中的中世纪房屋纹理映射](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mc2DVnUe6rFnXE6Pn1f%2F-Mc3zz-DM4QwjzxAUQ3Q%2FLDB_ModularTexture_MountAndBlade_gutekfiutek.jpg?alt=media\&token=8b648318-9bce-4ce4-9532-79434adbc74a)

### 模块化套件

**模块化套件**是由**模块**组成的 3D 瓦片集，模块是设计为以多种方式吸附拼接的环境网格。模块最适合用于经常沿网格重复的建筑和结构，但不太适合有机或自然形状。

&#x20;   *关于如何规划、测量和构建套件，参见* [*模块化套件设计*](/process/blockout/metrics/modular.md)*。*

![重复使用模块化墙段（左）构建圆形房间（右）；示例作者：Lea Kronenberger](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MHHerrgs2nPIQ70JYF0%2F-MHHfVk7B1iz103vfibN%2FLeaKronenberger_ModularAquarium.png?alt=media\&token=044ffcee-dcb1-40a2-8939-e181199a5d2a)

模块化网格无法干净地连接的情况很多，尤其是你脱离网格或使用非 90 度角建造时。尽管如此，你可能仍然希望保留某些角度或奇怪的长度，出于[尺度规范](/process/blockout/metrics.md)的原因，或者为了营造粗粝、脏污、非工业制造的自然感。这种情况下，只需让模块自由相交，再用另一个物体遮盖杂乱的交界。

例如，想象两块矩形地面网格以奇怪的角度相接——尽可能安排它们无缝连接，然后用墙、柱子、岩石、箱子、汽车等遮住交界。问题解决！

![两个模块如何以奇怪的角度连接？直接把杂乱遮住！图片作者：Joe Wintergreen](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MbP02oa-qIyy5tjCgbG%2F-MbP1MY61xgKY_mwqJy4%2FLDB_ModularMeshes_JoeWintergreen.jpg?alt=media\&token=f71a50f4-b28a-420b-84c3-5b718ef45ca0)

### 英雄道具 / 地标

英雄道具 / 英雄建筑应当让关卡中的重要地点落地

不要把英雄资产放在糟糕的位置……不要给垃圾箱来一段吉他独奏，它就是个垃圾箱，继续过你的生活吧

对于多人地图，独特的地标能赋予区域身份，并帮助形成**报点**：玩家可以用来快速谈论地图不同部分的简短、易记昵称。

下面是 Lydia Zanotti 为《Valorant》地图 Breeze 的 B 点制作的英雄资产。巨大的塔楼看起来很重要且仍在使用中，独特的深色金属机械与米色石头废墟形成对比。这种设计支持了游戏背景设定：发光的青绿色物质“辐能”是需要控制的重要资源；同时，它在游戏玩法上让塔楼底部保持空旷，避免分散注意力的形状或剪影。最重要的是，整个地图中只使用它一次，让这个区域显得特殊而独特。

![Lydia Zanotti 为《Valorant》制作的涂绘概念艺术、第一版模型和最终美术处理](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Maemlrnrs4nowWUvJIe%2F-Maenf-2GMcNyr1lfPsO%2FLDB_ValorantArtPass_LydiaZanotti.jpg?alt=media\&token=ccb7a05f-ad7b-49e0-a101-248959568c1a)

### 细节（道具、植被、杂物、场景布置）

#### 树木

![Marie Lazar（pixelbutterfly.com）的《通用植物技巧》教程图](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MJYbXqtzzgFbu3trUW6%2F-MJYm61VZU5mmrqronrM%2FGeneralPlantTips_MarieLazar.png?alt=media\&token=392f29cc-aa28-47eb-b873-3e50413e04ab)

对于高大的森林树木，不要在每根树干上都放树冠，并确保树根处有细节 <https://www.gamasutra.com/blogs/DannyWeinbaum/20170216/291658/Art_Tips_for_Building_Forests.php>

## 可读性

**可读性**关注玩家是否能在关卡中行走，并“读懂”他们正在看的东西。简化玩家必须看到的内容，让它易于理解。&#x20;

目标是让玩家把关卡理解成一个完整的地方，而不是一堆随机地板和墙段。

* 玩家是否有足够信息理解当前游戏状态？
  * 他们能从远处轻松看到敌人 / 游戏物体吗？&#x20;
  * 他们能理解敌人处于待机、警觉还是受伤状态吗？
* 玩家能理解自己可以去哪里 / 不能去哪里、应该去哪里 / 不应该去哪里吗？

关卡刚以抽象[白盒](/process/blockout.md)形式出现时，非常朴素，也很容易读懂。然而，当我们向世界中添加更多视觉细节时，关卡几何体会变得不那么清晰，也更加嘈杂。一个“繁杂”的美术处理关卡会“难以辨读”，很难理解。&#x20;

![《反恐精英：全球攻势》de_cache 的视觉发展和可读性动画 GIF，美术作者：Shawn Snelling，来自 2015 年 GDC 演讲《竞技 CS:GO 的社区关卡设计》](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MR8fRL5joAtwxQl4v1u%2F-MR8hC78BZ5HCKTihHJj%2FLDB_CSGO_de-cache-readability_ShawnSnelling_GDC2015.gif?alt=media\&token=596981b0-d19e-4075-b033-71be1d6788da)

在上面的动画 GIF 中，注意 CS 地图 de_cache 如何从一张拥有阴暗繁杂细节的深色高对比关卡，变成一张更明亮、阴影更均匀、视觉对比度更低的关卡——这种为可读性作出的让步符合这款游戏及其受众。

密室逃脱、找物游戏和道具猎人等游戏，都以解析繁杂拥挤空间的乐趣为核心。然而，《反恐精英》或《Valorant》等快节奏多人射击游戏严重依赖瞬间反应式瞄准和快速判断，这些玩家很可能会把失败归咎于无法读懂的关卡。&#x20;

当你对关卡进行美术处理并添加场景布置时，这些细节的累积会影响玩家对空间的理解。&#x20;

![《最后生还者 第二部》（2020）内部的常春藤可读性风格指南，作者：John Sweeney](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MEdVddyug3bU3Tk5Ibv%2F-MEdXiUXk9J1F0LNQuNE%2FTheLastOfUsPart2_IvyReadabilityStyleGuide_JohnSweeney.jpg?alt=media\&token=21c92616-3df3-4484-9f4c-578de7aa38ed)

例如，在为《最后生还者 第二部》的环境进行美术处理时，顽皮狗的艺术家用常春藤覆盖程度（见上图）表示被忽视、封闭的建筑，同时清除玩家应该进入的开放建筑上的常春藤。还要注意常春藤如何压平立面结构。玩家不再需要检查每扇窗户，猜测它是否可通行或相关——一栋完全被常春藤吞没的建筑意味着它是封闭的，并且会归结为一个绿色色块。因此，常春藤起到了简化视觉环境、为玩家提供导航辅助的作用。只要所有设计师和艺术家都一致地使用常春藤，这种装饰性植被效果就会获得一种超越“电子游戏看起来多么精致昂贵”的新含义。

但秘密在于：一切都是常春藤，*环境美术中的一切都有可读性功能。*当你对关卡的任何部分进行美术处理时，都是在细化帮助玩家推理空间逻辑的视觉模式。

&#x20;    *可读性也很大程度上取决于* [*体块*](/process/blockout/massing.md)*、* [*尺度规范*](/process/blockout/metrics.md) *和* [*构图*](/process/blockout/massing/composition.md)*。*

### 聚簇

为了帮助玩家更容易解析和理解游戏世界，可以尝试把场景布置组成相关细节的聚簇。邻近性、相似性和暗示的连通性会帮助我们把物体看成群组和模式。这对应于一种[格式塔知觉理论](https://en.wikipedia.org/wiki/Principles_of_grouping)。

要制作一片岩石露头，先放一块岩石，然后复制、缩小、旋转并稍微偏移……不断重复。要制作一片森林，先放一棵树，然后复制、缩小、旋转并稍微偏移……不断重复。任何自然场景布置，甚至景观构图，都可以重复这种工作流程。尝试以非对称分形结构构建这些构图，让道具摆放产生重复逻辑和一致性的感觉。

![来自 Anton Lavrushkin《Allods Online》美术圣经的“分形”岩石、树木、地形，甚至水桶聚簇](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MDLePXw3Ye3OrlBz7KR%2F-MDLphnFKdRGmhR28c3X%2FAllodsOnline_Clustering.jpg?alt=media\&token=d10c6c15-aa8c-401f-b969-678b0ca32090)

### 颜色和明度

避免颜色过度饱和，为灯光留出空间……如果你制作一张非常红的纹理，它就没有更多变红的余地了。有些游戏也可能保留特定的颜色编码（只有爆炸桶是红色的！只有门可以是蓝色和橙色的！）

渐变是平滑的（没有噪声），但仍要避免扁平（其中存在层次）。

在下面《守望先锋》“Castillo”地图的示例 GIF 中，注意地面通常比周围墙体暗；墙体纹理很朴素，噪声细节极少；红色和粉色通常保留给地板和屋顶平面。

![Helder Pinto（及其他人）制作的《守望先锋》“Castillo”地图从白盒到美术处理过程对比 GIF](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FOyo51Rroc44MfJRnp5l7%2FLDB_ArtPassBlockout_Castillo_Overwatch_HelderPinto.gif?alt=media&amp;token=75455ccb-09cc-40f2-bbaa-a2df5de29396)

### 材质性

材质是一个具体的技术术语，指导入游戏引擎的一组纹理——但更广义地说，“material”也指**材质性**：视觉表面所表现出的总体感觉、物质、质量和实体。&#x20;

理想情况下，环境纹理应该读起来像一种清晰的现实世界材质。它真的让人感觉是由砖块或岩石构成的吗？它是否太闪亮，无法让人感觉像混凝土？玻璃或木材给人的感觉是脆弱还是坚固？读懂材质通常对游戏玩法很重要；例如，脚步声和子弹穿透是战术射击游戏中的常见机制，依赖玩家理解自己正在行走 / 射击的材质。

作为一般规则，大多数艺术家都努力制作由清晰、独特材质组成的纹理。木材纹理在 50 米外仍然应该看起来像木头，闪亮的金属纹理也应该和闪亮的塑料纹理感觉不同。

&#x20;    *关于纹理和材质的更多内容，参见* [*纹理制作*](/process/env-art/texturing.md)*。*

![不同的世界纹理传达不同的表面属性和材质；纹理作者：Marie Lazar（来自 80 Level）](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MJYbXqtzzgFbu3trUW6%2F-MJYmZOmk-JTX_yMsK8u%2FTerrainTextures_MarieLazar.png?alt=media\&token=dc6f5eb1-ecba-474c-84e0-9374391a2cb0)

### 避免形状和色彩心理学

**形状和色彩心理学**是这样的理论：形状 / 颜色传达普遍性的想法并影响行为。&#x20;

虽然艺术家经常渴望拥有控制他人的秘密力量，但我们认为**形状和色彩心理学对关卡设计没有效果**。抽象的几何形状和颜色本身不会让所有人产生同样的感受，也不会传达同样的想法。这些简单化的理论无法捕捉艺术和文化的丰富复杂性，误解基础心理学，还会遮蔽更有用的设计工具。不使用它们反而更好。

&#x20;   *更多内容参见* [*形状和色彩心理学*](/process/env-art/psychology.md)*。*

## 如何进行美术处理

进行美术处理有许多方法，下面是一些一般建议：

* **迭代式工作，**分阶段进行，不要试图把每个资产都做成 100% 的最终版本。你需要看到美术资产在上下文中彼此如何关联，才能知道某个资产是否“完成”。有时，一个 50% 完成的美术资产被其他美术包围后，实际上已经“足够完成”了。
* **带着重点进行美术处理，**不要随机处理随机区域的随机部分。尝试以具体的部分、具体的方式或主题推动关卡进度，这样你才能获得关于修改的反馈。如果以杂乱、不连贯的方式随意进行美术处理，其他人就更难提供反馈。
* **从大的内容开始，**把小细节留到之后的美术处理中。先定义基础形状和体块、调色板以及主要主题。把所有基础内容做好之后，再去雕刻鹅卵石或绘制污渍痕迹。

对于下面的每个动画 GIF 示例，试着数一数美术处理迭代的次数。

![Kitty Calis（来自 Twitter）发布的 2D 像素游戏《Minit》系列美术处理](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M-evfaxsvlyM7PJms12%2F-M-ewT7nGJ6DE0X95O_G%2FMinit_KittyCalis_ArtPass.gif?alt=media\&token=60b63a13-5fb6-47d8-95a1-05fc2d2d7a53)

![Kieran Goodson（来自 80 Level）的作品集作品系列美术处理和迭代](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MDM6LMFqpAPY2U5YW4M%2F-MDM96X6Fn4gPcXSnxjJ%2FKieranGoodan_ThoseWhoMourn_Iteration.gif?alt=media\&token=ce82040e-b792-4fb5-843a-7fbaac4c28dd)

### 制作道具动物园 / 仓库 / 展示地图

和尺度规范练习地图、模块化套件回环测试类似，验证环境美术的最佳方式是在游戏中尝试使用它。**制作一个包含每个道具 / 美术资产的场景或关卡，然后在其中走动。**

《Caravan Sandwitch》的艺术总监 Charles Boury 为展示地图提供了以下建议：

> *我通常会创建：用于展示每个角色的 ShowcaseCharas；以宜家式方式概览所有游戏道具的 ShowcaseProps；以网格视图展示每种材质在不同光照条件下表现的 ShowcaseMats；以及可以操作每个 UI 元素的场景 ShowcaseUI。*
>
> *注意“每个”这个词。详尽的列表让你可以全面掌握游戏内容，并建立信心。例如，当你处理拾取物 UI 时，可以用所有可拾取物进行测试。当你问自己“角色身上使用红色吗？”，或者团队问你一个具体问题，比如“有多少道具使用复杂碰撞而不是简单碰撞，为什么？”，你都能自信地回答。*

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FrRMCa2UK0choS1zjI9EL%2FLDB_EnvArt_CharlesBoury_Road96_PropShowcaseScene.jpg?alt=media&amp;token=4fe85b1c-b8db-40d3-90b7-f2ebaae925cf" alt=""><figcaption><p>《Road 96》ShowcaseProps 场景的编辑器截图，Charles Boury 制作，来自<a href="https://charlesboury.fr/articles/scene-setup-for-art-direction.html">《为艺术指导设置场景》</a></p></figcaption></figure>

> *作为艺术总监，我在推动一种特定风格。我不关注某个单一道具或角色，而是不断关注整体、艺术统一性。那么，我怎样才能让自己更容易实现这个目标？*
>
> *我想看到所有道具经过有组织的排列，以检查它们的调色板、剪影和细节层级。有一个放置了所有游戏道具的漂亮仓库会很棒：按类别分组，排列在网格上，这样我就能比较它们，选择要改进的对象。游戏的哪些部分需要更一致？我怎样利用这套道具制作独特的东西？*
>
> ——Charles Boury，摘自[《为艺术指导设置场景》](https://charlesboury.fr/articles/scene-setup-for-art-direction.html)

<div data-full-width="true"><figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2F8yWTahQjStAIhlk0dyyw%2FLDB_EnvArt_CharlesBoury_CaravanSandwitch_PropWarehouseScene.jpg?alt=media&amp;token=878d9366-e06b-45b2-adbd-529095284ae0" alt=""><figcaption><p>《Caravan Sandwitch》的道具仓库测试关卡编辑器截图，Charles Boury 制作，来自<a href="https://charlesboury.fr/articles/scene-setup-for-art-direction.html">《为艺术指导设置场景》</a></p></figcaption></figure></div>

## 美术处理示例

### 《Valorant》的“Icebox”（Riot Games）

由于《Valorant》是一款依赖精确地图[平衡](/process/combat/balance.md)的竞技多人射击游戏，Riot 调整了美术处理流程，尽可能保留关卡设计师的白盒。在进入美术制作和细节阶段之前，《Valorant》地图会经历为期数月的大量灰盒（[白盒](/process/blockout.md)）和[试玩测试](/process/blockout/playtesting.md)阶段，以及几轮最初的*美术白盒*处理，用来测试色板和[体块](/process/blockout/massing.md)。这个*美术白盒*为关卡设计师提供了更多时间修改关卡几何体，也让这些调整可以以最小浪费传递给美术师。延长白盒阶段能够改善最终美术处理，并让部门之间有更多协作。

> 在 3D 艺术家接触地图之前，我们的艺术负责人和创意总监会与概念艺术家进行非常高层次的合作，通过一系列蓝天概念不断迭代，为地图寻找标志性外观。在这个阶段，艺术家和项目负责人之间会大量来回沟通，确保地图符合 VALORANT 的叙事，具有视觉变化，最重要的是，让团队真正期待参与制作。
>
> 高层方向确定后，概念艺术家会根据灰盒布局开始处理地图上的具体地点和报点。在这个阶段，概念艺术家会尽量覆盖地图的更多区域，然后 3D 艺术家才会介入，开始制作建筑的基础形状。

![《Valorant》Icebox 地图从灰盒到“美术白盒”再到“美术制作”的流程（来自 PlayValorant.com）](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MMXTx6oRpuSjL5oozQ5%2F-MMXlMVK1BXylPPgyTSE%2FValorant_LydiaZanotti_IceboxBlockoutFlow.gif?alt=media\&token=c4187993-6303-430c-bf02-8cbb4047ff9f)

> 我们会尝试在开始展开 UV 和制作纹理之前，先把基础建筑形状放入地图。当开始为网格添加颜色时，我们会确保它们不会太暗，尤其是在室内空间中。这里的目标是通过确保环境不会妨碍清晰度、角色始终清晰可见，来维护游戏玩法的完整性。
>
> 关于纹理制作，我们主要在建筑和大型结构上使用平铺纹理和装饰条纹理。这些纹理使用 ZBrush、Substance Designer、Substance Painter 和 Photoshop 等各种程序制作。需要时，我们会为道具使用定制纹理，例如厨房里的咖啡机或 A 点附近的叉车。
>
> \[...] 为了减少视觉噪声，我们会确保材质的明度相近，不会有太多对比或黑暗。我们还可以使用灯光照亮暗区，或照亮需要最大可见度的空间，例如 Spike 植物点位或经常被探头观察的角落，从而改善清晰度。
>
> ——摘自 Lydia Zanotti 的[《Valorant 地图环境的艺术》](https://playvalorant.com/en-us/news/dev/the-art-of-valorant-map-environments/)

![Icebox 中“厨房”区域从白盒到美术白盒的演进；走廊变成了房间！（来自 PlayValorant.com）](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MMaJShq300eEuVgAbnc%2F-MMaSudK0YXoK1BdAEST%2FValorant_LydiaZanotti_IceboxKitchenBlockout.gif?alt=media\&token=421ac229-937a-4c4d-a68e-b477ab8b46e3)

## 回顾要点\...

**环境美术**关注装饰并细化关卡的视觉效果。

工业美术师往往会通过**概念艺术**、**涂绘**和**模型表**进行大量规划。基于这些计划，他们会生成一份**资产清单**，以确定需要完成多少工作。

常见的环境**美术资产**包括**世界纹理**、**模块化套件**、**英雄道具**以及植被和杂物等常规**场景布置**道具。

制作资产时，艺术家应考虑**可读性**：物体的视觉外观如何暗示可供性（功能和用途）。要改善可读性，应把细节**聚簇**成群，注意**颜色和明度**，并确保**材质**清晰可辨。

我们强烈**反对**[**形状和色彩心理学**](/process/env-art/psychology.md)。&#x20;

**如何进行美术处理：**

* 先专注于替换进大型、重要、常见的核心物体 / 形状
* 不要试图逐个把每个资产做到 100% 完成，最好**迭代式工作**：先把多个物体做到 50%，然后退一步评估

## 接下来做什么？

* 继续进入[**发布**](/process/release.md)。
* ~~停止阅读关卡设计书，去找一本环境美术书 / 网站吧~~。
* 更详细地阅读环境美术的某个方面……

### 环境美术详解

在职环境美术师通常专精于某个方面：

* **建模和雕刻。**硬表面建筑和道具，还是自然和植被？
* [**灯光**](/process/lighting.md)会严重影响玩家对形状、纵深、空间和氛围的感知。
  * *那面墙是远还是近？这个房间是浅还是深？它可怕吗？*
* [**纹理制作**](/process/env-art/texturing.md)对理解形状、表面和材质很重要。
  * *那面墙是木头还是金属？……外星金属？附近有外星人吗？*

[**叙事**](/process/env-art/storytelling.md)和场景布置会赋予地点感 / 生活过的感觉。

完成美术处理后，关卡通常还需要进行[**优化**](/process/env-art/optimization.md)。

## 延伸阅读

记住，这是一本关卡设计书，不是环境美术书。你当然应该去别处了解更多。

* 环境美术网站链接，参见[社区：环境美术](/appendix/communities.md)。
* [《Environment Art blog》](https://environmentart.wordpress.com/)，作者 Rogelio Olguin（2016 年停更，但仍有很多好内容）
