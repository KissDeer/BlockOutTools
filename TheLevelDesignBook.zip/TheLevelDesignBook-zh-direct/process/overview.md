> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [process/overview.md](https://book.leveldesignbook.com/process/overview.md)。

# 如何制作一个关卡

电子游戏关卡设计的一般工作流程与概念概览

大多数 3D 关卡设计项目都会涉及以下流程：

1. [**前期设计**](/process/preproduction.md)：规划核心创意和整体体验设计。
2. [**战斗设计**](/process/combat.md) **（可选）**：针对战斗类游戏，定义玩家与不同敌人类型之间的互动方式。
3. [**布局**](/process/layout.md)：绘制关卡的俯视角 2D 视觉规划图。
4. [**白盒**](/process/blockout.md)：制作基础的游戏内 3D 粗模，并进行试玩测试。
5. [**脚本**](/process/scripting.md)：整合事件与行为（任务、门、按钮、AI 等）。
6. [**灯光**](/process/lighting.md)：安排光源，以塑造纵深并提升可读性。
7. [**环境美术**](/process/env-art.md)：通过“美术处理”添加道具和场景布置。
8. [**发布**](/process/release.md)：记录、宣传并发布项目。

如果你不知道从哪里开始，那就试着把所有环节都做一遍。经验增加之后，你会知道什么时候应该跳过某个阶段，或者扩展某个阶段。

![《反恐精英 1.6》中的 de_dust 地下通道，作者：Dave “DaveJ” Johnston](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lu58xf7oEP7GGmBzX1_%2F-Lu59-ymdYcYVhp24tQN%2Fresearch_dust_underpass.jpg?alt=media\&token=0a598225-b30d-46fa-8e67-f8c65e07a62a)

## 调整流程

每个关卡、每个项目的需求都不同。制作关卡没有唯一且万无一失的方法。

* **团队项目**需要更多的[**前期设计**](/process/preproduction.md)和规划，例如[节奏](/process/preproduction/pacing.md)大纲和[布局](/process/layout.md)图纸。没有足够的沟通和文档，合作者就无法真正协作。
* [**战斗类游戏**](/process/combat.md)**和多人地图**需要更多[**白盒**](/process/blockout.md)时间，以便调整[遭遇战](/process/combat/encounter.md)和[地图平衡](/process/combat/balance.md)，并且要高度重视[**试玩测试**](/process/blockout/playtesting.md)。
* **强调**[**叙事**](/process/env-art/storytelling.md)**的单人关卡**从长时间白盒中获益较少。这听起来可能很有吸引力，但实际上是一种完全没有确定性的特殊地狱。故事什么时候才算“足够好”？你需要反复迭代[脚本](/process/scripting.md)和[环境美术](/process/env-art.md)。如果故事发生变化，你就得重做一切，而且很难让所有内容保持同步。你是否玩过故事讲不通的游戏？你的游戏大概也会变成那样。

## 流程概览

### 1. [前期设计](/process/preproduction.md)

**前期设计**是规划项目基本形态和范围的阶段。项目的主题是什么？设计目标和约束是什么？

初学者经常完全忽视项目规划，而有经验的设计师有时又会计划过度。大型商业工作室往往会花几个月甚至几年的时间进行前期设计。团队协作时，这个阶段非常重要，因为大家会在此时对齐预期。独自进行业余项目时，你可能可以少做一些规划。

前期设计计划通常表现为文字文档、可以移动卡片的看板和电子表格。

*关于概念规划的更多内容，参见* [*前期设计*](/process/preproduction.md)

![《最后生还者》内部规划看板照片（顽皮狗），图片来自维多利亚与阿尔伯特博物馆的“电子游戏”展览](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lu4Y_E2F6Jj22AaTeoF%2F-Lu4cB1iELo7OzM1v7oa%2Fv%26a_lastOfUs_planning_board.jpg?alt=media\&token=db00790c-1290-4394-a553-15c3cc974967)

### 2. [战斗设计](/process/combat.md)（可选）

如果你的项目涉及战斗，那么典型的一场战斗是什么样的？战斗由什么组成？玩家如何准备？怎样让战斗保持多样和新鲜？

战斗和其他游戏系统或机制一样。你应该在为这些系统制作关卡**之前**，先定义它们的体验设计目标。

如果你从零开始制作战斗类游戏，那么在程序员和美术师把战斗做得可运行、可读之前，战斗不会“感觉良好”。基本上，你必须先把整个游戏做出来，才能知道战斗的手感！因为工作量太大，我们建议修改现有的战斗类游戏，这样你可以在已经经过实战验证的系统上练习。

*关于战斗、武器和敌人的更多设计内容，参见* [*战斗设计*](/process/combat.md)*。*

*推荐修改的战斗类游戏列表，参见* [*工具*](/appendix/tools.md)*。*

![展示《战神》（2018）女武神 Boss 招式矩阵的电子表格，作者：Jason de Heras（来自 Twitter）](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MWv39_9hxX4YRTiVgLr%2F-MWvAiVCuI_Tvzecv6YL2%2FLDB_Encounter_Matrix_GodOfWarValkyries_JasonDeHeras.png?alt=media\&token=70e31f40-2846-46d2-a2ef-cc38d43e09c4)

### 3. [布局](/process/layout.md)

**布局**是关卡的基本结构，通常是一张平面的 2D 图，表现核心区域和元素。

对于小型的个人业余项目，一张简单的布局草图，甚至是一张随手涂鸦，可能就够用了。

对于团队项目或大型项目，详细的布局图是重要的沟通工具。没有人能读懂你的想法；如果你不把想法画出来，也不把它说清楚，就没人会知道你想要什么。

布局图通常是俯视角 2D 平面图，但等距视图和透视图也很常见。记住，这件事与画得像不像无关，而与沟通有关！这张图是对玩家能够去哪里、能够做什么的视觉规划。

*关于视觉空间规划的更多内容，参见* [*布局*](/process/layout.md)

![《军团要塞：经典》多人地图“Warpath”的布局图，作者：Robin Walker](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mcfk2SN77KBX1CK8_Ov%2F-McfmtS2lUdC3s1KFrgH%2FLDB_Layout_Warpath_TeamFortressClassic_RobinWalker.jpg?alt=media\&token=9c21c702-5e14-44f4-a106-83e1e560a345)

### 4. [白盒](/process/blockout.md)

**白盒**是关卡的可游玩粗模，使用简单、低细节的块状 3D 形体搭建。

我们先把关卡的基本结构做成原型，这样就可以在游戏引擎中进行试玩测试。试玩测试能帮助我们判断关卡是否太小或太大、令人困惑或有趣、平衡或失衡，等等。

对于任何战斗类游戏，或者任何重新安排一个房间就可能大幅改变玩家行为的游戏，这种试玩测试都很重要。如果你发现房间设计不起作用，那么在它还是由简单形状构成时，修改起来会容易得多。

白盒文件是可以载入游戏引擎的可游玩关卡文件或场景文件。

*关于游戏内 3D 原型制作的更多内容，参见* [*白盒*](/process/blockout.md)

![《神秘海域 4》（顽皮狗）悬崖关卡的白盒截图，作者：Em Schatz](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LtwoKZ58xOGNTn9g_Qy%2F-Ltwq-JcDDEN7UHH9OLR%2Funcharted4_blockout_em_schatz.jpg?alt=media\&token=fe61470c-d734-4540-ab8e-a83eb330da7d)

### 5. [脚本](/process/scripting.md)

**脚本**是把行为、事件和游戏逻辑整合进关卡的过程。

[门的脚本](/process/scripting/doors.md)是游戏开发中最难的问题之一。火车和移动平台甚至更加复杂。最好先从按钮和收集物开始。

任务目标、任务线、过场动画、编舞，以及任何 AI 控制、战斗或[遭遇战设计](/process/combat/encounter.md)，通常都依赖脚本。如果你害怕编程，不用担心，许多游戏引擎和工具集都有专门的脚本语言和工具，可以简化编程过程。

关卡设计文化往往低估脚本设计师，但正是脚本让关卡显得“活起来”，也是把地图转化为体验的关键。

*关于让关卡产生实际行为的更多内容，参见* [*脚本*](/process/scripting.md)

![《回家》（Gone Home）的早期版本中，门还不能正常工作……图片来自 Johnnemann Nordhagen 的博客文章“Code Judo”](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MVcmniYhUKeyxyT9VDg%2F-MVcnJ7nwe4eCruqHe55%2FLDB_DoorScripting_GoneHome_JohnnemannNordhagen.jpg?alt=media\&token=ffcdfdb2-60f4-4517-b870-c80c44095d9c)

### 6. [灯光](/process/lighting.md)

**灯光**为白盒增加阴影和纵深，帮助玩家理解关卡的基本形状。

没有灯光，3D 游戏世界会更像一张平面的 2D 图片，玩家也很难判断距离或理解完整布局。光与影还可以充当掩体或信息层，这对战斗玩法至关重要。

虽然游戏行业通常把灯光更多地视为环境美术中的装饰性部分，但我们认为灯光具有关键的玩法功能，必须与关卡设计师进行深入协作来制作。

*关于服务于玩法的灯光设计，参见* [*灯光*](/process/lighting.md)*。*

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mh1jhg_FeQx6xy8Qe6b%2F-Mh1lkxbVgbUXAxBnb8b%2Fharley-wilson-natlight-b.jpg?alt=media&amp;token=1874b909-60db-4a01-bec9-a70b46939966" alt=""><figcaption><p>使用光源实体进行的中世纪灯光研究，作者：<a href="https://www.artstation.com/artwork/lBLzJ">Harley Wilson（来自 ArtStation.com）</a></p></figcaption></figure>

### 7. [环境美术](/process/env-art.md)

当你已经对关卡的整体形状和动线有了足够把握，就可以开始添加更多的**环境美术**或视觉细节。

**美术处理**就是添加这些细节的过程。大多数项目都需要多轮美术处理。

很多人认为美术处理是“有趣的部分”。初学者经常在规划、布局或白盒工作不足时，就过快地进入美术处理。过早的美术处理会把早期的设计错误固定下来，因为这会让修改关卡、重新制作全部美术变得“昂贵”。所以要抵制这种冲动！不要急着进行美术处理！

*关于让关卡变得漂亮的更多内容，参见* [*环境美术*](/process/env-art.md)

![《狙击精英》雪地军事码头关卡开发过程的动画 GIF](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MVOe7gOtBO2fR1OaIjJ%2F-MVOeNGkYd_XvSwlSxn7%2FLDB_Sniper_Rebellion_BlockoutArtpass.gif?alt=media\&token=a10f1d36-1367-4304-b106-8253f9b9ee1a)

### 8. [发布](/process/release.md)

项目完成后，就到了**发布**并确保它触达目标受众的时候。

对于商业项目，游戏发售只是噩梦的开始——你还必须继续营销和宣传项目，了解用户反馈，发布问题修复，并且可能还要制作更多上线后的内容。

对于个人作品集项目，你必须正确记录关卡设计过程，否则没人会理解你做了什么。没有有效的文档，这个项目基本就等于不存在。

初学者经常没有给发布阶段投入足够时间，以为项目会自己说明一切——*但如果没人知道它存在，你的作品就没有对象可以诉说。*

*关于发布关卡或制作作品集的更多内容，参见* [*发布*](/process/release.md)*。*

## 回顾

关卡设计通常包含多个步骤，大致顺序如下：（1）前期设计，（2）战斗设计（如果不是战斗类游戏则跳过），（3）布局，（4）白盒，（5）脚本，（6）灯光，（7）环境美术，以及（8）发布。

但每个项目都不同。有时你可能想跳过布局阶段，或扩展脚本阶段，或在脚本之前进行环境美术，等等。

如果你正处于项目早期，或正处于关卡设计职业生涯的早期，那么你可能应该把所有环节都试一遍，直到找到最适合你的流程。

## 接下来做什么？

* 从头开始——了解关卡设计的[前期设计](/process/preproduction.md)。哪怕只做一点规划，也会带来很大帮助。它能帮助你弄清楚自己到底在做什么。
* 在日常工作中，大多数关卡设计师会把重点放在[布局](/process/layout.md)和[白盒](/process/blockout.md)上。
