> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [process/layout/parti.md](https://book.leveldesignbook.com/process/layout/parti.md)。

# Parti

布局的核心想法 / 概念

在建筑学中，**parti**是项目的中心想法 / 概念。你能否用一句话把建筑简化为最重要的结构要素？

同样，关卡设计也能从定义一个锚定其余设计的核心想法中获益。如果你能用清晰的 parti 陈述或草图介绍你的关卡，那么协作者（甚至玩家）就能更好地理解你的意图。

### 建筑学中的 Parti

![Frank Lloyd Wright 设计的 Price Tower 的平面图、剖面图和照片（图片来自 https://es.wikiarquitectura.com/edificio/torre-price/）](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MgspaaGysdgZGFw9dKO%2F-MgsqGph_sf0v7812P0U%2FLDB_PartiPlanSection_PriceTower_FrankLloydWright.jpg?alt=media\&token=40f624d6-7f30-42bf-99b4-e0f9ead27af7)

Price Tower，“逃离拥挤森林的树”

剖面：中央“树干”核心（电梯）向每个楼层“分枝”

平面：中间有十字的正方形
