> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [process/layout/typology.md](https://book.leveldesignbook.com/process/layout/typology.md)。

# 类型学

用于关卡设计的抽象布局模式及具体示例

## 什么是类型学？

**类型学**是一种布局设计模式，是帮助我们思考布局的分类系统。它会对布局进行*抽象*，也就是简化并概括结构。

{% hint style="info" %}
**为什么说“类型学”，而不是“类型”？**这不只是学者故作矫饰。“-学”部分提醒我们，这是一个庞大的研究领域，是相互连接的想法系统。“类型”太宽泛了。
{% endhint %}

![Maja Baldea 绘制的建筑图“高密度住宅建筑的形式类型学”（来自 Density Architecture 博客）](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FxfRLuQ0NNUImorA77zDE%2FLDB_Typology_DensityArchitecture_MajaBaldea.jpg?alt=media&amp;token=8ead8433-3018-4e24-8ca9-7da4fa4cf55e)

在上面的现实世界建筑图中，Maja Baldea 思考了组织公寓楼的不同方式。她把这些建筑*抽象*（简化、概括）为没有窗户的方块，因为她对细节不感兴趣，而是在思考总体形状、[体块](/process/blockout/massing.md)和[构图](/process/blockout/massing/composition.md)，以便**对不同类型的住宅建筑进行分类**。

类型学对于以下内容很有用：

* 对不同类型的关卡设计进行分类
* 推理地图[平衡](/process/combat/balance.md)和[遭遇战](/process/combat/encounter.md)设计
* 开放世界 / 大逃杀类型项目，因为多样的类型学通常会带来多样的游戏内容
* 共享设计语言，帮助协作和团队工作

## 元素

除了墙体、地面和天花板，许多关卡中还经常出现一些常见的*游戏玩法元素*：

* [**掩体**](/process/combat/cover.md)。半掩体与全掩体，硬掩体与软掩体。
* [**闸门**](/process/layout/typology/gates.md)。硬闸门与软闸门、锁与钥匙、前进闸门与后退闸门。

## 房间类型学

**房间类型学**是单个区域 / 关卡“片段”的概括模式。&#x20;

{% hint style="info" %}
我们把“房间”作为“空间”的通用术语。房间可以是花园、洞穴等。这可以追溯到 1990 年代的游戏引擎，当时室外空间也是带有天空天花板的房间。
{% endhint %}

### 走廊

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lv6YGpBQxsQzANptpRi%2F-Lv6vQsjMSxXDUp7QepP%2Fleveldesignbook_corridor.png?alt=media\&token=678486bc-d308-4500-8c74-74f2506d5ed5)

像走廊、河流或峡谷一样，沿空间直线推进。任何沿着可预测空间序列进行单向移动的内容，都可以被视为走廊。

* 作者控制、掌控程度和确定性很高。你知道玩家必须去哪里，也知道玩家可能需要多少时间。
* 要加快速度，加入向下的斜坡、单向落差和明亮灯光
* 要放慢速度，加入侧面区域、壁龛和不连续的灯光

#### 走廊示例：《P.T.》中的房屋

第一人称恐怖游戏《P.T.》（2014）让玩家一遍遍走过相同的走廊：玩家打开尽头的门后，循环机制会把玩家传送回起点。这是对走廊的强力使用，如果采用更开放的布局，效果反而会变差。

![Kojima Productions 制作的《P.T.》（2014）平面图和关键路径；要完成游戏，玩家必须解决隐藏谜题，至少循环穿过同一组走廊 12 次](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lv6YGpBQxsQzANptpRi%2F-Lv6tE3LQLOrPYmjcvan%2Fleveldesignbook_pt.png?alt=media\&token=e21be228-d0c9-4173-bfb3-1c214543a816)

注意它对视线的强控制：迫使玩家盯着拐角处的窗户，或绕道进入浴室，注意镜子和水槽。恐怖套路和阴森的壁龛会阻止玩家移动得太快，而线性和熟悉感最终积累为不祥预感、恐惧和厄运。我们能做的只有继续深入，没有任何逃脱方式。&#x20;

### 折返 / 发卡弯

一条在原路返回时能看见出口的死胡同走廊。

* 类似走廊，提供大量控制和作者意图
* 遮挡出口会鼓励玩家先探索死胡同
* 短暂的困惑，轻微的探索和导航感

折返示例：《Dear Esther》中的洞穴

### 环绕玫瑰 / 战斗碗

中间有[掩体](/process/combat/cover.md)的小型开放区域，通常是柱子等全掩体，形成旋转 / 转点式动线。快节奏战斗游戏中尤其常见，玩家可以围绕中央掩体“跳舞” / 绕圈移动，同时躲避敌人攻击。

* 加入单向落差来强制特定动线，和 / 或加入垂直性

### 竞技场 / 兴趣点（POI）

![](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LvCPUfM6ZFrYpR7MOEF%2F-LvCPYN0y1Fy8Bw47a79%2Fleveldesignbook_arena_simpler2.png?alt=media\&token=ac70f80e-5481-403e-8f8a-685407cf7fac)

**竞技场**是拥有多条[流线](/process/layout/flow/circulation.md)的开放区域，中间有一些[掩体](/process/combat/cover.md)。

* 开放世界和大逃杀设计师会使用**兴趣点（POI）**，即由大型地标锚定、拥有多个入口和出口的大型竞技场
* 在单人游戏中，竞技场通常需要[闸门](/process/layout/typology/gates.md)；阻止玩家过早离开竞技场，同时也封住入口，防止玩家把所有敌人都拉到一个瓶颈处

#### 示例：《毁灭战士 2》的 Dead Simple

（TODO：绘制 Dead Simple 平面图和关键路径）

## 关卡类型学

**关卡类型学**是针对多个房间 / 整个关卡的概括布局模式。

### 中心辐射式

一种更大的多区域模式，拥有一个中央区域（中心）和多个从中心向外延伸的小区域 / 通道（辐条）。要探索不同的辐条，玩家必须返回中心。

* 为不同辐条提供统一身份，传达结构逻辑
* 每次访问都需要大量工作来更新中心，否则会感觉是在原路返回
* 可以成为有用的节奏工具；回到中心可以感觉像是一种放松奖励
* 锁住的中心会在开始时封闭大部分辐条，玩家逐渐解锁捷径
*

#### 示例：《生化奇兵 1》的医疗馆

《生化奇兵 1》包含多个中心辐射结构。开头的医疗馆第一章

### 回环

（TODO：图示）

一种会回到自身的线性推进，最常见于开放世界地牢。

* 类似走廊：控制和确定性高，玩家无需太多犹豫
* 即使推进最初是线性的，也能帮助区域在结构上感觉非线性且可信
* 微妙的回环感觉像完成了一个自然且必然的循环
* 过于方便的回环会像刻意安排、请求玩家感谢的捷径，因而显得人为或不可信

---
#### 示例：Skyrim 中的（某个地牢）

（示例：Skyrim 布局和截图）

开放世界奇幻 RPG《上古卷轴 V：天际》中有许多地牢，玩家完成地牢后必须回到地表。然而，一旦某个区域被清空，原路返回往往会感到单调或机械……（TODO：完成）

### 分支瓶颈 / 珍珠串

### 穿越式

### 时间洞穴

## 多人类型学

多人布局往往更非线性、更曲折、也更双向，强调高重玩价值和可复用区域。许多团队游戏都有基地 / 出生房间，让玩家安全加入游戏，也有供队伍进攻和防守的占领点。

### 基地 / 出生房间

### 无人区

### 狙击巢 / 狙击通道

### 8 字形

经典夺旗地图中最常见，例如血峡谷等

### 连接区 / 枢纽

在拥有基地和通往占领点的路线的多人团队游戏中

示例：《反恐精英：全球攻势》

### 三线路

示例：《英雄联盟》《DOTA》《使命召唤：现代战争》……《反恐精英：全球攻势》中也很常见（每个炸弹点一条线路，中间连接线路一条）

## 反对类型学？

一旦进行分类，就可能把自己困在这些分类的限制中。有时，忽略类型学并拒绝分类可能更有帮助。

## 回顾要点\...

**类型学**是对不同类别的关卡布局进行分类的一种方式。这些词和标签帮助我们讨论和思考布局。

**房间类型学**是设计单个区域的模式，例如走廊、折返、环绕玫瑰 / 战斗碗，以及竞技场 / POI。

**关卡类型学**是按顺序排列多个房间的模式，例如回环、穿越式、分支和瓶颈、中心辐射式，以及时间洞穴。

## 延伸阅读 / 来源

* [《模式语言》](https://en.wikipedia.org/wiki/A_Pattern_Language)（1977），建筑师 Christopher Alexander 等人所著，是当今现代建筑和城市规划的经典类型学手册，开创了新城市主义运动。
* [《论“三种类型学”》](https://medium.com/@tlukejones/on-the-three-typologies-ed0b5747fd9c)（2017），建筑师 Luke Jones 所著，是一篇精彩的文章，讲述建筑师至今仍不太确定该如何对建筑分类。
