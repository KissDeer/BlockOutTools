> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [process/layout/flow/circulation.md](https://book.leveldesignbook.com/process/layout/flow/circulation.md)。

# 流线

区域如何连接其他区域，地图的“连通性”

在建筑学中，**流线**通常指连接其他区域的“中间”区域，例如走廊、过道和楼梯。&#x20;

有些关卡设计师称其为*连通性*。但在本书中，我们认为*流线*是一个更好的词和概念，更多关卡设计师应该采用它。

## 流线类型

现实世界的建筑师会区分几种流线：

* **主要**流线与**次要**流线（通往主电梯的路径与通往储藏室的路径）
* **公共**流线与**私人**流线（底层大厅与卧室走廊）
* **水平**流线与**垂直**流线（走廊与楼梯）

许多这些问题并不直接适用于关卡设计。与可悲又不幸的现实世界建筑师不同，我们可以设计虚拟建筑，不必担心建筑规范、条例或热力学。然而，这些词和概念仍然有用。

![Studio Twenty Seven Architecture 为 Achievement Preparatory Academy 中学设计的流线图](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lxco6Y2Q4w3rLcoR9Y4%2F-LxcoEISPL1o6m16CVlo%2Fimage.jpeg?alt=media\&token=65698965-ce64-430d-afed-6a84d2eea47b)

在关卡设计中，至少还存在两种不同的流线类型：

* **叙事内流线：**流线的外观和感觉，以及空间在游戏内的虚构设定。
  * 与[环境美术](/process/env-art.md)和[叙事](/process/env-art/storytelling.md)相交
  * 对单人关卡至关重要，尤其是写实风格的单人关卡
* **形式流线：**不考虑任何游戏内虚构设定时，流线的系统功能。
  * 更多关注[战斗设计](/process/combat.md)、[掩体](/process/combat/cover.md)模式和[地图平衡](/process/combat/balance.md)
  * 对多人地图很重要，尤其是竞技战斗地图

## 叙事内流线

**叙事内流线**指虚构的游戏内角色会如何使用空间。&#x20;

在电影研究中，*叙事内世界（diegesis）*是屏幕上呈现的虚构想象世界。问问自己：*玩家会如何代入角色，在关卡中移动？这个空间的主题是什么？这种流线模式背后的故事是什么？*

对于单人关卡，传达流线对[叙事](/process/env-art/storytelling.md)至关重要。如果希望关卡感觉像一个可信的现实世界空间，就必须像一个可信的现实世界建筑师那样思考，设计可信的现实世界流线。

在设计探索游戏《Gone Home》（2013）时，Fullbright Company 选择了老宅主题，因为现代郊区住宅围绕一个中央房间展开，连接紧密而平坦；而豪宅则会深入分支到不同的侧翼。这个豪宅套路支持了他们想要的中心辐射式[类型学](/process/layout/typology.md)，帮助他们讲述想讲的故事。

![《Gone Home》（2013）带关键路径覆盖（绿色）的布局；出自 Steve Gaynor 和 Kate Craig 的《〈Gone Home〉的关卡设计》，2015 年 GDC](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LzirCahNHFS7Wm_zJnN%2F-LznUOx6VPLVPBGGXDpl2%2Fgdc2015_gonehome_flow_steve-gaynor_kate-craig.png?alt=media\&token=bc4d6b8c-cd8f-4b52-8041-995ff7848803)

《Gone Home》关键路径的前半段从“前廊”（底部中央）开始，在地下室（左上方）结束，同时频繁地原路返回，形成一种自由探索感，支持《Gone Home》调查一座空宅的体验目标。&#x20;

如果每条线索都通向一个新区域，它就不会有调查感（也不会像一座豪宅）。相反，我们要学会停留在这个空间中，并逐渐熟悉它。从这个角度看，建筑学研究对专注于故事的关卡至关重要，否则叙事内流线可能无法支持期望的关键路径。

### 叙事内流线作为寻路与引导

玩家会根据当前目标沿着流线前进。如果他们必须找到出口，就会沿着主要流线走。如果需要到达屋顶，玩家会寻找垂直流线。如果需要绕过敌人潜行或探索资源，他们会使用次要流线。

通常，更宽、更大的通道*感觉上*像主要公共流线，而较窄的区域更像次要流线。但想象你在关卡中行走，看见一扇又大又宽的门和一扇更小、更窄的门。哪扇门通往出口？大门可能通向主要流线和出口。但如果大门看起来像车辆使用的车库门，也许它锁着，我们应该走小门……于是，小门反而更可能让人感觉像主要流线……

&#x20;    *关于玩家导航的更多内容，参见* [*寻路与引导*](/process/blockout/wayfinding.md)*。*

## 形式流线

**形式流线**关注布局的物理功能（“形式”）和移动的可供性。&#x20;

这里忽略主题、设定和文化。用抽象关卡几何形状来思考关卡。问问自己：*职业玩家或速通玩家会如何理解这张地图？*

### 线路

**线路**是多人地图中的形式主要流线。&#x20;

线路帮助玩家预测和协调移动。一张拥有太多线路、或没有清晰线路层级的大地图会像迷宫一样运作；玩家不知道该把努力集中在哪里，会迷路，也会错过彼此。&#x20;

因此，大多数地图只使用 1–3 条线路。

### 单线路

《军团要塞 2》和《守望先锋》等团队多人游戏的推车地图，会把游戏玩法和冲突集中在一条蜿蜒穿过整张地图的线路上。进攻队必须站在推车附近，把推车向前“推”；防守队则必须阻止推车到达线路终点。推车路线会被明显标出，让玩家可以轻松协调行动（或准备伏击）。有时会加入额外的半线路和后巷，帮助进攻方突破防守。

![《军团要塞 2》推车地图“Badwater Basin”的单线路类型学](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LzycdR3jZ-j_PyEusfN%2F-Lzxs6Is1LHUx_VuazTn%2Ftf2_badwater-basin_layout_criticalpath.jpg?alt=media\&token=c39ca916-ad57-4bff-933b-d2eb4c1118a0)

### 三线路

线路也常见于《英雄联盟》等 MOBA，以及《使命召唤》和《反恐精英》等围绕领地控制的竞技多人游戏。这些游戏的地图经常使用**三线路**格式，即 3 条双向关键路径，通过较小的线路偶尔分支和相交。（在 MOBA 中，较小的中间线路 / 次要流线纠缠成的区域统称为*丛林*。）

![《英雄联盟》召唤师峡谷和《反恐精英：全球攻势》de_dust2 的三线路类型学](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lznde4LEhCB3ysDM0gz%2F-Lznks0aLf0e75KmhiT4%2Fleague_dust2_threelane.jpg?alt=media\&token=173bf66b-b486-4399-ba46-846dd29f54b0)

如果一名对手堵住了某条线路的推进，那么其他玩家可以尝试沿另一条线路前进，从侧面绕过他们。或者，如果玩家想完全避免冲突，就可以避开主要线路，尝试在丛林中刷资源。

线路不对称很重要，每条线路都应该感觉不同。在《英雄联盟》的召唤师峡谷中，上路和下路比中路更长，上路有一个强力 Boss，而下路有一个较弱的中 Boss。在《反恐精英：全球攻势》的 de_dust2 中，队伍必须决定集中进攻 A 点还是 B 点，以及如何接近或侧袭；如果队伍选择错误，可能需要通过中路移动到地图另一侧。

### 转点

**转点**（主要用于《反恐精英》）指玩家必须从一条线路移动到另一条线路。这通常需要团队合作与协调；转点与不转点之间的张力，是团队制竞技多人游戏的核心元素。
