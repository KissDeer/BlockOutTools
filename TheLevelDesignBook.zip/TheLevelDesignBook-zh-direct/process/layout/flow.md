> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [process/layout/flow.md](https://book.leveldesignbook.com/process/layout/flow.md)。

# 动线

玩家穿过关卡时的感受

在关卡设计中，**动线**指沿着关卡不同路径 / 不同部分移动时的总体感受。&#x20;

路径是简单还是复杂？直线还是曲线？缓慢还是快速？所有这些因素都会影响玩家在空间中的移动。简而言之，设计动线就是**设计移动**。

你应该在初始[布局](/process/layout.md)规划阶段开始设计动线，但只有在[制作白盒](/process/blockout.md)并[试玩测试](/process/blockout/playtesting.md)后，才能确认它实际感觉如何。

{% hint style="info" %}
*不要把（关卡设计中的）动线和* [*（游戏设计中的）flow*](https://www.gamasutra.com/view/feature/166972/cognitive_flow_the_psychology_of_.php) *混淆，后者是指当技能和挑战达到平衡时，玩家进入高度投入的“心流状态”的理论。*
{% endhint %}

![标有转弯编号的 Spa（F1）与 Daytona（NASCAR）赛道地图，作者 Will Pittenger（依据 CC-BY-SA 许可）](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LzxBngZZiccy6pmtNI6%2F-LzxHF70DrNlm51YIb11%2Flayout_flow_race-tracks.png?alt=media\&token=c91e6699-8615-4e38-83bc-1c69ca154ea7)

## 感受动线

比较上面展示的两条现实世界赛道。

[斯帕-弗朗科尔尚赛道](https://en.wikipedia.org/wiki/Circuit_de_Spa-Francorchamps)（上方左图）是一级方程式（F1）赛车场，拥有各种转弯、[视线](/process/combat/balance.md#sightlines)和坡度，需要无可挑剔的技术驾驶。相比之下，[代托纳国际赛车场](https://en.wikipedia.org/wiki/Daytona_International_Speedway)（上方右图）是一条 NASCAR 赛道，是平坦宽阔的椭圆形赛道，支持大量车辆相互推挤。&#x20;

两张“地图”服务于相同的赛车核心机制，但强调非常不同的驾驶风格和策略。&#x20;

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FoFdpE4TrM4ewjxblgPqW%2FLDB_Flow_SpaF1Race1965_LATPhotography.jpg?alt=media&amp;token=a483c165-6104-4edb-a020-83aaad2e803a" alt=""><figcaption><p>1965 年比利时大奖赛中斯帕著名的“Eau Rouge”弯道；照片版权归 LAT Photographic</p></figcaption></figure>

下面，一位职业赛车手描述了斯帕著名的 Eau Rouge 弯道的动线：

> *“……当你驶过坡顶时，你不知道会落在哪里。\[...] 之后有一条很长的上坡直道，如果犯错，你会损失很多时间。但这也是一个对车手感受很重要的弯道。每一圈它都会留下特殊印象，因为驶过弯道底部时，身体还会受到压缩。非常奇怪——但也非常有趣。”*
>
> ——F1 冠军 Fernando Alonso 描述 Eau Rouge（[来自 Formula1.com](https://web.archive.org/web/20131017080654/http://www.formula1.com/news/headlines/2004/8/2097.html)）

从这个角度看，关卡设计有点像赛车。我们要求玩家做什么类型的移动？它感觉安全还是危险，简单还是复杂？&#x20;

在 Dave Johnston 制作的多人地图 de_dust2 中，标志性的“Dust 门”（下图）把玩家引入狭窄而危险的之字形转弯。另一侧的对手甚至可以穿过薄木门射击。和 Eau Rouge 一样，你永远无法 100% 知道另一侧有什么。这比一条笔直、清晰、开放的路径更刺激。

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FeehW9bYge6x5GYF9SQIE%2FLDB_Flow_CounterStrike16_DeDustDoors.jpg?alt=media&amp;token=281c958a-2fae-45c6-a234-e86461d3f941" alt=""><figcaption><p>《反恐精英 1.6》de_dust2 地图上著名的“Dust 门”；地图作者：Dave Johnston</p></figcaption></figure>

## 最佳动线？

“Dust 门”可以被认为是“糟糕”的动线——门打断了移动路线，迫使玩家进行尖锐、突然而谨慎的转弯。但在这里，所谓的糟糕动线其实很好：在《反恐精英》快节奏战斗的语境中，它增加了戏剧性和策略。

有时快速很好，有时缓慢而复杂更好。一切取决于游戏系统和关卡的目的。

快节奏的街机风格游戏可能偏好平滑的动线、宽阔宽容的转弯和最少的中断。而恐怖步行模拟游戏可能更适合尖锐狭窄的转弯、盲区交叉口、S 形曲线和迷宫般的死路。&#x20;

归根结底，**最佳动线就是能够支持预期**[**体验设计目标**](/process/preproduction.md#experience-goals)**的动线。**

* 这个关卡 / 区域 / 遭遇战 / 体验是关于什么的？快速刺激的行动，还是平静的观察和导航？第一次看见大城市？恐怖追逐？聚会场所？
* 对竞技多人地图而言，动线会强烈影响整体[地图平衡](/process/combat/balance.md)。
* 要确认动线按预期运作，必须[制作白盒](/process/blockout.md)并[试玩测试](/process/blockout/playtesting.md)。

## 垂直性

**垂直性**就是垂直动线，即向上和向下移动时的感觉。&#x20;

在地图中，这通常意味着楼梯、坡道、斜坡、电梯、梯子、悬崖、高台、跳板等。

传统观点认为垂直性越多越好，因为它能增加地图结构的视觉趣味，打破地面平面。但如今，我们不建议加入太多随机的垂直性，而是主张克制。垂直性是否合适，在很大程度上取决于核心游戏设计；许多游戏机制需要的空间就是大而平坦的地面，这有时也没关系。你不必到处放置随机台阶和平台。

&#x20;    *关于垂直动线的更多内容，参见* [*垂直性*](#verticality)*。*

![Brandon James 为《Quake 3 Arena》（1999）制作的 Q3DM17“最长的院子”跳板与传送器轨迹图](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M0LFFpYhA9pRoTbeeA_%2F-M0LYunLb3nF9nAK8RAW%2Fldb_q3dm17_verticality.png?alt=media\&token=740db590-357f-4be3-a314-50156a3d4d20)

## 如何设计动线

动线就是**设计移动**。许多因素会影响移动的感觉：&#x20;

* **速度。**沿着路径移动感觉慢还是快？
* **方向。**路径平滑 / 连续，还是断裂 / 突然，带有尖锐转弯？
* [**寻路与引导**](/process/blockout/wayfinding.md)**。**路径明显吗？哪些信息能帮助玩家规划路线？
* [**尺度规范**](/process/blockout/metrics.md)**。**玩家的移动机制是什么？距离如何调整？

为了同时考虑这些因素，我们提供 3 种设计动线的技术：

* **愿望线：**比较单个房间 / 区域中的理想路径
* **关键路径：**可视化整个关卡的单人[节奏](/process/preproduction/pacing.md)
* **流线：**可视化整张地图上的多人线路

### 愿望线

在城市规划中，**愿望线**（或**愿望路径**）是由脚步和侵蚀留下的使用者路径。

在下面的照片中，一条“非官方”土路偏离了“官方”混凝土道路。非官方道路就是愿望路径，它是玩家实际想走的路，也是对玩家而言最自然、最直觉的路。

![偏离人行道 / 穿过草坪的愿望路径，照片作者 Duncan Rawlinson](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M-QrgYN1BiS9OiCyCTk%2F-M-Qv--HoLKFSFRufa06%2Fdesire-paths_duncan-rawlinson.jpg?alt=media\&token=680da146-6d9c-4641-8e79-90a836403073)

{% hint style="info" %}
*有时现实世界的建筑师会* [*把愿望路径铺成正式道路*](https://99percentinvisible.org/article/least-resistance-desire-paths-can-lead-better-design/)*。在关卡设计中，我们也会通过观察* [*试玩测试*](/process/blockout/playtesting.md) *并相应调整来做类似的事情。*
{% endhint %}

这种思考方式适合设计小尺度动线，即单个房间 / 区域内部的动线：

1. 想象一条从玩家到目的地的高效“愿望线”。
2. 将愿望线与玩家可以采取的实际路径进行比较。

在下面的示意图中，玩家必须爬楼梯到达出口……

![比较具有不同动线的折返楼梯（左）和转角楼梯（右）；关卡几何体作者：Andrew Yoder](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M-Sd_o0ZMtrCIz1IXMv%2F-M-SeI34uOMR4wwofDvB%2FFlowComparison_AndrewYoder.png?alt=media\&token=95779c53-f49c-402c-9007-23cf58122b36)

玩家的愿望线（*黄色*）直接通向二楼出口，但实际动线（*红色*）迫使玩家走上楼梯。&#x20;

折返楼梯（*左图*）不如单转角楼梯（*右图*）直接，因为折返楼梯要求玩家多转一次弯。

虽然折返楼梯效率较低，但要记住，**效率较低的动线不一定不好。**折返楼梯可能有以下作用：

* 放慢玩家速度，并鼓励他们先探索房间
* 提供跑酷式捷径，直接爬到中间平台
* 在中间平台放置远程敌人；玩家有多容易攻击它？

### 关键路径

**关键路径**（或“黄金路径”）是完成单人关卡的最短 / 主要路径。&#x20;

更广义地说，它代表一种*理想化的玩家动线*，突出关卡中最重要（“关键”）的部分，以及你希望所有玩家都体验到的必需游戏内容。

单人[布局](/process/layout.md)图通常需要某种带标签的关键路径。在图中勾画、突出显示或标记关键路径——如果图太复杂，至少标记玩家起点、出口和带标签的兴趣点。

&#x20;    *关于为单人关卡设计主要路线的更多内容，参见* [*关键路径*](/process/layout/criticalpath.md)*。*

![标出关键路径和编号游戏玩法节拍的关卡布局示例](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lzym-tKNi8yXq0u-46X%2F-M-21_eOR8UaLLu3gHTW%2Fldb_layout_example.png?alt=media\&token=f74ce3a9-5602-4fd8-932a-0585e2757d19)

### 流线

**流线**（或“连通性”）指区域如何相互连接。

使用流线进行设计，有助于支持关卡的叙事和寻路与引导。拥有可信流线的关卡可能类似现实世界建筑的运作方式，从而允许玩家基于游戏外的常识，理解并预测其中的模式。

流线分析对多人地图设计尤其有用，因为多人地图通常更非线性，不遵循单条关键路径。相反，我们会把关卡布局组织成一个由*线路*组成的系统。

&#x20;    *关于叙事、寻路与引导以及多人线路的更多内容，参见* [*流线*](/process/layout/flow/circulation.md)*。*

![Studio Twenty Seven Architecture 为 Achievement Preparatory Academy 中学设计的流线图](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lxco6Y2Q4w3rLcoR9Y4%2F-LxcoEISPL1o6m16CVlo%2Fimage.jpeg?alt=media\&token=65698965-ce64-430d-afed-6a84d2eea47b)

## 回顾要点\...

**动线**关注玩家如何在关卡中移动。[垂直性](#verticality)是垂直动线。

**设计移动**时，思考速度、方向、[寻路与引导](/process/blockout/wayfinding.md)和[尺度规范](/process/blockout/metrics.md)。没错，事情很多。

思考动线的三种方式：

* **愿望线：**比较房间 / 区域内的理想路径和实际路径
* [**关键路径**](/process/layout/criticalpath.md)**：**完成单人关卡的理想玩家路径
* [**流线**](/process/layout/flow/circulation.md)**：**关卡的连接区域 /“线路”

**动线是一种工具。**效率低的“糟糕”动线不一定不好，因为它在合适的语境中可以发挥作用。同样，效率过高的“良好”动线也可能让人感到无聊。一切取决于你的设计目标。

## 延伸阅读

* Matthew “Lunaran” Breit 在 1999 年写下了关于动线的[早期关卡设计理论](https://web.archive.org/web/20080211132942/http://www.lunaran.com/page.php?id=189)，以及一篇关于[连通性的文章](https://web.archive.org/web/20080211132937/http://www.lunaran.com/page.php?id=188)。如今，[Breit 对自己过度规定性的语气感到后悔](https://web.archive.org/web/20080212182719/http://lunaran.com/page.php?id=9)（“……错误地断言死路、强制间接路线，或其他会减慢玩家的东西在本质上都是非法的……”），认为这是 Quake 迷弟心态的产物，但我们仍然喜欢他。
