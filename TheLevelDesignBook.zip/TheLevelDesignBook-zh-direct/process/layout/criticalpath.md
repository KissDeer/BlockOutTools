> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [process/layout/criticalpath.md](https://book.leveldesignbook.com/process/layout/criticalpath.md)。

# 关键路径

完成单人关卡所需的最短 / 主要玩家路径

**关键路径**（或**黄金路径**）是完成关卡并推进进度的主要预期玩家路径 / 流程。&#x20;

* 通常用于拥有脚本化推进的单人关卡，而不是多人游戏
* 突出关卡中最重要（“关键”）的部分
* 表示忽略可选支线区域的*理想玩家动线*

最后一点很重要。关键路径代表你的*理想*设计目标和要求，但它不是现实。大多数玩家会闲逛、探索、停留，甚至只是感到困惑。

## 如何规划关键路径

在布局图中，关键路径标注能帮助其他设计师和协作者理解关卡的[节奏](/process/preproduction/pacing.md)。什么会发生，发生在哪里？

1. 绘制初始[布局](/process/layout.md)。
2. 标出并标注玩家的起点和出口。
3. 标出、标注并给所有主要[节拍](/process/preproduction/pacing.md#beats-and-variation)编号。
4. 如果不会让图看起来过于混乱，就用箭头绘制玩家路线。

&#x20;    *关于绘制平面图的更多内容，参见* [*布局*](/process/layout.md)*。*

![标出关键路径和编号游戏玩法节拍的关卡布局示例](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lzym-tKNi8yXq0u-46X%2F-M-21_eOR8UaLLu3gHTW%2Fldb_layout_example.png?alt=media\&token=f74ce3a9-5602-4fd8-932a-0585e2757d19)

## 关键路径作为范围控制工具

在工程领域，项目经理使用[关键路径法（CPM）](https://en.wikipedia.org/wiki/Critical_path_method)来确定哪些任务必须先发生，以及为什么。绘制关键路径能帮助他们理解项目的逻辑和流程。

我们可以用类似的方式把关键路径用于关卡设计，帮助管理项目[范围](/process/preproduction/scope.md)。

* 关卡的每个部分有多重要？&#x20;
* 如果某些内容不在关键路径上，那么只有一部分玩家会看到它。值得制作吗？

![黄色阴影区域可以删除，而不影响关键路径](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lzym-tKNi8yXq0u-46X%2F-M-23nLAYXxdB2RkcTid%2Fldb_layout_criticalpath_scope.png?alt=media\&token=6ef8702f-7657-48c2-bbd1-8102d2358753)

关键路径帮助我们想象“最小可行”布局的样子。&#x20;

例如，在上面的布局图中，黄色阴影区域不在关键路径上。那么它还值得制作吗？如果砍掉这个区域，我们要做的工作就会变少。

也许关卡仍然太大，工作量仍然太多。也许我们需要继续删除内容。&#x20;

如果把所有支线区域都删掉呢？它仍然能满足体验设计目标吗？也许我们需要彻底重新设计关键路径……

![如果砍掉所有“非必要”区域呢？现在搭建工作更少了，但它仍然满足体验目标吗？](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lzym-tKNi8yXq0u-46X%2F-M-25rDXmTkGBWwuVS-O2r%2Fldb_layout_criticalpath_scope_cut.png?alt=media\&token=d96d97c2-5999-4ebe-a114-423b5aa29c23)

## 反对关键路径？

围绕关键路径设计，可能是一种缩减空间思考方式的做法。&#x20;

关键路径会从资源、闸门和目标的角度工具化世界，变成关卡设计师强加给玩家的一张活动清单。游戏和关卡能不能不只是供用户消费的“内容”？如果项目要求很高的真实感、可信度或地点感呢？围绕关键路径构建通常会产生一种“电子游戏味”的空间。&#x20;

相反，有些设计师更喜欢在已经完成的[布局](/process/layout.md)和[白盒](/process/blockout.md)之后再组织关键路径，让它沿着已有的关卡几何体展开。任天堂 64 版《黄金眼 007》（1997）的制作人 Martin Hollis 解释了他们的关卡设计流程：

> *“关卡创作者，或者说建筑师，在没有太多关卡设计的情况下工作。我的意思是，他们通常没有考虑玩家起点或出口。当然，他们也没有考虑敌人位置或物体位置。他们的工作只是制作一个有趣的空间。关卡制作完成后，Dave 或有时是 Duncan 会面对如何填入目标、敌人和各种东西的问题。这种草率、无规划方式的好处是，游戏中许多关卡都有真实感和非线性感。某些房间与关卡没有直接关系。关卡中有多条路线。这坦白说是一种反游戏设计方法。它效率低，因为关卡的大量部分对游戏玩法来说没有必要。但它带来了更强的自由感和真实感。而这种自由感和真实感反过来极大地促进了游戏的成功。”*\
> \
> ——Martin Hollis，《黄金眼 007》（N64）制作人，引自 Chris DeLeon 的[《〈黄金眼 007〉中的反设计 / 逆向游戏设计》](http://www.hobbygamedev.com/int/anti-design-in-ge007/)

![Chris DeLeon 截取的《黄金眼 007》（1997）“Surface”关卡几何体 https://imgur.com/a/MY59R](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M-pU2WbIwJYUhInjEjr%2F-M-pWiCryMn_6vmSeAKF%2FGoldeneye007_Surface_Geometry_ChrisDeLeon.png?alt=media\&token=0671a8d1-d31c-4ef9-b3c9-1b4f18ea8e09)

## 关键路径示例：《死亡循环》（2021）

在第一人称 RPG《死亡循环》（2021）的“Complex”关卡图中，关卡设计师 Sylvain Menguy 为非线性单人地图标出了关键路径。他记录了下午配置和晚上配置，以及玩家可能前往区域 Boss 的路线。

> *游戏有 4 张主要地图，每张地图都可以在一天中的 4 个时段游玩（早晨、中午、下午和晚上）。玩家可以自由探索关卡、参与战斗、发现谜题，甚至解决构成游戏主线冒险的“谋杀谜题”……*

这张近似的布局图为了突出整体而省略了不必要的细节，有助于沟通[节奏](/process/preproduction/pacing.md)。注意，下面的白色箭头与地图地形并不完全匹配，但仍然传达了大量关于预期路线的信息。虽然玩家一开始有 3 条线路，但这些线路总会汇聚到地图另一侧 Boss 竞技场的两个入口。

![Sylvain Menguy 绘制的《死亡循环》（2021）“Complex”地图布局动线图，来自 SylvainMenguy.com](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FQHC9gOvGNYfBc12JQ70n%2FLDB_Deathloop_ComplexLayout_SylvainMenguy.jpg?alt=media\&token=faa621bc-b515-47f9-bcb9-0a205ebc6810)

> *地图从一开始就支持多人游戏，另一名玩家可以在下午或晚上入侵。因此，这两个时段对布局的理解不同，与会来追逐 Colt、让他的生活更加艰难的反派 Julianna 的遭遇战也不同。*
>
> *这个跨时段共享的布局始终提供多种导航选项，禁止设置死路和玩家无法脱身的长走廊，从而带来更顺畅的体验，让玩家可以在区域之间快速转点……*
>
> ——[Sylvain Menguy](https://sylvainmenguy.com/en/project/deathloop)

“转点”是指玩家必须把注意力（“转”）切换到地图的另一个区域，通常出现在《反恐精英：全球攻势》等团队制多人射击游戏中。Menguy 把多人关卡设计思维用于单人关卡，这很有意思。

&#x20;    *关于多人设计中的转点，参见* [*地图平衡*](/process/combat/balance.md)*。*

## 回顾要点\...

**关键路径**是玩家推进单人关卡时的理想路线。

它主要是规划和范围控制工具，能在[布局](/process/layout.md)图中沟通[节奏](/process/preproduction/pacing.md)。如果需要缩减项目范围，它还可以帮助你决定砍掉关卡的哪些部分。

然而，优先考虑关键路径可能会产生更人工、更不自然的空间。有些关卡设计师先设计空间，再之后确定关键路径。

## 接下来做什么？

* 进一步阅读[布局](/process/layout.md)和[动线](/process/layout/flow.md)。
* [流线](/process/layout/flow/circulation.md)也有助于思考。
