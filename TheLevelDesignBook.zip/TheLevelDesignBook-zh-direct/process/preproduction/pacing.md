> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [process/preproduction/pacing.md](https://book.leveldesignbook.com/process/preproduction/pacing.md)。

# 节奏

规划玩家在关卡中经历的各种活动与事件

## **什么是节奏？**

**节奏（pacing）**是关卡中活动与事件的大致顺序和律动。

单人关卡往往需要清晰而有力的节奏。如果玩家搞不清楚关卡中发生了什么，或者不知道自己能做什么，这可能就说明节奏存在问题。

一份有效的节奏计划应该回答：

* **范围：**玩家在每个关卡中能做什么？
* **层级：**关卡的哪些部分最重要？
* **因果：**玩家为什么要先做这件事，再做那件事？
* **信息：**我们告诉玩家什么，以及什么时候告诉？
* **强度：**玩家什么时候应该集中注意力，什么时候应该休息和恢复？

![《旅程》（2012）的节奏/剧情曲线图，来自 GDC 2013 演讲“设计《旅程》”](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lu4KBQwhlYBmS5t08B3%2F-Lu4N6a6empTSqjph2ZZ%2Fgdc2013_journey_pacing.jpg?alt=media\&token=e3177f05-d042-46a9-94fe-7421937c93a0)

## 节拍与变化

你的关卡中会发生什么？哪些时刻和地点共同定义了这段体验？

**节拍（beat）**是关卡中一个自成一体的小片段：一个区域、一个事件、一项活动或一个元素都可以是节拍。

我们可以把这些节拍比作歌曲中的音乐节拍。它们共同演奏时，会形成旋律和节奏。每个节拍都可以单独理解，也可以看作整体的一部分。为了让节拍更有趣，作曲家会用不同方式**编排**节拍，从而制造**变化**：

* **脉冲：**建立一种像心跳一样规律重复的节拍模式，确立[节拍（meter）](https://en.wikipedia.org/wiki/Metre_\(music\))。
  * *例：用一扇有辨识度的出口门结束每个关卡。*
* **重音/强调：**突出或强化某些节拍。
  * *有时出口很难找到或抵达。*
* **休止：**加入较弱的节拍或寂静，让观众重新对重音敏感。
  * *有时出口很容易找到或抵达。*
* **动机：**一小段反复出现的节拍序列。
  * *有时玩家必须在到达出口前与 Boss 战斗。*
* **变化：**重复一组节拍，但改变旋律、节奏等内容。
  * *有些关卡有多个出口门。*
* **切分：**偏离正常节拍，这是现代流行音乐的基础。
  * *Boss 战进行到一半时，另一个 Boss 出现。*
  * *有时假出口门后面藏着一只怪物。*
  * *最终 Boss 摧毁出口门，现在无处可逃。*
  * *玩家获得制造出口门的能力。*

![音乐理论中对不同节拍的强调（拍号、节奏、切分、预期），出自 Jack Perricone 的《歌曲创作中的旋律》](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MaqlzkI4oJ6odd7CSTG%2F-Mar2Q9Sf4lW5LaVAJUT%2FLDB_Rhythm_JackPerricone.png?alt=media\&token=edb45572-7112-47fc-a849-6c546570880f)

### 大型场景

**大型场景（set piece）**是一个格外复杂的节拍，拥有独特的概念或令人难忘的活动。

大型场景的实践[源于电影制作](https://en.wikipedia.org/wiki/Set_piece)：大预算电影项目经常会投入大量资金，制作需要独特场景和复杂规划的大型段落——这是一种观众会记住的高强度奇观。

例如，好莱坞商业动作片本质上就是一系列大型场景：规模宏大的战斗、追逐，以及与死亡擦肩而过的特技。电影的其他部分主要负责以一种基本连贯的方式把这些大型场景连接起来，并在激烈场景之间给观众提供休息。商业动作游戏的运作方式也很相似。

但大型场景不一定要是爆炸不断的动作场面。喜剧可以围绕极其尴尬、滑稽的处境展开；爱情片可能强调第一次约会或婚礼；剧情片可能安排催人落泪的坦白或背叛；推理片则会在结尾让侦探讲述真相。

电影或游戏中任何让人觉得重要、令人难忘或制作成本高昂的场景，很可能就是大型场景。

![动作电影《黑客帝国》（1999）中令人难忘的大厅枪战大型场景截图](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mar5HfLlJzHJcnFm7f9%2F-MarxR9pOotLOvQWrSIl%2FLDB_Matrix_Lobby_Setpiece.jpg?alt=media\&token=754cafc3-d3cf-43c0-a280-714bdd454021)

![电影《低俗小说》（1994）中令人难忘的舞蹈场景大型场景截图](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Mar5HfLlJzHJcnFm7f9%2F-MarySLySq_SoqnPtIDB%2FLDB_PulpFiction_Dance_Setpiece.jpg?alt=media\&token=82740ca6-ac02-4360-b2dc-525f67b84c74)

在游戏中，大型场景通常具有以下特征：

* **昂贵：**需要许多独特的美术和动画资产，以及持续迭代。它不容易缩小范围，也不容易改作他用，因此制作风险天然很高。
* **不可跳过：**与项目的核心支柱和主要体验目标紧密相连。如果玩家可能错过某个内容并因此责怪游戏，为什么还要花那么多时间和钱制作它？
* **高度脚本化：**通常具有一定的线性或“轨道式”结构，以确保玩家获得稳定可靠的体验。
  * 如果大型场景有三种不同的展开方式，那么它实际上相当于三个大型场景，制作成本也会变成三倍。

大型场景的关卡设计通常包括：

* **Boss 战、大型谜题或编舞：**需要大量[关卡脚本](/process/scripting.md)的内容。
* **竞技场**类型：一个大型房间，在玩家完成遭遇战或过场动画之前把玩家困在其中。
* [**核心道具**](/process/env-art.md#hero-props-landmarks)：独特的环境美术资产，让关卡显得格外特别。

在任何项目中，都可以尝试至少设计并规划一个大型场景。这些段落会成为项目其他部分的锚点。理想情况下，这个大型场景应该是你非常期待的内容，是你迫不及待想让玩家体验的东西。

如果你害怕制作大型场景，或者更糟糕的是，你根本不希望玩家真的玩到它，那么你大概就不该做它。

如果你正在学习一套新的工具，不要规划一个庞大的史诗级大型场景。如果你刚接触游戏开发，在积累足够经验之前，你可能很难判断大型场景的范围。记住：最好的大型场景，是那个你确实有机会完成并发布的大型场景。

### “节拍堆”方法

以战斗为主的项目和解谜游戏，可以从分别设计许多节拍、之后再把它们组合起来的方式中获益。工作流程如下：

1. 构思、绘制布局并白盒化一个孤立的战斗或谜题。
2. 对白盒进行试玩测试和迭代，直到它证明自己有潜力，或证明自己是个坏主意。
3. 重复第 1—2 步，直到你制作出几十个战斗或谜题原型。
4. 根据共同元素（或对比元素）编排最好的节拍。

第一人称解谜游戏《传送门》（2007）最初就是一系列互不相连的谜题房间原型；设计师选出最喜欢的谜题后，这些房间才逐渐凝聚成一套连贯的关卡战役。每个测试房间入口牌上展示的谜题元素图标，就是“节拍堆”流程留下的痕迹。

![《传送门 1》测试房间入口牌截图，图标显示该谜题中出现的不同元素](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Ml2zWACle45CIw9K_Ej%2F-Ml30L2-EZxNLTJiiJV2%2FLDB_Portal_Pacing_TestChamberSign.jpg?alt=media\&token=d100d650-d688-4363-ab25-bb9ce22653f8)

### 教学—测试—变化

**教学—测试—变化（teach, test, twist）**是关卡设计中常见的三节拍模式：

* **教学：**教玩家一项游戏活动。
  * *例：在*[《传送门 1》第 10 个测试房间](https://theportalwiki.com/wiki/Portal_Test_Chamber_10)*中，玩家学会简单的*[“弹射”](https://theportalwiki.com/wiki/Flinging)*。*
* **测试：**在提示下测试玩家能否重复并*识别*这项活动。
  * *之后，在《传送门 1》第 10 个测试房间中，玩家要完成一次更深入的弹射。*
* **变化：**改变这项活动的条件；减少提示后，玩家还能否*回忆起*它？
  * *在*[《传送门 1》第 12 个测试房间](https://theportalwiki.com/wiki/Portal_Test_Chamber_10)*中，玩家从更高处进行弹射。*
  * *在*[《传送门 1》第 15 个测试房间](https://theportalwiki.com/wiki/Portal_Test_Chamber_15)*中，玩家在空中完成“二段弹射”。*
  * *接着，*[《传送门 1》第 18 个测试房间](https://theportalwiki.com/wiki/Portal_Test_Chamber_18)*以一次“无限弹射”挑战收尾。*
  * *注意这些“变化”节拍之间留有间隔，并不会紧跟在“测试”之后。*

{% embed url="<https://youtu.be/ZFwxnKY7CUo?t=10>" %}
《传送门 1》第 10 个测试房间中的“教学”和“测试”节拍，来自攻略实况视频
{% endembed %}

## 关键路径

节奏设计假设我们能够影响、预测并限制玩家在游戏中会做什么或能够做什么。**关键路径**是每个玩家都必须经历、才能“完成”游戏的核心节拍进程——至于“完成”具体意味着什么，则取决于游戏本身。

关键路径可以有多种形式：

* 对遭遇战来说，关键路径可能是击败敌人的理想策略。
* 对谜题来说，关键路径是谜题的解法，或者至少是最令人满意的解法。
* 对移动来说，关键路径是完成关卡的理想路线。

*更多内容参见* [*关键路径*](/process/layout/criticalpath.md)*。*

## 绘制与记录

概括和记录关卡节拍有几种方法：

* **节拍表：**简单的节拍文字列表；
* **流程图：**展示节拍如何互相连接的图；
* **强度曲线：**把节拍按照某个玩家指标绘制出来的分段条形图。

### 节拍表

在电影和电视的编剧工作中，**节拍表**是概括主要场景和剧情节点的列表。在关卡设计中，我们也可以用类似方式绘制节拍：列出主要事件、场景和关卡。

把节拍表写在纸上、在线文档或电子表格中，也可以把它做成带有可移动卡片的项目看板。然后，把大型场景、场景、关卡、Boss 战等创意写成段落、行、索引卡或便利贴，再重新排列这些节拍，组成连贯的大纲。

* 在团队中，面对面或通过通话讨论并把思路说出来很重要。
* 一些免费的在线项目看板工具：[Trello](https://trello.com/)、[Notion](https://www.notion.so/)、[Miro](https://miro.com/)、[Codecks](https://www.codecks.io/)。
* 理想情况下，使用现实中的看板或墙面，这样就不用担心浏览器标签页。

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FwY9OZ9CSNXZx1xfq0Qw%2FLDB_PacingEncounterCombat_RobMeyer_GodOfWarRagnarok.jpg?alt=media&amp;token=45ce4dd9-2189-4f2e-b175-9507e821d7c2" alt=""><figcaption><p>“早期规划与共享生命条”幻灯片，来自 Rob Meyer 的<a href="https://youtu.be/6iTBqcBv5QA?t=3160">《与命运清算：诸神黄昏规模的战斗设计》</a>（来自 YouTube）</p></figcaption></figure>

节拍表的形式很多，取决于你在设计什么，以及它的用途是什么。

对于动作 RPG《战神：诸神黄昏》（2022），首席战斗设计师 Rob Meyer 撰写了“Boss 流程”文档（见上图），概括大型 Boss 战大型场景的关键元素和设计理由；这些文档帮助 Meyer 获得了制作系统性很强的战斗概念原型的批准。

对于《最后生还者》（2013），顽皮狗的设计师在整个游戏弧线中重新排列不同的关卡、故事时刻和主题。这张“节拍板”（见下图）帮助他们规划最终游戏的节奏，而最终成品其实与这里展示的早期计划有很大不同。

![顽皮狗为规划《最后生还者》（2013）制作的内部图钉板，来自 V&A 电子游戏展（2018）](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lu4Y_E2F6Jj22AaTeoF%2F-Lu4cB1iELo7OzM1v7oa%2Fv%26a_lastOfUs_planning_board.jpg?alt=media\&token=db00790c-1290-4394-a553-15c3cc974967)

### 流程图

[**流程图**](https://en.wikipedia.org/wiki/Flowchart)是用线、箭头和分支表现流程或程序的视觉图示。它把节拍之间连接的*逻辑*可视化。这对于解谜游戏，或拥有多种可能策略和事件链的非线性关卡很有用。当因果关系非常重要时，就使用流程图。

你可以在纸上或白板上绘制流程图，也可以使用在线白板或流程图工具。我们推荐 [Miro](https://miro.com/)。

* 尽可能让流程图保持简单。少用文字，省略次要节拍。如果它看起来像一团意大利面，那就说明过于复杂，需要简化。
* 尽量让流程图朝一个方向“流动”，例如从上到下，或从左到右。
* 根据节拍类型给方框填上不同的颜色。
* 不要制作一张巨大的流程图，可以把它拆成几张小流程图。

![Dana Nightingale 为《耻辱》潜行 Boss 遭遇战制作的流程图设计文档](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MVeiD_JUQ3mH55QvMSA%2F-MVekqo2wQ315ngopCaM%2FLDB_Encounter_Daud_Dishonored_DanaNightingale.png?alt=media\&token=80c095cc-2557-4ab8-aae3-9c6abe11f06d)

### 图表

如果要更详细地规划节奏，可以按照玩家的某个[指标](/process/blockout/metrics.md)排列关卡，并用**图表**可视化剧情。

在规划《半条命 2：第二章》和《求生之路》的关卡节奏时，Valve 设计师把节拍分为四类：

* *探索：*在空间中行走和导航，通常位于关卡的开头和结尾。
* *战斗：*与敌人交战。
* *编舞：*对话或经过编排的脚本化段落，用在战斗之前或之后，帮助提示战斗何时开始或结束。
* *谜题：*寻找物品储藏处、解锁一扇门等，用来拉开战斗序列之间的距离。

由于这些都是动作射击游戏，设计师关注的是**强度**。他们在水平 X 轴上绘制以分钟计算的时间，在垂直 Y 轴上用 0—100%、0—5 或 0—10 的简单数字刻度绘制强度。

![《半条命 2：第二章》白森林旅馆遭遇战的强度图，来自 GDC China 2014](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Ltl6WEWlIdpFwv9uPHR%2F-Ltl7Uo8sYvll_0cYTjA%2Fgdc2014_valve_pacing-graph.png?alt=media\&token=65facf01-0612-4bcf-8464-899fff7cec90)

但“5 分强度中的 4 分”究竟是什么意思？强度分数只是熟悉游戏并观察试玩测试后产生的直觉，并不是什么严谨的科学。

每个项目都必须自行设计类别和指标。你要如何定义“强度”？

在《旅程》中，强度不一定与游戏难度相同。

例如，深爱的角色死亡，可能是一段没有玩家输入、难度很低的过场动画，但它依然具有很高的情绪强度。在这个意义上，强度更适合被理解为游戏体验中的*悬念*、玩家的*利害关系*或*投入程度*。

![thatgamecompany 为《旅程》（2012）制作的内部电子表格，来自 V&A 电子游戏展（2018）；注意其中针对不同体验目标设置了多行，顶部还有强度条](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LzZS1CMIiUN5NWR-Wcz%2F-Lu4cvf00yi4UTlgdz3D%2Fv%26a_journey_pacing_spreadsheet.jpg?alt=media\&token=f9001e3f-38ff-4a3f-8c27-b6611dd04581)

## 节奏建议

#### 从缓慢而安静的节奏开始

《半条命》（1998）以一段朴素的 6 分钟电车旅程开场，这一点广为人知。让游戏或关卡从低强度内容开始，比如介绍性的过场动画，或低风险的探索。这能奠定氛围，也为[世界构建](/process/env-art/storytelling.md#worldbuilding)的背景介绍留出时间。即便是《毁灭战士》或《雷神之锤》这样的高强度动作射击游戏，也会先让玩家置身安静的房间，测试操作并“热身”，之后才进入战斗。

#### 交替安排高点与低点

玩家会逐渐适应长时间的高强度。任何激烈的 Boss 战，持续 10 分钟以上都会变得像苦差事。为了保持新鲜感，可以偶尔安排停顿作为对比和调剂，否则玩家只会逐渐麻木。不要试图强迫玩家一直保持“在线”状态。

高强度 Boss 战之后，过场动画和低强度区域会像奖励一样。或者，你的核心机制也可以鼓励玩家休息并回到城镇，例如出售战利品、修理装备、交付任务等。

#### 避免把最终 Boss 或最终遭遇战做成最高强度

thatgamecompany 读过 Joseph Campbell 的[英雄之旅](https://en.wikipedia.org/wiki/Hero%27s_journey)单一神话，并非常喜欢它，于是把自己的游戏命名为《旅程》。其他设计师则会参考[三幕结构](https://en.wikipedia.org/wiki/Three-act_structure)、[Gustav Freytag 的五幕结构](https://en.wikipedia.org/wiki/Dramatic_structur)和[亚里士多德的《诗学》](https://en.wikipedia.org/wiki/Poetics_\(Aristotle\))等经典叙事理论。这些传统叙事理论通常以*下降动作*、*“结局”*或最终反派的失败收尾；它必须让人感觉是高潮必然导致的结果，否则就会削弱高潮的冲击力。游戏中的例子包括：

* 《黑暗之魂》的最终 Boss 生命值很高，但战斗风格相对简单，且有明显的前摇；它仍然具有挑战性，却远不是游戏中最难的遭遇战。
* 《传送门 1》和《传送门 2》的最终[谜题](/process/scripting.md#puzzles)都提供了经过前置铺垫的简单解法，显然不是游戏里最难的谜题。
* 《半条命 2》的最终关卡包含低压力、过强且失衡的战斗遭遇战，同时主要反派还在长篇大论地讲述自己注定会失败。

![StoryboardThat 绘制的典型五幕剧情结构图；垂直轴更适合理解为“悬念”而不是“强度”](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lu4ic797CAh1mrlypiL%2F-Lu5-cXem4pGeyN_g4Jx2%2FFiveActStructure_StoryboardThat.png?alt=media\&token=d94bbb48-1df7-4753-af31-81be9ae2684b)

经典叙事理论很有用，但要注意：

* 故事中的“强度”不一定与游戏中的强度含义相同。
* 大多数游戏的进程或学习曲线很少出现“下降动作”。
  * 大多数游戏都在讲述如何避免失败。熟练的游玩意味着玩家会避免下滑、犯错或提交错误；但失败和错误往往能构成更好的故事。
* 在游戏之外，这些都是许多作家试图避免的经典叙事理论。使用这些模式常常会让作品显得刻板或公式化。

## 多人游戏节奏

竞技多人游戏的节奏更多来自整体玩法循环和游戏模式规则。在[大逃杀游戏](https://en.wikipedia.org/wiki/Battle_royale_game)《绝地求生》《堡垒之夜》或《Apex 英雄》中，当最后几名玩家被困在很小的区域里时，比赛会变得更加刺激。但这几名玩家究竟在哪里、什么时候展开最后的决战？每场比赛都不同，我们无法用脚本预先安排比赛会如何展开。

对于《反恐精英》《军团要塞》或《守望先锋》这样的团队游戏，关卡设计师必须仔细安排出生点区域与关键瓶颈之间的移动时间。如果某个队伍能够以不公平的方式抢先占据瓶颈，那么地图就会显得[失衡](/process/combat/balance.md)。在这里，节奏更多是地图[动线](/process/layout/flow.md)、[布局](/process/layout.md)和[尺度规范](/process/blockout/metrics.md)的直接结果。

![《英雄联盟》（左）或 de_dust2（右）这样的多人地图，其大部分节奏高度依赖移动时间、布局和动线](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Lznde4LEhCB3ysDM0gz%2F-Lznks0aLf0e75KmhiT4%2Fleague_dust2_threelane.jpg?alt=media\&token=173bf66b-b486-4399-ba46-846dd29f54b0)

## 开放世界/非线性节奏

在开放世界游戏中，玩家通常可以选择多条路线前往目标。设计一条单一路径没有意义，因为我们本来就希望给玩家一定自由，让他们自行选择路线和推进方式。但和多人游戏节奏一样，开放世界游戏会尽量减少脚本化节奏，因此布局和尺度规范是规划玩家穿越关卡速度的主要工具。

在开放世界潜行游戏《刺客信条》中，关卡设计师先制作[白盒](/process/blockout.md)，再把任务规划为一组同心圆叠加图。玩家靠近目标时，每个阶段或区段会逐渐变小、变密。随着玩家逐层突破敌人的防线，每个区段都会提升挑战感和危险感。

![《刺客信条》开放世界任务图，绿色为安全观察区域，红色为高安保目标区域；作者：Phillippe Bergeron，来自 GDC 2016 演讲“关卡设计工作坊：开放世界任务设计的 360 度方法”](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MIUaDM0tISsAW6yRYQT%2F-MIUd1IBf1rciZY-ixN9%2FLDB_OpenWorldPacing_AssassinsCreed_PhilippeBergeron.jpg?alt=media\&token=af860dbc-7f38-4c77-a833-9b1f3719023a)

## 反对节奏计划

节奏计划和文档在项目早期最有用。

* 文档很快会过时，需要持续维护；
* 许多项目规模太大，一份文档无论如何都无法容纳全部复杂性；
  * 大型工作室和团队会维护内部 Wiki，以及几十甚至几百份设计文档；
* 你无法对文档进行试玩测试，设计文档经不起现实检验。

初始计划很重要，因为它让所有人使用共同语言，对项目形成共识。但到了某个阶段，你必须关注实际正在制作的游戏，而不是当初计划中的想象游戏。

## 回顾……

**节奏**是关卡中活动或事件理想的顺序和律动。**节拍**是一项活动或一个事件。

* 单人关卡通常有清晰的关键路径和大型**场景**。
* 对于战斗和谜题系统都很多、遭遇战密集的游戏，“**节拍堆**”方法效果很好——先制作一批遭遇战和谜题，再把它们排列起来，也可以组成“**教学—测试—变化**”模式。
* 多人游戏的节奏更多来自[布局](/process/layout.md)，而不是设计好的事件。
* 开放世界或非线性节奏需要更宽松的“区域”方法。

节奏设计文档可能包括：

* **节拍表：**书面大纲，以列表或看板形式呈现节拍；
* **流程图：**带有箭头和逻辑的视觉大纲；
* **图表：**根据“强度”等玩家指标绘制节拍。

你在制作游戏的过程中，​​这些文档经常会过时。你可以更新它们，也可以忽略它们。

### 节奏延伸阅读

* 许多关于节奏和剧情曲线的行业理论来自电影与电视编剧，其中 [Robert McKee](https://en.wikipedia.org/wiki/Robert_McKee) 颇具影响力的著作 *Story: Substance, Structure, Style and the Principles of Screenwriting*（1997）占据重要位置。批评者认为 McKee 的方法会导致陈旧、公式化的叙事，但无论好坏，他的影响力都很难否认。
* 叙事设计领域比关卡设计师花了更多时间思考节奏。每当作者谈论“剧情”时，他们谈论的其实都是节奏，而你可以把这些洞见联系到关卡设计上。
