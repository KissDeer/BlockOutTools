> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [process/combat.md](https://book.leveldesignbook.com/process/combat.md)。

# 战斗

设计玩家与 / 或 NPC 之间的物理冲突

## **什么是战斗设计？**

**战斗设计**关注为玩家之间，以及通常还包括玩家与 AI 控制敌人之间的物理冲突制作游戏系统。&#x20;

在关卡设计中，我们通常假设这是第一人称射击或其他实时 3D 动作游戏中的战斗。本书也会基于这一假设展开。

请注意，竞技性的**玩家对玩家（PvP）**与单人 / 合作的**玩家对敌人（PvE）**战斗运作方式非常不同。PvP 通常意味着所有战斗者都有公平的获胜机会。相比之下，PvE 提供的是延迟但有保障的胜利。这是向玩家做出的两种非常不同的承诺，因此关卡设计也不同。

&#x20;    *如果你实际上不选择暴力，那就跳到[布局](/process/layout.md)继续学习。*

![《毁灭战士》（1993）截图，这款早期第一人称射击游戏普及了如今许多战斗设计模式](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MaDzEb98ZiFVBU8oEwG%2F-MaE1sNLV9gjsjW2nUtm%2FLDB_Doom1993_Gameplay.jpg?alt=media\&token=ac242d30-a8ad-455a-bf99-ac506977fffe)

## 战斗系统

制作战斗游戏时，你有两个选择：

* 修改一款已有的战斗游戏。
* 从零开始制作自己的战斗玩法。

没有好的战斗系统，就无法制作好的战斗关卡。但开发这个核心战斗工具包需要大量代码、美术、动画、音频和调校工作。&#x20;

这是一个超出关卡设计书范围的复杂主题。问“如何制作好的战斗？”就像问“如何制作一款好游戏？”一样，是个很大的问题。

这就是我们强烈建议制作模组的原因：这样可以复用游戏已经经过验证的核心战斗系统，而不必自己搭建一套。

&#x20;    *推荐修改和研究的战斗游戏列表，参见* [*工具*](/appendix/tools.md)*。*

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FM7vrEtuIuX99gobPUa1d%2FLDB_GDC2012_Skylanders_CombatFarEnemy.png?alt=media&amp;token=852b3154-5f00-4005-8169-9dfa97c1a0c2" alt=""><figcaption><p>演讲幻灯片，出自 Mike Stout 在 2012 年 GDC 的演讲<a href="https://www.gdcvault.com/play/1015838/Reaching-Into-the-Toy-Chest">《深入玩具箱：〈Skylanders Spyro's Adventure〉设计一瞥》</a></p></figcaption></figure>

话虽如此，即使你修改一款已有的战斗游戏，也必须能够理论化地理解它的运作方式。所有单人和多人战斗游戏都以某种形式包含以下核心元素：

* **战斗机制**
* **武器设计**
* **经济系统**

在拥有专业开发岗位的大型商业工作室中，**这些核心战斗元素都不会由关卡设计师负责**。然而，关卡设计师不理解它们，就无法制作关卡。

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LtX1qT9uxspZe0aRBgD%2F-LtX9S_JeZqVlz5xv8rG%2Fgdc2016_combat_fronts.png?alt=media&amp;token=0079286c-7ad9-4d5c-a142-fc13d2a47fb5" alt=""><figcaption><p>图片出自 Michael Barclay 等人在 2016 年 GDC 的演讲<a href="https://www.gdcvault.com/play/1023791/Creating-Conflict-Combat-Design-for">《制造冲突：AAA 动作游戏的战斗设计》</a></p></figcaption></figure>

### 战斗机制

**战斗机制**是玩家用来对抗敌人的重复动作 / 技能 / 武器。一些常见的战斗机制：

* 远离危险、控制**领地**
* 瞄准特定敌人类型 / 弱点
* 针对攻击的**前摇 / 预示**（机会）把握**时机**
* 将攻击串成**连招**，组合动作或武器
* 格挡敌人攻击；在正确时机进行**招架** / **反击** / **闪避**
* 使用爆炸桶、水、熔岩、悬崖等**陷阱**

![Sony Santa Monica 为《战神》（2018）制作的 2014 年早期测试地图 + 战斗原型动画 GIF](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MCcQT9RgVLd-yLRamEE%2F-MCcQmBwTl4MKjF33SYl%2FGodOfWar2014_CombatPrototype.gif?alt=media\&token=e4c053d2-c9b7-4bbb-92e7-ec21bee8bc54)

### 武器设计

许多游戏会为玩家提供多种武器。**武器设计**关注如何构思、实现和平衡这套武器库。需要考虑的方面包括：

* **武器手感和幻想**（例如大型缓慢的枪、隐蔽的刀、响亮的链锯）
* **数值**，例如不同的伤害、射程、射速、弹药供给
  * 对枪械而言：不同的散布、后坐力、瞄具、穿透力、弹匣容量、装填速度
* **态势感知**，选择最合适 / 有效的武器

![启发了此后许多射击游戏的《毁灭战士》（1993）武器：(1) 链锯；(2) 手枪；(3) 霰弹枪；(4) 超级霰弹枪；(5) 链式机枪；(6) 火箭发射器；(7) 等离子枪；(8) BFG](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MWwF44URjg88NMz-OF3%2F-MWwJUl5WpzfUVf-IlEy%2Fdoom-2-weapons.png?alt=media\&token=9a0f58cb-87c0-483d-a81e-de1581ac70c7)

### 经济系统

**经济系统**是一个广义的游戏设计术语，指玩家在整个游戏过程中必须考虑的成本 / 收益 / 奖励总体系统。玩家获取资源的情况会影响他们使用哪些机制和武器，以及何时使用：

* **武器经济：**弹药、时间（DPS）、武器库 / 装备配置
  * *例：玩家只剩 1 枚火箭，因此会留到面对弱点是火箭的强敌时再用*
  * *例：玩家在水下只有 15 秒氧气，所以需要使用高 DPS 武器对付水下敌人*
* **玩家状态：**类似生命值、背包、消耗品这样的*短期经济*
  * *例：玩家有 99% 生命值，因此会避开能增加 +25% 生命值的生命物品，因为那会“浪费”拾取物 24% 的效果*
* **玩家成长：**类似经验值、技能、升级、装备这样的*长期经济*
  * *例：玩家有 99% 生命值，但拥有一项在满生命值时提供 +100% 伤害的升级，因此仍然决定拾取 +25% 生命值的物品，因为伤害加成比浪费的治疗更有价值*

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2Fiz3dIaVNvmDNNOlmE843%2FLDB_CombatProgression_RobMeyer_GodOfWarRagnarok.png?alt=media&amp;token=8cf58f25-1f6d-4f3e-b22d-913b64ca4793" alt=""><figcaption><p>动作 RPG《战神：诸神黄昏》（2022）使用的武器成长表格，来自 Rob Meyer 的演讲<a href="https://youtu.be/6iTBqcBv5QA?t=1311">《与命运清算：〈诸神黄昏〉规模下的战斗》（2023），Rob Meyer（来自 YouTube）</a></p></figcaption></figure>

> *“我们尝试以我们认为在纸面上健康的方式，为装备获取和成长建立预期模型，然后不断试玩测试并迭代，努力让试玩测试的现实结果符合我们的模型。* \
> \
> *[这里是一张表格（如上图），展示了游戏不同阶段、不同装备槽位的计划战力成长。每一行代表游戏时间线中的一个不同等级。每一列代表一件不同的装备，这些数字是我们预期你在游戏该阶段把那件装备提升到的等级。我们会不断交叉参考我们认为应该发生的事情和试玩测试中实际发生的事情……*
>
> *我们使用的一个技巧是[让升级已有装备的成本高于购买新装备]，这样你就会暂时有动力去寻找新装备\[...] 或者，在我们知道当时还没有资源从 4 级升级到 5 级时，在探索内容中奖励 5 级护甲，这样我们能保证这件护甲在短时间内令人兴奋、让人想要。”*
>
> ——Rob Meyer，[《与命运清算：〈诸神黄昏〉规模下的战斗》（2023）（YouTube）](https://www.youtube.com/watch?v=6iTBqcBv5QA\&t=1311s)

## 战斗示例

这里总结三种主要的战斗方式：

* **经典战斗**（Doom、Quake）关注**移动**
  * **魂系游戏**（《黑暗之魂》《血源诅咒》《艾尔登法环》）要求**闪避**
  * 战斗通常是近距离且连续的。
* **军事写实**（《反恐精英》《使命召唤》）关注**瞄准**
  * **大逃杀**（《堡垒之夜》《PUBG》《Apex Legends》）进一步加入了更多**经济系统**
  * 战斗通常是远距离且混乱的。
* **现代战斗**（《光环》《军团要塞 2》《守望先锋》）强调**伤害**
  * **掩体射击**（《战争机器》《神秘海域》）加入了**站位**
  * 战斗通常是中距离且有节奏的。

注意：没有任何游戏能完全符合某一类别。这些只是示例，也只是思考这些游戏的一种方式。

![《毁灭战士 2》中标志性关卡“Dead Simple”的截图，作者 American McGee 和 Sandy Petersen。](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MWwF44URjg88NMz-OF3%2F-MWwIRW8W0Iwo1pox6n-%2FLDB_Doom2_DeathSimple_Mancubus.png?alt=media\&token=9932a024-5478-4db0-91db-eb1d471405dd)

### 经典战斗

《毁灭战士》（1993）的战斗具有很强的内置自动瞄准辅助。玩家甚至不能上下垂直观察。Doom 显然不是关于瞄准的。相反，Doom 的高速移动支持了拥有大量敌人、丰富遭遇战变化和巨大复杂关卡布局的关卡。

> *“[玩家]的移动速度约为每小时 50 个尺度单位——按现代标准看快得不合理。Doom 的大多数敌人没有瞬间命中的投射物攻击，而有这种攻击的敌人大多也很弱——低等步兵和中士。其他敌人的投射物都需要时间才能命中目标，在更写实的视觉呈现中会显得很滑稽。*
>
> *因此，因为玩家在 Doom 中移动得非常快，而且大多数敌人攻击都能躲开，玩家只靠移动就能避免相当多的伤害。\[...] 这让 Doom 的遭遇战可以加入大量敌人，通过混合不同威胁的比例来改变场景，还可以制作巨大、复杂、通常非线性的空间，让玩家轻松穿越。”*&#x20;
>
> *——JP LeBreton，* [*《腔棘鱼：从 Doom 中得到的教训》*](http://vectorpoem.com/news/?p=74)

《黑暗之魂》式动作 RPG 通过“翻滚”正式化了闪避机制，并以“无敌帧”（I-frame）在正确时机完全抵消伤害。学习读取敌人的招式，以及通过重新定位 / 闪避来避免伤害，往往比使用最好的武器或拥有最好的装备更重要。

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MWwKuv36sIacrXzo8RS%2F-MWwMiIwfWDFwy2gYMXs%2Fquake1.jpg?alt=media&amp;token=d3172b72-6176-4e74-9225-6f7742df1516" alt=""><figcaption><p>Quake（1996）截图，呈现它在 1996 年可能有的样子</p></figcaption></figure>

### 军事写实

最初的《反恐精英》（1999）以写实军事风格普及了竞技性团队多人游戏。武器杀伤力很高，战斗在几秒内就会结束。成功取决于快速反应，以及在正确时间瞄准正确位置，同时清理射击角度和视线——但闪光弹和烟雾弹可以阻断视野。不同的枪械精度、后坐力和子弹穿透机制进一步支持了这种注重观察和瞄准的玩法。

更新近的大逃杀类型最初是名为 ARMA 的写实军事模拟射击系列的模组，其许多做法延续到了《PUBG：绝地求生》中，后者是商业上第一款成功的大逃杀射击游戏。即便是《堡垒之夜》或《Apex》等军事色彩较弱的大逃杀游戏，也仍然很常见新玩家突然被百米外看不见的狙击手击杀。然而，这一切都取决于玩家积累补给和枪械的能力，这为每一局增加了背包管理和类似 RPG 的成长因素。

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FYzdB7hFJPYBMQGzUCZDF%2FLDB_CS16_Combat.jpg?alt=media&amp;token=c0e4a8a0-30d1-4d70-8910-707269a52260" alt=""><figcaption><p>Dave Johnston 为《反恐精英 1.6》制作的标志性多人地图 de_dust2 游戏截图</p></figcaption></figure>

### 现代战斗

在《光环：战斗进化》（2001）中，玩家移动缓慢，跳跃也非常漂浮，因此这里没多少闪避。但这里也没多少瞄准；默认手枪臭名昭著地是游戏中最好的武器之一，配合细微的自动瞄准“磁性”，可以廉价而频繁地进行中距离 / 远距离爆头，非常适合休闲主机游戏。光环关注的不是移动或瞄准，而是管理伤害：

> *“在几乎所有现代 FPS 中，玩家移动得相当慢，而且很大一部分敌人装备了瞬间命中的攻击——手枪、机枪、狙击步枪。这通常让玩家扮演‘伤害海绵’的角色——他们预期承受一定量的、基本无法避免的敌人攻击，然后寻找掩体并恢复生命值。光环的可再生护盾把这个机制表达得非常明确——默认情况下，玩家暴露在伤害中会死亡，而寻找掩体会停止这一过程，并完成任何战斗基本循环。”*
>
> ——JP LeBreton，[《腔棘鱼：从 Doom 中得到的教训》](http://vectorpoem.com/news/?p=74)

《军团要塞 2》等多人团队射击游戏非常强调治疗，以至于每支队伍都总是需要一个治疗者。《守望先锋》在光环的可再生护盾机制之上继续发展。《战争机器》或《神秘海域》等掩体射击游戏拥有可再生生命值，但把这种节奏与躲在物体后面联系起来。现代战斗就是被射击，并在风险与休息之间交替。

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FWIvFFmu1iry71ysC3g5Q%2FLDB_Halo_Combat_BloodGulch.jpg?alt=media&amp;token=6d17a004-6b7a-4830-a25a-2a437cc036af" alt=""><figcaption><p>《光环：战斗进化》中备受喜爱的多人地图血峡谷游戏截图，由 Bungie 制作</p></figcaption></figure>

## TODO：如何制作战斗

* 白盒一个测试竞技场
  * 开放区域和 / 或三线结构
* 放置一些敌人
* 试玩测试并重复
* 怎样知道战斗已经“足够好”？

## 战斗关卡的核心概念

建立核心战斗系统之后，无论是通过游玩你正在修改的游戏，还是从零开始制作自己的战斗系统，你就可以开始设计更具体的战斗场景：

* [**敌人设计**](/process/combat/enemy.md)**是定义不同敌对 NPC 类型。**
  * 理想情况下，每种类型都有独特的行为、强项和弱点。
  * 没有多样化的敌人阵容，战斗会显得重复。
* [**遭遇战**](/process/combat/encounter.md)**是针对 NPC 的结构化战斗。**
  * 开放式战斗谜题；玩家通常必须临场发挥，找到解决方案
  * 实现通常涉及一些[脚本](/process/scripting.md)。
* [**掩体**](/process/combat/cover.md)**是制作可供战斗的空间。**
  * 哪里安全，哪里风险高？玩家可以在哪里战斗或恢复？
  * 掩体会随机制 / 武器而变化。你需要先确定核心战斗设计。
* [**地图平衡**](/process/combat/balance.md)**是玩家选项的公平性，通常用于 PvP。**
  * 玩家可以去哪里、控制哪些领地？玩家如何知道？
  * 平衡的关卡能帮助玩家信任[布局](/process/layout.md)，并投入到结果中。

我们建议按上面的顺序处理战斗。每个方面都依赖之前的方面。要制作遭遇战，首先需要敌人设计。要协调掩体，需要先了解遭遇战应该如何展开。要平衡地图，需要知道哪些掩体模式合理。

![《光环》（2001）中的敌人角色，这款早期主机 FPS 普及了动态小队战斗和载具](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FwikRGFeyppGh71QsQLHO%2FLDB_Halo1_EnemyRoster_CombatEncounter.png?alt=media\&token=002f386d-5e9b-4b60-8bc6-ead3f6f32fdd)

## 回顾要点\...

* **战斗设计**关注设计物理冲突的系统。
* 要制作战斗关卡，首先需要一款战斗游戏。但制作完整游戏很难，而这只是一本关卡设计书。制作模组更容易。
* 常见战斗系统包括：
  * **战斗机制**，例如瞄准、闪避、时机等。
  * **武器设计**，一组多样且有趣的使用工具
  * **经济系统**，关于武器、背包和成长的成本 / 收益系统
* 一些战斗示例：
  * **经典战斗**和**魂系游戏**强调速度和闪避火力
  * **军事写实**和**大逃杀**让枪械和瞄准更加重要
  * **现代战斗**和**掩体射击**关注管理生命值 / 伤害
* 制作战斗游戏的方法，（TODO）

## 接下来做什么？

* 进一步阅读战斗关卡设计的关键设计概念：
  * [敌人设计](/process/combat/enemy.md)
  * [遭遇战设计](/process/combat/encounter.md)
  * [掩体](/process/combat/cover.md)
  * [地图平衡](/process/combat/balance.md)
* 继续进入[布局](/process/layout.md)阶段。

### 战斗设计延伸阅读

* [《与命运清算：〈诸神黄昏〉规模下的战斗》（2023）（来自 YouTube）](https://www.youtube.com/watch?v=6iTBqcBv5QA)是 Rob Meyer 关于现代 AAA 战斗设计最全面的演讲。Meyer 是《战神：诸神黄昏》（2022）的首席战斗设计师，他在演讲中给出了具体工作示例，并详细介绍了 Sony Santa Monica 战斗设计师的职责。
