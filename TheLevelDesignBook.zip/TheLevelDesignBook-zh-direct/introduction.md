> 完整文档目录见 [llms.txt](https://book.leveldesignbook.com/llms.txt)。文档页面的 Markdown 版本可以通过在页面 URL 后添加 `.md` 获取；本页的 Markdown 版本见 [introduction.md](https://book.leveldesignbook.com/introduction.md)。

# 什么是关卡设计

什么是关卡、什么是关卡设计，以及如何使用本书

## 什么是关卡

<figure><img src="https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F-LtVT8pJjInrrHVCovzy%2Fuploads%2FQ6fLyf3fBmZnzHP8Qm0k%2FLDB_Halo_BloodGulch_BasketballCourt.jpg?alt=media&amp;token=50234527-5221-4178-a91a-4f99e6344f08" alt=""><figcaption>将篮球场示意图叠加在《光环 1》血峡谷全景图上的图示，作者：<a href="https://twitter.com/neilsonks/status/1658549380691968003">@neilsonks（来自 Twitter）</a></figcaption></figure>

**关卡（level）**是游戏发生的空间。例如：

* 《堡垒之夜》的岛屿，或 Roblox 中的障碍赛（“obby”）；
* 篮球场、赛车场或游乐场；
* 大富翁棋盘、填字游戏或涂色书。

所有这些游戏空间都会为玩家的移动和互动设定**边界**。

不同的关卡会带来**变化**。例如，所有篮球场的形状都大致相似，但室外球场和室内体育馆会带来不同的**体验**、**文化**和**氛围**。

关卡设计师关注的是：不同的游戏空间会让玩家产生怎样的**感受**，并做出怎样的**行为**。

## 什么是关卡设计

我们对关卡设计采取宽泛的定义，但有一个明确的限定：

**关卡设计，是规划和建造电子游戏空间的实践……**

**……通常指第一人称或第三人称动作射击游戏。**

本书对于横版平台游戏、俯视角策略游戏或非战斗游戏依然有用。但无论好坏，大多数关卡设计理论都把 3D 射击游戏当作默认媒介；这可以追溯到射击游戏盛行的 1990 年代，当时“关卡设计师”这一职业角色刚刚形成。

*关于关卡设计师这一职业角色的历史，参见* [*关卡设计师的历史*](/culture/history-level-designer.md)*。*

![《神秘海域 4》“岛屿登陆”白盒开发截图，作者：Em Schatz](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LtwoKZ58xOGNTn9g_Qy%2F-Ltwq-JcDDEN7UHH9OLR%2Funcharted4_blockout_em_schatz.jpg?alt=media\&token=fe61470c-d734-4540-ab8e-a83eb330da7d)

### 功能性关卡设计与环境美术

关卡设计师的工作重点是塑造玩家的行为。在大型工作室中，他们通常会撰写文档、绘制[布局](/process/layout.md)、制作[白盒](/process/blockout.md)、观察[试玩测试](/process/blockout/playtesting.md)，并调整地图和[遭遇战](/process/combat/encounter.md)的[平衡](/process/combat/balance.md)。

与此相对，**环境美术师**更关注画面。他们会对模型、材质、场景布置和[灯光](/process/lighting.md)进行[美术处理](/process/env-art.md)，完善关卡的视觉表现。虽然这些工作大多属于装饰，但优秀的环境美术能够支持体验设计目标，也能帮助玩家进行游戏。

因此，理解关卡设计有两种方式：

* 不包含环境美术的、首字母大写的“Level Design”，即正式的行业定义；
* 包含环境美术和关卡中一切内容的“level design”，即广义的日常用法。

出于学习目的，本书强调正式的行业定义——“Level Design”。但请始终记住，玩家接触的是包含一切内容的广义“level design”整体。

![对比“Level Design”“level design”和“environment art”的图示，使用《Dust 514》盖伦特研究设施的开发过程图](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-Maev3jxp4WpKXebg88n%2F-Maf5hE1bqDx4IO2HGuP%2FLDB_leveldesign_env-art_compare.jpg?alt=media\&token=a921482a-e5bf-42f5-83a6-78975cbc4078)

### 房间设计与世界设计

关卡设计师可能会花上几天甚至几周设计一个房间。

但对于拥有数百甚至数千个房间的大型大逃杀游戏、开放世界或 MMO 来说，反复琢磨一个房间并不现实。**世界设计师**考虑的是街区而不是房屋、生态群系而不是地点、类别而不是实例的[动线](/process/layout/flow.md)和[寻路与引导](/process/blockout/wayfinding.md)。这种概括性的做法能给玩家和系统留下呼吸空间。但如果没有玩家或系统去填充这片空间，最终的世界可能会显得空旷或平淡。

如果你要制作一个有明确引导或依靠脚本驱动的体验，就像建筑师一样仔细推敲每一个房间。

但对于玩家和系统都很多、空间也很大的游戏，世界设计更像是城市规划师的工作：施加更轻、更宽松的干预。

![《堡垒之夜》的“宜人公园”中，单栋房屋的房间布局不如街区的整体形状重要](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MPphiBNyOFqTcMnqNAF%2F-MPppJ9ZGig_wxc7cSE0%2FFortnite_PleasantPark_TopDownOverview.jpg?alt=media\&token=3fd67bec-7be1-4eb5-98f7-e0a3fbc3c6d6)

### 理论与“去做地图”

这是一本书，所以我们当然认为阅读是件好事。

但和其他艺术一样，书只能把你带入这门技艺。在某个时候，你必须合上书，去制作一些关卡。

如果你向《雷神之锤》社区的地图制作者提很多问题，他们有时会用一个直截了当的回答回应你：**“去做地图（go map）。”**这句话听起来可能有些无礼，但它的本意是鼓励你——仿佛在说：“别再拖延了，你会自己摸索出来的；现在就去试试，你已经准备好了。”

成为关卡设计师的唯一方法……就是制作关卡。理想情况下，还要制作很多关卡。

*不知道该做什么？参见我们推荐的* [*项目*](/learning/projects.md)*列表。*

{% hint style="info" %}
有时我们会用“地图（map）”而不是“关卡（level）”。地图暗示一种支持多样性的自由空间，而关卡暗示更强的脚本化引导。

但这并不是什么大问题。你可以把这两个词交替使用。
{% endhint %}

![《雷神之锤 1》模组 Arcane Dimensions 的起始大厅截图，作者：Simon “sock” O'Callaghan 等人](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MDj_ngSOdI6jitZ76zx%2F-MDjzO9IvS-gUFWrgq6l%2FArcaneDimensions.jpg?alt=media\&token=7162ef12-dc38-4cd9-8999-ab0c0869e6f2)

## 理念

本书在特定的关卡设计理想和信念下写成。

### 更清晰的理论

大多数关卡设计书要么过于学术化、概念化，要么过于商业化、简化。我们的目标是解释并拓展在职关卡设计师使用的同一套语言，同时保持足够的批判性，剔除懒惰的思考。

关卡设计师经常缺少讨论形状和体积的语言，而建筑学中的[体块（massing）](/process/blockout/massing.md)概念能带来很大帮助。我们引用外部概念时，往往没有意识到它们更深层的来源；例如，[关键路径](/process/layout/flow.md#critical-path)来自关键路径法——一种用于工程项目范围控制和依赖关系检查的工具。当我们对词语和理论的使用不够精确时，思考和沟通都会受到影响。

![建筑中使用的多种采光策略，出自 Francis Ching 的《形式、空间与秩序》](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-M0j1masUKQWiwiDGXN8%2F-M0j2-GH3OSU0m4JRUf2%2FFormSpaceAndOrder_Light_FrancisChing.png?alt=media\&token=a65a1dcf-1b00-47e4-b858-fea1a643e4d5)

### 拉远视角

虽然关卡设计师应当关注玩家行为，但有时我们必须把视角拉远，看看全局。

一个关卡是空间设计、美术、心理学、编程和文化的结合。从玩家的角度看，关卡设计与环境美术没有区别。任何会影响游戏世界的东西，都属于关卡设计。

避免被简单的“该做什么、不要做什么”诱惑。关卡不只是房间和掩体盒子的集合，也不只是撒上岩石和树木的风景。一个关卡拥有历史、文化和意图；作为负责任的设计师，我们必须考虑完整的游玩体验。

![Steve Lee 在 GDC 2017 演讲“整体关卡设计方法”中的视频截图](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LtwiHYWTP0HfTGol6GY%2F-Ltwj6_WXropnQEVl4pb%2Fan_approach_to_holistic_level_design_gdc2017.png?alt=media\&token=cffc6cf2-28f9-4247-b90d-46110d7ecbe5)

### 保持活力与自由

纸质出版物往往会让关卡设计书在几年内就过时。幸运的是，本书在线上存在。在可以预见的未来，我们会随着关卡设计中的新发展和新趋势出现，继续更新本书。别让它死掉。

本书会一直免费开放，直到服务器关闭——即使到了那时，其内容也很可能已经散布在互联网的各处，得到保存。关卡设计是整个关卡设计社区共同创造的，因此它也应当继续自由地属于这个社区。**我们永远不会给本书设置付费墙，也不会出售本书的任何副本。**

本书未注明出处的文字（以及未注明出处的图片和内容）依据宽松的知识共享 BY-NC-SA 4.0 许可证[授权](/appendix/license.md)。你不能出售本书，也不能出售本书的移植版或译本。**所有副本、译本和衍生作品都必须继续保持免费和开放访问。**

![所有未注明出处的文字和图片均依据 CC-BY-NC-SA 4.0 获得授权](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-LtfRE6vMa7dIv6OW2I1%2F-Ltf_CKhdLuJKGDXZ0IR%2Fcreative_commons_BY-NC-SA_4.png?alt=media\&token=67bdaaa2-ed85-4dc1-8933-9e00c1193c91)

## 如何使用本书

本书由四个部分组成：

[**流程（Process）**](/process/overview.md)详细介绍关卡设计的核心概念。对于需要学习关卡设计工作流程和语言的初学者与学生来说，这是必读部分。大多数读者都应该从这里开始。

[**文化（Culture）**](/culture/overview.md)从不同角度讨论关卡设计趋势，并简要介绍建筑、灯光以及其他与关卡设计相邻的工艺的历史。

[**研究（Studies）**](/studies/overview.md)分析并拆解特定关卡的运作方式，并配有图示和截图。

[**项目（Projects）**](/learning/projects.md)是面向学生和爱好者的自学教程与项目创意。教师应查看[给教育者的笔记](/learning/notes.md)。

此外，本书还有附录，其中包括推荐软件和游戏引擎的[**工具**](/appendix/tools.md)列表，以及其他关卡设计[**资产与资源**](/appendix/resources.md)的链接（免费模型和纹理、其他关卡设计书籍的推荐等）。最后，我们强烈建议加入关卡设计[**社区**](/appendix/communities.md)，因为书不会回应你的爱。

![ustwo Games 为 Alba 制作的早期开放世界白盒编辑器截图，图片作者：Jessie Van Aelst](https://1666186240-files.gitbook.io/~/files/v0/b/gitbook-legacy-files/o/assets%2F-LtVT8pJjInrrHVCovzy%2F-MeE6S6RE84hTY0E4Lwf%2F-MeEBQvgO3g54xMOuO9K%2FLDB_Alba_Blockout2019_Jesse_UsTwo.jpg?alt=media\&token=c5e8dc22-5eef-44a8-bf25-44c3f605047f)

## 接下来做什么？

* **初学者：**先大致了解[流程](/process/overview.md)，尤其是[前期设计](/process/preproduction.md)、[布局](/process/layout.md)和[白盒](/process/blockout.md)。然后选择一个[工具](/appendix/tools.md)，加入关卡设计[社区](/appendix/communities.md)，并*去做地图*。
* **有一些经验：**阅读[节奏](/process/preproduction/pacing.md)、[动线](/process/layout/flow.md)、[平衡](/process/combat/balance.md)、[体块](/process/blockout/massing.md)、[尺度规范](/process/blockout/metrics.md)和[灯光](/process/lighting.md)等具体主题；这些主题在大多数在线关卡设计教程中通常会被忽略。
  * 我们也明确反对[“视觉引导线”](/process/blockout/massing/composition.md)，并反对[形状心理学/色彩心理学](/process/env-art/psychology.md)，因为我们认为这些理论具有误导性、效果有限，或者对关卡设计师的用途有限。
* **经验非常丰富：**阅读我们的批判性关卡设计[研究](/studies/overview.md)，甚至可以贡献一些你自己的研究。
